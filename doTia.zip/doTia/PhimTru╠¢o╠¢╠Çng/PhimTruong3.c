#include "PhimTruong3.h"
#include "../DocThamSo.h"
#include "../Toán/BienHoa.h"
//#include "../Mau.h"
#include <stdlib.h>

#pragma mark ---- PHIM TRƯỜNG 3
void chuanBiMayQuayPhimVaMatTroiPhimTruong3( PhimTruong *phimTruong );
unsigned short vatTheThu( VatThe *danhSachVat );

void nangCapPhimTruong3_nhanVat( PhimTruong *phimTruong );


PhimTruong datPhimTruongSo3( unsigned int argc, char **argv ) {
   
   PhimTruong phimTruong;
   phimTruong.soNhoiToiDa = 5;
   
   unsigned int soHoatHinhDau = 0;
   unsigned int soHoatHinhCuoi = 100;     // số bức ảnh cuối cho phim trường này
   
   docThamSoHoatHinh( argc, argv, &soHoatHinhDau, &soHoatHinhCuoi );
   if( soHoatHinhDau > 99 )
      soHoatHinhDau = 99;
   if( soHoatHinhCuoi > 100 )     // số bức ảnh cuối cho phim trường này
      soHoatHinhCuoi = 100;
   
   phimTruong.soHoatHinhDau = soHoatHinhDau;
   phimTruong.soHoatHinhHienTai = soHoatHinhDau;
   phimTruong.soHoatHinhCuoi = soHoatHinhCuoi;
   
   phimTruong.soLuongVatThe = 0;
   phimTruong.danhSachVatThe = malloc( kSO_LUONG_VAT_THE_TOI_DA*sizeof(VatThe) );
   
   // ---- chuẩn bị máy quay phim
   chuanBiMayQuayPhimVaMatTroiPhimTruong3( &phimTruong );
   Mau mauDinhTroi;
   mauDinhTroi.d = 0.0f;   mauDinhTroi.l = 0.0f;   mauDinhTroi.x = 0.5f;   mauDinhTroi.dd = 1.0f;
   Mau mauChanTroi;  // chỉ có một;
   mauChanTroi.d = 0.7f;  mauChanTroi.l = 0.7f;   mauChanTroi.x = 1.0f;    mauChanTroi.dd = 1.0f;
   phimTruong.hoaTietBauTroi = datHoaTietBauTroi( &mauDinhTroi, &mauChanTroi, &mauChanTroi, 0.0f );
   
   VatThe *danhSachVat = phimTruong.danhSachVatThe;
   
   // ----
   phimTruong.soLuongVatThe += vatTheThu( &(danhSachVat[phimTruong.soLuongVatThe]) );
   
   return phimTruong;
}

void chuanBiMayQuayPhimVaMatTroiPhimTruong3( PhimTruong *phimTruong ) {
   
   // ==== máy quay phim
   phimTruong->mayQuayPhim.kieuChieu = kKIEU_CHIEU__TOAN_CANH;
   // ---- vị trí bắt đầu cho máy quay phim
   phimTruong->mayQuayPhim.viTri.x = 0.0f;
   phimTruong->mayQuayPhim.viTri.y = 0.0f;
   phimTruong->mayQuayPhim.viTri.z = 5.0f;
   phimTruong->mayQuayPhim.cachManChieu = 5.0f;
   Vecto trucQuayMayQuayPhim;
   trucQuayMayQuayPhim.x = 0.0f;
   trucQuayMayQuayPhim.y = 1.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, 3.14159f );
   trucQuayMayQuayPhim.x = 1.0f;
   trucQuayMayQuayPhim.y = 0.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   Quaternion quaternion1 = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, -0.0f );
   Quaternion quaternionKetQua = nhanQuaternionVoiQuaternion( &quaternion, &quaternion1 );
   phimTruong->mayQuayPhim.quaternion = quaternionKetQua;
   
   quaternionSangMaTran( &(phimTruong->mayQuayPhim.quaternion), phimTruong->mayQuayPhim.xoay );
   
   // ---- mặt trời
   Vecto anhSangMatTroi;
   anhSangMatTroi.x = -1.0f;
   anhSangMatTroi.y = -1.0f;
   anhSangMatTroi.z = 0.0f;
   donViHoa( &anhSangMatTroi );
   phimTruong->matTroi.huongAnh = anhSangMatTroi;
   phimTruong->matTroi.mauAnh.d = 1.0f;
   phimTruong->matTroi.mauAnh.l = 1.0f;
   phimTruong->matTroi.mauAnh.x = 1.0f;
   phimTruong->matTroi.mauAnh.dd = 1.0f;
}

unsigned short vatTheThu( VatThe *danhSachVat ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;   Mau mau1;
   Vecto viTri;
   
   // ----
   mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.0f;    mau.dd = 1.0f;    mau.p = 0.3f;
   mau1.d = 1.0f;   mau1.l = 0.0f;   mau1.x = 0.0f;    mau1.dd = 1.0f;    mau1.p = 0.3f;
   
   Mau mauNen;
   Mau mauThap;
   Mau mauCao;
   mauNen.d = 1.0f;
   mauNen.l = 1.0f;
   mauNen.x = 1.0f;
   mauNen.dd = 1.0f;
   mauNen.p = 0.0f;
   mauThap.d = 1.0f;
   mauThap.l = 0.0f;
   mauThap.x = 0.1f;
   mauThap.dd = 1.0f;
   mauThap.p = 0.0f;
   mauCao.d = 1.0f;   mauCao.l = 1.0f;    mauCao.x = 1.0f;   mauCao.dd = 1.0f;   mauCao.p = 0.0f;
   Mau mauOc0;
   Mau mauOc1;
   Mau mauOc2;
   mauOc0.d = 0.0f;     mauOc0.l = 0.3f;      mauOc0.x = 1.0f;     mauOc0.dd = 1.0f;    mauOc0.p = 0.0f;
   mauOc1.d = 0.2f;     mauOc1.l = 0.65f;      mauOc1.x = 1.0f;     mauOc1.dd = 1.0f;    mauOc1.p = 0.0f;
   mauOc2.d = 0.65f;     mauOc2.l = 1.0f;      mauOc2.x = 1.0f;     mauOc2.dd = 1.0f;    mauOc2.p = 0.0f;
   
   Vecto huongDoc;
   huongDoc.x = 0.0f;   huongDoc.y = 1.0f;   huongDoc.z = 0.0f;
   Vecto huongNgang;
   huongNgang.x = 1.0f;   huongNgang.y = 0.0f;   huongNgang.z = 0.0f;
   unsigned char soLuongVat = 0;
 
/*
   viTri.x = 2.0f;    viTri.y = -2.2f;    viTri.z = 0.0f;
   danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 4.2f, 1.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mau, &mauOc0, &mauOc1, &mauOc2, 0.1667f, 0.5f, 0.5f, 5.0f, 5.0f, 0.2f, 0.0f, 1.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   soLuongVat++;

   //   viTri.x = 3.0f;    viTri.y = 0.0f;     viTri.z = 0.0f;
   //   hoaTietHaiChamBi( &viTri, &(danhSachVat[0].hoaTiet.hoaTietHaiChamBi) );
   mauNen.p = 0.0f;   mauOc0.p = 0.0f;
   viTri.x = -5.0f;    viTri.y = -3.5f;    viTri.z = 1.0f;
   mauNen.dd = 1.0f;    mauOc0.dd = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hinhLangTru = datHinhLangTru( 2.0f, 0.5f, 6, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_LANG_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong(&mauOc0, &mauNen );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__DI_HUONG;
   soLuongVat++;
   
   viTri.y += 0.5f;
   danhSachVat[soLuongVat].hinhDang.hinhChop = datHinhChop( 2.0f, 1.5f, 0.5f, 6, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_CHOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong(&mauOc0, &mauNen );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__DI_HUONG;
   soLuongVat++;
   
   viTri.y = 1.5f;
   danhSachVat[soLuongVat].hinhDang.hinhLangTru = datHinhLangTru( 2.0f, 0.5f, 6, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_LANG_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong(&mauOc0, &mauNen );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__DI_HUONG;
   soLuongVat++;
   
   viTri.y += 0.5f;
   danhSachVat[soLuongVat].hinhDang.hinhChop = datHinhChop( 2.0f, 1.5f, 0.5f, 6, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_CHOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong(&mauOc0, &mauNen );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__DI_HUONG;
   soLuongVat++; */

   
   // ---- đặt mặt hyperbol
   // (x-x_0)^2 + (z-z_0)^2 = R^2 + B*(y-y_0)^2    = 2 + 1.2*9
   mauNen.d = 0.8f;   mauNen.l = 0.0f;   mauNen.x = 1.0f;
   viTri.x = 0.0f;    viTri.y = 0.2f;    viTri.z = 0.0f;
   danhSachVat[soLuongVat].hinhDang.matHyperbol = datMatHyperbol( 2.0f, 1.2f, 6.0f, kDUNG,
                                                                 &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_HYPERBOL;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
   danhSachVat[soLuongVat].soHoatHinh = 0;
   soLuongVat++;
   
   return soLuongVat;
}

#pragma mark ---- NÂNG CẤP PHIM TRƯỜNG 3
void nangCapPhimTruong3( PhimTruong *phimTruong ) {
   
   //   printf( "phimTruong->soHoatHinhDau; %d\n", phimTruong->soHoatHinhDau );
   //   nangCapPhimTruong0_mayQuayPhim( phimTruong );
   nangCapPhimTruong3_nhanVat( phimTruong );

   
   // ---- tăng số hoạt hình
   phimTruong->soHoatHinhDau++;
}

void nangCapPhimTruong3_nhanVat( PhimTruong *phimTruong ) {
   
   VatThe *danhSachVat = phimTruong->danhSachVatThe;
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;    trucXoay.y = 1.0f;     trucXoay.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   unsigned short soMatHyperbol = 0;
   unsigned short soHoatHinh = danhSachVat[soMatHyperbol].soHoatHinh;
   if( soHoatHinh < 20 ) {
      danhSachVat[soMatHyperbol].hinhDang.matHyperbol.banKinhBinh += 0.2f;
      danhSachVat[soMatHyperbol].soHoatHinh++;
   }
   else if( soHoatHinh < 40 ) {
      danhSachVat[soMatHyperbol].hinhDang.matHyperbol.banKinhBinh -= 0.2f;
      danhSachVat[soMatHyperbol].soHoatHinh++;
   }
   
   if( soHoatHinh == 40 )
      danhSachVat[soMatHyperbol].soHoatHinh = 0;
   
   // ---- tính lại hợp bao bì
   tinhBaoBiMatHyperbol( &(danhSachVat[soMatHyperbol].hinhDang.matHyperbol), &(danhSachVat[soHoatHinh].baoBiVT) );
   soMatHyperbol++;
   
   danhSachVat[soMatHyperbol].soHoatHinh++;
}
