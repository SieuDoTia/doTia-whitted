#include "PhimTruong.h"

PhimTruong datPhimTruongSo1( unsigned int argc, char **argv );
void nangCapPhimTruong1( PhimTruong *phimTruong );