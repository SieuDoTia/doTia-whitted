#include "PhimTruong.h"

PhimTruong datPhimTruongSo0( unsigned int argc, char **argv );
void nangCapPhimTruong0( PhimTruong *phimTruong );