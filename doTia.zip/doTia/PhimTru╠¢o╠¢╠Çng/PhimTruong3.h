#include "PhimTruong.h"

PhimTruong datPhimTruongSo3( unsigned int argc, char **argv );
void nangCapPhimTruong3( PhimTruong *phimTruong );