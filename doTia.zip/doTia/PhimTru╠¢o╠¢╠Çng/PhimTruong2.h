#include "PhimTruong.h"

PhimTruong datPhimTruongSo2( unsigned int argc, char **argv );
void nangCapPhimTruong2( PhimTruong *phimTruong );