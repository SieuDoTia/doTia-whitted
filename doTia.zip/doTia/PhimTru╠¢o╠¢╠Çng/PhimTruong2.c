#include "PhimTruong2.h"
#include "../HangSo.h"
#include "../NhanVat.h"
#include "../Toán/BienHoa.h"
#include "../XemCắt/TinhBaoBi.h"
#include "../DocThamSo.h"
#include "../Toán/Bezier.h"
#include "../Toán/Vecto.h"
#include <stdlib.h>

#pragma mark ---- PHIM TRƯỜNG 2
#define kNHAN_VAT__VAI_CHANH           0       // nhân vật vai chánh
#define kNHAN_VAT__SAO_GAI_XANH        1       // sao gai xanh
#define kNHAN_VAT__KIEN_LONG_SAO_GAI_XANH 2    // kiến lồng sao gai xanh
#define kNHAN_VAT__MAT_HO_DAU          3       // mặt hồ đầu
#define kNHAN_VAT__MAT_HO_CUOI         4       // mặt hồ cuối
#define kNHAN_VAT__HINH_XUYEN_KHONG_LO_0    5  // hình xuyên khổng lộ 0
#define kNHAN_VAT__HINH_XUYEN_KHONG_LO_1    6  // hình xuyên khổng lộ 1
#define kNHAN_VAT__HINH_XUYEN_KHONG_LO_2    7  // hình xuyên khổng lộ 2 -- chưa làm
#define kNHAN_VAT__HINH_XUYEN_TRUNG_BINH_0  8  // hình xuyên khổng lộ 0

#define kNHAN_VAT__RUNG_MAT_HYPERBOL_DAU    10       // hyperbol đầu
#define kNHAN_VAT__RUNG_MAT_HYPERBOL_CUOI   11      // hyperbol cuối
#define kNHAN_VAT__LOC_XOAY_0          12      // lốc xoay 0 (thả trái banh vai chánh)
#define kNHAN_VAT__LOC_XOAY_1          13      // lốc xoay 1
#define kNHAN_VAT__LOC_XOAY_2          14      // lốc xoay 2 -- chưa làm

#define kNHAN_VAT__VAT_THE_DONG_SONG_DAU   15
#define kNHAN_VAT__VAT_THE_DONG_SONG_CUOI  16

#define kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY  300   // số lượng hạt bay trong lốc xoay

#define kLOC_XOAY__GOC_XOAN 0.25f
#define kLOC_XOAY__CACH_CAO 1.0f

#define kLOC_XOAY__VAN_TOC_X  0.5f    // vận tốc lốc xoay
#define kLOC_XOAY__VAN_TOC_Z -0.5f


void chuanBiMayQuayPhimVaMatTroiPhimTruong2( PhimTruong *phimTruong );
unsigned short datMatDatPhimTruongSo2( VatThe *danhSachVat ); /* Đăt Mặt Đất Phim Trương Số 2 */
unsigned short datThapNui( VatThe *danhSachVat, Vecto diem );   /* Tháp Núi */
unsigned short datMatCacHoNuocThapNui( VatThe *danhSachVat, Vecto viTriDayThap );   /* Mặt Các Hồ Nước */
unsigned short datRungHinhNonThuyTinh( VatThe *danhSachVat, float doCaoMatDat );  /* rừng hình nón thủy tinh */
unsigned short datDanHinhTru( VatThe *danhSachVat, Vecto viTri );            /* đặt đàn hình trụ */
unsigned short datHinhXuyenKhongLo( VatThe *danhSachVat, Vecto viTriDayThap );   /* Hình Xuyên Khổng Lộ */
unsigned short datHinhXuyenTrungBinh( VatThe *danhSachVat, Vecto viTriDayThap );   /* Hình Xuyên Trung Bình */
unsigned short datRungMatHyperbol( VatThe *danhSachVat, float doCaoMatDat, float viTriX, float viTriZ );   /* Rừng Mặt Hyperbol */
unsigned short datLocXoayPhai( VatThe *danhSachVat, Vecto viTriDay );     /* Đặt Lốc Xoay Phai Màu */
unsigned short datLongSaoGaiXanh( VatThe *danhSachVat, Vecto viTriDay );  /* Đăt Lồng Sao Gai Xanh */
unsigned short datKienLongSaoGaiXanh( VatThe *danhSachVat, Vecto viTriDayLong );      /* Đặt Liến Lồng Sao Gai Xanh */
unsigned short datDongSong( VatThe *danhSachVat );
unsigned short datThapHinhTruCau( VatThe *danhSachVat, Vecto viTriDayThap );
unsigned short datNuiParabolSoc( VatThe *danhSachVat, float doCaoMatDat );
unsigned short datNuiHinhNon( VatThe *danhSachVat, float doCaoMatDat );
unsigned short datCauThuyTinh( VatThe *danhSachVat, float doCaoMatDat );

void nangCapPhimTruong2_mayQuayPhim( PhimTruong *phimTruong );
void nangCapPhimTruong2_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh );
void nangCapVaiChanh_PT_2( VatThe *vaiChanh, unsigned short soHoatHinh );
void nangCapOc( VatThe *VatThe, unsigned short soHoatHinh );
void nangCapMatCacHo( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh );
void nangCapHinhXuyenXoay( VatThe *hinhXuyenXoay, unsigned short soHoatHinh, float vanTocXoay, unsigned char huongXoay );
void nangCapRungMatHyperbol( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh );
void nangCapLocXoayPhai( VatThe *danhSachVat, unsigned short soHoatHinh );
void nangCapKienLongSaoGaiXanh( VatThe *kienLongSaoGai, unsigned short soHoatHinh );
void nangCapDongSong( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh );


PhimTruong datPhimTruongSo2( unsigned int argc, char **argv ) {
   
   PhimTruong phimTruong;
   phimTruong.soNhoiToiDa = 5;
   
   unsigned int soHoatHinhDau = 0;
   unsigned int soHoatHinhCuoi = 1000;     // số bức ảnh cuối cho phim trường này
   
   docThamSoHoatHinh( argc, argv, &soHoatHinhDau, &soHoatHinhCuoi );
   if( soHoatHinhDau > 1999 )
      soHoatHinhDau = 1999;
   if( soHoatHinhCuoi > 3000 )     // số bức ảnh cuối cho phim trường này
      soHoatHinhCuoi = 3000;
   
   phimTruong.soHoatHinhDau = soHoatHinhDau;
   phimTruong.soHoatHinhHienTai = soHoatHinhDau;
   phimTruong.soHoatHinhCuoi = soHoatHinhCuoi;
   
   phimTruong.soLuongVatThe = 0;
   phimTruong.danhSachVatThe = malloc( kSO_LUONG_VAT_THE_TOI_DA*sizeof(VatThe) );
   
   // ---- chuẩn bị máy quay phim
   chuanBiMayQuayPhimVaMatTroiPhimTruong2( &phimTruong );
   Mau mauDinhTroi;
   mauDinhTroi.d = 0.8f;   mauDinhTroi.l = 0.5f;   mauDinhTroi.x = 0.0f;   mauDinhTroi.dd = 1.0f;
   Mau mauChanTroi;  // chỉ có một;
   mauChanTroi.d = 1.0f;  mauChanTroi.l = 1.0f;   mauChanTroi.x = 0.7f;    mauChanTroi.dd = 1.0f;
   phimTruong.hoaTietBauTroi = datHoaTietBauTroi( &mauDinhTroi, &mauChanTroi, &mauChanTroi, 0.0f );
   
   VatThe *danhSachVat = phimTruong.danhSachVatThe;
   
   // ---- tháp núi
   phimTruong.soLuongVatThe = datMatDatPhimTruongSo2( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- vị trí đấy cho tháp 0
   Vecto viTriDayThap0;
   viTriDayThap0.x = 100.0f;   viTriDayThap0.y = 20.0f;    viTriDayThap0.z = 90.0f;
   // ---- vị trí đấy cho tháp 1
   Vecto viTriDayThap1;
   viTriDayThap1.x = 255.0f;   viTriDayThap1.y = 32.0f;    viTriDayThap1.z = 0.0f;
   // ---- vị trí đấy cho tháp 2
   Vecto viTriDayThap2;  // vị trí đấy cho tháp 2
   viTriDayThap2.x = 0.0f;   viTriDayThap2.y = 20.0f;    viTriDayThap2.z = 200.0f;
   
   phimTruong.soLuongVatThe += datThapNui( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDayThap0 );
   phimTruong.soLuongVatThe += datThapNui( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDayThap1 );
   phimTruong.soLuongVatThe += datThapNui( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDayThap2 );
   
   phimTruong.soLuongVatThe += datNuiParabolSoc( &(danhSachVat[phimTruong.soLuongVatThe]), 20.0f );
   phimTruong.soLuongVatThe += datNuiHinhNon( &(danhSachVat[phimTruong.soLuongVatThe]), 20.0f );
   
   // ---- rừng hình nón thủy tinh
   phimTruong.soLuongVatThe += datRungHinhNonThuyTinh( &(danhSachVat[phimTruong.soLuongVatThe]), 20.0f );
   
   // ---- đàn hình trụ
   Vecto viTriDanHinhTru;
   viTriDanHinhTru.x = 400.0f;  viTriDanHinhTru.y = 30.0f; viTriDanHinhTru.z = 500.0f;
   phimTruong.soLuongVatThe += datDanHinhTru( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDanHinhTru );
   viTriDanHinhTru.x = -80.0f;  viTriDanHinhTru.y = 25.0f; viTriDanHinhTru.z = 0.0f;
   phimTruong.soLuongVatThe += datDanHinhTru( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDanHinhTru );
   
   // ---- cầu thủy tinh
   phimTruong.soLuongVatThe += datCauThuyTinh( &(danhSachVat[phimTruong.soLuongVatThe]), 20.0f );
   
   // ---- hình xuyên khổng lộ
   Vecto viTriHinhXuyen;
   viTriHinhXuyen.x = 170.0f;   viTriHinhXuyen.y = 20.0f;    viTriHinhXuyen.z = 160.0f;
   phimTruong.nhanVat[kNHAN_VAT__HINH_XUYEN_KHONG_LO_0] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datHinhXuyenKhongLo( &(danhSachVat[phimTruong.soLuongVatThe]), viTriHinhXuyen );
   phimTruong.nhanVat[kNHAN_VAT__HINH_XUYEN_TRUNG_BINH_0] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datHinhXuyenTrungBinh( &(danhSachVat[phimTruong.soLuongVatThe]), viTriHinhXuyen );
   viTriHinhXuyen.x = 30.0f;   viTriHinhXuyen.y = 20.0f;    viTriHinhXuyen.z = 260.0f;
   phimTruong.nhanVat[kNHAN_VAT__HINH_XUYEN_KHONG_LO_1] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datHinhXuyenKhongLo( &(danhSachVat[phimTruong.soLuongVatThe]), viTriHinhXuyen );
   
   // ---- lồng sai gai xanh
   Vecto viTriHinhNon;
   viTriHinhNon.x = 295.0f;    viTriHinhNon.y = 20.0f;    viTriHinhNon.z = -105.0f;
   phimTruong.soLuongVatThe += datThapHinhTruCau( &(danhSachVat[phimTruong.soLuongVatThe]), viTriHinhNon );

   viTriHinhNon.z = -400.0f;
   phimTruong.soLuongVatThe += datThapHinhTruCau( &(danhSachVat[phimTruong.soLuongVatThe]), viTriHinhNon );

   // ---- lồng sai gai xanh
   Vecto viTriLongSaoGaiXanh;
   viTriLongSaoGaiXanh.x = 30.0f;     viTriLongSaoGaiXanh.y = 20.0f;    viTriLongSaoGaiXanh.z = -420.0f;
   phimTruong.soLuongVatThe += datLongSaoGaiXanh( &(danhSachVat[phimTruong.soLuongVatThe]), viTriLongSaoGaiXanh );
   
   // ---- lồng kiến lồng sao gai xanh
   phimTruong.nhanVat[kNHAN_VAT__KIEN_LONG_SAO_GAI_XANH] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datKienLongSaoGaiXanh( &(danhSachVat[phimTruong.soLuongVatThe]), viTriLongSaoGaiXanh );
   
   // ---- VAI CHÁNH
   Vecto viTriDauVaiChanh;  // vị trí đầu vai chanh (thật theo lốc xoay 0)
   viTriDauVaiChanh.x = 3.0f;   viTriDauVaiChanh.y = 20.0f + 0.7f;     viTriDauVaiChanh.z = 120.0f;  // 0.7 là bán kính vai chánh
   phimTruong.nhanVat[kNHAN_VAT__VAI_CHANH] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datVaiChanh( &(danhSachVat[phimTruong.soLuongVatThe]) , viTriDauVaiChanh );
   
   // ---- mặt hồ nước
   phimTruong.nhanVat[kNHAN_VAT__MAT_HO_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datMatCacHoNuocThapNui( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDayThap0 );
   phimTruong.soLuongVatThe += datMatCacHoNuocThapNui( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDayThap1 );
   phimTruong.soLuongVatThe += datMatCacHoNuocThapNui( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDayThap2 );
   phimTruong.nhanVat[kNHAN_VAT__MAT_HO_CUOI] = phimTruong.soLuongVatThe;
   
   // ----- SAO GAI XANH
   Vecto viTriSaoGaiXanh;
   viTriSaoGaiXanh.x = 30.0f;   viTriSaoGaiXanh.y = 21.7f + kSAO_GAI__BAN_KINH*1.4f;     viTriSaoGaiXanh.z = -420.0f;
   phimTruong.nhanVat[kNHAN_VAT__SAO_GAI_XANH] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datKeThuSaoGaiXanh( &(danhSachVat[phimTruong.soLuongVatThe]), viTriSaoGaiXanh );
   
   // ---- rừng hyperbol
   Vecto viTriRungHyperbol;
   phimTruong.nhanVat[kNHAN_VAT__RUNG_MAT_HYPERBOL_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datRungMatHyperbol( &(danhSachVat[phimTruong.soLuongVatThe]),  20.0f, 35.0f, -55.0f ); //20.0f, 0.0f, -100.0f );
   phimTruong.nhanVat[kNHAN_VAT__RUNG_MAT_HYPERBOL_CUOI] = phimTruong.soLuongVatThe;

   // ---- lốc xoay 0 (thả tái banh vai chánh)
   Vecto viTriLocXoay;
   viTriLocXoay.x = -60.0f;   viTriLocXoay.y = 21.0f;     viTriLocXoay.z = 340.0f;
   phimTruong.nhanVat[kNHAN_VAT__LOC_XOAY_0] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datLocXoayPhai( &(danhSachVat[phimTruong.soLuongVatThe]), viTriLocXoay );
   
   // ---- lốc xoay 1
   viTriLocXoay.x = 125.0f;   viTriLocXoay.y = 21.0f;     viTriLocXoay.z = 155.0f;
   phimTruong.nhanVat[kNHAN_VAT__LOC_XOAY_1] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datLocXoayPhai( &(danhSachVat[phimTruong.soLuongVatThe]), viTriLocXoay );
   
   // ---- dòng song
   phimTruong.nhanVat[kNHAN_VAT__VAT_THE_DONG_SONG_DAU] = phimTruong.soLuongVatThe;
   
   phimTruong.soLuongVatThe += datDongSong( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.nhanVat[kNHAN_VAT__VAT_THE_DONG_SONG_CUOI] = phimTruong.soLuongVatThe;
   
   // ---- nâng cấp mô phỏng cho các trái banh và nhân vật
   unsigned short soHoatHinh = 0;
   while ( soHoatHinh < phimTruong.soHoatHinhDau ) {
      nangCapPhimTruong2_nhanVat( &phimTruong, soHoatHinh );
      soHoatHinh++;
   }
   
   return phimTruong;
}

void chuanBiMayQuayPhimVaMatTroiPhimTruong2( PhimTruong *phimTruong ) {
   
   // ==== máy quay phim
   phimTruong->mayQuayPhim.kieuChieu = kKIEU_CHIEU__PHOI_CANH;
   // ---- vị trí bắt đầu cho máy quay phim
   phimTruong->mayQuayPhim.viTri.x = 100.0f;
   phimTruong->mayQuayPhim.viTri.y = 100.0f;
   phimTruong->mayQuayPhim.viTri.z = 150.0f;
   phimTruong->mayQuayPhim.cachManChieu = 5.0f;
   Vecto trucQuayMayQuayPhim;
   trucQuayMayQuayPhim.x = 0.0f;
   trucQuayMayQuayPhim.y = 1.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, 3.75f );
   trucQuayMayQuayPhim.x = 1.0f;
   trucQuayMayQuayPhim.y = 0.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   Quaternion quaternion1 = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, -0.4f );
   Quaternion quaternionKetQua = nhanQuaternionVoiQuaternion( &quaternion, &quaternion1 );
   phimTruong->mayQuayPhim.quaternion = quaternionKetQua;
   
   quaternionSangMaTran( &(phimTruong->mayQuayPhim.quaternion), phimTruong->mayQuayPhim.xoay );
   
   // ---- mặt trời
   Vecto anhSangMatTroi;
   anhSangMatTroi.x = -0.5f;
   anhSangMatTroi.y = -0.2f;
   anhSangMatTroi.z = 1.0f;
   donViHoa( &anhSangMatTroi );
   phimTruong->matTroi.huongAnh = anhSangMatTroi;
   phimTruong->matTroi.mauAnh.d = 1.0f;
   phimTruong->matTroi.mauAnh.l = 1.0f;
   phimTruong->matTroi.mauAnh.x = 1.0f;
   phimTruong->matTroi.mauAnh.dd = 1.0f;
}

unsigned short datMatDatPhimTruongSo2( VatThe *danhSachVat ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   unsigned short soLuongVat = 0;
   
   Mau mau0;   Mau mau1;
   Vecto viTri;
   
   // ----
   mau0.d = 1.0f;   mau0.l = 1.0f;   mau0.x = 1.0f;    mau0.dd = 1.0f;    mau0.p = 0.0f;
   mau1.d = 1.0f;   mau1.l = 0.8f;   mau1.x = 0.5f;    mau1.dd = 1.0f;    mau1.p = 0.0f;
   
   // ---- các miến đất to
   viTri.x = -1200.0f;    viTri.y = -30.0f;     viTri.z = 100.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 3100.0f, 100.0f, 500.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRoSong = datHoaTietCaRoSong( &mau0, &mau1, 10.0f, 11.0f, 10.0f, 1.0f, 0.314159f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO_SONG;
   soLuongVat++;
   
   viTri.x = -1200.0f;   viTri.z = -1900.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 3100.0f, 100.0f, 3100.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRoSong = datHoaTietCaRoSong( &mau0, &mau1, 10.0f, 11.0f, 10.0f, 1.0f, 0.314159f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO_SONG;
   soLuongVat++;

   viTri.x = -1190.0f;   viTri.y = -45.0f;   viTri.z = -250.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 3100.0f, 75.0f, 500.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRoSong = datHoaTietCaRoSong( &mau0, &mau1, 10.0f, 11.0f, 10.0f, 1.0f, 0.314159f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO_SONG;
   soLuongVat++;
   
   // ----- chi tiết đất bên +x
   viTri.x = 255.0f;    viTri.y = 16.0f;     viTri.z = 0.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 100.0f, 32.0f, 100.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRoSong = datHoaTietCaRoSong( &mau0, &mau1, 10.0f, 11.0f, 10.0f, 1.0f, 0.314159f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO_SONG;
   soLuongVat++;
   
   viTri.x = 290.0f;    viTri.y = 12.0f;     viTri.z = 120.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 100.0f, 24.0f, 150.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRoSong = datHoaTietCaRoSong( &mau0, &mau1, 10.0f, 11.0f, 10.0f, 1.0f, 0.314159f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO_SONG;
   soLuongVat++;
   
   return soLuongVat;
}

unsigned short datThapNui( VatThe *danhSachVat, Vecto viTriDayThap ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   Vecto viTri = viTriDayThap;
   unsigned char soLuongVat = 0;
   
   Mau mau0;   Mau mau1;   Mau mau2;  // Mau mau3;
   Mau mauNuoc;
   
   // ----
   mau0.d = 0.15f;   mau0.l = 0.08f;   mau0.x = 0.0f;    mau0.dd = 1.0f;    mau0.p = 0.0f;
   mau1.d = 1.0f;   mau1.l = 0.7f;   mau1.x = 0.15f;    mau1.dd = 1.0f;    mau1.p = 0.0f;
   mau2.d = 0.85f;   mau2.l = 0.5f;   mau2.x = 0.0f;    mau2.dd = 1.0f;    mau2.p = 0.0f;
   mauNuoc.d = 0.3f;   mauNuoc.l = 0.3f;   mauNuoc.x = 0.3f;  mauNuoc.dd = 1.0f;  mauNuoc.p = 0.5f;
   
   Vecto trucSoc;
   trucSoc.x = 0.0f;    trucSoc.y = 1.0f;    trucSoc.z = 0.0f;

   viTri.y += 22.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 39.0f, 43.999f, 39.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietSoc = datHoaTietSoc( &mau1, &mau0, 4.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__SOC;
   soLuongVat++;
   
   // ---- các hình trụ ló ra mặt
   viTri.y = 20.0f + viTriDayThap.y;   viTri.x -= 5.0f;
   danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 19.0f, 39.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietSoc = datHoaTietSoc( &mau0, &mau1, 4.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__SOC;
   soLuongVat++;
   
   viTri.x += 10.0f;
   danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 19.0f, 39.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietSoc = datHoaTietSoc( &mau0, &mau1, 4.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__SOC;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x;  viTri.z -= 5.0f;
   danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 19.0f, 39.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietSoc = datHoaTietSoc( &mau0, &mau1, 4.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__SOC;
   soLuongVat++;
   
   viTri.z += 10.0f;
   danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 19.0f, 39.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietSoc = datHoaTietSoc( &mau0, &mau1, 4.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__SOC;
   soLuongVat++;
   
   // ---- hình nón trên các hình trụ
   viTri.x -= 5.0f;   viTri.y = 41.0f + viTriDayThap.y;   viTri.z = viTriDayThap.z;
   danhSachVat[soLuongVat].hinhDang.hinhNon = datHinhNon( 18.0f, 17.0f, 1.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x += 10.0f;
   danhSachVat[soLuongVat].hinhDang.hinhNon = datHinhNon( 18.0f, 17.0f, 1.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x;  viTri.z -= 5.0f;
   danhSachVat[soLuongVat].hinhDang.hinhNon = datHinhNon( 18.0f, 17.0f, 1.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.z += 10.0f;
   danhSachVat[soLuongVat].hinhDang.hinhNon = datHinhNon( 18.0f, 17.0f, 1.999f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   // ---- hình trụ mỏng trên hình hộp
   viTri.y = viTriDayThap.y + 43.0f;
   viTri.z = viTriDayThap.z;
   danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 21.0f, 2.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.y = viTriDayThap.y + 44.5f;
   viTri.z = viTriDayThap.z;
   danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 21.0f, 1.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau2 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   // ---- nắp
   viTri.y = viTriDayThap.y + 46.0f;
   viTri.z = viTriDayThap.z;
   // ---- vật thể bool
   danhSachVat[soLuongVat].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[soLuongVat].mucDichBool = 1;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   
   danhSachVat[soLuongVat].soLuongVatThe = 2;
   danhSachVat[soLuongVat].danhSachVatThe = malloc( 2*sizeof(VatThe) );
   
   // vị trí tương đối
   Vecto viTriTuongDoi;
   viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.0f;        viTriTuongDoi.z = 0.0f;
   danhSachVat[soLuongVat].danhSachVatThe[0].hinhDang.hinhNon = datHinhNon( 20.0f, 18.5f, 2.0f, &(danhSachVat[soLuongVat].danhSachVatThe[0].baoBiVT) );
   danhSachVat[soLuongVat].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVat].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[0]), &phongTo, &quaternion, &viTriTuongDoi );
   danhSachVat[soLuongVat].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVat].danhSachVatThe[0].giaTri = 1;
   
   //   viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.0f;        viTriTuongDoi.z = 0.0f;
   danhSachVat[soLuongVat].danhSachVatThe[1].hinhDang.hinhNon = datHinhNon( 8.5f, 12.5f, 3.0f, &(danhSachVat[soLuongVat].danhSachVatThe[1].baoBiVT) );
   danhSachVat[soLuongVat].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVat].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[1]), &phongTo, &quaternion, &viTriTuongDoi );
   danhSachVat[soLuongVat].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVat].danhSachVatThe[1].giaTri = -1;
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVat]) );
   soLuongVat++;
   
   // ---- vật thể bool
   viTri.y += 1.25f;
   danhSachVat[soLuongVat].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[soLuongVat].mucDichBool = 1;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   
   danhSachVat[soLuongVat].soLuongVatThe = 2;
   danhSachVat[soLuongVat].danhSachVatThe = malloc( 2*sizeof(VatThe) );
   
   // vị trí tương đối
   viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.0f;        viTriTuongDoi.z = 0.0f;
   danhSachVat[soLuongVat].danhSachVatThe[0].hinhDang.hinhTru = datHinhTru( 17.5f, 0.5f, &(danhSachVat[soLuongVat].danhSachVatThe[0].baoBiVT) );
   danhSachVat[soLuongVat].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[0]), &phongTo, &quaternion, &viTriTuongDoi );
   danhSachVat[soLuongVat].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVat].danhSachVatThe[0].giaTri = 1;
   
   //   viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.0f;        viTriTuongDoi.z = 0.0f;
   danhSachVat[soLuongVat].danhSachVatThe[1].hinhDang.hinhTru = datHinhTru( 13.0f, 1.0f, &(danhSachVat[soLuongVat].danhSachVatThe[1].baoBiVT) );
   danhSachVat[soLuongVat].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVat].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[1]), &phongTo, &quaternion, &viTriTuongDoi );
   danhSachVat[soLuongVat].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVat].danhSachVatThe[1].giaTri = -1;
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVat]) );
   soLuongVat++;
   
   mau1.d = 0.75f;   mau1.l = 0.45f;   mau1.x = 0.1f;    mau1.dd = 1.0f;    mau1.p = 0.0f;
   
   // ---- các hồ lớn xung quanh
   float mangHo_ViTriX[] = {-13.0f, 13.0f,  26.0f, 26.0f,  13.0f, -13.0f,      -26.0f, -26.0f};
   float mangHo_ViTriZ[] = {26.0f, 26.0f,   13.0f, -13.0f,    -26.0f, -26.0f,   -13.0f, 13.0f};
   //   unsigned char mangMau[] = {0, 0,   0, 1, 0,  0, 1, 0,   0, 1, 0};
   
   unsigned char soHo = 0;
   while( soHo < 8 ) {
      viTri.y = viTriDayThap.y + 3.5f;
      viTri.x = viTriDayThap.x + mangHo_ViTriX[soHo];
      viTri.z = viTriDayThap.z + mangHo_ViTriZ[soHo];
      // ---- vật thể bool
      danhSachVat[soLuongVat].loai = kLOAI_VAT_THE__BOOL;
      danhSachVat[soLuongVat].mucDichBool = 1;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
      
      danhSachVat[soLuongVat].soLuongVatThe = 2;
      danhSachVat[soLuongVat].danhSachVatThe = malloc( 2*sizeof(VatThe) );
      
      // vị trí tương đối
      Vecto viTriTuongDoi;
      viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.0f;        viTriTuongDoi.z = 0.0f;
      danhSachVat[soLuongVat].danhSachVatThe[0].hinhDang.hop = datHop( 13.0f, 5.0f, 13.0f, &(danhSachVat[soLuongVat].danhSachVatThe[0].baoBiVT) );
      danhSachVat[soLuongVat].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVat].danhSachVatThe[0].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[0]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVat].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVat].danhSachVatThe[0].giaTri = 1;
      
      viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 2.0f;        viTriTuongDoi.z = 0.0f;
      danhSachVat[soLuongVat].danhSachVatThe[1].hinhDang.hinhNon = datHinhNon( 4.5f, 5.5f, 2.5f, &(danhSachVat[soLuongVat].danhSachVatThe[1].baoBiVT) );
      danhSachVat[soLuongVat].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVat].danhSachVatThe[1].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[1]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVat].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVat].danhSachVatThe[1].giaTri = -1;
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
      tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVat]) );
      soLuongVat++;
      
      soHo++;
   }
   
   // ---- hộp giữa các hồ
   float mangViTri_x[] = {0.0f, -26.0f, 0.0f, 26.0f};
   float mangViTri_z[] = {-26.0f, 0.0f, 26.0f, 0.0f};
   
   unsigned char soVat = 0;
   
   while( soVat < 4 ) {
      viTri.x = viTriDayThap.x + mangViTri_x[soVat];
      viTri.y = viTriDayThap.y + 2.25f;
      viTri.z = viTriDayThap.z + mangViTri_z[soVat];
      danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 4.5f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
      danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVat++;
      
      viTri.y = viTriDayThap.y + 4.25f;
      danhSachVat[soLuongVat].hinhDang.hop = datHop( 6.0f, 1.0f, 6.0f, &(danhSachVat[soLuongVat].baoBiVT) );
      danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVat++;
      soVat++;
   }
   
   // ==== các hộp quanh tháp
   mau1.d = 1.0f;   mau1.l = 0.8f;   mau1.x = 0.3f;    mau1.dd = 1.0f;    mau1.p = 0.0f;
   // ---- hướng +x
   viTri.x = viTriDayThap.x - 24.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z + 37.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x - 13.0;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z + 39.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x;
   viTri.y = viTriDayThap.y + 1.5f;
   viTri.z = viTriDayThap.z + 39.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 3.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x + 13.0;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z + 39.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x + 24.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z + 37.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   // ---- hướng -z
   viTri.x = viTriDayThap.x + 37.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z - 24.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x + 39.0f;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z - 13.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x + 39.0f;
   viTri.y = viTriDayThap.y + 1.5f;
   viTri.z = viTriDayThap.z;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 3.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x + 39.0f;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z + 13.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x + 37.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z + 24.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   // ---- hướng -x
   viTri.x = viTriDayThap.x + 24.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z - 37.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x + 13.0;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z - 39.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x;
   viTri.y = viTriDayThap.y + 1.5f;
   viTri.z = viTriDayThap.z - 39.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 3.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x - 13.0;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z - 39.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x - 24.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z - 37.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   // ---- hướng +z
   viTri.x = viTriDayThap.x - 37.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z - 24.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x - 39.0f;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z - 13.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x - 39.0f;
   viTri.y = viTriDayThap.y + 1.5f;
   viTri.z = viTriDayThap.z;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 3.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x - 39.0f;
   viTri.y = viTriDayThap.y + 1.0f;
   viTri.z = viTriDayThap.z + 13.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 13.0f, 2.0f, 13.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   viTri.x = viTriDayThap.x - 37.5;
   viTri.y = viTriDayThap.y + 0.5f;
   viTri.z = viTriDayThap.z + 24.5f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 10.0f, 1.0f, 10.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   // ---- 4 hồ nhỏ ở 4 góc
   mangHo_ViTriX[0] = 26.0f;   mangHo_ViTriZ[0] = 26.0f;
   mangHo_ViTriX[1] = 26.0f;   mangHo_ViTriZ[1] = -26.0f;
   mangHo_ViTriX[2] = -26.0f;   mangHo_ViTriZ[2] = -26.0f;
   mangHo_ViTriX[3] = -26.0f;   mangHo_ViTriZ[3] = 26.0f;
   
   //   Mau mauNuoc;
   //   mauNuoc.d = 0.3f;   mauNuoc.l = 0.3f;   mauNuoc.x = 0.3f;  mauNuoc.dd = 1.0f;  mauNuoc.p = 0.5f;
   
   soHo = 0;
   while( soHo < 4 ) {
      viTri.y = viTriDayThap.y + 1.5f;
      viTri.x = viTriDayThap.x + mangHo_ViTriX[soHo];
      viTri.z = viTriDayThap.z + mangHo_ViTriZ[soHo];
      // ---- vật thể bool
      danhSachVat[soLuongVat].loai = kLOAI_VAT_THE__BOOL;
      danhSachVat[soLuongVat].mucDichBool = 1;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau1, &mau0, 6.5001f, 6.5001f, 6.5001f );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
      
      danhSachVat[soLuongVat].soLuongVatThe = 5;
      danhSachVat[soLuongVat].danhSachVatThe = malloc( 5*sizeof(VatThe) );
      
      // vị trí tương đối
      Vecto viTriTuongDoi;
      viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.0f;        viTriTuongDoi.z = 0.0f;
      danhSachVat[soLuongVat].danhSachVatThe[0].hinhDang.hop = datHop( 13.0f, 3.0f, 13.0f, &(danhSachVat[soLuongVat].danhSachVatThe[0].baoBiVT) );
      danhSachVat[soLuongVat].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVat].danhSachVatThe[0].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[0]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVat].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVat].danhSachVatThe[0].giaTri = 1;
      
      viTriTuongDoi.x = -3.25f;      viTriTuongDoi.y = 0.5f;        viTriTuongDoi.z = 3.25f;
      danhSachVat[soLuongVat].danhSachVatThe[1].hinhDang.hinhNon = datHinhNon( 1.5f, 2.5f, 2.5f, &(danhSachVat[soLuongVat].danhSachVatThe[1].baoBiVT) );
      danhSachVat[soLuongVat].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVat].danhSachVatThe[1].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[1]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVat].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVat].danhSachVatThe[1].giaTri = -1;
      
      viTriTuongDoi.x = 3.25f;      viTriTuongDoi.y = 0.5f;        viTriTuongDoi.z = 3.25f;
      danhSachVat[soLuongVat].danhSachVatThe[2].hinhDang.hinhNon = datHinhNon( 1.5f, 2.5f, 2.5f, &(danhSachVat[soLuongVat].danhSachVatThe[2].baoBiVT) );
      danhSachVat[soLuongVat].danhSachVatThe[2].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVat].danhSachVatThe[2].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[2]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVat].danhSachVatThe[2].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].danhSachVatThe[2].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVat].danhSachVatThe[2].giaTri = -1;
      
      viTriTuongDoi.x = 3.25f;      viTriTuongDoi.y = 0.5f;        viTriTuongDoi.z = -3.25f;
      danhSachVat[soLuongVat].danhSachVatThe[3].hinhDang.hinhNon = datHinhNon( 1.5f, 2.5f, 2.5f, &(danhSachVat[soLuongVat].danhSachVatThe[3].baoBiVT) );
      danhSachVat[soLuongVat].danhSachVatThe[3].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVat].danhSachVatThe[3].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[3]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVat].danhSachVatThe[3].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].danhSachVatThe[3].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVat].danhSachVatThe[3].giaTri = -1;
      
      viTriTuongDoi.x = -3.25f;      viTriTuongDoi.y = 0.5f;        viTriTuongDoi.z = -3.25f;
      danhSachVat[soLuongVat].danhSachVatThe[4].hinhDang.hinhNon = datHinhNon( 1.5f, 2.5f, 2.5f, &(danhSachVat[soLuongVat].danhSachVatThe[4].baoBiVT) );
      danhSachVat[soLuongVat].danhSachVatThe[4].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVat].danhSachVatThe[4].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat].danhSachVatThe[4]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVat].danhSachVatThe[4].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVat].danhSachVatThe[4].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVat].danhSachVatThe[4].giaTri = -1;
      
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
      tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVat]) );
      soLuongVat++;
      
      soHo++;
   }
   
   return soLuongVat;
}


// ==== các tần số cho mặt nước
#define kTAN_SO_0__HO_LON   0.8f
#define kTAN_SO_1__HO_LON   0.5f
#define kTAN_SO_X_0__HO_LON   1.0f
#define kTAN_SO_X_1__HO_LON   1.5f
#define kTAN_SO_Z_0__HO_LON  -1.3f
#define kTAN_SO_Z_1__HO_LON   1.3f

#define kTAN_SO_0__HO_GIUA   0.8f
#define kTAN_SO_1__HO_GIUA   0.5f
#define kTAN_SO_X_0__HO_GIUA   2.0f
#define kTAN_SO_X_1__HO_GIUA   2.2f
#define kTAN_SO_Z_0__HO_GIUA   2.3f
#define kTAN_SO_Z_1__HO_GIUA  -2.3f

#define kTAN_SO_0__HO_NHO   0.1f
#define kTAN_SO_1__HO_NHO   0.12f
#define kTAN_SO_X_0__HO_NHO   3.8f
#define kTAN_SO_X_1__HO_NHO   3.5f
#define kTAN_SO_Z_0__HO_NHO   3.0f
#define kTAN_SO_Z_1__HO_NHO  -3.0f

unsigned short datMatCacHoNuocThapNui( VatThe *danhSachVat, Vecto viTriDayThap ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   Vecto viTri = viTriDayThap;
   unsigned short soLuongVat = 0;
   
   Mau mauNuoc;
   mauNuoc.d = 0.3f;   mauNuoc.l = 0.3f;   mauNuoc.x = 0.3f;  mauNuoc.dd = 1.0f;  mauNuoc.p = 0.5f;
   
   // ---- mặt nước
   viTri.y = viTriDayThap.y + 46.1f;
   danhSachVat[soLuongVat].hinhDang.matSong = datMatSong( 26.0f, 26.0f, 0.2f, 0.22f,
                                                         kTAN_SO_0__HO_LON, kTAN_SO_1__HO_LON, kTAN_SO_X_0__HO_LON, kTAN_SO_X_1__HO_LON,
                                                         kTAN_SO_Z_0__HO_LON, kTAN_SO_Z_1__HO_LON, kDUNG, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_SONG;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNuoc );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVat++;
   
   // ---- các hồ lớn xung quanh
   float mangHo_ViTriX[] = {-13.0f, 13.0f,  26.0f, 26.0f,  13.0f, -13.0f,      -26.0f, -26.0f};
   float mangHo_ViTriZ[] = {26.0f, 26.0f,   13.0f, -13.0f,    -26.0f, -26.0f,   -13.0f, 13.0f};
   //   unsigned char mangMau[] = {0, 0,   0, 1, 0,  0, 1, 0,   0, 1, 0};
   
   unsigned char soHo = 0;
   while( soHo < 8 ) {
      viTri.y = viTriDayThap.y + 3.5f;
      viTri.x = viTriDayThap.x + mangHo_ViTriX[soHo];
      viTri.z = viTriDayThap.z + mangHo_ViTriZ[soHo];
      
      // ---- mặt nước
      viTri.y += 2.0f;
      danhSachVat[soLuongVat].hinhDang.matSong = datMatSong( 12.0f, 12.0f, 0.15f, 0.12f,
                                                            kTAN_SO_0__HO_GIUA, kTAN_SO_1__HO_GIUA, kTAN_SO_X_0__HO_GIUA, kTAN_SO_X_1__HO_GIUA,
                                                            kTAN_SO_Z_0__HO_GIUA, kTAN_SO_Z_1__HO_GIUA, kDUNG, &(danhSachVat[soLuongVat].baoBiVT) );
      danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_SONG;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNuoc );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVat++;
      
      soHo++;
   }
   
   // ---- 4 hồ nhỏ ở 4 góc
   mangHo_ViTriX[0] = 26.0f;   mangHo_ViTriZ[0] = 26.0f;
   mangHo_ViTriX[1] = 26.0f;   mangHo_ViTriZ[1] = -26.0f;
   mangHo_ViTriX[2] = -26.0f;   mangHo_ViTriZ[2] = -26.0f;
   mangHo_ViTriX[3] = -26.0f;   mangHo_ViTriZ[3] = 26.0f;
   
   soHo = 0;
   while( soHo < 4 ) {
      viTri.y = viTriDayThap.y + 2.5f;
      viTri.x = viTriDayThap.x + mangHo_ViTriX[soHo];
      viTri.z = viTriDayThap.z + mangHo_ViTriZ[soHo];
      
      danhSachVat[soLuongVat].hinhDang.matSong = datMatSong( 12.0f, 12.0f, 0.1f, 0.12f,
                                                            kTAN_SO_0__HO_NHO, kTAN_SO_1__HO_NHO, kTAN_SO_X_0__HO_NHO, kTAN_SO_X_1__HO_NHO,
                                                            kTAN_SO_Z_0__HO_NHO, kTAN_SO_Z_1__HO_NHO, kDUNG, &(danhSachVat[soLuongVat].baoBiVT) );
      danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_SONG;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNuoc );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVat++;
      
      soHo++;
   }
   
   return soLuongVat;
}

unsigned short datRungHinhNonThuyTinh( VatThe *danhSachVat, float doCaoMatDat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;   quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   unsigned short soLuongVat = 0;
   
   float mangViTri_x[] = {
      80.0f,  60.0f, 120.0f,  0.0f,  0.0f,
      70.0f,  80.0f,  75.0f, 40.0f,  0.0f,
      20.0f,  15.0f,   0.0f, 40.0f, 45.0f,
      142.0f, 120.0f,
      170.0f, 180.0f,};
   float mangViTri_z[] = {
      -20.0f,-25.0f, 20.0f, 10.0f, -20.0f,
      -60.0f,-50.0f,-45.0f,-40.0f,-50.0f,
      -70.0f,-75.0f,-85.0f, -78.0f,-95.0f,
      -58.0f, -45.0f,
      -180.0, -100.0f,};
   
   Mau mauThuyTinh;
   mauThuyTinh.d = 1.0f;    mauThuyTinh.l = 0.5f;    mauThuyTinh.x = 0.5f;    mauThuyTinh.dd = 0.3f;   mauThuyTinh.p = 0.3f;
   
   while( soLuongVat < 19 ) {
      float coKich = (rand() & 0xf) * 0.125f + 0.5f;
      Vecto viTri;
      viTri.x = mangViTri_x[soLuongVat];
      viTri.y = doCaoMatDat + 1.5*coKich;
      viTri.z = mangViTri_z[soLuongVat];
      danhSachVat[soLuongVat].hinhDang.hinhNon = datHinhNon( 1.5f*coKich, 0.0, 3.0f*coKich, &(danhSachVat[soLuongVat].baoBiVT) );
      danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVat].chietSuat = 1.5f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauThuyTinh );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVat++;
   }
   
   return soLuongVat;
}


unsigned short datDanHinhTru( VatThe *danhSachVat, Vecto viTriDan ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;   quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   unsigned short soDanVien = (rand() & 0xf) + 5;
   unsigned short soLuongVat = 0;
   
   while( soLuongVat < soDanVien ) {
      // ---- chọn màu
      Mau mauHinhTru;
      mauHinhTru.d = (rand() & 0xff)/255.0f;
      mauHinhTru.l = (rand() & 0xff)/255.0f;
      mauHinhTru.x = (rand() & 0xff)/255.0f;
      mauHinhTru.dd = 1.0f;
      mauHinhTru.p = 0.3f;
      
      // ---- chọn cỡ kích
      float coKich = (rand() & 0xf) * 0.125f + 0.5f;
      Vecto viTri;
      // ---- chọn vị trí
      viTri.x = viTriDan.x + (rand() & 0xf);
      viTri.y = viTriDan.y + (rand() & 0xf);
      viTri.z = viTriDan.z + (rand() & 0xf);
      
      // ---- tạo các vật thể
      unsigned char soLuongBat = (rand() & 0xf) + 5; // số lượn bật
      unsigned char soBat = 0;
      while( soBat < soLuongBat ) {
         
         danhSachVat[soLuongVat].hinhDang.hinhTru = datHinhTru( 1.5f*coKich, 0.15f*coKich, &(danhSachVat[soLuongVat].baoBiVT) );
         danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_TRU;
         danhSachVat[soLuongVat].chietSuat = 1.5f;
         datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
         danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauHinhTru );
         danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
         soLuongVat++;
         
         viTri.y += 0.5f*coKich;
         soBat++;
      }
   }
   
   return soLuongVat;
}


unsigned short datHinhXuyenKhongLo( VatThe *danhSachVat, Vecto viTriDayThap ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 0.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 1.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 1.57079635f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   Vecto viTri = viTriDayThap;
   unsigned short soLuongVat = 0;
   
   Mau mauNen;
   Mau mauQuan0;
   Mau mauQuan1;
   Mau mauQuan2;
   mauNen.d = 1.0f;   mauNen.l = 0.7f;   mauNen.x = 0.3f;  mauNen.dd = 1.0f;  mauNen.p = 0.0f;
   mauQuan0.d = 1.0f;   mauQuan0.l = 0.7f;   mauQuan0.x = 0.6f;  mauQuan0.dd = 1.0f;  mauQuan0.p = 0.2f;
   mauQuan1.d = 1.0f;   mauQuan1.l = 0.46f;   mauQuan1.x = 0.45f;  mauQuan1.dd = 1.0f;  mauQuan1.p = 0.1f;
   mauQuan2.d = 0.55f;   mauQuan2.l = 0.25f;   mauQuan2.x = 0.0f;  mauQuan2.dd = 1.0f;  mauQuan2.p = 0.0f;
   
   viTri.y += 30.0f;
   danhSachVat[soLuongVat].hinhDang.hinhXuyen = datHinhXuyen( 30.0f, 3.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_XUYEN;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietQuanSongTrucZ = datHoaTietQuanSongTrucZ( &mauNen, &mauQuan0, &mauQuan1, &mauQuan2, 0.1f, 0.2f, 0.3f, 2.0f, 0.1f, 0.0f, 3 );
   
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__QUAN_SONG_TRUC_Z;
   soLuongVat++;
   
   return soLuongVat;
}

unsigned short datHinhXuyenTrungBinh( VatThe *danhSachVat, Vecto viTriDayThap ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 0.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 1.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 1.57079635f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   Vecto viTri = viTriDayThap;
   unsigned short soLuongVat = 0;
   
   Mau mauNen;
   Mau mauQuan0;
   Mau mauQuan1;
   Mau mauQuan2;
   mauNen.d = 0.7f;   mauNen.l = 0.7f;   mauNen.x = 1.0f;  mauNen.dd = 1.0f;  mauNen.p = 0.0f;
   mauQuan0.d = 0.7f;   mauQuan0.l = 0.6f;   mauQuan0.x = 1.0f;  mauQuan0.dd = 1.0f;  mauQuan0.p = 0.2f;
   mauQuan1.d = 0.46f;   mauQuan1.l = 0.25f;   mauQuan1.x = 0.85f;  mauQuan1.dd = 1.0f;  mauQuan1.p = 0.1f;
   mauQuan2.d = 0.00f;   mauQuan2.l = 0.25f;   mauQuan2.x = 0.55f;  mauQuan2.dd = 1.0f;  mauQuan2.p = 0.0f;
   
   viTri.y += 30.0f;
   
   viTri.x += 2.0f;
   danhSachVat[soLuongVat].hinhDang.hinhXuyen = datHinhXuyen( 20.0f, 2.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_XUYEN;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietQuanSongTrucZ = datHoaTietQuanSongTrucZ( &mauNen, &mauQuan0, &mauQuan1, &mauQuan2, 0.1f, 0.2f, 0.3f, 2.0f, 0.1f, 0.0f, 3 );
   
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__QUAN_SONG_TRUC_Z;
   soLuongVat++;
   
   return soLuongVat;
}

/*
 unsigned short datRungMatHyperbol( VatThe *danhSachVat, float doCaoMatDat, float viTriX, float viTriZ ) {
 
 Quaternion quaternion;
 quaternion.w = 1.0f;  quaternion.x = 0.0f;   quaternion.y = 0.0f;    quaternion.z = 0.0f;
 
 Vecto phongTo;
 phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
 
 // ---- cach giữa cây
 float cachGiuaCayX = 12.0f;
 float cachGiuaCayZ = 10.3f;
 
 // ---- vị trí tính góc rừng
 viTriX -= cachGiuaCayX*5.5f;  // cho giữa rộng 10 'cây', 10.0f giữa mỗi cây
 viTriZ -= cachGiuaCayZ*3;
 
 Vecto viTri;
 viTri.y = doCaoMatDat + 3.0f;
 viTri.z = -127.0f;//viTriZ;
 
 Mau mauNen;
 mauNen.d = 0.5f;   mauNen.l = 0.2f;   mauNen.x = 1.0f;  mauNen.dd = 1.0f;  mauNen.p = 0.5f;
 
 
 unsigned short soLuongVat = 0;
 unsigned short soHoatHinh = 0;
 // ==== biến độ mặt hyperbol
 float bienDoMatHyperbol = 1.2f;
 
 
 danhSachVat[soLuongVat].soHoatHinh = soHoatHinh;
 
 // ---- đặt mặt hyperbol
 danhSachVat[soLuongVat].hinhDang.matHyperbol = datMatHyperbol( 5.0f, bienDoMatHyperbol, 6.0f, kDUNG,
 &(danhSachVat[soLuongVat].baoBiVT) );
 danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_HYPERBOL;
 danhSachVat[soLuongVat].chietSuat = 1.0f;
 datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
 danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
 soLuongVat++;
 
 return soLuongVat;
 } */

unsigned short datRungMatHyperbol( VatThe *danhSachVat, float doCaoMatDat, float viTriX, float viTriZ ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;   quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- cach giữa cây
   float cachGiuaCayX = 12.0f;
   float cachGiuaCayZ = 10.3f;
   
   // ---- vị trí tính góc rừng
   viTriX -= cachGiuaCayX*5.5f;  // cho giữa rộng 10 'cây', 10.0f giữa mỗi cây
   viTriZ -= cachGiuaCayZ*3;
   
   Vecto viTri;
   viTri.y = doCaoMatDat + 3.0f;
   viTri.z = viTriZ;
   
   Mau mauNen;
   mauNen.d = 0.5f;   mauNen.l = 0.2f;   mauNen.x = 1.0f;  mauNen.dd = 1.0f;  mauNen.p = 0.5f;
   
   // ==== biến độ mặt hyperbol
   float bienDoMatHyperbol = 1.2f;
   
   unsigned short soLuongVat = 0;
   
   unsigned char soHang = 0;
   while( soHang < 6 ) {
      unsigned char soCot = 0;
      viTri.x = viTriX;
      while( soCot < 20 ) {
         // ---- ngẫu nhiên chọn số hoạt hình
         unsigned short soHoatHinh = rand() % 40;
         float banKinhBinh = 0.0f;
         if( soHoatHinh < 20 )
            banKinhBinh = -2.0f + 0.2f*soHoatHinh;
         else
            banKinhBinh = 2.0f - 0.2f*(soHoatHinh - 20);
         danhSachVat[soLuongVat].soHoatHinh = soHoatHinh;
         
         // ---- đặt mặt hyperbol
         danhSachVat[soLuongVat].hinhDang.matHyperbol = datMatHyperbol( banKinhBinh, bienDoMatHyperbol, 6.0f, kSAI,
                                                                       &(danhSachVat[soLuongVat].baoBiVT) );
         danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_HYPERBOL;
         danhSachVat[soLuongVat].chietSuat = 1.0f;
         datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
         danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
         
         viTri.x += cachGiuaCayX;
         soLuongVat++;
         soCot++;
      }
      
      viTri.x = viTriX + 5.0f;
      viTri.z += cachGiuaCayZ;
      soCot = 0;
      while( soCot < 19 ) {
         // ---- ngẫu nhiên chọn số hoạt hình
         unsigned short soHoatHinh = rand() % 40;
         float banKinhBinh = 0.0f;
         if( soHoatHinh < 20 )
            banKinhBinh = -2.0f + 0.2f*soHoatHinh;
         else
            banKinhBinh = 2.0f - 0.2f*(soHoatHinh - 20);
         danhSachVat[soLuongVat].soHoatHinh = soHoatHinh;
         
         // ---- đặt mặt hyperbol
         danhSachVat[soLuongVat].hinhDang.matHyperbol = datMatHyperbol( banKinhBinh, bienDoMatHyperbol, 6.0f, kSAI,
                                                                       &(danhSachVat[soLuongVat].baoBiVT) );
         danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_HYPERBOL;
         danhSachVat[soLuongVat].chietSuat = 1.0f;
         datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
         danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
         
         viTri.x += cachGiuaCayX;
         soLuongVat++;
         soCot++;
      }
      
      viTri.z += cachGiuaCayZ;
      soHang++;
   }
   
/*   viTri.x = viTriX;
   // viTri.z += cachGiuaCayZ;  đã làm ở trong lặp ở trước đây
   unsigned char soCot = 0;
   while( soCot < 20 ) {
      // ---- ngẫu nhiên chọn số hoạt hình
      unsigned short soHoatHinh = rand() % 40;
      float banKinhBinh = 0.0f;
      if( soHoatHinh < 20 )
         banKinhBinh = -2.0f + 0.2f*soHoatHinh;
      else
         banKinhBinh = 2.0f - 0.2f*(soHoatHinh - 20);
      danhSachVat[soLuongVat].soHoatHinh = soHoatHinh;
      
      // ---- đặt mặt hyperbol
      danhSachVat[soLuongVat].hinhDang.matHyperbol = datMatHyperbol( banKinhBinh, bienDoMatHyperbol, 6.0f, kDUNG,
                                                                    &(danhSachVat[soLuongVat].baoBiVT) );
      danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__MAT_HYPERBOL;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
      
      
      viTri.x += cachGiuaCayX;
      soLuongVat++;
      soCot++;
   }
   */
   return soLuongVat;
}

unsigned short datLocXoayPhai( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   viTri = viTriDay;
   viTri.y += 1.0f;  // giữa hộp đầu
   
   Mau mau;
   
   float goc = 0.0f;
   float banKinhXoay = 8.0f;
   float banKinhHinhCau = 1.0f;
   float doDuc = 0.01f;
   
   unsigned short soLuongVatThe = 0;
   while( soLuongVatThe < kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY ) {
      
      // ---- cỡ và màu của hình cầu lốc xoay
      if( (soLuongVatThe % 10) == 0 ) {
         mau.d = 0.4f;   mau.l = 0.3f;  mau.x = 0.1f;   mau.dd = doDuc;  mau.p = 0.0f;
         banKinhHinhCau = 1.0f;
      }
      else {
         mau.d = 0.8f;   mau.l = 0.5f;  mau.x = 0.2f;   mau.dd = doDuc;   mau.p = 0.0f;
         banKinhHinhCau = 0.7f;
      }
      
      viTri.x = viTriDay.x + banKinhXoay*cosf( goc );
      viTri.z = viTriDay.z + banKinhXoay*sinf( goc );
      danhSachVat[soLuongVatThe].hinhDang.hinhCau = datHinhCau( banKinhHinhCau, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau.x = viTriDay.x;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.y = viTri.y;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.z = viTriDay.z;  // cần này cho hoạt hình
      soLuongVatThe++;
      
      float gocDiaPhuong = goc + 1.57080;
      viTri.x = viTriDay.x + banKinhXoay*cosf( gocDiaPhuong );
      viTri.z = viTriDay.z + banKinhXoay*sinf( gocDiaPhuong );
      danhSachVat[soLuongVatThe].hinhDang.hinhCau = datHinhCau( banKinhHinhCau, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau.x = viTriDay.x;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.y = viTri.y;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.z = viTriDay.z;  // cần này cho hoạt hình
      soLuongVatThe++;
      
      gocDiaPhuong += 1.57080;
      viTri.x = viTriDay.x + banKinhXoay*cosf( gocDiaPhuong );
      viTri.z = viTriDay.z + banKinhXoay*sinf( gocDiaPhuong );
      danhSachVat[soLuongVatThe].hinhDang.hinhCau = datHinhCau( banKinhHinhCau, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau.x = viTriDay.x;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.y = viTri.y;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.z = viTriDay.z;  // cần này cho hoạt hình
      soLuongVatThe++;
      
      gocDiaPhuong += 1.57080;
      viTri.x = viTriDay.x + banKinhXoay*cosf( gocDiaPhuong );
      viTri.z = viTriDay.z + banKinhXoay*sinf( gocDiaPhuong );
      danhSachVat[soLuongVatThe].hinhDang.hinhCau = datHinhCau( banKinhHinhCau, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau.x = viTriDay.x;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.y = viTri.y;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.z = viTriDay.z;  // cần này cho hoạt hình
      soLuongVatThe++;
      
      goc += kLOC_XOAY__GOC_XOAN;
      viTri.y += kLOC_XOAY__CACH_CAO;
      
      if( viTri.y - viTriDay.y < 10.0f ) {  // cho đoàn gần đất trong
         doDuc = (viTri.y - viTriDay.y)*0.05f;
      }
      else
         doDuc -= 0.0065f;  // 1.0/kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY
      
      //      printf( "viTri.y %5.3f  doDuc %5.3f\n", viTri.y, doDuc );
   }
   
   return soLuongVatThe;
}

unsigned short datLongSaoGaiXanh( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   viTri = viTriDay;
   viTri.y += 0.05f;  // giữa hộp đầu
   
   Mau mau;
   mau.d = 0.0f;   mau.l = 0.0f;   mau.x = 1.0f;   mau.dd = 1.0f;   mau.p = 0.1f;
   
   unsigned short soLuongVatThe = 0;
   
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 10.0f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.55f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 10.0f, 4.0f, 1.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.7f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 3.9f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ---- sàn lồng - vật thể bool
   //mau.d = 1.0f;      mau.l = 0.1f;      mau.x = 0.05f;      mau.dd = 1.0f;
   viTri.y += 0.25f;
   danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[soLuongVatThe].mucDichBool = 1;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   
   danhSachVat[soLuongVatThe].soLuongVatThe = 2;
   danhSachVat[soLuongVatThe].danhSachVatThe = malloc( 2*sizeof(VatThe) );
   
   // vị trí tương đối
   Vecto viTriTuongDoi;
   viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.0f;        viTriTuongDoi.z = 0.0f;
   danhSachVat[soLuongVatThe].danhSachVatThe[0].hinhDang.hinhTru = datHinhTru( 3.2f, 0.1f, &(danhSachVat[soLuongVatThe].danhSachVatThe[0].baoBiVT) );
   danhSachVat[soLuongVatThe].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[0]), &phongTo, &quaternion, &viTriTuongDoi );
   danhSachVat[soLuongVatThe].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].danhSachVatThe[0].giaTri = 1;
   
   viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = 0.05f;        viTriTuongDoi.z = 0.0f;
   danhSachVat[soLuongVatThe].danhSachVatThe[1].hinhDang.hinhTru = datHinhTru( 1.5f, 0.1f, &(danhSachVat[soLuongVatThe].danhSachVatThe[1].baoBiVT) );
   danhSachVat[soLuongVatThe].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[1]), &phongTo, &quaternion, &viTriTuongDoi );
   danhSachVat[soLuongVatThe].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].danhSachVatThe[1].giaTri = -1;
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
   soLuongVatThe++;
   
   
   // ---- nắp
   viTri.y += 4.8f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.0f, 3.4f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.3f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.9f, 4.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.3f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.0f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.6f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.5f, 0.8f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ---- mất hình trụ nhỏ trên nắp
   
   unsigned char soVatThe = 0;
   float goc = 0.0f;
   
   while ( soVatThe < 10 ) {
      viTriTuongDoi.y = viTri.y;
      viTriTuongDoi.x = viTri.x + 3.6f*cosf( goc );
      viTriTuongDoi.z = viTri.z + 3.6f*sinf( goc );
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 0.8f, 1.8f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      viTriTuongDoi.y += 0.95f;
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 0.6f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      viTriTuongDoi.y += 0.1f;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 0.6f, 0.4f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      // ---- đến vị trí tiếp
      goc += 0.314159f*2.0f;
      soVatThe++;
   }
   
   // ----
   viTri.y += 0.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.2f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.2f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 4.2f, 3.9f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ----
   viTri.y += 0.2f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 3.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.2f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.0f, 2.7f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ----
   viTri.y += 0.3f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 2.0f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.45f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 2.0f, 1.5f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ----
   viTri.y += 0.45f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 1.0f, 0.5f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   return soLuongVatThe;
}


#define kKIEN_LONG__BE_RONG  1.0f
#define kKIEN_LONG__BE_CAO   4.5f
#define kKIEN_LONG__BE_DAY   0.1f
#define kKIEN_LONG__BAN_KINH 3.5f

unsigned short datKienLongSaoGaiXanh( VatThe *danhSachVat, Vecto viTriDayLong ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri = viTriDayLong;
   viTri.y += 4.0f;
   
   // ---- kiến lồng - vật thể ghép
   mau.d = 0.4f;      mau.l = 0.7f;      mau.x = 1.0f;      mau.dd = 0.15f;   mau.p = 0.1f;
   
   //   danhSachVat[0].hinhDang.hinhCau = datHinhCau( 5.0f );  // cho xem vị trí tâm
   danhSachVat[0].loai = kLOAI_VAT_THE__GHEP;
   danhSachVat[0].xaiHoaThietVatTheGhep = kSAI;
   danhSachVat[0].chietSuat = 1.4f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[0].viTriDau = viTri;
   
   danhSachVat[0].soLuongVatThe = 20;
   danhSachVat[0].danhSachVatThe = malloc( 20*sizeof(VatThe) );
   
   // ---- các thành phân trong vật ghép
   VatThe *danhSachVatThe = danhSachVat[0].danhSachVatThe;
   Vecto trucQuay;
   trucQuay.x = 0.0f;
   trucQuay.y = 1.0f;
   trucQuay.z = 0.0f;
   float buocGoc = 0.31415927f;    // 2π/20
   
   unsigned char chiSo = 0;
   while ( chiSo < 20 ) {
      float gocXoay = buocGoc*chiSo ;
      // ---- tính vị trí tương đối
      viTri.x = kKIEN_LONG__BAN_KINH*sinf( gocXoay );
      viTri.y = 0.0f;
      viTri.z = kKIEN_LONG__BAN_KINH*cosf( gocXoay );
      
      quaternion = datQuaternionTuVectoVaGocQuay( &trucQuay,  gocXoay );
      danhSachVatThe[chiSo].hinhDang.hop = datHop( kKIEN_LONG__BE_RONG, kKIEN_LONG__BE_CAO, kKIEN_LONG__BE_DAY, &(danhSachVatThe[chiSo].baoBiVT) );
      danhSachVatThe[chiSo].loai = kLOAI_HINH_DANG__HOP;
      danhSachVatThe[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVatThe[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVatThe[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVatThe[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
   }
   
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[0]) );
   
   return 1;
}

//  ---> +x
//    phần bằng    thác parabol
// +------------------+-\
//                       --\
//                          -\
//                            \
// |<---------------->|<------>|
//  kDONG_SONG__BE_DAI  kDONG_SONG__PARABOL
//

// vị trí các hình trụ
// +-------------------+
// | * * * * * * ... * |  | hướng di chuyển
// |  * * * * * *...*  |  |
// | * * * * * * ... * |  v
//       ....
// | * * * * * * ... * |
// +-------------------+


#define kDONG_SONG__BAN_KINH_VAT_THE 6.5f
//#define kDONG_SONG__BE_RONG 165.0f
#define kDONG_SONG__BE_DAI_PHAN_BANG  650.0f*1.732f
#define kDONG_SONG__BE_DAI_PHAN_PARABOL 130.0f*1.732f
#define kDONG_SONG__HINH_TRU__BE_DAY 2.0f
#define kDONG_SONG__HINH_NON__BE_DAY 0.8f
#define kDONG_SONG__HANG_SO_PARABOL -0.008f

#define kDONG_SONG__VI_TRI_X -200.0f
#define kDONG_SONG__VI_TRI_Y   10.0f
#define kDONG_SONG__VI_TRI_Z -250.0f

unsigned short datDongSong( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   
   mau.dd = 1.0f;
   mau.p = 0.2f;
   
   unsigned short soLuongVatThe = 0;
   
   // ---- tính bán kính hình trụ
   float banKinh = kDONG_SONG__BAN_KINH_VAT_THE;   // rộng năm hình trụ
   
   // ==== PHẦN BẰNG
   float x = -kDONG_SONG__BE_DAI_PHAN_BANG*0.5f + kDONG_SONG__VI_TRI_X;
   float xKetThucBang = kDONG_SONG__BE_DAI_PHAN_BANG*0.5f + kDONG_SONG__VI_TRI_X;
   float buocX = banKinh*1.732f;
   float buocZ = banKinh*2.0f;
   unsigned char le = 0;  // cho biết chẵn hay lẹ
   
   while( x < xKetThucBang ) {
      Vecto viTriVatThe;
      viTriVatThe.x = x;
      viTriVatThe.y = kDONG_SONG__VI_TRI_Y;
      viTriVatThe.z = kDONG_SONG__VI_TRI_Z;
      
      unsigned char soLuongVatTheNgang;
      
      Vecto viTriTuongDoi;
      if( le & 0x01 ) {
         soLuongVatTheNgang = 14;
         viTriTuongDoi.z = -6.5f*buocZ;
      }
      else {
         soLuongVatTheNgang = 15;
         viTriTuongDoi.z = -7.0f*buocZ;
      }
      
      soLuongVatTheNgang <<= 1;   // nhân hai cho hai vật thể tại mỗi địa điểm
      
      danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__GHEP;
      danhSachVat[soLuongVatThe].xaiHoaThietVatTheGhep = kDUNG;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriVatThe );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      
      danhSachVat[soLuongVatThe].soLuongVatThe = soLuongVatTheNgang;
      danhSachVat[soLuongVatThe].danhSachVatThe = malloc( soLuongVatTheNgang*sizeof(VatThe));
      
      unsigned char soVatThe = 0;
      while( soVatThe < soLuongVatTheNgang ) {
         // ---- chọn màu
         unsigned char soMau = rand() % 3;
         if( soMau == 0 ) {
            mau.d = (0xff & rand())/255.0f;
            mau.l = (0xff & rand())/255.0f;
            mau.x = 0.0f;
         }
         else if( soMau == 1 ) {
            mau.d = (0xff & rand())/255.0f;
            mau.l = 0.0f;
            mau.x = (0xff & rand())/255.0f;
         }
         else {// if( soMau == 2 ) {
            mau.d = 0.0f;
            mau.l = (0xff & rand())/255.0f;
            mau.x = (0xff & rand())/255.0f;
         }
         //         printf( "mau  %5.3f %5.3f %5.3f \n", mau.d, mau.l, mau.x );
         
         // ---- vị trí tương đối
         
         viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = (rand() & 0xff)/127.0f;
         
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hinhDang.hinhLangTru = datHinhLangTru( banKinh - 0.3f,kDONG_SONG__HINH_TRU__BE_DAY, 6,
                                                                                           &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].baoBiVT) );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].loai = kLOAI_HINH_DANG__HINH_LANG_TRU;
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].chietSuat = 1.0f;
         datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe]), &phongTo, &quaternion, &viTriTuongDoi );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
         soVatThe++;
         
         viTriTuongDoi.y += (kDONG_SONG__HINH_TRU__BE_DAY + kDONG_SONG__HINH_NON__BE_DAY)*0.5f;
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hinhDang.hinhChop = datHinhChop( banKinh - 0.3f, banKinh - kDONG_SONG__HINH_NON__BE_DAY - 0.3f,
                                                                                           kDONG_SONG__HINH_NON__BE_DAY, 6, &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].baoBiVT) );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].loai = kLOAI_HINH_DANG__HINH_LANG_TRU;
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].chietSuat = 1.0f;
         datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe]), &phongTo, &quaternion, &viTriTuongDoi );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
         soVatThe++;
         
         viTriTuongDoi.z += buocZ;
      }
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
      tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
      soLuongVatThe++;
      
      x += buocX;
      le++;
   }
   
   // ==== PARABOL
   // ---- tính z
   float xParabol = x - kDONG_SONG__BE_DAI_PHAN_BANG*0.5f;
   
   float xKetThucParabol = xKetThucBang + kDONG_SONG__BE_DAI_PHAN_PARABOL;
   //   printf( "datDongSong: xKetThucBang %5.3f  xKetThucParabol %5.3f\n", xKetThucBang, xKetThucParabol );
   
   while( x < xKetThucParabol ) {

      float xParabol = x - kDONG_SONG__BE_DAI_PHAN_BANG*0.5f - kDONG_SONG__VI_TRI_X;
      float y = kDONG_SONG__HANG_SO_PARABOL*xParabol*xParabol;
      //      printf( "%5.3f < %5.3f  y %5.3f\n", x, xKetThuc, y );
      
      Vecto viTriVatThe;
      viTriVatThe.x = x;
      viTriVatThe.y = y + kDONG_SONG__VI_TRI_Y;
      viTriVatThe.z = kDONG_SONG__VI_TRI_Z;
      
      unsigned char soLuongVatTheNgang;
      
      Vecto viTriTuongDoi;
      if( le & 0x01 ) {
         soLuongVatTheNgang = 14;
         viTriTuongDoi.z = -6.5f*buocZ;
      }
      else {
         soLuongVatTheNgang = 15;
         viTriTuongDoi.z = -7.0f*buocZ;
      }
      
      soLuongVatTheNgang <<= 1;   // nhân hai cho hai vật thể tại mỗi địa điểm
      
      // ---- tính góc xoay vật thể
      Vecto trucQuay;
      trucQuay.x = 0.0f;  trucQuay.y = 0.0f;   trucQuay.z = 1.0f;
      float goc = atanf( kDONG_SONG__HANG_SO_PARABOL*2.0f*xParabol );
      Quaternion quaternionGoc = datQuaternionTuVectoVaGocQuay( &trucQuay, goc );
      
      danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__GHEP;
      danhSachVat[soLuongVatThe].xaiHoaThietVatTheGhep = kDUNG;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternionGoc, &viTriVatThe );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      
      danhSachVat[soLuongVatThe].soLuongVatThe = soLuongVatTheNgang;
      danhSachVat[soLuongVatThe].danhSachVatThe = malloc( soLuongVatTheNgang*sizeof(VatThe));
      
      //      printf( "viTri P" );
      unsigned char soVatThe = 0;
      while( soVatThe < soLuongVatTheNgang ) {
         // ---- chọn màu
         unsigned char soMau = rand() % 3;
         if( soMau == 0 ) {
            mau.d = (0xff & rand())/255.0f;
            mau.l = (0xff & rand())/255.0f;
            mau.x = 0.0f;
         }
         else if( soMau == 1 ) {
            mau.d = (0xff & rand())/255.0f;
            mau.l = 0.0f;
            mau.x = (0xff & rand())/255.0f;
         }
         else {// if( soMau == 2 ) {
            mau.d = 0.0f;
            mau.l = (0xff & rand())/255.0f;
            mau.x = (0xff & rand())/255.0f;
         }
         
         float doLonMau = sqrt( mau.d*mau.d + mau.l*mau.l + mau.x*mau.x );
         if( doLonMau > 0.0f ) {
            mau.d /= doLonMau;
            mau.l /= doLonMau;
            mau.x /= doLonMau;
         }
         
         viTriTuongDoi.x = 0.0f;      viTriTuongDoi.y = (rand() & 0xff)/127.0f;
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hinhDang.hinhLangTru = datHinhLangTru( banKinh - 0.3f, kDONG_SONG__HINH_TRU__BE_DAY, 6,
                                                                                           &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].baoBiVT) );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].loai = kLOAI_HINH_DANG__HINH_LANG_TRU;
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].chietSuat = 1.0f;
         datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe]), &phongTo, &quaternion, &viTriTuongDoi );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
         soVatThe++;
         
         viTriTuongDoi.y += (kDONG_SONG__HINH_TRU__BE_DAY + kDONG_SONG__HINH_NON__BE_DAY)*0.5f;
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hinhDang.hinhChop = datHinhChop( banKinh - 0.3f, banKinh - kDONG_SONG__HINH_NON__BE_DAY - 0.3f,
                                                                                           kDONG_SONG__HINH_NON__BE_DAY, 6, &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].baoBiVT) );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].loai = kLOAI_HINH_DANG__HINH_CHOP;
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].chietSuat = 1.0f;
         datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe]), &phongTo, &quaternion, &viTriTuongDoi );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[soLuongVatThe].danhSachVatThe[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
         soVatThe++;
         
         viTriTuongDoi.z += buocZ;
         
      }
      tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
      
      soLuongVatThe++;
      
      x += buocX;
      le++;
   }
   
   return soLuongVatThe;
}


unsigned short datThapHinhTruCau( VatThe *danhSachVat, Vecto viTriDayThap ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   
   mau.d = 0.66f;   mau.l = 0.66f;   mau.x = 0.66f;   mau.dd = 1.0f;   mau.p = 0.2f;
   
   unsigned short soLuongVatThe = 0;

   Vecto viTriHinhNon = viTriDayThap;

   // ----
   viTriHinhNon.y += 0.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 40.0f, 1.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   mau.d = 0.81f;   mau.l = 0.81f;   mau.x = 0.53f;
   viTriHinhNon.y += 1.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 34.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 3.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 34.0f, 25.0, 5.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   mau.d = 0.66f;   mau.l = 0.66f;   mau.x = 0.66f;
   viTriHinhNon.y += 3.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 22.0f, 1.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 3.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 5.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTriHinhNon.y += 8.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 5.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 8.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 5.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 8.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 5.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 4.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 15.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 2.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 10.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTriHinhNon.y += 4.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhCau = datHinhCau( 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriHinhNon );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   return soLuongVatThe;
}


unsigned short datNuiParabolSoc( VatThe *danhSachVat, float doCaoMatDat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mauNen;
   mauNen.d = 1.00f;   mauNen.l = 0.97f;   mauNen.x = 0.66f;   mauNen.dd = 1.0f;   mauNen.p = 0.0f;
   Mau mauSoc;
   mauSoc.d = 0.61f;   mauSoc.l = 0.73f;   mauSoc.x = 0.20f;   mauSoc.dd = 1.0f;   mauSoc.p = 0.0f;

   unsigned short soLuongVatThe = 0;
   
   float mangBanKinh[] = {
      -250.0f, -180.0f, -450.0f, -350.0f, -150.0f,
      -250.0f,  -100.0f, -300.0f, -500.0f};
   
   float mangBeCao[] =   {
      50.0f, 30.0, 50.0f, 60.0f, 40.0f,
       80.0f, 65.0f, 40.0f,  100.0f};
   
   float mangViTri_x[] = {
      -200.0f, -110.0f, -500.0f, -650.0f, -250.0f,
      -330.0f, -280.0f, -100.0f, -800.0f};
   
   float mangViTri_z[] = {
      -600.0f, -750.0f, -700.0f, -500.0f, -750.0f,
      -620.0f, -520.0f, -1000.0f, -1100.0f};

   Vecto trucSoc;
   trucSoc.x = 0.8f;    trucSoc.y = 0.8f;    trucSoc.z = -1.0f;

   unsigned char soNui = 0;
   while( soNui < 9 ) {
      Vecto viTriNui;
      viTriNui.y = doCaoMatDat + mangBeCao[soNui];
      viTriNui.x = mangViTri_x[soNui];
      viTriNui.z = mangViTri_z[soNui];
      danhSachVat[soLuongVatThe].hinhDang.matParabol = datMatParabol( mangBanKinh[soNui], mangBeCao[soNui], &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__MAT_PARABOL;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriNui );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauNen, &mauSoc, 20.0f, 0.5f, &trucSoc );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__SOC;
      soLuongVatThe++;
      soNui++;
   }

   return soLuongVatThe;
}

unsigned short datNuiHinhNon( VatThe *danhSachVat, float doCaoMatDat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mauNen;
   mauNen.d = 1.00f;   mauNen.l = 0.97f;   mauNen.x = 0.72f;   mauNen.dd = 1.0f;   mauNen.p = 0.0f;
   Mau mauSoc;
   mauSoc.d = 0.34f;   mauSoc.l = 0.41f;   mauSoc.x = 0.10f;   mauSoc.dd = 1.0f;   mauSoc.p = 0.0f;
   
   unsigned short soLuongVatThe = 0;
   
   Vecto trucSoc;
   trucSoc.x = 0.0f;    trucSoc.y = 1.0f;    trucSoc.z = 0.0f;
   
   Vecto viTriNui;
   viTriNui.y = doCaoMatDat + 75.0f;   viTriNui.x = -300.0f;   viTriNui.z = -1800.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 300.0f, 200.0f, 150.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriNui );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauNen, &mauSoc, 50.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__SOC;
   soLuongVatThe++;

   viTriNui.y += 150.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 0.0f, 100.0f, 66.667f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriNui );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauNen, &mauSoc, 30.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__SOC;
   soLuongVatThe++;
   
   viTriNui.y += 56.667f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 120.0f, 150.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriNui );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauNen, &mauSoc, 30.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__SOC;
   soLuongVatThe++;
   
   // ----
   viTriNui.y = doCaoMatDat + 50.0f;
   viTriNui.x = -150.0f;
   viTriNui.z = -2300.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 250.0f, 170.0f, 100.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriNui );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauNen, &mauSoc, 50.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__SOC;
   soLuongVatThe++;
   
   viTriNui.y += 100.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 0.0f, 80.0f, 40.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriNui );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauNen, &mauSoc, 30.0f, 0.5f, &trucSoc );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__SOC;
   soLuongVatThe++;

   return soLuongVatThe;
}

unsigned short datCauThuyTinh( VatThe *danhSachVat, float doCaoMatDat ) {
 
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mauTrang;
   mauTrang.d = 1.0f;   mauTrang.l = 1.0f;   mauTrang.x = 1.0f;   mauTrang.dd = 0.55f;   mauTrang.p = 0.3f;
   
   Mau mauTim;
   mauTim.d = 0.2f;   mauTim.l = 0.0f;   mauTim.x = 1.0f;   mauTim.dd = 0.85f;   mauTim.p = 0.3f;

   
   unsigned short soLuongVatThe = 0;

   float mangViTri_x[] = {
      150.0f, 150.0f, 150.0f, 150.0f, 150.0f,
      150.0f, 150.0f, 140.0f, 130.0f, 120.0f,
      110.0f, 100.0f, 90.0f,  90.0f,  90.0f,
       90.0f,  90.0f, 90.0f,  90.0f,  80.0f,
       70.0f,  60.0f, 50.0f,  40.0f,  30.0f,
       30.0f,  30.0f, 30.0f,  30.0f,  30.0f,
       30.0f,  30.0f};
   float mangViTri_z[] = {
      -155.0f, -165.0f, -175.0f, -185.0f, -195.0f,
      -205.0f, -215.0f, -215.0f, -215.0f, -215.0f,
      -215.0f, -215.0f, -215.0f, -225.0f, -235.0f,
      -245.0f, -255.0f, -265.0f, -275.0f, -275.0f,
      -275.0f, -275.0f, -275.0f, -275.0f, -275.0f,
      -285.0f, -295.0f, -305.0f, -315.0f, -325.0f,
      -335.0f, -345.0f};
   
   unsigned chiSoViTri = 0;   // chỉ số vị trí
   
   while( chiSoViTri < 32 ) {

      Vecto viTriThanhPhan;
      viTriThanhPhan.x = mangViTri_x[chiSoViTri];
      viTriThanhPhan.z = mangViTri_z[chiSoViTri];
      viTriThanhPhan.y = doCaoMatDat - 1.0f;
      
      if( chiSoViTri & 0x01 ) {
         mauTrang.d = 0.82f;
         mauTrang.l = 0.71f;
      }
      else {
         mauTrang.d = 1.00f;
         mauTrang.l = 1.00f;
      }
 
      // ---- mặt trên
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 10.0f, 2.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 1.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriThanhPhan );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;

      // ---- mặt trên
      viTriThanhPhan.y -= 1.5f;
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 8.0f, 1.0f, 8.0f, &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 1.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriThanhPhan );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTim );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      viTriThanhPhan.y -= 1.0f;
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 9.5f, 1.0f, 9.5f, &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 1.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriThanhPhan );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
 
      // ---- mặt dưới
      viTriThanhPhan.y -= 1.0f;
      danhSachVat[soLuongVatThe].hinhDang.hinhChop = datHinhChop( 2.5f, 4.0f, 2.0f, 4, &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CHOP;
      danhSachVat[soLuongVatThe].chietSuat = 1.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriThanhPhan );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      viTriThanhPhan.y -= 1.5f;
      danhSachVat[soLuongVatThe].hinhDang.hinhChop = datHinhChop( 0.0f, 2.0f, 3.0f, 4, &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CHOP;
      danhSachVat[soLuongVatThe].chietSuat = 1.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriThanhPhan );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTim );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;

      chiSoViTri++;
   }
   
   // ---- các cột
   float mangViTriCot_x[] = {
      145.0f, 155.0f,
      145.0f, 155.0f,
      145.0f, 155.0f,
      145.0f, 155.0f,
      145.0f, 155.0f, // 10
      145.0f, 155.0f,
      145.0f, 155.0f,
      145.0f, 155.0f,

      135.0f, 135.0f,
      125.0f, 125.0f, // 20
      115.0f, 115.0f,
      105.0f, 105.0f,
       95.0f,  95.0f,
       85.0f,  85.0f,

       85.0f, 95.0f,  // 30
       85.0f, 95.0f,
       85.0f, 95.0f,
       85.0f, 95.0f,
       85.0f, 95.0f,
       85.0f, 95.0f,  // 40

       75.0f, 75.0f,
       65.0f, 65.0f,
       55.0f, 55.0f,
       45.0f, 45.0f,
       35.0f, 35.0f,  // 50
       25.0f, 25.0f,

       25.0f, 35.0f,
       25.0f, 35.0f,
       25.0f, 35.0f,
       25.0f, 35.0f,  // 60
       25.0f, 35.0f,
       25.0f, 35.0f,
       25.0f, 35.0f,
   };
   float mangViTriCot_z[] = {
      -150.0f, -150.0f,
      -160.0f, -160.0f,
      -170.0f, -170.0f,
      -180.0f, -180.0f,
      -190.0f, -190.0f, // 10
      -200.0f, -200.0f,
      -210.0f, -210.0f,
      -220.0f, -220.0f,

      -210.0f, -220.0f,
      -210.0f, -220.0f, // 20
      -210.0f, -220.0f,
      -210.0f, -220.0f,
      -210.0f, -220.0f,
      -210.0f, -220.0f,
      
      -230.0f, -230.0f, // 30
      -240.0f, -240.0f,
      -250.0f, -250.0f,
      -260.0f, -260.0f,
      -270.0f, -270.0f,
      -280.0f, -280.0f, // 40
      
      -270.0f, -280.0f,
      -270.0f, -280.0f,
      -270.0f, -280.0f,
      -270.0f, -280.0f,
      -270.0f, -280.0f, // 50
      -270.0f, -280.0f,
      
      -290.0f, -290.0f,
      -300.0f, -300.0f,
      -310.0f, -310.0f,
      -320.0f, -320.0f, // 60
      -330.0f, -330.0f,
      -340.0f, -340.0f,
      -350.0f, -350.0f,
   };
   
   mauTim.dd = 0.85f;
   chiSoViTri = 0;
   while ( chiSoViTri < 66 ) {
      Vecto viTriThanhPhan;
      viTriThanhPhan.x = mangViTriCot_x[chiSoViTri];
      viTriThanhPhan.z = mangViTriCot_z[chiSoViTri];
      viTriThanhPhan.y = doCaoMatDat - 1.0f;

      danhSachVat[soLuongVatThe].hinhDang.hinhLangTru = datHinhLangTru( 1.0f, 8.0f, 4, &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_LANG_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriThanhPhan );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTim );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      viTriThanhPhan.y += 4.5f;
      danhSachVat[soLuongVatThe].hinhDang.hinhLangTru = datHinhLangTru( 0.8f, 1.0f, 4, &(danhSachVat[soLuongVatThe].baoBiVT));
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_LANG_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTriThanhPhan );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTim );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;

      chiSoViTri++;
   }
   
   return soLuongVatThe;
}

#pragma mark ---- NÂNG CẤP PHIM TRƯỜNG 2
void nangCapPhimTruong2( PhimTruong *phimTruong ) {
   
   //   printf( "phimTruong->soHoatHinhDau; %d\n", phimTruong->soHoatHinhDau );
   nangCapPhimTruong2_mayQuayPhim( phimTruong );
   nangCapPhimTruong2_nhanVat( phimTruong, phimTruong->soHoatHinhDau );
   
   // ---- tăng số hoạt hình
   phimTruong->soHoatHinhDau++;
}

void nangCapPhimTruong2_mayQuayPhim( PhimTruong *phimTruong ) {
   
   unsigned short soHoatHinh = phimTruong->soHoatHinhDau;
   MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);
   
   if( soHoatHinh < 170 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 261.0f;
      bezier.diemQuanTri[0].y = 70.0f;
      bezier.diemQuanTri[0].z = 303.0f;
      
      bezier.diemQuanTri[1].x = 237.0f;
      bezier.diemQuanTri[1].y =  65.0f;
      bezier.diemQuanTri[1].z = 217.0f;
      
      bezier.diemQuanTri[2].x = 195.0f;
      bezier.diemQuanTri[2].y = 60.7f;
      bezier.diemQuanTri[2].z = 170.8f;
      
      bezier.diemQuanTri[3].x = 170.0f;
      bezier.diemQuanTri[3].y = 50.0f;
      bezier.diemQuanTri[3].z = 160.0f;
      float buoc = soHoatHinh/170.0f;
      
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;
      
      // ---- tính hướng
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      donViHoa( &tiepTuyen );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &tiepTuyen );
      //      printf( "%d (%5.3f) viTriMayQuayPhim %5.3f %5.3f %5.3f\n", soHoatHinh, buoc, viTriMayQuayPhim.x, viTriMayQuayPhim.y, viTriMayQuayPhim.z );
      
   }
   else if( soHoatHinh < 320 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 170.0f;
      bezier.diemQuanTri[0].y = 50.0f;
      bezier.diemQuanTri[0].z = 160.0f;
      
      bezier.diemQuanTri[1].x = 153.0f;
      bezier.diemQuanTri[1].y = 42.7f;
      bezier.diemQuanTri[1].z = 152.6f;
      
      bezier.diemQuanTri[2].x = 133.0f;
      bezier.diemQuanTri[2].y = 35.0f;
      bezier.diemQuanTri[2].z = 160.5f;
      
      bezier.diemQuanTri[3].x = 127.5f;
      bezier.diemQuanTri[3].y = 33.0f;
      bezier.diemQuanTri[3].z = 164.0f;
      float buoc = (soHoatHinh - 170)/150.0f;
      
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;
      
      // ---- tính hướng
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      donViHoa( &tiepTuyen );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &tiepTuyen );
      //      printf( "%d (%5.3f) viTriMayQuayPhim %5.3f %5.3f %5.3f\n", soHoatHinh, buoc, viTriMayQuayPhim.x, viTriMayQuayPhim.y, viTriMayQuayPhim.z );
   }
   else if( soHoatHinh < 400 ) {  // đời trái banh hạ xuống
      
      mayQuayPhim->viTri.x = 127.5f;
      mayQuayPhim->viTri.y = 33.0f;
      mayQuayPhim->viTri.z = 164.0f;

      Vecto huongNhin;
      huongNhin.x = -17.078f;
      huongNhin.y = -6.227f;
      huongNhin.z = 10.673f;
  
      donViHoa( &huongNhin );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 455 ) {  // đời trái banh hạ xuống
      
      mayQuayPhim->viTri.x = 76.0f;
      mayQuayPhim->viTri.y = 30.0f;
      mayQuayPhim->viTri.z = 178.0f;
      
      Vecto huongNhin;
      huongNhin.x = 0.500f;
      huongNhin.y = -0.190f;
      huongNhin.z = -0.327f;
      
      donViHoa( &huongNhin );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 620 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 76.0f;
      bezier.diemQuanTri[0].y = 30.0f;
      bezier.diemQuanTri[0].z = 178.0f;
      
      bezier.diemQuanTri[1].x = 83.2f;
      bezier.diemQuanTri[1].y = 30.0f;
      bezier.diemQuanTri[1].z = 175.4f;
      
      bezier.diemQuanTri[2].x = 129.8f;
      bezier.diemQuanTri[2].y = 27.0f;
      bezier.diemQuanTri[2].z = 147.0f;
      
      bezier.diemQuanTri[3].x = 142.8f;
      bezier.diemQuanTri[3].y = 25.5f;
      bezier.diemQuanTri[3].z = 117.0f;
      float buoc = (soHoatHinh - 455)/165.0f;
   
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;

      // ---- tính hướng
/*      VatThe *vaiChanh = &(phimTruong->danhSachVatThe[kNHAN_VAT__VAI_CHANH]);
      Vecto huongVaiChan;
      huongVaiChan.x = vaiChanh->dich[12] - viTriMayQuayPhim.x;
      huongVaiChan.y = vaiChanh->dich[13] - viTriMayQuayPhim.y;
      huongVaiChan.z = vaiChanh->dich[14] - viTriMayQuayPhim.z;
      donViHoa( &huongVaiChan ); */

      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      float tocDo = sqrtf( tiepTuyen.x*tiepTuyen.x + tiepTuyen.y*tiepTuyen.y + tiepTuyen.z*tiepTuyen.z )/165.0f;
      printf( "mayQuayPhim %d  vanToc %5.3f\n", soHoatHinh, tocDo );
      donViHoa( &tiepTuyen );

      Vecto huongNhin;
      huongNhin.x = 0.500f*(1.0f - buoc) + tiepTuyen.x*buoc;
      huongNhin.y = -0.190f*(1.0f - buoc)*(1.0f - buoc) + -0.300f*buoc*buoc;
      huongNhin.z = -0.327f*(1.0f - buoc) + tiepTuyen.z*buoc;

      donViHoa( &huongNhin );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
      printf( "%d  buoc %5.3f  huongNhin %5.3f %5.3f %5.3f\n", soHoatHinh, buoc, huongNhin.x, huongNhin.y, huongNhin.z );
   }
   else if( soHoatHinh < 755 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 142.8f;
      bezier.diemQuanTri[0].y = 25.5f;
      bezier.diemQuanTri[0].z = 117.0f;
      
      bezier.diemQuanTri[1].x = 154.5f;
      bezier.diemQuanTri[1].y = 25.5f;
      bezier.diemQuanTri[1].z = 92.9f;
      
      bezier.diemQuanTri[2].x = 157.0f;
      bezier.diemQuanTri[2].y = 21.3f;
      bezier.diemQuanTri[2].z = 77.0f;
      
      bezier.diemQuanTri[3].x = 157.7f;
      bezier.diemQuanTri[3].y = 21.3f;
      bezier.diemQuanTri[3].z = 61.7f;
      float buoc = (soHoatHinh - 620)/135.0f;

      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;

      // ---- tính hướnh nhìn
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      float tocDo = sqrtf( tiepTuyen.x*tiepTuyen.x + tiepTuyen.y*tiepTuyen.y + tiepTuyen.z*tiepTuyen.z )/135.0f;
      printf( "mayQuayPhim %d  buoc %5.3f  tocDo %5.3f\n", soHoatHinh, buoc, tocDo );
      donViHoa( &tiepTuyen );
      
      Vecto huongNhin;
      huongNhin.x = 0.381f*(1.0f - buoc) + tiepTuyen.x*buoc;
      huongNhin.y = -0.288*(1.0f - buoc) - 0.050f*buoc;
      huongNhin.z = -0.879f*(1.0f - buoc) + tiepTuyen.z*buoc;
      printf( "  huongNhin %5.3f %5.3f %5.3f\n", huongNhin.x, huongNhin.y, huongNhin.z );

      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 800 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 157.7f;
      bezier.diemQuanTri[0].y = 21.3f;
      bezier.diemQuanTri[0].z = 61.7f;
      
      bezier.diemQuanTri[1].x = 158.4f;
      bezier.diemQuanTri[1].y = 21.3f;
      bezier.diemQuanTri[1].z = 53.7f;
      
      bezier.diemQuanTri[2].x = 159.1f;
      bezier.diemQuanTri[2].y = 21.3f;
      bezier.diemQuanTri[2].z = 42.4f;
      
      bezier.diemQuanTri[3].x = 159.1f;
      bezier.diemQuanTri[3].y = 21.3f;
      bezier.diemQuanTri[3].z = 35.7f;
      float buoc = (soHoatHinh - 755)/45.0f;
      
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;
      
      // ---- tính hướnh nhìn
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      float tocDo = sqrtf( tiepTuyen.x*tiepTuyen.x + tiepTuyen.y*tiepTuyen.y + tiepTuyen.z*tiepTuyen.z )/45.0f;
      printf( "mayQuayPhim %d  tocDo %5.3f\n", soHoatHinh, tocDo );
      donViHoa( &tiepTuyen );
      
      Vecto huongNhin;
      huongNhin.x = 0.047f*(1.0f - buoc) + tiepTuyen.x*buoc;
      huongNhin.y = -0.050f;
      huongNhin.z = -0.999f*(1.0f - buoc) + tiepTuyen.z*buoc;
      printf( "  huongNhin %5.3f %5.3f %5.3f\n", huongNhin.x, huongNhin.y, huongNhin.z );

      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 880 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 159.1f;
      bezier.diemQuanTri[0].y = 21.3f;
      bezier.diemQuanTri[0].z = 35.7f;
      
      bezier.diemQuanTri[1].x = 159.1f;
      bezier.diemQuanTri[1].y = 21.3f;
      bezier.diemQuanTri[1].z = 23.5f;
      
      bezier.diemQuanTri[2].x = 156.8f;
      bezier.diemQuanTri[2].y = 21.3f;
      bezier.diemQuanTri[2].z = 20.3f;
      
      bezier.diemQuanTri[3].x = 154.0f;
      bezier.diemQuanTri[3].y = 21.3f;
      bezier.diemQuanTri[3].z = 16.0f;
      float buoc = (soHoatHinh - 800)/80.0f;
      
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;
      
      // ---- tính hướng nhìn
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      float tocDo = sqrtf( tiepTuyen.x*tiepTuyen.x + tiepTuyen.y*tiepTuyen.y + tiepTuyen.z*tiepTuyen.z )/80.0f;
      printf( "mayQuayPhim %d  tocDo %5.3f\n", soHoatHinh, tocDo );
      donViHoa( &tiepTuyen );

      Vecto huongNhin;
      huongNhin.x = tiepTuyen.x;
      huongNhin.y = -0.050f;
      huongNhin.z = tiepTuyen.z;
      printf( "  buoc %5.3f  huongNhin %5.3f %5.3f %5.3f\n", buoc, huongNhin.x, huongNhin.y, huongNhin.z );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 945 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 154.0f;
      bezier.diemQuanTri[0].y = 21.3f;
      bezier.diemQuanTri[0].z = 16.0f;
      
      bezier.diemQuanTri[1].x = 152.3f;
      bezier.diemQuanTri[1].y = 21.3f;
      bezier.diemQuanTri[1].z = 12.5f;
      
      bezier.diemQuanTri[2].x = 144.1f;
      bezier.diemQuanTri[2].y = 21.3f;
      bezier.diemQuanTri[2].z = 7.4f;
      
      bezier.diemQuanTri[3].x = 151.0f;
      bezier.diemQuanTri[3].y = 21.3f;
      bezier.diemQuanTri[3].z = 1.0f;
      float buoc = (soHoatHinh - 880)/65.0f;
      
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;
      
      // ---- tính hướng nhìn
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      float tocDo = sqrtf( tiepTuyen.x*tiepTuyen.x + tiepTuyen.y*tiepTuyen.y + tiepTuyen.z*tiepTuyen.z )/65.0f;
      printf( "mayQuayPhim %d  tocDo %5.3f\n", soHoatHinh, tocDo );
      donViHoa( &tiepTuyen );
      
      Vecto huongNhin;
      huongNhin.x = -0.546f*(1.0f - buoc) + tiepTuyen.x*buoc;
      huongNhin.y = -0.050f;
      huongNhin.z = -0.838f*(1.0f - buoc) + tiepTuyen.z*buoc;
      printf( "  buoc %5.3f  huongNhin %5.3f %5.3f %5.3f\n", buoc, huongNhin.x, huongNhin.y, huongNhin.z );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 995 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 151.0f;
      bezier.diemQuanTri[0].y = 21.3f;
      bezier.diemQuanTri[0].z = 1.0f;
      
      bezier.diemQuanTri[1].x = 156.6f;
      bezier.diemQuanTri[1].y = 21.3f;
      bezier.diemQuanTri[1].z = -3.2f;
      
      bezier.diemQuanTri[2].x = 155.8f;
      bezier.diemQuanTri[2].y = 21.3f;
      bezier.diemQuanTri[2].z = -7.6f;
      
      bezier.diemQuanTri[3].x = 150.3f;
      bezier.diemQuanTri[3].y = 21.3f;
      bezier.diemQuanTri[3].z = -10.3f;
      float buoc = (soHoatHinh - 945)/50.0f;
      
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;
      
      // ---- tính hướng nhìn
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      float tocDo = sqrtf( tiepTuyen.x*tiepTuyen.x + tiepTuyen.y*tiepTuyen.y + tiepTuyen.z*tiepTuyen.z )/50.0f;
      printf( "mayQuayPhim %d  tocDo %5.3f\n", soHoatHinh, tocDo );
      donViHoa( &tiepTuyen );
      
      Vecto huongNhin;
      huongNhin.x = 0.733f*(1.0f - buoc) + tiepTuyen.x*buoc;
      huongNhin.y = -0.050f;
      huongNhin.z = -0.680f*(1.0f - buoc) + tiepTuyen.z*buoc;
      printf( "  buoc %5.3f  huongNhin %5.3f %5.3f %5.3f\n", buoc, huongNhin.x, huongNhin.y, huongNhin.z );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1045 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = 150.3f;
      bezier.diemQuanTri[0].y = 21.3f;
      bezier.diemQuanTri[0].z = -10.3f;
      
      bezier.diemQuanTri[1].x = 145.4f;
      bezier.diemQuanTri[1].y = 21.3f;
      bezier.diemQuanTri[1].z = -13.4f;
      
      bezier.diemQuanTri[2].x = 148.3f;
      bezier.diemQuanTri[2].y = 21.3f;
      bezier.diemQuanTri[2].z = -18.2f;
      
      bezier.diemQuanTri[3].x = 153.2f;
      bezier.diemQuanTri[3].y = 21.3f;
      bezier.diemQuanTri[3].z = -21.2f;
      float buoc = (soHoatHinh - 995)/50.0f;
      
      // ---- tính vị trí
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTriMayQuayPhim.x;
      mayQuayPhim->viTri.y = viTriMayQuayPhim.y;
      mayQuayPhim->viTri.z = viTriMayQuayPhim.z;
      
      // ---- tính hướng nhìn
      Vecto tiepTuyen = tinhVanTocBezier3C( &bezier, buoc );  // vận tốc soongๆ với đường Bezier
      float tocDo = sqrtf( tiepTuyen.x*tiepTuyen.x + tiepTuyen.y*tiepTuyen.y + tiepTuyen.z*tiepTuyen.z )/50.0f;
      printf( "mayQuayPhim %d  tocDo %5.3f\n", soHoatHinh, tocDo );
      donViHoa( &tiepTuyen );
      
      Vecto huongNhin;
      huongNhin.x = tiepTuyen.x;
      huongNhin.y = -0.050f;
      huongNhin.z = tiepTuyen.z;
      printf( "  buoc %5.3f  huongNhin %5.3f %5.3f %5.3f\n", buoc, huongNhin.x, huongNhin.y, huongNhin.z );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1200 ) {  // xem vai chánh từ trên trong rừng mặt hyperbol
      mayQuayPhim->viTri.x = 170.0f - (soHoatHinh - 1045)*0.1f;
      mayQuayPhim->viTri.y = 35.0f;
      mayQuayPhim->viTri.z = -40.0f - (soHoatHinh - 1045)*0.3f;
      Vecto huongNhin;
      huongNhin.x = -0.8f;
      huongNhin.y = -1.0f;
      huongNhin.z = 0.6f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1300 ) {
      mayQuayPhim->viTri.x = 300.0f;
      mayQuayPhim->viTri.y = 27.0f;
      mayQuayPhim->viTri.z = -250.0f;
      Vecto huongNhin;
      huongNhin.x = -1.0f;
      huongNhin.y = -0.05f;
      huongNhin.z = 0.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   // ----
   else if( soHoatHinh < 1500 ) {
      
      mayQuayPhim->viTri.x = 300.0f;
      mayQuayPhim->viTri.y = 70.0f;
      mayQuayPhim->viTri.z = -200.0f;
      Vecto huongNhin;
      huongNhin.x = -2.0f;
      huongNhin.y = -0.5f;
      huongNhin.z = -0.3f;
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
      
   }
   else if( soHoatHinh < 1650 ) {
      
      mayQuayPhim->viTri.x = 0.0f;
      mayQuayPhim->viTri.y = 200.0f;
      mayQuayPhim->viTri.z = -240.0f;
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;
      mayQuayPhim->kieuChieu = kKIEU_CHIEU__CU_TUYEN;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1700 ) {
      
      mayQuayPhim->viTri.x = 100.0f;
      mayQuayPhim->viTri.y = 23.5f;
      mayQuayPhim->viTri.z = -400.0f;
      Vecto huongNhin;
      huongNhin.x = -0.5f;
      huongNhin.y = 0.0f;
      huongNhin.z = -1.0f;
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   /*
    // ---- cho xem từ trời xuống
    mayQuayPhim->viTri.x = 50.0f;//800.0f - 2.0f*soHoatHinh;
    mayQuayPhim->viTri.y = 280.0f;
    mayQuayPhim->viTri.z = -450.0f;
    
    Vecto huongNhin;
    huongNhin.x = -0.01f;
    huongNhin.y = -1.0f;
    huongNhin.z = -0.0f;  // 1,5 là vận tốc trái banh vai chánh và sao gai
    dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin ); */
}

void nangCapPhimTruong2_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh ) {
   
   // ----
   nangCapVaiChanh_PT_2(  &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__VAI_CHANH]]), soHoatHinh );

   // ---- kiến lồng sao gai xanh
   nangCapKienLongSaoGaiXanh( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__KIEN_LONG_SAO_GAI_XANH]]), soHoatHinh );
   
   // ---- mặt hồ
   nangCapMatCacHo( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__MAT_HO_DAU]]), phimTruong->nhanVat[kNHAN_VAT__MAT_HO_CUOI] - phimTruong->nhanVat[kNHAN_VAT__MAT_HO_DAU], soHoatHinh );
   
   // ---- hình xuyên
   nangCapHinhXuyenXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__HINH_XUYEN_KHONG_LO_0]]), soHoatHinh, 0.01f, 0 );
   nangCapHinhXuyenXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__HINH_XUYEN_TRUNG_BINH_0]]), soHoatHinh, 0.02f, 1 );
   
   // ---- rừng mặt hyperbol
   nangCapRungMatHyperbol( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__RUNG_MAT_HYPERBOL_DAU]]), phimTruong->nhanVat[kNHAN_VAT__RUNG_MAT_HYPERBOL_CUOI] - phimTruong->nhanVat[kNHAN_VAT__RUNG_MAT_HYPERBOL_DAU], soHoatHinh );
   nangCapLocXoayPhai( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__LOC_XOAY_0]]), soHoatHinh );
   nangCapLocXoayPhai( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__LOC_XOAY_1]]), soHoatHinh );
   
   nangCapDongSong( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__VAT_THE_DONG_SONG_DAU]]), phimTruong->nhanVat[kNHAN_VAT__VAT_THE_DONG_SONG_CUOI] - phimTruong->nhanVat[kNHAN_VAT__VAT_THE_DONG_SONG_DAU], soHoatHinh );
   
}


void nangCapVaiChanh_PT_2( VatThe *vaiChanh, unsigned short soHoatHinh ) {
   
   // ---- vận tốc
   Vecto vanToc;
   float tocDo = 0.0f;
   Vecto trucXoay;
   trucXoay.x = -1.0f;    trucXoay.y = 0.0f;   trucXoay.z = 0.0;
   Quaternion quaternion = tinhXoayChoVatThe( &(vaiChanh->quaternion), trucXoay, 2.0f, vaiChanh->hinhDang.hinhCau.banKinh );
   //   printf( "hinhCauKhongLoXoay->hinhDang.hinhCau.banKinh %5.3f\n", hinhCauKhongLoXoay->hinhDang.hinhCau.banKinh );
   //   printf( "quaternion %5.3f %5.3f %5.3f %5.3f\n", quaternion.w, quaternion.x, quaternion.y, quaternion.z );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- vectơ thẳnh lên (cho tính trục xoay)
   Vecto phapThuyenMatDat;
   phapThuyenMatDat.x = 0.0f;   phapThuyenMatDat.y = 1.0f;   phapThuyenMatDat.z = 0.0f;

   Vecto viTriVaiChanh;
   viTriVaiChanh.x = 0.0f;   viTriVaiChanh.y = 20.7f;    viTriVaiChanh.z = 100.0f;
   if( soHoatHinh < 300 ) {  // mất két trong lốc xoay 
      float goc = soHoatHinh*0.3333f;
      viTriVaiChanh.x = -60.0f + kLOC_XOAY__VAN_TOC_X*soHoatHinh + 5.0f*cosf( goc );
      viTriVaiChanh.y = 30.0f + 0.7f;
      viTriVaiChanh.z = 340.0f + kLOC_XOAY__VAN_TOC_Z*soHoatHinh + 5.0f*sinf( goc );
   }
   else if( soHoatHinh < 320 ) {  // lốc xoay thả xuống
      viTriVaiChanh.y = 30.0f + 0.7f - (soHoatHinh - 300)*0.5f;  // 0.1 = 1/10
      
      float banKinh = 5.0f*sinf((320 - soHoatHinh)*1.5707963f*0.05f);
      float goc = soHoatHinh*0.3333f;
      viTriVaiChanh.x = -60.0f + kLOC_XOAY__VAN_TOC_X*soHoatHinh + banKinh*cosf( goc );
      viTriVaiChanh.z = 340.0f + kLOC_XOAY__VAN_TOC_Z*soHoatHinh + banKinh*sinf( goc );
   }
   else if( soHoatHinh < 380 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 100.0f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = 180.0f;
      duongDi.diemQuanTri[1].x =  93.0f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = 179.5f;
      duongDi.diemQuanTri[2].x =  90.0f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = 172.0f;
      duongDi.diemQuanTri[3].x =  92.8f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = 165.1f;
      
      float thamSoBezier = (float)(soHoatHinh - 320)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
//      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 420 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x =  92.8f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = 165.1f;
      duongDi.diemQuanTri[1].x =  95.0f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = 160.9f;
      duongDi.diemQuanTri[2].x = 106.2f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = 159.8f;
      duongDi.diemQuanTri[3].x = 105.3f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = 168.3f;
      
      float thamSoBezier = (float)(soHoatHinh - 380)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
//      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 440 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 105.3f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = 168.3f;
      duongDi.diemQuanTri[1].x = 105.0f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = 173.0f;
      duongDi.diemQuanTri[2].x = 98.9f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = 174.0f;
      duongDi.diemQuanTri[3].x = 95.7f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = 171.0f;
      
      float thamSoBezier = (float)(soHoatHinh - 420)/20.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/20.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 470 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 95.7f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = 171.0f;
      duongDi.diemQuanTri[1].x = 91.1f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = 166.7f;
      duongDi.diemQuanTri[2].x = 90.6f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = 154.4f;
      duongDi.diemQuanTri[3].x = 100.2f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = 146.3f;
      
      float thamSoBezier = (float)(soHoatHinh - 440)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
//      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 500 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 100.2f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = 146.3f;
      duongDi.diemQuanTri[1].x = 109.0f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = 140.6f;
      duongDi.diemQuanTri[2].x = 117.5f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = 141.8f;
      duongDi.diemQuanTri[3].x = 123.9f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = 147.3f;
      
      float thamSoBezier = (float)(soHoatHinh - 470)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 560 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 123.9f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = 147.3f;
      duongDi.diemQuanTri[1].x = 135.0f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = 160.4f;
      duongDi.diemQuanTri[2].x = 133.9f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = 132.0f;
      duongDi.diemQuanTri[3].x = 140.6f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = 124.8f;
      
      float thamSoBezier = (float)(soHoatHinh - 500)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
//      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 650 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 140.6f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = 124.8f;
      duongDi.diemQuanTri[1].x = 154.8f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = 114.0f;
      duongDi.diemQuanTri[2].x = 138.6f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = 98.6f;
      duongDi.diemQuanTri[3].x = 152.6f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = 90.3f;
      
      float thamSoBezier = (float)(soHoatHinh - 560)/90.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/90.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
//      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 750 ) {

      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 152.6f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z =  90.3f;
      duongDi.diemQuanTri[1].x = 161.3f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z =  75.7f;
      duongDi.diemQuanTri[2].x = 154.0f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z =  71.7f;
      duongDi.diemQuanTri[3].x = 155.5f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z =  52.5f;
      
      float thamSoBezier = (float)(soHoatHinh - 650)/100.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/100.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
//      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 790 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 155.5f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z =  52.5f;
      duongDi.diemQuanTri[1].x = 155.2f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z =  45.5f;
      duongDi.diemQuanTri[2].x = 158.5f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z =  37.4f;
      duongDi.diemQuanTri[3].x = 159.9f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z =  31.2f;
      
      float thamSoBezier = (float)(soHoatHinh - 750)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 850 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 159.9f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z =  31.2f;
      duongDi.diemQuanTri[1].x = 161.9f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z =  21.7f;
      duongDi.diemQuanTri[2].x = 154.0f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z =  21.7f;
      duongDi.diemQuanTri[3].x = 154.1f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z =  17.1f;
      
      float thamSoBezier = (float)(soHoatHinh - 790)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 905 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 154.1f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z =  17.1f;
      duongDi.diemQuanTri[1].x = 154.2f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z =  12.9f;
      duongDi.diemQuanTri[2].x = 146.9f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z =  10.6f;
      duongDi.diemQuanTri[3].x = 148.1f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z =  5.1f;
      
      float thamSoBezier = (float)(soHoatHinh - 850)/55.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/55.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 950 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 148.1f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z =  5.1f;
      duongDi.diemQuanTri[1].x = 149.5f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z =  0.5f;
      duongDi.diemQuanTri[2].x = 154.8f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -0.6f;
      duongDi.diemQuanTri[3].x = 154.8f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -4.6f;
      
      float thamSoBezier = (float)(soHoatHinh - 905)/45.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 990 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 154.8f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -4.6f;
      duongDi.diemQuanTri[1].x = 154.8f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -8.6f;
      duongDi.diemQuanTri[2].x = 147.6f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -8.6f;
      duongDi.diemQuanTri[3].x = 147.6f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -14.7f;
      
      float thamSoBezier = (float)(soHoatHinh - 950)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1030 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 147.6f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -14.7f;
      duongDi.diemQuanTri[1].x = 147.6f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -19.7f;
      duongDi.diemQuanTri[2].x = 154.6f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -20.1f;
      duongDi.diemQuanTri[3].x = 155.0f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -25.2f;
      
      float thamSoBezier = (float)(soHoatHinh - 990)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1065 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 155.0f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -25.2f;
      duongDi.diemQuanTri[1].x = 155.1f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -30.5f;
      duongDi.diemQuanTri[2].x = 160.3f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -29.3f;
      duongDi.diemQuanTri[3].x = 160.1f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -35.7f;
      
      float thamSoBezier = (float)(soHoatHinh - 1030)/35.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/35.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1095 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 160.1f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -35.7f;
      duongDi.diemQuanTri[1].x = 160.3f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -40.8f;
      duongDi.diemQuanTri[2].x = 154.7f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -39.7f;
      duongDi.diemQuanTri[3].x = 154.0f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -46.1f;
      
      float thamSoBezier = (float)(soHoatHinh - 1065)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1120 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 154.0f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -46.1f;
      duongDi.diemQuanTri[1].x = 153.8f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -51.0f;
      duongDi.diemQuanTri[2].x = 148.5f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -49.6f;
      duongDi.diemQuanTri[3].x = 147.9f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -56.4f;
      
      float thamSoBezier = (float)(soHoatHinh - 1095)/25.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/25.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1150 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 147.9f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -56.4f;
      duongDi.diemQuanTri[1].x = 147.3f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -61.8f;
      duongDi.diemQuanTri[2].x = 142.4f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -60.1f;
      duongDi.diemQuanTri[3].x = 141.9f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -65.9f;
      
      float thamSoBezier = (float)(soHoatHinh - 1120)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1180 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 141.9f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -65.9f;
      duongDi.diemQuanTri[1].x = 141.3f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -72.4f;
      duongDi.diemQuanTri[2].x = 136.0f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -69.9f;
      duongDi.diemQuanTri[3].x = 135.9f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -76.8f;
      
      float thamSoBezier = (float)(soHoatHinh - 1150)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1210 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 135.9f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -76.8f;
      duongDi.diemQuanTri[1].x = 135.9f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -82.9f;
      duongDi.diemQuanTri[2].x = 144.1f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -81.1f;
      duongDi.diemQuanTri[3].x = 143.1f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -89.9f;
      
      float thamSoBezier = (float)(soHoatHinh - 1180)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1280 ) {
      
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 143.1f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -89.9f;
      duongDi.diemQuanTri[1].x = 142.3f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -107.4f;
      duongDi.diemQuanTri[2].x = 147.0f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -128.8f;
      duongDi.diemQuanTri[3].x = 150.8f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -152.9f;
      
      float thamSoBezier = (float)(soHoatHinh - 1210)/70.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/70.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      //      printf( "thamSo %5.3f  ", thamSoBezier );
   }
   else if( soHoatHinh < 1340 ) {
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 150.8f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -152.9f;
      duongDi.diemQuanTri[1].x = 154.5f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -174.0f;
      duongDi.diemQuanTri[2].x = 153.3f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -205.5f;
      duongDi.diemQuanTri[3].x = 149.0f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -212.0f;
      
      float thamSoBezier = (float)(soHoatHinh - 1280)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1400 ) {
      Bezier duongDi;
      duongDi.diemQuanTri[0].x = 149.0f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -212.0f;
      duongDi.diemQuanTri[1].x = 144.5f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -219.3f;
      duongDi.diemQuanTri[2].x = 104.8f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -213.3f;
      duongDi.diemQuanTri[3].x =  95.8f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -217.3f;
      
      float thamSoBezier = (float)(soHoatHinh - 1340)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1460 ) {
      Bezier duongDi;
      duongDi.diemQuanTri[0].x =  95.8f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -217.3f;
      duongDi.diemQuanTri[1].x =  85.5f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -220.8f;
      duongDi.diemQuanTri[2].x =  97.0f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -259.8f;
      duongDi.diemQuanTri[3].x =  90.3f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -272.0f;
      
      float thamSoBezier = (float)(soHoatHinh - 1400)/50.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/50.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1520 ) {
      Bezier duongDi;
      duongDi.diemQuanTri[0].x =  90.3f;  duongDi.diemQuanTri[0].y = 20.7f;  duongDi.diemQuanTri[0].z = -272.0f;
      duongDi.diemQuanTri[1].x =  26.5f;  duongDi.diemQuanTri[1].y = 20.7f;  duongDi.diemQuanTri[1].z = -287.5f;
      duongDi.diemQuanTri[2].x =  32.5f;  duongDi.diemQuanTri[2].y = 20.7f;  duongDi.diemQuanTri[2].z = -315.5f;
      duongDi.diemQuanTri[3].x =  31.5f;  duongDi.diemQuanTri[3].y = 20.7f;  duongDi.diemQuanTri[3].z = -344.0f;
      
      float thamSoBezier = (float)(soHoatHinh - 1460)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&duongDi, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &duongDi, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }

   printf( "%d viTriVaiChanh %5.3f %5.3f %5.3f  tocDo %5.3f\n", soHoatHinh, viTriVaiChanh.x, viTriVaiChanh.y, viTriVaiChanh.z, tocDo );
   quaternion = tinhXoayChoVatThe( &(vaiChanh->quaternion), trucXoay, tocDo, 0.7f );
   datBienHoaChoVat( vaiChanh, &phongTo, &quaternion, &viTriVaiChanh );
}


void nangCapMatCacHo( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh ) {
   
   unsigned short soHo = 0;
   while ( soHo < soLuongVatThe ) {
      
      danhSachVat[soHo].hinhDang.matSong.thoiGian++;
      soHo++;
   }
   
}

void nangCapHinhXuyenXoay( VatThe *hinhXuyenXoay, unsigned short soHoatHinh, float vanTocXoay, unsigned char huongXoay ) {
   
   Vecto trucXoay;
   trucXoay.x = 1.0f;   trucXoay.y = 0.0f;   trucXoay.z = 0.0f;
   
   Quaternion quaternionXoay;
   if( huongXoay )
      quaternionXoay = datQuaternionTuVectoVaGocQuay( &trucXoay, -vanTocXoay );
   else
      quaternionXoay = datQuaternionTuVectoVaGocQuay( &trucXoay, vanTocXoay );
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTriHinhXuyenXoay;
   viTriHinhXuyenXoay.x = hinhXuyenXoay->dich[12];
   viTriHinhXuyenXoay.y = hinhXuyenXoay->dich[13];
   viTriHinhXuyenXoay.z = hinhXuyenXoay->dich[14];
   
   Quaternion quaternionKetQua = nhanQuaternionVoiQuaternion( &(hinhXuyenXoay->quaternion), &quaternionXoay );
   
   datBienHoaChoVat( hinhXuyenXoay, &phongTo, &quaternionKetQua, &viTriHinhXuyenXoay );
}


void nangCapRungMatHyperbol( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh ) {
   
   unsigned short soMatHyperbol = 0;
   while ( soMatHyperbol < soLuongVatThe ) {
      unsigned short soHoatHinh = danhSachVat[soMatHyperbol].soHoatHinh;
      if( soHoatHinh < 20 ) {
         danhSachVat[soMatHyperbol].hinhDang.matHyperbol.banKinhBinh += 0.2f;
         danhSachVat[soMatHyperbol].soHoatHinh++;
      }
      else if( soHoatHinh < 40 ) {
         danhSachVat[soMatHyperbol].hinhDang.matHyperbol.banKinhBinh -= 0.2f;
         danhSachVat[soMatHyperbol].soHoatHinh++;
      }
      
      if( soHoatHinh == 40 )
         danhSachVat[soMatHyperbol].soHoatHinh = 0;
      
      // ---- tính lại hợp bao bì
      tinhBaoBiMatHyperbol( &(danhSachVat[soMatHyperbol].hinhDang.matHyperbol), &(danhSachVat[soHoatHinh].baoBiVT) );
      soMatHyperbol++;
   }
}


void nangCapLocXoayPhai( VatThe *danhSachVat, unsigned short soHoatHinh ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   float goc = soHoatHinh*0.3333f;
   float chenhLech = 1.5f*sinf( soHoatHinh*0.5f );
   
   unsigned short soVat = 0;
   while ( soVat < kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY ) {
      
      Vecto viTriDau = danhSachVat[soVat].viTriDau;
      float banKinh = 7.0f + expf( (viTriDau.y - 20.0f)*0.04f ) + chenhLech;  // 100.0f là đố cao mặt đất
      
      // ==== bên này
      //      printf( "viTriDau %5.3f %5.3f %5.3f\n", viTriDau.x, viTriDau.y, viTriDau.z );
      
      // ---- tính vị trí mới
      float banKinhCos = banKinh*cosf( goc );
      float banKinhSin = banKinh*sinf( goc );
      
      // ---- nâng cấp vị tri
      
      viTriDau.x += kLOC_XOAY__VAN_TOC_X;
      viTriDau.z += kLOC_XOAY__VAN_TOC_Z;
      // ---- giữ vị tri mới
      danhSachVat[soVat].viTriDau = viTriDau;
      
      Vecto viTri = viTriDau;
      // ----
      viTri.x += banKinhCos;
      viTri.z += banKinhSin;
      datBienHoaChoVat( &(danhSachVat[soVat]), &phongTo, &quaternion, &viTri );
      
      // ==== bên kia
      // ---- nâng cấp vị tri
      viTriDau = danhSachVat[soVat+1].viTriDau;
      viTriDau.x += kLOC_XOAY__VAN_TOC_X;
      viTriDau.z += kLOC_XOAY__VAN_TOC_Z;
      //      printf( "viTriDau %5.3f %5.3f\n", viTriDau.x, viTriDau.z );
      // ---- giữ vị tri mới
      danhSachVat[soVat+1].viTriDau = viTriDau;
      
      viTri = viTriDau;
      // ----
      viTri.x -= banKinhCos;
      viTri.z -= banKinhSin;
      datBienHoaChoVat( &(danhSachVat[soVat + 1]), &phongTo, &quaternion, &viTri );
      
      // =========
      // ---- tính vị trí mới
      banKinhCos = banKinh*cosf( goc + 1.57080f );
      banKinhSin = banKinh*sinf( goc + 1.57080f );
      
      // ---- nâng cấp vị tri
      viTriDau = danhSachVat[soVat+2].viTriDau;
      viTriDau.x += kLOC_XOAY__VAN_TOC_X;
      viTriDau.z += kLOC_XOAY__VAN_TOC_Z;
      // ---- giữ vị tri mới
      danhSachVat[soVat+2].viTriDau = viTriDau;
      
      viTri = viTriDau;
      // ----
      viTri.x += banKinhCos;
      viTri.z += banKinhSin;
      datBienHoaChoVat( &(danhSachVat[soVat+2]), &phongTo, &quaternion, &viTri );
      
      // ==== bên kia
      // ---- nâng cấp vị tri
      viTriDau = danhSachVat[soVat+3].viTriDau;
      viTriDau.x += kLOC_XOAY__VAN_TOC_X;
      viTriDau.z += kLOC_XOAY__VAN_TOC_Z;
      //      printf( "viTriDau %5.3f %5.3f\n", viTriDau.x, viTriDau.z );
      // ---- giữ vị tri mới
      danhSachVat[soVat+3].viTriDau = viTriDau;
      
      viTri = viTriDau;
      // ----
      viTri.x -= banKinhCos;
      viTri.z -= banKinhSin;
      datBienHoaChoVat( &(danhSachVat[soVat + 3]), &phongTo, &quaternion, &viTri );
      
      goc += kLOC_XOAY__GOC_XOAN;
      soVat += 4;
   }
   //   printf( "ViTriLocXoay %5.3f %5.3f %5.3f\n", danhSachVat[0].viTriDau.x, danhSachVat[0].viTriDau.y, danhSachVat[0].viTriDau.z );
   
}


void nangCapKienLongSaoGaiXanh( VatThe *kienLongSaoGai, unsigned short soHoatHinh ) {
   
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;   trucXoay.y = 1.0f;   trucXoay.z = 0.0f;
   
   Quaternion xoay = datQuaternionTuVectoVaGocQuay( &trucXoay, 0.31415926f*0.1f*soHoatHinh );
   
   Vecto viTriKienLongSaoGai = kienLongSaoGai->viTriDau;
   
   // ---- kiến lồng sao gai
   if( soHoatHinh < 1000 ) {
      ; // ---- không làm gì đặt biệt
   }
   else if( soHoatHinh < 1250 ) { // mở kiến nhốp sao gai
      
      float buocKeoLen = 3.2f/(250.0f);
      unsigned short soHoatHinhTuongDoi = soHoatHinh - 1000.0f;
      // ---- nâng cấp bề cao kiến
      unsigned short chiSo = 0;
      unsigned short soLuongVatThe = kienLongSaoGai->soLuongVatThe;
      while( chiSo < soLuongVatThe ) {
         float beCao = kKIEN_LONG__BE_CAO - buocKeoLen*soHoatHinhTuongDoi;
         kienLongSaoGai->danhSachVatThe[chiSo].hinhDang.hop = datHop( kKIEN_LONG__BE_RONG, beCao, kKIEN_LONG__BE_DAY, &(kienLongSaoGai->danhSachVatThe[chiSo].baoBiVT) );
         chiSo++;
      }
      
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép
      tinhBaoBiVTChoVatTheGhep( kienLongSaoGai );
      
      // ---- nâng cấp vị trí
      viTriKienLongSaoGai.y += 0.5f*buocKeoLen*soHoatHinhTuongDoi;
      
      //      printf( "beCao %5.3f   viTri %5.3f %5.3f %5.3f  buocKeoLen %5.3f\n", 3.5f - buocKeoLen*(soHoatHinh - 675.0f), viTriKienLongSaoGai.x, viTriKienLongSaoGai.y, viTriKienLongSaoGai.z, buocKeoLen );
   }
   else {  // phải làm này vì không biết cần bắt đầu từ bức ảnh nào
      
      unsigned short chiSo = 0;
      unsigned short soLuongVatThe = kienLongSaoGai->soLuongVatThe;
      while( chiSo < soLuongVatThe ) {
         kienLongSaoGai->danhSachVatThe[chiSo].hinhDang.hop = datHop( kKIEN_LONG__BE_RONG, 0.3f, kKIEN_LONG__BE_CAO, &(kienLongSaoGai->danhSachVatThe[chiSo].baoBiVT) );
         chiSo++;
      }
      
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép
      tinhBaoBiVTChoVatTheGhep( kienLongSaoGai );
      
      // ---- nâng cấp vị trí
      viTriKienLongSaoGai.y += 1.6f;
   }
   
   datBienHoaChoVat( kienLongSaoGai, &phongTo, &xoay, &viTriKienLongSaoGai );
}

#define kDONG_SONG__VAN_TOC_X 0.5f

void nangCapDongSong( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh ) {
   //  printf( "\nsoHoatHinh %d\n", soHoatHinh );
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   float xKetThucBang = kDONG_SONG__BE_DAI_PHAN_BANG*0.5f + kDONG_SONG__VI_TRI_X;
   float xKetThucParabol = xKetThucBang + kDONG_SONG__BE_DAI_PHAN_PARABOL;
   
   unsigned short soVatThe = 0;
   while( soVatThe < soLuongVatThe ) {
      // ---- nâng cấp vị trí vật thể
      Vecto viTri;
      viTri.x = danhSachVat[soVatThe].dich[12] + kDONG_SONG__VAN_TOC_X;
      viTri.z = kDONG_SONG__VI_TRI_Z;
      
      if( viTri.x < xKetThucBang ) {
         viTri.y = kDONG_SONG__VI_TRI_Y;
         datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
         /*        printf( "viTri.x %5.3f\n", viTri.x );
          printf( "binhT %d\n   %5.3f %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f %5.3f\n", soVatThe, danhSachVat[soVatThe].bienHoa[0], danhSachVat[soVatThe].bienHoa[1], danhSachVat[soVatThe].bienHoa[2], danhSachVat[soVatThe].bienHoa[3],
          danhSachVat[soVatThe].bienHoa[4], danhSachVat[soVatThe].bienHoa[5], danhSachVat[soVatThe].bienHoa[6], danhSachVat[soVatThe].bienHoa[7],
          danhSachVat[soVatThe].bienHoa[8], danhSachVat[soVatThe].bienHoa[9], danhSachVat[soVatThe].bienHoa[10], danhSachVat[soVatThe].bienHoa[11],
          danhSachVat[soVatThe].bienHoa[12], danhSachVat[soVatThe].bienHoa[13], danhSachVat[soVatThe].bienHoa[14], danhSachVat[soVatThe].bienHoa[15] ); */
      }
      // ---- tới kết thúc phần băng
      else if( viTri.x < xKetThucParabol ) {
         float xParabol = viTri.x - xKetThucBang;
         float y = kDONG_SONG__HANG_SO_PARABOL*xParabol*xParabol + kDONG_SONG__VI_TRI_Y;
         
         viTri.y = y;
         
         // ---- tính góc xoay vật thể
         Vecto trucQuay;
         trucQuay.x = 0.0f;  trucQuay.y = 0.0f;   trucQuay.z = 1.0f;
         float goc = atanf( kDONG_SONG__HANG_SO_PARABOL*2.0f*xParabol );
         Quaternion quaternionGoc = datQuaternionTuVectoVaGocQuay( &trucQuay, goc );
         datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternionGoc, &viTri );
      }
      // ---- tới kết thúc phần parabol
      else {
         //         printf( "xKetThucParabol %5.3f  xKetThucBang %5.3f  viTri.x %5.3f\n", xKetThucParabol, xKetThucBang, viTri.x );
         //         exit(0);
         viTri.x = -kDONG_SONG__BE_DAI_PHAN_BANG*0.5f + kDONG_SONG__VI_TRI_X;
         viTri.y = kDONG_SONG__VI_TRI_Y;
         datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
         
         /*         printf( "PARABOL %d\n   %5.3f %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f %5.3f\n   %5.3f %5.3f %5.3f %5.3f\n", soVatThe, danhSachVat[soVatThe].bienHoa[0], danhSachVat[soVatThe].bienHoa[1], danhSachVat[soVatThe].bienHoa[2], danhSachVat[soVatThe].bienHoa[3],
          danhSachVat[soVatThe].bienHoa[4], danhSachVat[soVatThe].bienHoa[5], danhSachVat[soVatThe].bienHoa[6], danhSachVat[soVatThe].bienHoa[7],
          danhSachVat[soVatThe].bienHoa[8], danhSachVat[soVatThe].bienHoa[9], danhSachVat[soVatThe].bienHoa[10], danhSachVat[soVatThe].bienHoa[11],
          danhSachVat[soVatThe].bienHoa[12], danhSachVat[soVatThe].bienHoa[13], danhSachVat[soVatThe].bienHoa[14], danhSachVat[soVatThe].bienHoa[15] ); */
      }
      
      soVatThe++;
   }
   
}
