#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Sọc */
typedef struct {
   Mau mauNen;       // màu nền
   Mau mauSoc;       // màu sọc
   float quangSoc;   // quãng sọc
   float phanSoSoc;  // phân số tô sọc trong quãng sọc
   Vecto trucSoc;    // trục (hướng cho sọc)

} HoaTietSoc;

// ---- sọc
HoaTietSoc datHoaTietSoc( Mau *mauNen, Mau *mauSoc, float quangSoc, float phanSoSoc, Vecto *trucSoc );
Mau hoaTietSoc( Vecto *viTri, HoaTietSoc *hoaTietSoc );