#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Dị Hướng */
typedef struct {
   Mau mauRanh;     // màu ranh
   Mau mauTam;      // màu tâm
} HoaTietDiHuong;


// ---- dị hướng
HoaTietDiHuong datHoaTietDiHuong( Mau *mauRanh, Mau *mauTam );
Mau hoaTietDiHuong( Vecto phapThuyen, Vecto huongTia, HoaTietDiHuong *hoaTietDiHuong );