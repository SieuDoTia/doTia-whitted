// 2562.01.20
#include "HoaTietCaRoSauMau.h"
#include <math.h>

#define kTI_SO_PHA_TRON 0.500f


#pragma mark ---- Họa Tiết Ca Rô
HoaTietCaRoSauMau datHoaTietCaRoSauMau( Mau *mau0_x, Mau *mau1_x,
                                       Mau *mau0_y, Mau *mau1_y,
                                       Mau *mau0_z, Mau *mau1_z,
                                       float beRong, float beCao, float beDai ) {
   HoaTietCaRoSauMau hoaTietCaRoSauMau;
   // ---- hướng x
   hoaTietCaRoSauMau.mau0_x.d = mau0_x->d;
   hoaTietCaRoSauMau.mau0_x.l = mau0_x->l;
   hoaTietCaRoSauMau.mau0_x.x = mau0_x->x;
   hoaTietCaRoSauMau.mau0_x.dd = mau0_x->dd;
   hoaTietCaRoSauMau.mau0_x.p = mau0_x->p;
   
   hoaTietCaRoSauMau.mau1_x.d = mau1_x->d;
   hoaTietCaRoSauMau.mau1_x.l = mau1_x->l;
   hoaTietCaRoSauMau.mau1_x.x = mau1_x->x;
   hoaTietCaRoSauMau.mau1_x.dd = mau1_x->dd;
   hoaTietCaRoSauMau.mau1_x.p = mau1_x->p;
   
   // ---- hướng y
   hoaTietCaRoSauMau.mau0_y.d = mau0_y->d;
   hoaTietCaRoSauMau.mau0_y.l = mau0_y->l;
   hoaTietCaRoSauMau.mau0_y.x = mau0_y->x;
   hoaTietCaRoSauMau.mau0_y.dd = mau0_y->dd;
   hoaTietCaRoSauMau.mau0_y.p = mau0_y->p;
   
   hoaTietCaRoSauMau.mau1_y.d = mau1_y->d;
   hoaTietCaRoSauMau.mau1_y.l = mau1_y->l;
   hoaTietCaRoSauMau.mau1_y.x = mau1_y->x;
   hoaTietCaRoSauMau.mau1_y.dd = mau1_y->dd;
   hoaTietCaRoSauMau.mau1_y.p = mau1_y->p;
   
   // ---- hướng z
   hoaTietCaRoSauMau.mau0_z.d = mau0_z->d;
   hoaTietCaRoSauMau.mau0_z.l = mau0_z->l;
   hoaTietCaRoSauMau.mau0_z.x = mau0_z->x;
   hoaTietCaRoSauMau.mau0_z.dd = mau0_z->dd;
   hoaTietCaRoSauMau.mau0_z.p = mau0_z->p;
   
   hoaTietCaRoSauMau.mau1_z.d = mau1_z->d;
   hoaTietCaRoSauMau.mau1_z.l = mau1_z->l;
   hoaTietCaRoSauMau.mau1_z.x = mau1_z->x;
   hoaTietCaRoSauMau.mau1_z.dd = mau1_z->dd;
   hoaTietCaRoSauMau.mau1_z.p = mau1_z->p;
   
   // ---- kích cỡ ca rô
   hoaTietCaRoSauMau.beRong = beRong;
   hoaTietCaRoSauMau.beCao = beCao;
   hoaTietCaRoSauMau.beDai = beDai;
   
   return hoaTietCaRoSauMau;
}

Mau hoaTietCaRoSauMau( Vecto *viTri, HoaTietCaRoSauMau *hoaTietCaRoSauMau ) {
   
   int soX = ceilf((viTri->x)/hoaTietCaRoSauMau->beRong);
   int soY = ceilf((viTri->y)/hoaTietCaRoSauMau->beCao);
   int soZ = ceilf((viTri->z)/hoaTietCaRoSauMau->beDai);
   
   Mau mauCaRo;
   
   // ---- x
   if( soX & 0x01 ){
      mauCaRo.d = 0.33333f*hoaTietCaRoSauMau->mau1_x.d;
      mauCaRo.l = 0.33333f*hoaTietCaRoSauMau->mau1_x.l;
      mauCaRo.x = 0.33333f*hoaTietCaRoSauMau->mau1_x.x;
      mauCaRo.dd = 0.33333f*hoaTietCaRoSauMau->mau1_x.dd;
      mauCaRo.p = 0.33333f*hoaTietCaRoSauMau->mau1_x.p;
   }
   else {
      mauCaRo.d = 0.33333f*hoaTietCaRoSauMau->mau0_x.d;
      mauCaRo.l = 0.33333f*hoaTietCaRoSauMau->mau0_x.l;
      mauCaRo.x = 0.33333f*hoaTietCaRoSauMau->mau0_x.x;
      mauCaRo.dd = 0.33333f*hoaTietCaRoSauMau->mau0_x.dd;
      mauCaRo.p = 0.33333f*hoaTietCaRoSauMau->mau0_x.p;
   }
   
   // ---- y
   if( soY & 0x01 ){
      mauCaRo.d += 0.33333f*hoaTietCaRoSauMau->mau1_y.d;
      mauCaRo.l += 0.33333f*hoaTietCaRoSauMau->mau1_y.l;
      mauCaRo.x += 0.33333f*hoaTietCaRoSauMau->mau1_y.x;
      mauCaRo.dd += 0.33333f*hoaTietCaRoSauMau->mau1_y.dd;
      mauCaRo.p += 0.33333f*hoaTietCaRoSauMau->mau1_y.p;
   }
   else {
      mauCaRo.d += 0.33333f*hoaTietCaRoSauMau->mau0_y.d;
      mauCaRo.l += 0.33333f*hoaTietCaRoSauMau->mau0_y.l;
      mauCaRo.x += 0.33333f*hoaTietCaRoSauMau->mau0_y.x;
      mauCaRo.dd += 0.33333f*hoaTietCaRoSauMau->mau0_y.dd;
      mauCaRo.p += 0.33333f*hoaTietCaRoSauMau->mau0_y.p;
   }
   
   // ---- z
   if( soZ & 0x01 ){
      mauCaRo.d += 0.33333f*hoaTietCaRoSauMau->mau1_z.d;
      mauCaRo.l += 0.33333f*hoaTietCaRoSauMau->mau1_z.l;
      mauCaRo.x += 0.33333f*hoaTietCaRoSauMau->mau1_z.x;
      mauCaRo.dd += 0.33333f*hoaTietCaRoSauMau->mau1_z.dd;
      mauCaRo.p += 0.33333f*hoaTietCaRoSauMau->mau1_z.p;
   }
   else {
      mauCaRo.d += 0.33333f*hoaTietCaRoSauMau->mau0_z.d;
      mauCaRo.l += 0.33333f*hoaTietCaRoSauMau->mau0_z.l;
      mauCaRo.x += 0.33333f*hoaTietCaRoSauMau->mau0_z.x;
      mauCaRo.dd += 0.33333f*hoaTietCaRoSauMau->mau0_z.dd;
      mauCaRo.p += 0.33333f*hoaTietCaRoSauMau->mau0_z.p;
   }
   
   return mauCaRo;
}
