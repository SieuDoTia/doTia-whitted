#include "HoaTietOcXoay2.h"
#include <math.h>

#pragma mark ---- Họa Tiết Óc Xoáy
HoaTietOcXoay2 datHoaTietOcXoay2( Mau *mau0, Mau *mau1, float beRongNet, float phongTo, float goc, unsigned char huong ) {
   HoaTietOcXoay2 hoaTietOcXoay2;
   hoaTietOcXoay2.mau0.d = mau0->d;
   hoaTietOcXoay2.mau0.l = mau0->l;
   hoaTietOcXoay2.mau0.x = mau0->x;
   hoaTietOcXoay2.mau0.dd = mau0->dd;
   hoaTietOcXoay2.mau0.p = mau0->p;
   
   hoaTietOcXoay2.mau1.d = mau1->d;
   hoaTietOcXoay2.mau1.l = mau1->l;
   hoaTietOcXoay2.mau1.x = mau1->x;
   hoaTietOcXoay2.mau1.dd = mau1->dd;
   hoaTietOcXoay2.mau1.p = mau1->p;
   
   hoaTietOcXoay2.beRongNet = beRongNet;
   hoaTietOcXoay2.phongTo = phongTo;
   hoaTietOcXoay2.huong = 1;
   
   // ---- hạn chế góc
   if( goc < 0.0f )
      goc = 0.0f;
   else if( goc > 6.283184f )
      goc = 0.0f;
   
   hoaTietOcXoay2.goc = goc;

   return hoaTietOcXoay2;
}

// cho phóng to, xài giá trị < 1.0 cho rộng hơn


// hướng 0
//
//                                          +    m
//                               +          |    ộ
//                     +         |          |    t
//           +         |         |          |    V
//           |         |         |          |    ò
// +---------+---------+---------+----------+    n
// 0         π/2       π        3π/2       2π    g

// hướng 1
//
// +                                             m
// |         +                                   ộ
// |         |         +                         t
// |         |         |         +               V
// |         |         |         |               ò
// +---------+---------+---------+----------+    n
// 0         π/2       π        3π/2       2π    g


Mau hoaTietOcXoay2( Vecto *viTri, HoaTietOcXoay2 *hoaTietOcXoay2 ) {
   
   float banKinh = sqrtf( viTri->x*viTri->x + viTri->z*viTri->z );
   banKinh *= hoaTietOcXoay2->phongTo;  // sẽ phóng nhỏ
   
   // ---- tính góc
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atanf( viTri->z/viTri->x );
   
   if( hoaTietOcXoay2->huong ) {
      goc = -goc;
      // ---- giữ 0 ≤ góc ≤ 2π, mà nghịch hướng
      if( viTri->x < 0.0f )
         goc += 3.141592f;
      else
         if( viTri->z > 0.0f )
            goc += 6.283184f;
      
   }
   else {
      // ---- giữ 0 ≤ góc ≤ 2π
      if( viTri->x < 0.0f )
         goc += 3.141592f;
      else
         if( viTri->z < 0.0f )
            goc += 6.283184f;
   }
   
   goc += hoaTietOcXoay2->goc;
   
   // ---- tính vòng
   unsigned short soVong = banKinh/6.283184f;

   goc += (float)soVong*6.283184f;
   
   // ---- chọn màu
   Mau mauTo;
   float nuaBeRongNet = hoaTietOcXoay2->beRongNet*0.5f;
   
   if( (goc < banKinh + nuaBeRongNet) && (goc > banKinh - nuaBeRongNet ) ) {
      mauTo.d = hoaTietOcXoay2->mau0.d;
      mauTo.l = hoaTietOcXoay2->mau0.l;
      mauTo.x = hoaTietOcXoay2->mau0.x;
      mauTo.dd = hoaTietOcXoay2->mau0.dd;
      mauTo.p = hoaTietOcXoay2->mau0.p;
   }
   else {
      if( goc < banKinh )
         goc += 6.283184f;
      else if( goc > banKinh )
         goc -= 6.283184f;

      if( (goc < banKinh + nuaBeRongNet) && (goc > banKinh - nuaBeRongNet ) ) {
         mauTo.d = hoaTietOcXoay2->mau0.d;
         mauTo.l = hoaTietOcXoay2->mau0.l;
         mauTo.x = hoaTietOcXoay2->mau0.x;
         mauTo.dd = hoaTietOcXoay2->mau0.dd;
         mauTo.p = hoaTietOcXoay2->mau0.p;
      }
      else {
         mauTo.d = hoaTietOcXoay2->mau1.d;
         mauTo.l = hoaTietOcXoay2->mau1.l;
         mauTo.x = hoaTietOcXoay2->mau1.x;
         mauTo.dd = hoaTietOcXoay2->mau1.dd;
         mauTo.p = hoaTietOcXoay2->mau1.p;
      }
   }
   //   printf( "hoaTietOcXoay2: goc %5.3f  banKinh %5.3f %5.3f  soVong %d  mauTo %5.3f\n", goc, banKinh - 0.5f*beRongNet, banKinh + 0.5f*beRongNet, soVong, mauTo.d);
   
   return mauTo;
}

