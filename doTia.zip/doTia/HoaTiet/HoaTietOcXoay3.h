#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Ốc Xoay 3 màu, quanh trục y */
typedef struct {
   Mau mauNen;      // màu nền
   Mau mauXoay0;    // màu xoay 0
   Mau mauXoay1;    // màu xoay 1
   float xoay;      // xoay
   float beRongNet; // bề rộng nét
   unsigned char soLapVong;  // số lặp vòng
   float goc;       // góc
   float doan;      // đoạn
} HoaTietOcXoay3;


// ---- óc xoáy 3
HoaTietOcXoay3 datHoaTietOcXoay3( Mau *mauNen, Mau *mauXoay0, Mau *mauXoay1, float beRongNet, float xoay, unsigned char soLapVong, float goc );
Mau hoaTietOcXoay3( Vecto *viTri, HoaTietOcXoay3 *hoaTietOcXoay3 );  // hoạ tiết óc xoáy