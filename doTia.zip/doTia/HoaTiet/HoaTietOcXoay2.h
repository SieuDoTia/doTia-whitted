#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Ốc Xoay 2 (xoay quanh trục y, 2 màu) */

typedef struct {
   Mau mau0;     // màu0
   Mau mau1;     // màu1
   float phongTo;   // phóng to - 'tốc độ phóng từ' trung tâm
   float beRongNet; // bề rộng nét
   float goc;       // góc xoay
   unsigned char huong; // hướng xoay
} HoaTietOcXoay2;


// ---- óc xoáy
HoaTietOcXoay2 datHoaTietOcXoay2( Mau *mau0, Mau *mau1, float beRongNet, float phongTo, float goc, unsigned char huong );
Mau hoaTietOcXoay2( Vecto *viTri, HoaTietOcXoay2 *hoaTietOcXoay2 );  // hoạ tiết óc xoáy