#include "HoaTietBauTroi.h"
#include <math.h>

#define kHE_SO_MU_BAU_TROI 8.0f

#pragma mark ---- Họa Tiết Bầu Trời
HoaTietBauTroi datHoaTietBauTroi( Mau *mauDayTroi, Mau *mauDinhTroi, Mau *mauChanTroiTay, Mau *mauChanTroiDong, float gocXoayChanTroi ) {
   
   HoaTietBauTroi hoaTietBauTroi;
   
   // ---- màu cho đấy trời
   hoaTietBauTroi.mauDayTroi.d = mauDayTroi->d;
   hoaTietBauTroi.mauDayTroi.l = mauDayTroi->l;
   hoaTietBauTroi.mauDayTroi.x = mauDayTroi->x;
   hoaTietBauTroi.mauDayTroi.dd = mauDayTroi->dd;
   hoaTietBauTroi.mauDayTroi.p = mauDayTroi->p;
   
   // ---- màu cho đỉnh trời
   hoaTietBauTroi.mauDinhTroi.d = mauDinhTroi->d;
   hoaTietBauTroi.mauDinhTroi.l = mauDinhTroi->l;
   hoaTietBauTroi.mauDinhTroi.x = mauDinhTroi->x;
   hoaTietBauTroi.mauDinhTroi.dd = mauDinhTroi->dd;
   hoaTietBauTroi.mauDinhTroi.p = mauDinhTroi->p;
   
   // ---- màu cho chân trời tây
   hoaTietBauTroi.mauChanTroiTay.d = mauChanTroiTay->d;
   hoaTietBauTroi.mauChanTroiTay.l = mauChanTroiTay->l;
   hoaTietBauTroi.mauChanTroiTay.x = mauChanTroiTay->x;
   hoaTietBauTroi.mauChanTroiTay.dd = mauChanTroiTay->dd;
   hoaTietBauTroi.mauChanTroiTay.p = mauChanTroiTay->p;
   
   // ---- màu cho chân trời đông
   hoaTietBauTroi.mauChanTroiDong.d = mauChanTroiDong->d;
   hoaTietBauTroi.mauChanTroiDong.l = mauChanTroiDong->l;
   hoaTietBauTroi.mauChanTroiDong.x = mauChanTroiDong->x;
   hoaTietBauTroi.mauChanTroiDong.dd = mauChanTroiDong->dd;
   hoaTietBauTroi.mauChanTroiDong.p = mauChanTroiDong->p;
   
   hoaTietBauTroi.gocXoayChanTroi = gocXoayChanTroi;
   
   return hoaTietBauTroi;
}

// tính màu theo hướng
//          ĐỈNH
//          -----
//        -       -
//      /           \
//     /             \
// TÂY +-π----+----0-+ ĐÔNG
//     \             /
//      \           /
//        -       -
//          -----
//           ĐẤY
Mau hoaTietBauTroi( Vecto huongTia, HoaTietBauTroi *hoaTietBauTroi ) {
   
   donViHoa( &huongTia );
   
   // ---- tính bán kính
   float banKinh = sqrtf( huongTia.x*huongTia.x + huongTia.z*huongTia.z );
   
   // ---- tính kinh độ
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atan( huongTia.z/huongTia.x );
   
   // ---- giữ kính độ 0 ≤ góc ≤ 2π
   if( huongTia.x < 0.0f )
      goc += 3.141592f;
   else
      if( huongTia.z < 0.0f )
         goc += 6.283184f;
   
   // ---- cộng xoay bầu trời
   goc += hoaTietBauTroi->gocXoayChanTroi;
   if( goc < 0.0f )
      goc += 6.283184f;
   else if( goc > 6.283184f )
      goc -= 6.283184f;

   // ---- phạm vi 0 ≤ 2
   goc /= 3.141592f;
   
   // ---- tính màu chân trời
   Mau mauChanTroi;
   if( goc < 1.0f ) {
      float nghichGoc = 1.0f - goc;
      mauChanTroi.d = nghichGoc*hoaTietBauTroi->mauChanTroiDong.d + goc*hoaTietBauTroi->mauChanTroiTay.d;
      mauChanTroi.l = nghichGoc*hoaTietBauTroi->mauChanTroiDong.l + goc*hoaTietBauTroi->mauChanTroiTay.l;
      mauChanTroi.x = nghichGoc*hoaTietBauTroi->mauChanTroiDong.x + goc*hoaTietBauTroi->mauChanTroiTay.x;
      mauChanTroi.dd = nghichGoc*hoaTietBauTroi->mauChanTroiDong.dd + goc*hoaTietBauTroi->mauChanTroiTay.dd;
      mauChanTroi.p = nghichGoc*hoaTietBauTroi->mauChanTroiDong.p + goc*hoaTietBauTroi->mauChanTroiTay.p;
   }
   else {
      goc -= 1.0f;
      float nghichGoc = 1.0f - goc;
      mauChanTroi.d = nghichGoc*hoaTietBauTroi->mauChanTroiDong.d + goc*hoaTietBauTroi->mauChanTroiTay.d;
      mauChanTroi.l = nghichGoc*hoaTietBauTroi->mauChanTroiDong.l + goc*hoaTietBauTroi->mauChanTroiTay.l;
      mauChanTroi.x = nghichGoc*hoaTietBauTroi->mauChanTroiDong.x + goc*hoaTietBauTroi->mauChanTroiTay.x;
      mauChanTroi.dd = nghichGoc*hoaTietBauTroi->mauChanTroiDong.dd + goc*hoaTietBauTroi->mauChanTroiTay.dd;
      mauChanTroi.p = nghichGoc*hoaTietBauTroi->mauChanTroiDong.p + goc*hoaTietBauTroi->mauChanTroiTay.p;
   }
   
   Mau mauTroi;
   if( huongTia.y < 0.0f ) {  // dưới
      float tiSoChanTroi = 1.0f + huongTia.y;
      tiSoChanTroi = powf( tiSoChanTroi, kHE_SO_MU_BAU_TROI );
      float nghichTiSoChanTroi = 1.0f - tiSoChanTroi;
      mauTroi.d = tiSoChanTroi*mauChanTroi.d + nghichTiSoChanTroi*hoaTietBauTroi->mauDayTroi.d;
      mauTroi.l = tiSoChanTroi*mauChanTroi.l + nghichTiSoChanTroi*hoaTietBauTroi->mauDayTroi.l;
      mauTroi.x = tiSoChanTroi*mauChanTroi.x + nghichTiSoChanTroi*hoaTietBauTroi->mauDayTroi.x;
      mauTroi.dd = tiSoChanTroi*mauChanTroi.dd + nghichTiSoChanTroi*hoaTietBauTroi->mauDayTroi.dd;
      mauTroi.p = tiSoChanTroi*mauChanTroi.p + nghichTiSoChanTroi*hoaTietBauTroi->mauDayTroi.p;
   }
   else {   // trên
      float tiSoChanTroi = 1.0f - huongTia.y;
      tiSoChanTroi = powf( tiSoChanTroi, kHE_SO_MU_BAU_TROI );
      float nghichTiSoChanTroi = 1.0f - tiSoChanTroi;
      mauTroi.d = tiSoChanTroi*mauChanTroi.d + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.d;
      mauTroi.l = tiSoChanTroi*mauChanTroi.l + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.l;
      mauTroi.x = tiSoChanTroi*mauChanTroi.x + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.x;
      mauTroi.dd = tiSoChanTroi*mauChanTroi.dd + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.dd;
      mauTroi.p = tiSoChanTroi*mauChanTroi.p + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.p;
   }

   return mauTroi;
}
