#include "HoaTietQuanXoay.h"
#include <math.h>

#pragma mark ---- Họa Tiết Quần Xoay
HoaTietQuanXoay datHoaTietQuanXoay( Mau *mauNen, Mau *mauQuan0, Mau *mauQuan1, Mau *mauQuan2, float phanQuan0, float phanQuan1, float phanQuan2, float xoay, float dich, unsigned char soLapVong ) {
   HoaTietQuanXoay hoaTietQuanXoay;
   // ---- màu nền
   hoaTietQuanXoay.mauNen.d = mauNen->d;
   hoaTietQuanXoay.mauNen.l = mauNen->l;
   hoaTietQuanXoay.mauNen.x = mauNen->x;
   hoaTietQuanXoay.mauNen.dd = mauNen->dd;
   hoaTietQuanXoay.mauNen.p = mauNen->p;
   // ---- màu quằn 0
   hoaTietQuanXoay.mauQuan0.d = mauQuan0->d;
   hoaTietQuanXoay.mauQuan0.l = mauQuan0->l;
   hoaTietQuanXoay.mauQuan0.x = mauQuan0->x;
   hoaTietQuanXoay.mauQuan0.dd = mauQuan0->dd;
   hoaTietQuanXoay.mauQuan0.p = mauQuan0->p;
   // ---- màu quằn 1
   hoaTietQuanXoay.mauQuan1.d = mauQuan1->d;
   hoaTietQuanXoay.mauQuan1.l = mauQuan1->l;
   hoaTietQuanXoay.mauQuan1.x = mauQuan1->x;
   hoaTietQuanXoay.mauQuan1.dd = mauQuan1->dd;
   hoaTietQuanXoay.mauQuan1.p = mauQuan1->p;
   // ---- màu quằn 1
   hoaTietQuanXoay.mauQuan2.d = mauQuan2->d;
   hoaTietQuanXoay.mauQuan2.l = mauQuan2->l;
   hoaTietQuanXoay.mauQuan2.x = mauQuan2->x;
   hoaTietQuanXoay.mauQuan2.dd = mauQuan2->dd;
   hoaTietQuanXoay.mauQuan2.p = mauQuan2->p;
   // ---- phân số cho quằn
   hoaTietQuanXoay.phanQuan0 = phanQuan0;
   hoaTietQuanXoay.phanQuan1 = phanQuan1;
   hoaTietQuanXoay.phanQuan2 = phanQuan2;
   // ---- xoay
   hoaTietQuanXoay.xoay = xoay;
   // ---- dịch xoay
   hoaTietQuanXoay.dich = dich;
   // ---- tính đoạn
   if( soLapVong < 2 )
      soLapVong = 2;
   hoaTietQuanXoay.soLapVong = soLapVong;
   hoaTietQuanXoay.doan = 6.283184f/(float)soLapVong;
   return hoaTietQuanXoay;
}

Mau hoaTietQuanXoay( Vecto *viTri, HoaTietQuanXoay *hoaTietQuanXoay ) {
   
   // ---- tính bán kính
   float banKinh = viTri->x*viTri->x + viTri->z*viTri->z;

   // ---- tính góc
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atanf( viTri->z/viTri->x );
   
   // ---- giữ 0 ≤ góc ≤ 2π
   if( viTri->x < 0.0f )
      goc += 3.141592f;
   else
      if( viTri->z < 0.0f )
         goc += 6.283184f;
   
   goc += hoaTietQuanXoay->xoay*viTri->y + hoaTietQuanXoay->dich;
   
   // ---- 0,0 đến 1,0
   goc /= hoaTietQuanXoay->doan;
   // ---- cần phần số
   goc -= floorf(goc);

   Mau mau;
   if( goc < 0.333333f ) {
      if( goc < 0.333333f - hoaTietQuanXoay->phanQuan0 ) {
         mau.d = hoaTietQuanXoay->mauNen.d;
         mau.l = hoaTietQuanXoay->mauNen.l;
         mau.x = hoaTietQuanXoay->mauNen.x;
         mau.dd = hoaTietQuanXoay->mauNen.dd;
         mau.p = hoaTietQuanXoay->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanXoay->mauQuan0.d;
         mau.l = hoaTietQuanXoay->mauQuan0.l;
         mau.x = hoaTietQuanXoay->mauQuan0.x;
         mau.dd = hoaTietQuanXoay->mauQuan0.dd;
         mau.p = hoaTietQuanXoay->mauQuan0.p;
      }
   }
   else if( goc < 0.666667f ) {
      if( goc < 0.666667f - hoaTietQuanXoay->phanQuan1 ) {
         mau.d = hoaTietQuanXoay->mauNen.d;
         mau.l = hoaTietQuanXoay->mauNen.l;
         mau.x = hoaTietQuanXoay->mauNen.x;
         mau.dd = hoaTietQuanXoay->mauNen.dd;
         mau.p = hoaTietQuanXoay->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanXoay->mauQuan1.d;
         mau.l = hoaTietQuanXoay->mauQuan1.l;
         mau.x = hoaTietQuanXoay->mauQuan1.x;
         mau.dd = hoaTietQuanXoay->mauQuan1.dd;
         mau.p = hoaTietQuanXoay->mauQuan1.p;
      }
   }
   else {
      if( goc < 1.0f - hoaTietQuanXoay->phanQuan2 ) {
         mau.d = hoaTietQuanXoay->mauNen.d;
         mau.l = hoaTietQuanXoay->mauNen.l;
         mau.x = hoaTietQuanXoay->mauNen.x;
         mau.dd = hoaTietQuanXoay->mauNen.dd;
         mau.p = hoaTietQuanXoay->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanXoay->mauQuan2.d;
         mau.l = hoaTietQuanXoay->mauQuan2.l;
         mau.x = hoaTietQuanXoay->mauQuan2.x;
         mau.dd = hoaTietQuanXoay->mauQuan2.dd;
         mau.p = hoaTietQuanXoay->mauQuan2.p;
      }
   }
   
   return mau;
}
