#pragma once

#include "../Mau.h"

/* Họa Tiết Gằn */
typedef struct {
   Mau mauTren;   // màu trên
   Mau mauDuoi;   // màu dưới
   float beCaoTren;  // bề cao trên
   float beCaoDuoi;  // bề cao dưới
} HoaTietGan;


// ---- gằn
HoaTietGan datHoaTietGan( Mau *mauTren, Mau *mauDuoi, float beCaoTren, float beCaoDuoi );
Mau hoaTietGan( float toaDo, HoaTietGan *hoaTietGan );