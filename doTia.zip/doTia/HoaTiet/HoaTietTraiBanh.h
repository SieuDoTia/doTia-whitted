#pragma once
#include "../Mau.h"
#include "../Toan/Vecto.h"

Mau hoaTietTraiBanh( Vecto *viTri );