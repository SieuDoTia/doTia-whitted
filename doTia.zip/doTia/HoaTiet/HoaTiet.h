#pragma once

/* Hằng Số cho Họa Tiết */
#define kHOA_TIET__KHONG        0 // không có họa tiết, xài màu của vật thể
#define kHOA_TIET__DI_HUONG     1 // họa tiết dị hướng
#define kHOA_TIET__VONG_TRON    2 // họa tiết vòng tròn quanh trục Y
#define kHOA_TIET__OC_XOAY_2    3 // họa tiết óc xoay 2 màu quanh trục Y
#define kHOA_TIET__OC_XOAY_3    4 // họa tiết óc xoay 3 màu quanh trục Y
#define kHOA_TIET__GAN          5 // họa tiết gằn ngang
#define kHOA_TIET__CHAM_BI      6 // họa tiết chấm bi
#define kHOA_TIET__NGOI_SAO_CAU 7 // họa tiết nôi sao cầu
#define kHOA_TIET__CA_RO        8 // họa tiết ca rô
#define kHOA_TIET__CA_RO_SONG   9 // họa tiết ca rô sóng
#define kHOA_TIET__QUAN        10 // họa tiết quăn cầu
#define kHOA_TIET__QUAN_XOAY   11 // họa tiết quăn cầu xoay
#define kHOA_TIET__CA_RO_SAU_MAU  12 // họa tiết ca rô sáu màu
#define kHOA_TIET__QUAN_SONG_THEO_HUONG  13 // họa tiết quăn sóng theo hướng
#define kHOA_TIET__QUAN_SONG_TRUC_Z    14 // họa tiết quăn sóng theo hướng
#define kHOA_TIET__QUAN_SONG_TIA_PHAI  15 // họa tiết quăn sóng tia phai
#define kHOA_TIET__SOC         16 // họa tiết sọc
#define kHOA_TIET__CA_RO_MIN   17 // họa tiết ca rô mịn
#define kHOA_TIET__HAI_CHAM_BI 18 // họa tiết hai chấm bi
#define kHOA_TIET__BONG_VONG   19 // họa tiết bông vòng (bông vòng tròn)
#define kHOA_TIET__KIM_TUYEN_LAP_LANH   20 // họa tiết kim tuyến lấp lánh
#define kHOA_TIET__BAU_TROI    21 // họa tiết bầu trời
#define kHOA_TIET__TRAI_BANH   30 // họa tiết cho trái banh


#include <stdio.h>
#include "../HangSo.h"

#include "HoaTietKhong.h"
#include "HoaTietDiHuong.h"
#include "HoaTietCaRo.h"
#include "HoaTietCaRoSong.h"
#include "HoaTietCaRoSauMau.h"
#include "HoaTietVongTron.h"
#include "HoaTietOcXoay2.h"
#include "HoaTietOcXoay3.h"
#include "HoaTietGan.h"
#include "HoaTietChamBi.h"
#include "HoaTietNgoiSaoCau.h"
#include "HoaTietQuan.h"
#include "HoaTietQuanXoay.h"
#include "HoaTietQuanSongTheoHuong.h"
#include "HoaTietQuanSongTrucZ.h"
#include "HoaTietQuanSongTiaPhai.h"
#include "HoaTietSoc.h"
#include "HoaTietCaRoMin.h"
#include "HoaTietHaiChamBi.h"
#include "HoaTietBongVong.h"
#include "HoaTietKimTuyenLapLanh.h"
#include "HoaTietBauTroi.h"


/* Họa Tiết */
typedef union {
   HoaTietKhong hoaTietKhong;       // họa tiết không
   HoaTietDiHuong hoaTietDiHuong;   // họa tiết dị hướng
   HoaTietCaRo hoaTietCaRo;         // họa tiết ca rô
   HoaTietCaRoSong hoaTietCaRoSong; // họa tiết ca rô sóng
   HoaTietCaRoSauMau hoaTietCaRoSauMau; // họa tiết ca rô sáu màu
   HoaTietVongTron hoaTietVongTron; // họa tiết vòng tròn
   HoaTietOcXoay2 hoaTietOcXoay2;   // họa tiết óc xoay hai màu
   HoaTietOcXoay3 hoaTietOcXoay3;   // họa tiết óc xoay ba màu
   HoaTietGan hoaTietGan;           // họa tiết gằn, gằn có thể theo trục x, y, z
   HoaTietChamBi hoaTietChamBi;     // hoạ tiết chấm bi
   HoaTietNgoiSaoCau hoaTietNgoiSaoCau; // hoạ tiết ngôi sao cho hình cầu
   HoaTietQuan hoaTietQuan;         // họa tiết quăn
   HoaTietQuanXoay hoaTietQuanXoay; // họa tiết quằn xoay
   HoaTietQuanSongTheoHuong hoaTietQuanSongTheoHuong; // họa tiết quằn sóng theo hướng (vectơ hướng)
   HoaTietQuanSongTrucZ hoaTietQuanSongTrucZ; // họa tiết quằn sóng quanh trục Z
   HoaTietQuanSongTiaPhai hoaTietQuanSongTiaPhai; // họa tiết quằn sóng tia phai (bán kính)
   HoaTietSoc hoaTietSoc;           // họa tiết sọc
   HoaTietCaRoMin hoaTietCaRoMin;   // họa tiết ca rô mịn
   HoaTietHaiChamBi hoaTietHaiChamBi;  // họa tiết hai chấm bi
   HoaTietBongVong hoaTietBongVong;   // họa tiết bông vòng (bông vòng tròn)
   HoaTietKimTuyenLapLanh hoaTietKimTuyenLapLanh;   // họa tiết kim tuyến lấp lánh
   HoaTietBauTroi hoaTietBauTroi;    // họa tiết bầu trời
} HoaTiet;                           // họa tiết

void chonVaToHoaTietNgauNhien( unsigned char *soHoaTiet, HoaTiet *hoaTiet );