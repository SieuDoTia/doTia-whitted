#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Bầu Trời */
typedef struct {
   Mau mauDayTroi;        // màu đấy trời
   Mau mauDinhTroi;       // màu đỉnh trời
   Mau mauChanTroiTay;    // màu chân trời tây
   Mau mauChanTroiDong;   // màu chân trời đậng
   float gocXoayChanTroi; // góc xoay chân trời
} HoaTietBauTroi;

// ---- bầu trời
HoaTietBauTroi datHoaTietBauTroi( Mau *mauDayToi, Mau *mauDinhToi, Mau *mauChanTroiTay, Mau *mauChanTroiDong, float gocXoayChanTroi );
Mau hoaTietBauTroi( Vecto huongTia, HoaTietBauTroi *hoaTietBauTroi );