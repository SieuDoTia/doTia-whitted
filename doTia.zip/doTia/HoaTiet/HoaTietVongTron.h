#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Vòng Tròn */
typedef struct {
   Mau mauNoi;     // màu nội
   Mau mauNgoai;   // màu ngoại
   float banKinh;  // bán kính
} HoaTietVongTron;


// ---- vòng tròn
HoaTietVongTron datHoaTietVongTron( Mau *mau0, Mau *mau1, float banKinh );
Mau hoaTietVongTron( Vecto *viTri, HoaTietVongTron *hoaTietVongTron );  // họa tiết vòng tròn quanh trục y
