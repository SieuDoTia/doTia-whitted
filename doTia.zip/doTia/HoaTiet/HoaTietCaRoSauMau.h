// 2562.01.20
#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Ca Rô Sáu Màu */
typedef struct {
   Mau mau0_x;     // màu0 x
   Mau mau1_x;     // màu1 x
   Mau mau0_y;     // màu0 y
   Mau mau1_y;     // màu1 y
   Mau mau0_z;     // màu0 z
   Mau mau1_z;     // màu1 z
   float beRong; // bề rộng (x)
   float beCao;  // bề dài (y)
   float beDai;  // bề dài (z)
} HoaTietCaRoSauMau;


// ---- ca rô sáu màu
HoaTietCaRoSauMau datHoaTietCaRoSauMau( Mau *mau0_x, Mau *mau1_x,
                                        Mau *mau0_y, Mau *mau1_y,
                                        Mau *mau0_z, Mau *mau1_z,
                                       float beRong, float beCao, float beDai );

// họa tiết ca rô sáu màu
Mau hoaTietCaRoSauMau( Vecto *viTri, HoaTietCaRoSauMau *hoaTietCaRoSauMau );