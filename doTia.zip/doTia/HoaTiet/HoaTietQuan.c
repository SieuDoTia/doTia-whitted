#include "HoaTietQuan.h"
#include "../HangSo.h"
#include <stdlib.h>
#include <math.h>

#pragma mark ---- Họa Tiết Quăn
HoaTietQuan datHoaTietQuan( Mau *mauNen, Mau *mauThap, Mau *mauCao ) {
   HoaTietQuan hoaTietQuan;
   hoaTietQuan.mauNen.d = mauNen->d;
   hoaTietQuan.mauNen.l = mauNen->l;
   hoaTietQuan.mauNen.x = mauNen->x;
   hoaTietQuan.mauNen.dd = mauNen->dd;
   hoaTietQuan.mauNen.p = mauNen->p;
   
   Mau phamViMau;
   phamViMau.d = mauCao->d - mauThap->d;
   phamViMau.l = mauCao->l - mauThap->l;
   phamViMau.x = mauCao->x - mauThap->x;
   phamViMau.dd = mauCao->dd - mauThap->dd;
   phamViMau.p = mauCao->p - mauThap->p;
   
   hoaTietQuan.tanSo = (rand() & 0x07) + 2;
   hoaTietQuan.soLuongQuan = (rand() & 0x0f) + 1;
   hoaTietQuan.beRongQuan = rand()/kSO_NGUYEN_TOI_DA;

   if( hoaTietQuan.soLuongQuan < 5 )
      hoaTietQuan.soLuongQuan = 5;
   
   unsigned char soQuan = 0;
   while( soQuan < hoaTietQuan.soLuongQuan ) {
      hoaTietQuan.mangMau[soQuan].d = phamViMau.d*rand()/kSO_NGUYEN_TOI_DA + mauThap->d;
      hoaTietQuan.mangMau[soQuan].l = phamViMau.l*rand()/kSO_NGUYEN_TOI_DA + mauThap->l;
      hoaTietQuan.mangMau[soQuan].x = phamViMau.x*rand()/kSO_NGUYEN_TOI_DA + mauThap->x;
      hoaTietQuan.mangMau[soQuan].dd = phamViMau.dd*rand()/kSO_NGUYEN_TOI_DA + mauThap->dd;
      hoaTietQuan.mangMau[soQuan].p = phamViMau.p*rand()/kSO_NGUYEN_TOI_DA + mauThap->p;
      soQuan++;
   }

   return hoaTietQuan;
}

Mau hoaTietQuan( Vecto *viTri, HoaTietQuan *hoaTietQuan ) {

   // ---- tính bán kính
   float banKinh = sqrtf( viTri->x*viTri->x + viTri->z*viTri->z );
   float viDo = atanf( viTri->y/banKinh );
   
   // ---- tính kính độ
   float kinhDo = 0.0f;
   if( banKinh != 0.0f )
      kinhDo = atan( viTri->z/viTri->x );
   
   kinhDo += 0.1f*sinf( hoaTietQuan->tanSo*viDo );
   
   // ---- giữ 0 ≤ kinh độ ≤ 2π
   if( viTri->x < 0.0f )
      kinhDo += 3.141592f;
   else
      if( viTri->z < 0.0f )
         kinhDo += 6.283184f;

   // ---- tính số quăn thực
   float soQuanThuc = kinhDo*hoaTietQuan->soLuongQuan/6.283184f;

   unsigned char soQuan = floorf(soQuanThuc);
   Mau mau;
   if( (soQuanThuc - soQuan) < hoaTietQuan->beRongQuan ) {
      mau.d = hoaTietQuan->mauNen.d;
      mau.l = hoaTietQuan->mauNen.l;
      mau.x = hoaTietQuan->mauNen.x;
      mau.dd = hoaTietQuan->mauNen.dd;
      mau.p = hoaTietQuan->mauNen.p;
   }
   else {
      mau.d = hoaTietQuan->mangMau[soQuan].d;
      mau.l = hoaTietQuan->mangMau[soQuan].l;
      mau.x = hoaTietQuan->mangMau[soQuan].x;
      mau.dd = hoaTietQuan->mangMau[soQuan].dd;
      mau.p = hoaTietQuan->mangMau[soQuan].p;
   }
   
   return mau;
}
