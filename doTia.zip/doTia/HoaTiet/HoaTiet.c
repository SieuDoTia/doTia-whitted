#include "HoaTiet.h"
#include <stdlib.h>


#pragma mark ---- Họa Tiệt Ngẫu Nhiên
void chonVaToHoaTietNgauNhien( unsigned char *soHoaTiet, HoaTiet *hoaTiet ) {
   // ---- chọn họa tiệt
   *soHoaTiet = rand() % 12;
   
   if( *soHoaTiet == kHOA_TIET__CA_RO ) {
      Mau mau0;
      Mau mau1;
      mau0.d = rand()/kSO_NGUYEN_TOI_DA;
      mau0.l = rand()/kSO_NGUYEN_TOI_DA;
      mau0.x = rand()/kSO_NGUYEN_TOI_DA;
      mau0.dd = 1.0f;
      mau0.p = 0.1f;
      mau1.d = rand()/kSO_NGUYEN_TOI_DA;
      mau1.l = rand()/kSO_NGUYEN_TOI_DA;
      mau1.x = rand()/kSO_NGUYEN_TOI_DA;
      mau1.dd = 1.0f;
      mau1.p = 0.1f;
      float coKich = rand()/kSO_NGUYEN_TOI_DA + 0.3f;
      (*hoaTiet).hoaTietCaRo = datHoaTietCaRo( &mau0, &mau0, coKich, coKich, coKich );
   }
   else if( *soHoaTiet == kHOA_TIET__CA_RO_SONG ) {
      Mau mau0;
      Mau mau1;
      mau0.d = rand()/kSO_NGUYEN_TOI_DA;
      mau0.l = rand()/kSO_NGUYEN_TOI_DA;
      mau0.x = rand()/kSO_NGUYEN_TOI_DA;
      mau0.dd = 1.0f;
      mau0.p = 0.1f;
      mau1.d = rand()/kSO_NGUYEN_TOI_DA;
      mau1.l = rand()/kSO_NGUYEN_TOI_DA;
      mau1.x = rand()/kSO_NGUYEN_TOI_DA;
      mau1.dd = 1.0f;
      mau1.p = 0.1f;
      float coKich = rand()/kSO_NGUYEN_TOI_DA + 0.3f;
      float bienDo = rand()/kSO_NGUYEN_TOI_DA*0.1f + 0.1f;
      float tanSo = 0.5f;
      (*hoaTiet).hoaTietCaRoSong = datHoaTietCaRoSong( &mau0, &mau0, coKich, coKich, coKich, bienDo, tanSo );
   }
   else if( *soHoaTiet == kHOA_TIET__VONG_TRON ) {
      Mau mau0;
      Mau mau1;
      mau0.d = rand()/kSO_NGUYEN_TOI_DA;
      mau0.l = rand()/kSO_NGUYEN_TOI_DA;
      mau0.x = rand()/kSO_NGUYEN_TOI_DA;
      mau0.dd = 1.0f;
      mau0.p = 0.1f;
      mau1.d = rand()/kSO_NGUYEN_TOI_DA;
      mau1.l = rand()/kSO_NGUYEN_TOI_DA;
      mau1.x = rand()/kSO_NGUYEN_TOI_DA;
      mau1.dd = 1.0f;
      mau1.p = 0.1f;
      float coKich = rand()/kSO_NGUYEN_TOI_DA + 0.3f;
      (*hoaTiet).hoaTietVongTron = datHoaTietVongTron( &mau0, &mau1, coKich );
   }
   else if( *soHoaTiet == kHOA_TIET__OC_XOAY_2 ) {
      Mau mau0;
      Mau mau1;
      mau0.d = rand()/kSO_NGUYEN_TOI_DA;
      mau0.l = rand()/kSO_NGUYEN_TOI_DA;
      mau0.x = rand()/kSO_NGUYEN_TOI_DA;
      mau0.dd = 1.0f;
      mau0.p = 0.1f;
      mau1.d = rand()/kSO_NGUYEN_TOI_DA;
      mau1.l = rand()/kSO_NGUYEN_TOI_DA;
      mau1.x = rand()/kSO_NGUYEN_TOI_DA;
      mau1.dd = 1.0f;
      mau1.p = 0.1f;
      float beRongNet = 0.3f*rand()/kSO_NGUYEN_TOI_DA + 0.2f;
      float phongTo = rand()/kSO_NGUYEN_TOI_DA + 1.0f;
      float goc = rand()/kSO_NGUYEN_TOI_DA*3.14159f;
      unsigned char huong = rand() & 1;
      (*hoaTiet).hoaTietOcXoay2 = datHoaTietOcXoay2( &mau0, &mau1, beRongNet, phongTo, goc, huong );
   }
   else if( *soHoaTiet == kHOA_TIET__OC_XOAY_3 ) {
      Mau mau0;
      Mau mau1;
      Mau mau2;
      mau0.d = rand()/kSO_NGUYEN_TOI_DA;
      mau0.l = rand()/kSO_NGUYEN_TOI_DA;
      mau0.x = rand()/kSO_NGUYEN_TOI_DA;
      mau0.dd = 1.0f;
      mau0.p = 0.1f;
      mau1.d = rand()/kSO_NGUYEN_TOI_DA;
      mau1.l = rand()/kSO_NGUYEN_TOI_DA;
      mau1.x = rand()/kSO_NGUYEN_TOI_DA;
      mau1.dd = 1.0f;
      mau1.p = 0.1f;
      mau2.d = rand()/kSO_NGUYEN_TOI_DA;
      mau2.l = rand()/kSO_NGUYEN_TOI_DA;
      mau2.x = rand()/kSO_NGUYEN_TOI_DA;
      mau2.dd = 1.0f;
      mau2.p = 0.1f;
      float beRongNet = 0.3f*rand()/kSO_NGUYEN_TOI_DA + 0.2f;
      float phongTo = rand()/kSO_NGUYEN_TOI_DA + 1.0f;
      float goc = rand()/kSO_NGUYEN_TOI_DA*3.14159f;
      unsigned char huong = rand() & 1;
      (*hoaTiet).hoaTietOcXoay3 = datHoaTietOcXoay3( &mau0, &mau1, &mau2, beRongNet, phongTo, goc, huong );
   }
   else if( *soHoaTiet == kHOA_TIET__GAN ) {
      Mau mauTren;
      Mau mauDuoi;
      mauTren.d = rand()/kSO_NGUYEN_TOI_DA;
      mauTren.l = rand()/kSO_NGUYEN_TOI_DA;
      mauTren.x = rand()/kSO_NGUYEN_TOI_DA;
      mauTren.dd = 1.0f;
      mauTren.p = 0.1f;
      mauDuoi.d = rand()/kSO_NGUYEN_TOI_DA;
      mauDuoi.l = rand()/kSO_NGUYEN_TOI_DA;
      mauDuoi.x = rand()/kSO_NGUYEN_TOI_DA;
      mauDuoi.dd = 1.0f;
      mauDuoi.p = 0.1f;
      float beCaoTren = 0.2f + 0.5f*rand()/kSO_NGUYEN_TOI_DA;
      float beCaoDuoi = 0.2f + 0.5f*rand()/kSO_NGUYEN_TOI_DA;
      (*hoaTiet).hoaTietGan = datHoaTietGan( &mauTren, &mauDuoi, beCaoTren, beCaoDuoi );
   }
   else if( *soHoaTiet == kHOA_TIET__CHAM_BI ) {
      Mau mauNen;
      Mau mauThap;
      Mau mauCao;
      mauNen.d = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.l = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.x = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.dd = 1.0f;
      mauNen.p = 0.1f;
      mauThap.d = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.l = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.x = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.dd = 1.0f;
      mauThap.p = 0.1f;
      mauCao.d = 1.0f;   mauCao.l = 1.0f;    mauCao.x = 1.0f;   mauCao.dd = 1.0f;   mauCao.p = 0.1f;
      (*hoaTiet).hoaTietChamBi = datHoaTietChamBi( &mauNen, &mauThap, &mauCao );
   }
   else if( *soHoaTiet == kHOA_TIET__QUAN ) {
      Mau mauNen;
      Mau mauThap;
      Mau mauCao;
      mauNen.d = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.l = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.x = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.dd = 1.0f;
      mauNen.p = 0.1f;
      mauThap.d = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.l = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.x = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.dd = 1.0f;
      mauThap.p = 0.1f;
      mauCao.d = 1.0f;   mauCao.l = 1.0f;    mauCao.x = 1.0f;   mauCao.dd = 1.0f;   mauCao.p = 0.1f;
      (*hoaTiet).hoaTietQuan = datHoaTietQuan( &mauNen, &mauThap, &mauCao );
   }
   else if( *soHoaTiet == kHOA_TIET__QUAN_XOAY ) {
      Mau mauNen;
      Mau mauOc0;
      Mau mauOc1;
      Mau mauOc2;
      mauNen.d = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.l = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.x = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.dd = 1.0f;
      mauNen.p = 0.1f;
      mauOc0.d = rand()/kSO_NGUYEN_TOI_DA;
      mauOc0.l = rand()/kSO_NGUYEN_TOI_DA;
      mauOc0.x = rand()/kSO_NGUYEN_TOI_DA;
      mauOc0.dd = 1.0f;
      mauOc0.p = 0.1f;
      mauOc1.d = rand()/kSO_NGUYEN_TOI_DA;
      mauOc1.l = rand()/kSO_NGUYEN_TOI_DA;
      mauOc1.x = rand()/kSO_NGUYEN_TOI_DA;
      mauOc1.dd = 1.0f;
      mauOc1.p = 0.1f;
      mauOc2.d = rand()/kSO_NGUYEN_TOI_DA;
      mauOc2.l = rand()/kSO_NGUYEN_TOI_DA;
      mauOc2.x = rand()/kSO_NGUYEN_TOI_DA;
      mauOc2.dd = 1.0f;
      mauOc2.p = 0.1f;
      (*hoaTiet).hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen, &mauOc0, &mauOc1, &mauOc2, 0.05f, 0.08f, 0.15f, 0.0f, 0.165f, 16 );
   }
   else if( *soHoaTiet == kHOA_TIET__DI_HUONG ){  //    if( *soHoaTiet == kHOA_TIET__KHONG ) {
      Mau mauRanh;
      mauRanh.d = rand()/kSO_NGUYEN_TOI_DA;
      mauRanh.l = rand()/kSO_NGUYEN_TOI_DA;
      mauRanh.x = rand()/kSO_NGUYEN_TOI_DA;
      mauRanh.dd = 1.0f;
      mauRanh.p = 0.1f;
      Mau mauTam;
      mauTam.d = rand()/kSO_NGUYEN_TOI_DA;
      mauTam.l = rand()/kSO_NGUYEN_TOI_DA;
      mauTam.x = rand()/kSO_NGUYEN_TOI_DA;
      mauTam.dd = 1.0f;
      mauTam.p = 0.1f;
      (*hoaTiet).hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   }
   else if( *soHoaTiet == kHOA_TIET__NGOI_SAO_CAU ) {
      Mau mauNen;
      Mau mauThap;
      Mau mauCao;
      mauNen.d = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.l = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.x = rand()/kSO_NGUYEN_TOI_DA;
      mauNen.dd = 1.0f;
      mauNen.p = 0.1f;
      mauThap.d = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.l = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.x = rand()/kSO_NGUYEN_TOI_DA;
      mauThap.dd = 1.0f;
      mauThap.p = 0.1f;
      mauCao.d = 1.0f;   mauCao.l = 1.0f;    mauCao.x = 1.0f;   mauCao.dd = 1.0f;   mauCao.p = 0.1f;
      float banKinhNoi = 0.1f + 0.05f*rand()/kSO_NGUYEN_TOI_DA;
      float banKinhNgoai = 0.15 + 0.2f*rand()/kSO_NGUYEN_TOI_DA;
      float chenhLech = rand()/kSO_NGUYEN_TOI_DA;
      unsigned char soNan = 3 + rand() & 0x07;
      //      printf( "chonHoaTietngauNhien: banKinh %5.3f %5.3f chenhLech %5.3f soNan %d\n", banKinhNoi, banKinhNgoai, chenhLech, soNan );
      (*hoaTiet).hoaTietNgoiSaoCau = datHoaTietNgoiSaoCau( &mauNen, &mauThap, &mauCao, banKinhNoi, banKinhNgoai, chenhLech, soNan );
   }
   else {  //    if( *soHoaTiet == kHOA_TIET__KHONG ) {
      Mau mau;
      mau.d = rand()/kSO_NGUYEN_TOI_DA;
      mau.l = rand()/kSO_NGUYEN_TOI_DA;
      mau.x = 0.0f;//rand()/kSO_NGUYEN_TOI_DA;
      mau.dd = 1.0f;
      mau.p = 0.1f;
      (*hoaTiet).hoaTietKhong = datHoaTietKhong( &mau );
   }
}
