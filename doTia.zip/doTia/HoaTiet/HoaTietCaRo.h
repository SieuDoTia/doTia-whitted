#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Ca Rô */
typedef struct {
   Mau mau0;     // màu0
   Mau mau1;     // màu1
   float beRong; // bề rộng (x)
   float beCao;  // bề dài (y)
   float beDai;  // bề dài (z)
} HoaTietCaRo;


// ---- ca rô
HoaTietCaRo datHoaTietCaRo( Mau *mau0, Mau *mau1, float beRong, float beCao, float beDai );
Mau hoaTietCaRo( Vecto *viTri, HoaTietCaRo *hoaTietCao ); // họa tiết ca rô
