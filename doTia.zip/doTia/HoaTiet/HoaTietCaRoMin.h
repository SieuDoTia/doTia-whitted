#pragma once
#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Ca Rô Mịn */
typedef struct {
   Mau mau0;     // màu0
   Mau mau1;     // màu1
   float beRong; // bề rộng (x)
   float beCao;  // bề dài (y)
   float beDai;  // bề dài (z)
} HoaTietCaRoMin;


// ---- ca rô mịn
HoaTietCaRoMin datHoaTietCaRoMin( Mau *mau0, Mau *mau1, float beRong, float beCao, float beDai );
Mau hoaTietCaRoMin( Vecto *viTri, HoaTietCaRoMin *hoaTietCao ); // họa tiết ca rô