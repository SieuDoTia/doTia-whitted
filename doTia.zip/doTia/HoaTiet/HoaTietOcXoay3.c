#include "HoaTietOcXoay3.h"
#include <math.h>

#pragma mark ---- Họa Tiết Óc Xoáy
HoaTietOcXoay3 datHoaTietOcXoay3( Mau *mauNen, Mau *mauXoay0, Mau *mauXoay1, float beRongNet, float xoay, unsigned char soLapVong, float goc ) {
   HoaTietOcXoay3 hoaTietOcXoay3;
   hoaTietOcXoay3.mauNen.d = mauNen->d;
   hoaTietOcXoay3.mauNen.l = mauNen->l;
   hoaTietOcXoay3.mauNen.x = mauNen->x;
   hoaTietOcXoay3.mauNen.dd = mauNen->dd;
   hoaTietOcXoay3.mauNen.p = mauNen->p;
   
   hoaTietOcXoay3.mauXoay0.d = mauXoay0->d;
   hoaTietOcXoay3.mauXoay0.l = mauXoay0->l;
   hoaTietOcXoay3.mauXoay0.x = mauXoay0->x;
   hoaTietOcXoay3.mauXoay0.dd = mauXoay0->dd;
   hoaTietOcXoay3.mauXoay0.p = mauXoay0->p;
   
   hoaTietOcXoay3.mauXoay1.d = mauXoay1->d;
   hoaTietOcXoay3.mauXoay1.l = mauXoay1->l;
   hoaTietOcXoay3.mauXoay1.x = mauXoay1->x;
   hoaTietOcXoay3.mauXoay1.dd = mauXoay1->dd;
   hoaTietOcXoay3.mauXoay1.p = mauXoay1->p;
   
   hoaTietOcXoay3.beRongNet = beRongNet;
   hoaTietOcXoay3.xoay = xoay;
   hoaTietOcXoay3.soLapVong = soLapVong;
   
   hoaTietOcXoay3.doan = 6.283184f/(float)soLapVong;
   
   // ---- hạn chế góc
   if( goc < 0.0f )
      goc = 0.0f;
   else if( goc > 6.283184f )
      goc = 0.0f;
   
   hoaTietOcXoay3.goc = goc;

   return hoaTietOcXoay3;
}

// cho phóng to, xài giá trị < 1.0 cho rộng hơn
Mau hoaTietOcXoay3( Vecto *viTri, HoaTietOcXoay3 *hoaTietOcXoay3 ) {
   
   float banKinh = sqrtf( viTri->x*viTri->x + viTri->z*viTri->z );
   
   // ---- tính góc
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atanf( viTri->z/viTri->x );
   
   // ---- giữ 0 ≤ góc ≤ 2π
   if( viTri->x < 0.0f )
      goc += 3.141592f;
   else
      if( viTri->z < 0.0f )
         goc += 6.283184f;
   
   goc += hoaTietOcXoay3->xoay*banKinh;
   goc += hoaTietOcXoay3->goc;

   // ---- 0,0 đến 1,0
   goc /= hoaTietOcXoay3->doan;
   // ---- cần phần số
   goc -= floor(goc);

   // ---- chọn màu
   Mau mauTo;

   if( goc < 0.5f ) {
      if( goc < 0.5f - hoaTietOcXoay3->beRongNet ) {
         mauTo.d = hoaTietOcXoay3->mauNen.d;
         mauTo.l = hoaTietOcXoay3->mauNen.l;
         mauTo.x = hoaTietOcXoay3->mauNen.x;
         mauTo.dd = hoaTietOcXoay3->mauNen.dd;
         mauTo.p = hoaTietOcXoay3->mauNen.p;
      }
      else {
         mauTo.d = hoaTietOcXoay3->mauXoay0.d;
         mauTo.l = hoaTietOcXoay3->mauXoay0.l;
         mauTo.x = hoaTietOcXoay3->mauXoay0.x;
         mauTo.dd = hoaTietOcXoay3->mauXoay0.dd;
         mauTo.p = hoaTietOcXoay3->mauXoay0.p;
      }
   }
   else {
      if( goc < 1.0f - hoaTietOcXoay3->beRongNet ) {
         mauTo.d = hoaTietOcXoay3->mauNen.d;
         mauTo.l = hoaTietOcXoay3->mauNen.l;
         mauTo.x = hoaTietOcXoay3->mauNen.x;
         mauTo.dd = hoaTietOcXoay3->mauNen.dd;
         mauTo.p = hoaTietOcXoay3->mauNen.p;
      }
      else {
         mauTo.d = hoaTietOcXoay3->mauXoay1.d;
         mauTo.l = hoaTietOcXoay3->mauXoay1.l;
         mauTo.x = hoaTietOcXoay3->mauXoay1.x;
         mauTo.dd = hoaTietOcXoay3->mauXoay1.dd;
         mauTo.p = hoaTietOcXoay3->mauXoay1.p;
      }
   }

   //   printf( "hoatTietOcXoay3: goc %5.3f  banKinh %5.3f %5.3f  soVong %d  mauTo %5.3f\n", goc, banKinh - 0.5f*beRongNet, banKinh + 0.5f*beRongNet, soVong, mauTo.d);
   
   return mauTo;
}

