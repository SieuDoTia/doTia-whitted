#pragma once

#include "../Mau.h"
#include "../Toan/Vecto.h"

/* Họa Tiết Chấm Bị */
typedef struct {
   float banKinhBinh0; // bán kính bình phương 0
   float banKinhBinh1; // bán kính bình phương 1
   Vecto viTri0;   // vị trí 0
   Vecto viTri1;   // vị trí 1
   Mau mauNen;   // màu nền
   Mau mau0;     // màu0
   Mau mau1;     // màu1
   float beRong; // bề rộng (x)
   float beCao;  // bề dài (y)
   float beDai;  // bề dài (z)
} HoaTietHaiChamBi;


// ---- hai chấm bi
HoaTietHaiChamBi datHoaTietHaiChamBi( Mau *mauNen, Mau *mau0, Mau *mau1, float banKinh0, float banKinh1, Vecto *viTri0, Vecto *viTri1, float beRong, float beCao, float beDai );
Mau hoaTietHaiChamBi( Vecto *viTri, HoaTietHaiChamBi *hoaTietHaiChamBi );