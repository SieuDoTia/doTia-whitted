/* Đọc Tham Số */

#pragma mark Đọc Tham Số Dòng Lệnh
void docThamSoPhimTruong( int argc, char **argv, unsigned int *soPhimTruong );
void docThamSoHoatHinh( int argc, char **argv, unsigned int *soHoatHinhDau, unsigned int *soHoatHinhCuoi );
void docThamCoKich( int argc, char **argv, unsigned int *beRong, unsigned int *beCao, float *coThuocDiemAnh );
