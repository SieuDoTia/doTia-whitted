#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../XemCắt/BaoBi.h"


/* Hình Trụ */
typedef struct {
   float banKinh;
   float beCao;
   float hopQuanh[6];   // hộp quanh
} HinhTru;


// ---- hình trụ
HinhTru datHinhTru( float banKinh, float beCao, BaoBi *baoBiVT );  // đặt hình trụ
float xemCatHinhTru( HinhTru *hinhTru, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );  // xem cắt hình trụ
unsigned char xemDiemTrongHinhTru( HinhTru *hinhTru, Vecto *diem );