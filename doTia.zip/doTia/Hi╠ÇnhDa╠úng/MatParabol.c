#include "MatParabol.h"
#include "../HangSo.h"
#include <math.h>

#pragma mark ---- Mặt Parabol
// xài bán kính dương cho ở trên, âm cho ở dưới 
MatParabol datMatParabol( float banKinh, float beCao, BaoBi *baoBiVT ) {

   MatParabol matParabol;
   matParabol.banKinh = banKinh;
   matParabol.beCao = beCao;
   
   // ---- tinh hộp bao bì
   banKinh *= beCao;

   if( banKinh > 0.0f ) {
      baoBiVT->gocCucTieu.x = -banKinh;
      baoBiVT->gocCucTieu.y = 0.0f;
      baoBiVT->gocCucTieu.z = -banKinh;
      
      baoBiVT->gocCucDai.x = banKinh;
      baoBiVT->gocCucDai.y = beCao;
      baoBiVT->gocCucDai.z = banKinh;
   }
   else {
      baoBiVT->gocCucTieu.x = banKinh;
      baoBiVT->gocCucTieu.y = -beCao;
      baoBiVT->gocCucTieu.z = banKinh;
   
      baoBiVT->gocCucDai.x = -banKinh;
      baoBiVT->gocCucDai.y = 0.0f;
      baoBiVT->gocCucDai.z = -banKinh;
   }

   return matParabol;
}

// cộng thức: (x - x_0)^2 + (z - z_0)^2 = B(y - y0)
float xemCatMatParabol( MatParabol *matParabol, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {
   
   float nghiemGanNhat = kVO_CUC;
   
   // ---- tính vectơ từ trung tâm hình cầu đến điểm nhìn
   Vecto huongDenMatParabol;   // hướng đến trung tâm hình trụ
   huongDenMatParabol.x = tia->goc.x;
   huongDenMatParabol.y = tia->goc.y;
   huongDenMatParabol.z = tia->goc.z;
   
   float A = tia->huong.x*tia->huong.x + tia->huong.z*tia->huong.z;
   float B = 2.0f*(tia->huong.x*huongDenMatParabol.x + tia->huong.z*huongDenMatParabol.z) - tia->huong.y*matParabol->banKinh;
   float C = huongDenMatParabol.x*huongDenMatParabol.x + huongDenMatParabol.z*huongDenMatParabol.z - huongDenMatParabol.y*matParabol->banKinh;
   float D = B*B - 4.0f*A*C;
   
   if( D > 0.0f ) {
      // ---- tính nghiệm và nghiệm gần nhất, xài giải thuật chính xác hơn
      float Q;
      if( B < 0.0f )
         Q = -0.5f*(B - sqrtf(D) );
      else
         Q = -0.5f*(B + sqrtf(D) );
      
      float nghiem0 = Q/A;
      float nghiem1 = C/Q;
      
      // ---- coi trừng nghiệm âm và khác không vỉ tia coi thể bắt đẩu tại mặt của hình cầu
      if( nghiem0 < 0.01f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.01f )
         nghiem1 = kVO_CUC;
      
      // ---- gởi lại nghiệm nhỏ nhất mà dương
      if( nghiem0 < nghiem1 )
         nghiemGanNhat = nghiem0;
      else
         nghiemGanNhat = nghiem1;
   }
   
   // ---- biết có cắt trụ cao vô cụng nhưng chư biết có cắt trụ ở trên và ở dưới hai mặt của hình trụ
   unsigned char catNap = kSAI;  // cắt nắp
   if( nghiemGanNhat < kVO_CUC ) {
      // ---- kiểm tra tọa độ y của điểm trúng
      float toaDoY = tia->goc.y + nghiemGanNhat*tia->huong.y;
      // ---- không giống các mặt khác vì chỉ có mặt một bên
      float yMatTren = matParabol->beCao;
      float yMatDuoi = -matParabol->beCao;
      
      if( (toaDoY > yMatTren ) && (tia->huong.y < 0.0f) ) {   // tọa độ y cao hơn mà tia đang bay xuống
         float nghiemY = (yMatTren - tia->goc.y)/tia->huong.y;
         Vecto diemTrungTuongDoi;
         diemTrungTuongDoi.x = tia->goc.x + nghiemY*tia->huong.x;
         diemTrungTuongDoi.y = tia->goc.y + nghiemY*tia->huong.y;
         diemTrungTuongDoi.z = tia->goc.z + nghiemY*tia->huong.z;
         // ---- tính bán kính cắt ngang
         if( diemTrungTuongDoi.x*diemTrungTuongDoi.x + diemTrungTuongDoi.z*diemTrungTuongDoi.z < matParabol->banKinh*diemTrungTuongDoi.y ) {
            catNap = kTRUNG_TREN;
            nghiemGanNhat = nghiemY;
            diemTrung->x = tia->goc.x + nghiemY*tia->huong.x;
            diemTrung->y = tia->goc.y + nghiemY*tia->huong.y;
            diemTrung->z = tia->goc.z + nghiemY*tia->huong.z;
         }
         else
            nghiemGanNhat = kVO_CUC;
      }
      else if( (toaDoY < yMatDuoi) && (tia->huong.y > 0.0f) ) { // tọa độ y thấp hơn mà tia đang bay lên
         float nghiemY = (yMatDuoi - tia->goc.y)/tia->huong.y;
         Vecto diemTrungTuongDoi;
         diemTrungTuongDoi.x = tia->goc.x + nghiemY*tia->huong.x;
         diemTrungTuongDoi.y = tia->goc.y + nghiemY*tia->huong.y;
         diemTrungTuongDoi.z = tia->goc.z + nghiemY*tia->huong.z;
         if( diemTrungTuongDoi.x*diemTrungTuongDoi.x + diemTrungTuongDoi.z*diemTrungTuongDoi.z < matParabol->banKinh*diemTrungTuongDoi.y ) {
            catNap = kTRUNG_DUOI;
            nghiemGanNhat = nghiemY;
            diemTrung->x = tia->goc.x + nghiemY*tia->huong.x;
            diemTrung->y = tia->goc.y + nghiemY*tia->huong.y;
            diemTrung->z = tia->goc.z + nghiemY*tia->huong.z;
         }
         else
            nghiemGanNhat = kVO_CUC;
      }
      else if( (toaDoY < yMatTren) && (toaDoY > yMatDuoi) )
         catNap = kSAI;
      else
         nghiemGanNhat = kVO_CUC;    // không cắt hình trụ
   }
   
   // ---- pháp tuyến cho tường hình trụ
   if( nghiemGanNhat < kVO_CUC && !catNap ) {
      diemTrung->x = tia->goc.x + nghiemGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + nghiemGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + nghiemGanNhat*tia->huong.z;
      // ---- vectơ vuông góc cho phát tia tiếp
      phapTuyen->x = diemTrung->x;
      phapTuyen->y = -0.5f*matParabol->banKinh;
      phapTuyen->z = diemTrung->z;
      donViHoa( phapTuyen );
   }
   else if( catNap == kTRUNG_TREN ) {  // cắt nắp trên
      phapTuyen->x = 0.0f;
      phapTuyen->y = 1.0f;
      phapTuyen->z = 0.0f;
   }
   else if( catNap == kTRUNG_DUOI ) {  // cắt nắp dưới
      phapTuyen->x = 0.0f;
      phapTuyen->y = -1.0f;
      phapTuyen->z = 0.0f;
   }
   
   return nghiemGanNhat;
}
