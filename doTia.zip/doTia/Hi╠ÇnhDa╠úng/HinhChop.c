#include "HinhChop.h"
#include "../HangSo.h"
#include <math.h>
#include <stdlib.h>


#pragma mark ---- Hình Chóp
HinhChop datHinhChop( float banKinhDuoi, float banKinhTren, float beCao, unsigned char soLuongMat, BaoBi *baoBiVT ) {
   
   HinhChop hinhChop;
   
   if( soLuongMat < 3 )
      soLuongMat = 3;
   else if( soLuongMat > 100 )
      soLuongMat = 100;
   
   float nuaBeCao = beCao*0.5f;

   // ---- số lượng đỉnh 1 + (2*số lượng mặt) + 1
   hinhChop.mangDinh = malloc( ((soLuongMat << 1) + 2)*sizeof( Vecto ) );
   // ---- đỉnh cực
   hinhChop.mangDinh[0].x = 0.0f;
   hinhChop.mangDinh[0].y = nuaBeCao;
   hinhChop.mangDinh[0].z = 0.0f;

   // ---- đỉnh rành
   float goc = 0.0f;
   float buocGoc = 6.2831854f/soLuongMat;
   unsigned char soMat = 0;
   while( soMat < soLuongMat ) {
      // ----
      float cosGoc = cosf( goc );
      float sinGoc = sinf( goc );
      hinhChop.mangDinh[soMat+1].x = banKinhTren*cosGoc;
      hinhChop.mangDinh[soMat+1].y = nuaBeCao;
      hinhChop.mangDinh[soMat+1].z = banKinhTren*sinGoc;
      
      hinhChop.mangDinh[soMat+soLuongMat+1].x = banKinhDuoi*cosGoc;
      hinhChop.mangDinh[soMat+soLuongMat+1].y = -nuaBeCao;
      hinhChop.mangDinh[soMat+soLuongMat+1].z = banKinhDuoi*sinGoc;
      goc += buocGoc;
      soMat++;
   }
   
   // ---- đỉnh cực
   unsigned char chiSoDinhCuc = ((soLuongMat + 1) << 1) - 1;
   hinhChop.mangDinh[chiSoDinhCuc].x = 0.0f;
   hinhChop.mangDinh[chiSoDinhCuc].y = -nuaBeCao;
   hinhChop.mangDinh[chiSoDinhCuc].z = 0.0f;
   
/*   chiSoDinhCuc = 0;
   while( chiSoDinhCuc < ((soLuongMat + 1) << 1) ) {
      printf( "%d  %5.3f %5.3f %5.3f\n", chiSoDinhCuc, hinhChop.mangDinh[chiSoDinhCuc].x, hinhChop.mangDinh[chiSoDinhCuc].y, hinhChop.mangDinh[chiSoDinhCuc].z );
      chiSoDinhCuc++;
   }*/
   
   // ---- số lượng tam giác (1 + 2 + 1)*số lượng mặt --> nhân 3 cho số lượng đỉnh tam giác
   hinhChop.soLuongTamGiac = soLuongMat << 2;
   hinhChop.mangTamGiac = malloc( hinhChop.soLuongTamGiac*sizeof( TamGiac ) );
   
   // ---- mặt trên
   soMat = 0;
   while( soMat < soLuongMat - 1 ) {
      hinhChop.mangTamGiac[soMat].dinh0 = 0;
      hinhChop.mangTamGiac[soMat].dinh1 = soMat+2;
      hinhChop.mangTamGiac[soMat].dinh2 = soMat+1;
      soMat++;
   }
   
   hinhChop.mangTamGiac[soMat].dinh0 = 0;
   hinhChop.mangTamGiac[soMat].dinh1 = 1;
   hinhChop.mangTamGiac[soMat].dinh2 = soMat+1;
   
   // ---- mặt hông
   //   n+1                     n+1                  n
   //   +-----                   +-------------------+
   //   |     \-----\             \-----             |
   //   |            -----\             \-----       |
   //   +------------------+                  \------+
   // 2n+2               2n+1                       2n
   unsigned char chiSoMat = soLuongMat;
   soMat = 0;
   while( soMat < soLuongMat - 1 ) {
      hinhChop.mangTamGiac[chiSoMat].dinh0 = soMat+1;
      hinhChop.mangTamGiac[chiSoMat].dinh1 = soMat+2;
      hinhChop.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
      chiSoMat++;

      hinhChop.mangTamGiac[chiSoMat].dinh0 = soMat+2;
      hinhChop.mangTamGiac[chiSoMat].dinh1 = soMat+soLuongMat+2;
      hinhChop.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
      chiSoMat++;
      soMat++;
   }
   
   hinhChop.mangTamGiac[chiSoMat].dinh0 = soMat+1;
   hinhChop.mangTamGiac[chiSoMat].dinh1 = 1;
   hinhChop.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
   chiSoMat++;
   
   hinhChop.mangTamGiac[chiSoMat].dinh0 = 1;
   hinhChop.mangTamGiac[chiSoMat].dinh1 = soLuongMat+1;
   hinhChop.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
   chiSoMat++;

   // ---- mặt dưới
   soMat = 0;
   while( soMat < soLuongMat - 1 ) {
      hinhChop.mangTamGiac[chiSoMat].dinh0 = chiSoDinhCuc;
      hinhChop.mangTamGiac[chiSoMat].dinh1 = soMat+soLuongMat+1;
      hinhChop.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+2;
      soMat++;
      chiSoMat++;
   }

   hinhChop.mangTamGiac[chiSoMat].dinh0 = chiSoDinhCuc;
   hinhChop.mangTamGiac[chiSoMat].dinh1 = soMat+soLuongMat+1;
   hinhChop.mangTamGiac[chiSoMat].dinh2 = soLuongMat+1;
   /*
   chiSoMat = 0;
   while( chiSoMat < hinhChop.soLuongTamGiac ) {
      printf( "%d  %d %d %d\n", chiSoMat, hinhChop.mangTamGiac[chiSoMat].dinh0, hinhChop.mangTamGiac[chiSoMat].dinh1, hinhChop.mangTamGiac[chiSoMat].dinh2 );
      chiSoMat++;
   } */
   
   // ---- xài bán kính lớn nhất
   float banKinh = banKinhDuoi > banKinhTren ? banKinhDuoi : banKinhTren;
   
   baoBiVT->gocCucTieu.x = -banKinh;
   baoBiVT->gocCucDai.x = banKinh;
   baoBiVT->gocCucTieu.y = -0.5*beCao;
   baoBiVT->gocCucDai.y = 0.5f*beCao;
   baoBiVT->gocCucTieu.z = -banKinh;
   baoBiVT->gocCucDai.z = banKinh;

   return hinhChop;
}
