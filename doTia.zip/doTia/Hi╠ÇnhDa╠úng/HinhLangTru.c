#include "HinhLangTru.h"
#include "../HangSo.h"
#include <math.h>
#include <stdlib.h>


#pragma mark ---- Hình Lăng Trụ
HinhLangTru datHinhLangTru( float banKinh, float beCao, unsigned char soLuongMat, BaoBi *baoBiVT ) {
   
   HinhLangTru hinhLangTru;
   
   if( soLuongMat < 3 )
      soLuongMat = 3;
   else if( soLuongMat > 100 )
      soLuongMat = 100;
   
   float nuaBeCao = beCao*0.5f;

   // ---- số lượng đỉnh 1 + (2*số lượng mặt) + 1
   hinhLangTru.mangDinh = malloc( ((soLuongMat << 1) + 2)*sizeof( Vecto ) );
   // ---- đỉnh cực
   hinhLangTru.mangDinh[0].x = 0.0f;
   hinhLangTru.mangDinh[0].y = nuaBeCao;
   hinhLangTru.mangDinh[0].z = 0.0f;

   // ---- đỉnh rành
   float goc = 0.0f;
   float buocGoc = 6.2831854f/soLuongMat;
   unsigned char soMat = 0;
   while( soMat < soLuongMat ) {
      // ---- 
      hinhLangTru.mangDinh[soMat+1].x = banKinh*cosf( goc );
      hinhLangTru.mangDinh[soMat+1].y = nuaBeCao;
      hinhLangTru.mangDinh[soMat+1].z = banKinh*sinf( goc );
      
      hinhLangTru.mangDinh[soMat+soLuongMat+1].x = hinhLangTru.mangDinh[soMat+1].x;
      hinhLangTru.mangDinh[soMat+soLuongMat+1].y = -nuaBeCao;
      hinhLangTru.mangDinh[soMat+soLuongMat+1].z = hinhLangTru.mangDinh[soMat+1].z;
      goc += buocGoc;
      soMat++;
   }
   
   // ---- đỉnh cực
   unsigned char chiSoDinhCuc = ((soLuongMat + 1) << 1) - 1;
   hinhLangTru.mangDinh[chiSoDinhCuc].x = 0.0f;
   hinhLangTru.mangDinh[chiSoDinhCuc].y = -nuaBeCao;
   hinhLangTru.mangDinh[chiSoDinhCuc].z = 0.0f;
   
/*   chiSoDinhCuc = 0;
   while( chiSoDinhCuc < ((soLuongMat + 1) << 1) ) {
      printf( "%d  %5.3f %5.3f %5.3f\n", chiSoDinhCuc, hinhLangTru.mangDinh[chiSoDinhCuc].x, hinhLangTru.mangDinh[chiSoDinhCuc].y, hinhLangTru.mangDinh[chiSoDinhCuc].z );
      chiSoDinhCuc++;
   }*/
   
   // ---- số lượng tam giác (1 + 2 + 1)*số lượng mặt --> nhân 3 cho số lượng đỉnh tam giác
   hinhLangTru.soLuongTamGiac = soLuongMat << 2;
   hinhLangTru.mangTamGiac = malloc( hinhLangTru.soLuongTamGiac*sizeof( TamGiac ) );
   
   // ---- mặt trên
   soMat = 0;
   while( soMat < soLuongMat - 1 ) {
      hinhLangTru.mangTamGiac[soMat].dinh0 = 0;
      hinhLangTru.mangTamGiac[soMat].dinh1 = soMat+2;
      hinhLangTru.mangTamGiac[soMat].dinh2 = soMat+1;
      soMat++;
   }
   
   hinhLangTru.mangTamGiac[soMat].dinh0 = 0;
   hinhLangTru.mangTamGiac[soMat].dinh1 = 1;
   hinhLangTru.mangTamGiac[soMat].dinh2 = soMat+1;
   
   // ---- mặt hông
   //   n+1                     n+1                  n
   //   +-----                   +-------------------+
   //   |     \-----\             \-----             |
   //   |            -----\             \-----       |
   //   +------------------+                  \------+
   // 2n+2               2n+1                       2n
   unsigned char chiSoMat = soLuongMat;
   soMat = 0;
   while( soMat < soLuongMat - 1 ) {
      hinhLangTru.mangTamGiac[chiSoMat].dinh0 = soMat+1;
      hinhLangTru.mangTamGiac[chiSoMat].dinh1 = soMat+2;
      hinhLangTru.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
      chiSoMat++;

      hinhLangTru.mangTamGiac[chiSoMat].dinh0 = soMat+2;
      hinhLangTru.mangTamGiac[chiSoMat].dinh1 = soMat+soLuongMat+2;
      hinhLangTru.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
      chiSoMat++;
      soMat++;
   }
   
   hinhLangTru.mangTamGiac[chiSoMat].dinh0 = soMat+1;
   hinhLangTru.mangTamGiac[chiSoMat].dinh1 = 1;
   hinhLangTru.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
   chiSoMat++;
   
   hinhLangTru.mangTamGiac[chiSoMat].dinh0 = 1;
   hinhLangTru.mangTamGiac[chiSoMat].dinh1 = soLuongMat+1;
   hinhLangTru.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+1;
   chiSoMat++;

   // ---- mặt dưới
   soMat = 0;
   while( soMat < soLuongMat - 1 ) {
      hinhLangTru.mangTamGiac[chiSoMat].dinh0 = chiSoDinhCuc;
      hinhLangTru.mangTamGiac[chiSoMat].dinh1 = soMat+soLuongMat+1;
      hinhLangTru.mangTamGiac[chiSoMat].dinh2 = soMat+soLuongMat+2;
      soMat++;
      chiSoMat++;
   }

   hinhLangTru.mangTamGiac[chiSoMat].dinh0 = chiSoDinhCuc;
   hinhLangTru.mangTamGiac[chiSoMat].dinh1 = soMat+soLuongMat+1;
   hinhLangTru.mangTamGiac[chiSoMat].dinh2 = soLuongMat+1;
   /*
   chiSoMat = 0;
   while( chiSoMat < hinhLangTru.soLuongTamGiac ) {
      printf( "%d  %d %d %d\n", chiSoMat, hinhLangTru.mangTamGiac[chiSoMat].dinh0, hinhLangTru.mangTamGiac[chiSoMat].dinh1, hinhLangTru.mangTamGiac[chiSoMat].dinh2 );
      chiSoMat++;
   } */
   
   baoBiVT->gocCucTieu.x = -banKinh;
   baoBiVT->gocCucDai.x = banKinh;
   baoBiVT->gocCucTieu.y = -0.5*beCao;
   baoBiVT->gocCucDai.y = 0.5f*beCao;
   baoBiVT->gocCucTieu.z = -banKinh;
   baoBiVT->gocCucDai.z = banKinh;

   return hinhLangTru;
}
