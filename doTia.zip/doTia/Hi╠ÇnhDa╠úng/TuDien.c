#include "TuDien.h"
#include "../HangSo.h"


#pragma mark ---- Tứ Diện
TuDien datTuDien( float beRong, float beCao, float beDai, BaoBi *baoBiVT ) {
   
   TuDien tuDien;
   tuDien.soLuongTamGiac = 4;

   // ---- tính các đỉnh
   tuDien.mangDinh[0].x = 0.0f;
   tuDien.mangDinh[0].y = beCao;
   tuDien.mangDinh[0].z = 0.0f;

   tuDien.mangDinh[1].x = 0.0f;
   tuDien.mangDinh[1].y = -0.5f*beCao;
   tuDien.mangDinh[1].z = 0.868f*beDai;
   
   tuDien.mangDinh[2].x = 0.868f*beRong;
   tuDien.mangDinh[2].y = -0.5f*beCao;
   tuDien.mangDinh[2].z = -0.868f*0.5f*beDai;

   tuDien.mangDinh[3].x = -0.868f*beRong;
   tuDien.mangDinh[3].y = -0.5f*beCao;
   tuDien.mangDinh[3].z = -0.868f*0.5f*beDai;

   // ----
   tuDien.mangTamGiac[0].dinh0 = 0;
   tuDien.mangTamGiac[0].dinh1 = 1;
   tuDien.mangTamGiac[0].dinh2 = 2;

   tuDien.mangTamGiac[1].dinh0 = 0;
   tuDien.mangTamGiac[1].dinh1 = 2;
   tuDien.mangTamGiac[1].dinh2 = 3;

   tuDien.mangTamGiac[2].dinh0 = 0;
   tuDien.mangTamGiac[2].dinh1 = 3;
   tuDien.mangTamGiac[2].dinh2 = 1;
   // ---- dái
   tuDien.mangTamGiac[3].dinh0 = 3;
   tuDien.mangTamGiac[3].dinh1 = 2;
   tuDien.mangTamGiac[3].dinh2 = 1;

   baoBiVT->gocCucTieu.x = -0.868f*beRong;
   baoBiVT->gocCucDai.x = 0.868f*beRong;
   baoBiVT->gocCucTieu.y = -0.5f*beCao;
   baoBiVT->gocCucDai.y = beCao;
   baoBiVT->gocCucTieu.z = -0.5f*0.868f*beDai;
   baoBiVT->gocCucDai.z = 0.868f*beDai;

   return tuDien;
}
