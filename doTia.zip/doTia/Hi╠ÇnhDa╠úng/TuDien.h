#pragma once
#include "TamGiac.h"
#include "../Toán/Vecto.h"
#include "../XemCắt/BaoBi.h"


/* Tứ Diện */
typedef struct {
//   Vecto viTri;    // vị trí
//   float banKinh;  // bán kính
   Vecto mangDinh[4];   // mảng đỉnh
   TamGiac mangTamGiac[4]; // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} TuDien;


// ---- tứ diện
TuDien datTuDien( float beRong, float beCao, float beDai, BaoBi *baoBiVT ); // đặt tứ diện
