#include "ThapNhiDien.h"

#pragma mark ---- Thập Nhị Diện
ThapNhiDien datThapNhiDien( float beRong, float beCao, float beDai, BaoBi *baoBi ) {
   
   ThapNhiDien thapNhiDien;
   thapNhiDien.soLuongTamGiac = 60;  // 12 ngũ giảc x 5 tam giác
   
   // ==== các tâm
   // ---- tâm mặt trên
   thapNhiDien.mangDinh[0].x = 0.0f;
   thapNhiDien.mangDinh[0].y = 0.79465f*beCao;
   thapNhiDien.mangDinh[0].z = 0.0f;
   // ---- tâm 5 ngũ giác lớp trên
   thapNhiDien.mangDinh[1].x = 0.417777f*beRong;
   thapNhiDien.mangDinh[1].y = 0.35568f*beCao;
   thapNhiDien.mangDinh[1].z = 0.57551f*beDai;
   
   thapNhiDien.mangDinh[2].x = 0.67597f*beRong;
   thapNhiDien.mangDinh[2].y = 0.35568f*beCao;
   thapNhiDien.mangDinh[2].z = -0.21915f*beDai;

   thapNhiDien.mangDinh[3].x = 0.000000f*beRong;
   thapNhiDien.mangDinh[3].y = 0.35568f*beCao;
   thapNhiDien.mangDinh[3].z = -0.71027f*beDai;

   thapNhiDien.mangDinh[4].x = -0.67597f*beRong;
   thapNhiDien.mangDinh[4].y = 0.35568f*beCao;
   thapNhiDien.mangDinh[4].z = -0.21915f*beDai;

   thapNhiDien.mangDinh[5].x = -0.41777f*beRong;
   thapNhiDien.mangDinh[5].y = 0.35568f*beCao;
   thapNhiDien.mangDinh[5].z = 0.57551f*beDai;
   // ---- tâm 5 ngũ giác lớp dưới
   thapNhiDien.mangDinh[6].x = 0.00000f*beRong;
   thapNhiDien.mangDinh[6].y = -0.35568f*beCao;
   thapNhiDien.mangDinh[6].z = 0.71027f*beDai;
   
   thapNhiDien.mangDinh[7].x = 0.67597f*beRong;
   thapNhiDien.mangDinh[7].y = -0.35568f*beCao;
   thapNhiDien.mangDinh[7].z = 0.21915f*beDai;

   thapNhiDien.mangDinh[8].x = 0.41777f*beRong;
   thapNhiDien.mangDinh[8].y = -0.35568f*beCao;
   thapNhiDien.mangDinh[8].z = -0.57551f*beDai;
   
   thapNhiDien.mangDinh[9].x = -0.41777f*beRong;
   thapNhiDien.mangDinh[9].y = -0.35568f*beCao;
   thapNhiDien.mangDinh[9].z = -0.57551f*beDai;

   thapNhiDien.mangDinh[10].x = -0.67597f*beRong;
   thapNhiDien.mangDinh[10].y = -0.35568f*beCao;
   thapNhiDien.mangDinh[10].z = 0.21915f*beDai;
   // ---- tâm mặt dưới
   thapNhiDien.mangDinh[11].x = 0.00000f*beRong;
   thapNhiDien.mangDinh[11].y = -0.79465f*beCao;
   thapNhiDien.mangDinh[11].z = 0.000000f*beDai;

   // ---- rìa mặt trên
   thapNhiDien.mangDinh[12].x = 0.0f;
   thapNhiDien.mangDinh[12].y = 0.79465451f*beCao;
   thapNhiDien.mangDinh[12].z = 0.60706196f*beRong;

   thapNhiDien.mangDinh[13].x = 0.57735022f*beDai;
   thapNhiDien.mangDinh[13].y = 0.79465451f*beCao;
   thapNhiDien.mangDinh[13].z = 0.18759247f*beRong;
   
   thapNhiDien.mangDinh[14].x = 0.35682211f*beDai;
   thapNhiDien.mangDinh[14].y = 0.79465451f*beCao;
   thapNhiDien.mangDinh[14].z = -0.49112344f*beRong;
   
   thapNhiDien.mangDinh[15].x = -0.35682211f*beDai;
   thapNhiDien.mangDinh[15].y = 0.79465451f*beCao;
   thapNhiDien.mangDinh[15].z = -0.49112344f*beRong;

   thapNhiDien.mangDinh[16].x = -0.57735022f*beDai;
   thapNhiDien.mangDinh[16].y = 0.79465451f*beCao;
   thapNhiDien.mangDinh[16].z = 0.18759247f*beRong;

   // ---- xích đạo
   thapNhiDien.mangDinh[17].x = 0.0f;
   thapNhiDien.mangDinh[17].y = 0.18759248f*beCao;
   thapNhiDien.mangDinh[17].z = 0.98224695f*beRong;
   
   thapNhiDien.mangDinh[18].x = 0.93417235f*beDai;
   thapNhiDien.mangDinh[18].y = 0.18759248f*beCao;
   thapNhiDien.mangDinh[18].z = 0.30353102f*beRong;

   thapNhiDien.mangDinh[19].x = 0.57735022f*beDai;
   thapNhiDien.mangDinh[19].y = 0.18759248f*beCao;
   thapNhiDien.mangDinh[19].z = -0.79465445f*beRong;

   thapNhiDien.mangDinh[20].x = -0.57735022f*beDai;
   thapNhiDien.mangDinh[20].y = 0.18759248f*beCao;
   thapNhiDien.mangDinh[20].z = -0.79465445f*beRong;
   
   thapNhiDien.mangDinh[21].x = -0.93417235f*beDai;
   thapNhiDien.mangDinh[21].y = 0.18759248f*beCao;
   thapNhiDien.mangDinh[21].z = 0.30353102f*beRong;
   
   // ----
   thapNhiDien.mangDinh[22].x = 0.57735022f*beDai;
   thapNhiDien.mangDinh[22].y = -0.18759248f*beCao;
   thapNhiDien.mangDinh[22].z = 0.79465445f*beRong;
   
   thapNhiDien.mangDinh[23].x = 0.93417235f*beDai;
   thapNhiDien.mangDinh[23].y = -0.18759248f*beCao;
   thapNhiDien.mangDinh[23].z = -0.30353102f*beRong;
   
   thapNhiDien.mangDinh[24].x = 0.0f;
   thapNhiDien.mangDinh[24].y = -0.18759248f*beCao;
   thapNhiDien.mangDinh[24].z = -0.98224695f*beRong;

   thapNhiDien.mangDinh[25].x = -0.93417235f*beDai;
   thapNhiDien.mangDinh[25].y = -0.18759248f*beCao;
   thapNhiDien.mangDinh[25].z = -0.30353102f*beRong;
   
   thapNhiDien.mangDinh[26].x = -0.57735022f*beDai;
   thapNhiDien.mangDinh[26].y = -0.18759248f*beCao;
   thapNhiDien.mangDinh[26].z = 0.79465445f*beRong;

   // ---- rìa mặt dưới
   thapNhiDien.mangDinh[27].x = 0.35682211f*beDai;
   thapNhiDien.mangDinh[27].y = -0.79465451f*beCao;
   thapNhiDien.mangDinh[27].z = 0.49112344f*beRong;
   
   thapNhiDien.mangDinh[28].x = 0.57735022f*beDai;
   thapNhiDien.mangDinh[28].y = -0.79465451f*beCao;
   thapNhiDien.mangDinh[28].z = -0.18759247f*beRong;
   
   thapNhiDien.mangDinh[29].x = 0.0f;
   thapNhiDien.mangDinh[29].y = -0.79465451f*beCao;
   thapNhiDien.mangDinh[29].z = -0.60706196f*beRong;
   
   thapNhiDien.mangDinh[30].x = -0.57735022f*beDai;
   thapNhiDien.mangDinh[30].y = -0.79465451f*beCao;
   thapNhiDien.mangDinh[30].z = -0.18759247f*beRong;
   
   thapNhiDien.mangDinh[31].x = -0.35682211f*beDai;
   thapNhiDien.mangDinh[31].y = -0.79465451f*beCao;
   thapNhiDien.mangDinh[31].z = 0.49112344f*beRong;

   // ---- mảng tam giác
   // ngũ giác trên
   thapNhiDien.mangTamGiac[0].dinh0 = 0;
   thapNhiDien.mangTamGiac[0].dinh1 = 12;
   thapNhiDien.mangTamGiac[0].dinh2 = 13;
   
   thapNhiDien.mangTamGiac[1].dinh0 = 0;
   thapNhiDien.mangTamGiac[1].dinh1 = 13;
   thapNhiDien.mangTamGiac[1].dinh2 = 14;
   
   thapNhiDien.mangTamGiac[2].dinh0 = 0;
   thapNhiDien.mangTamGiac[2].dinh1 = 14;
   thapNhiDien.mangTamGiac[2].dinh2 = 15;
   
   thapNhiDien.mangTamGiac[3].dinh0 = 0;
   thapNhiDien.mangTamGiac[3].dinh1 = 15;
   thapNhiDien.mangTamGiac[3].dinh2 = 16;

   thapNhiDien.mangTamGiac[4].dinh0 = 0;
   thapNhiDien.mangTamGiac[4].dinh1 = 16;
   thapNhiDien.mangTamGiac[4].dinh2 = 12;
   // ----
   thapNhiDien.mangTamGiac[5].dinh0 = 1;
   thapNhiDien.mangTamGiac[5].dinh1 = 13;
   thapNhiDien.mangTamGiac[5].dinh2 = 12;
   
   thapNhiDien.mangTamGiac[6].dinh0 = 1;
   thapNhiDien.mangTamGiac[6].dinh1 = 12;
   thapNhiDien.mangTamGiac[6].dinh2 = 17;
   
   thapNhiDien.mangTamGiac[7].dinh0 = 1;
   thapNhiDien.mangTamGiac[7].dinh1 = 17;
   thapNhiDien.mangTamGiac[7].dinh2 = 22;
   
   thapNhiDien.mangTamGiac[8].dinh0 = 1;
   thapNhiDien.mangTamGiac[8].dinh1 = 22;
   thapNhiDien.mangTamGiac[8].dinh2 = 18;
   
   thapNhiDien.mangTamGiac[9].dinh0 = 1;
   thapNhiDien.mangTamGiac[9].dinh1 = 18;
   thapNhiDien.mangTamGiac[9].dinh2 = 13;
   // ----
   thapNhiDien.mangTamGiac[10].dinh0 = 2;
   thapNhiDien.mangTamGiac[10].dinh1 = 14;
   thapNhiDien.mangTamGiac[10].dinh2 = 13;
   
   thapNhiDien.mangTamGiac[11].dinh0 = 2;
   thapNhiDien.mangTamGiac[11].dinh1 = 13;
   thapNhiDien.mangTamGiac[11].dinh2 = 18;

   thapNhiDien.mangTamGiac[12].dinh0 = 2;
   thapNhiDien.mangTamGiac[12].dinh1 = 18;
   thapNhiDien.mangTamGiac[12].dinh2 = 23;
   
   thapNhiDien.mangTamGiac[13].dinh0 = 2;
   thapNhiDien.mangTamGiac[13].dinh1 = 23;
   thapNhiDien.mangTamGiac[13].dinh2 = 19;

   thapNhiDien.mangTamGiac[14].dinh0 = 2;
   thapNhiDien.mangTamGiac[14].dinh1 = 19;
   thapNhiDien.mangTamGiac[14].dinh2 = 14;
   // ----
   thapNhiDien.mangTamGiac[15].dinh0 = 3;
   thapNhiDien.mangTamGiac[15].dinh1 = 15;
   thapNhiDien.mangTamGiac[15].dinh2 = 14;

   thapNhiDien.mangTamGiac[16].dinh0 = 3;
   thapNhiDien.mangTamGiac[16].dinh1 = 14;
   thapNhiDien.mangTamGiac[16].dinh2 = 19;
   
   thapNhiDien.mangTamGiac[17].dinh0 = 3;
   thapNhiDien.mangTamGiac[17].dinh1 = 19;
   thapNhiDien.mangTamGiac[17].dinh2 = 24;
   
   thapNhiDien.mangTamGiac[18].dinh0 = 3;
   thapNhiDien.mangTamGiac[18].dinh1 = 24;
   thapNhiDien.mangTamGiac[18].dinh2 = 20;
   
   thapNhiDien.mangTamGiac[19].dinh0 = 3;
   thapNhiDien.mangTamGiac[19].dinh1 = 20;
   thapNhiDien.mangTamGiac[19].dinh2 = 15;
   // ----
   thapNhiDien.mangTamGiac[20].dinh0 = 4;
   thapNhiDien.mangTamGiac[20].dinh1 = 16;
   thapNhiDien.mangTamGiac[20].dinh2 = 15;
   
   thapNhiDien.mangTamGiac[21].dinh0 = 4;
   thapNhiDien.mangTamGiac[21].dinh1 = 15;
   thapNhiDien.mangTamGiac[21].dinh2 = 20;

   thapNhiDien.mangTamGiac[22].dinh0 = 4;
   thapNhiDien.mangTamGiac[22].dinh1 = 20;
   thapNhiDien.mangTamGiac[22].dinh2 = 25;

   thapNhiDien.mangTamGiac[23].dinh0 = 4;
   thapNhiDien.mangTamGiac[23].dinh1 = 25;
   thapNhiDien.mangTamGiac[23].dinh2 = 21;

   thapNhiDien.mangTamGiac[24].dinh0 = 4;
   thapNhiDien.mangTamGiac[24].dinh1 = 21;
   thapNhiDien.mangTamGiac[24].dinh2 = 16;
   // ----
   thapNhiDien.mangTamGiac[25].dinh0 = 5;
   thapNhiDien.mangTamGiac[25].dinh1 = 12;
   thapNhiDien.mangTamGiac[25].dinh2 = 16;

   thapNhiDien.mangTamGiac[26].dinh0 = 5;
   thapNhiDien.mangTamGiac[26].dinh1 = 16;
   thapNhiDien.mangTamGiac[26].dinh2 = 21;

   thapNhiDien.mangTamGiac[27].dinh0 = 5;
   thapNhiDien.mangTamGiac[27].dinh1 = 21;
   thapNhiDien.mangTamGiac[27].dinh2 = 26;

   thapNhiDien.mangTamGiac[28].dinh0 = 5;
   thapNhiDien.mangTamGiac[28].dinh1 = 26;
   thapNhiDien.mangTamGiac[28].dinh2 = 17;
   
   thapNhiDien.mangTamGiac[29].dinh0 = 5;
   thapNhiDien.mangTamGiac[29].dinh1 = 17;
   thapNhiDien.mangTamGiac[29].dinh2 = 12;
   // ====
   thapNhiDien.mangTamGiac[30].dinh0 = 6;
   thapNhiDien.mangTamGiac[30].dinh1 = 31;
   thapNhiDien.mangTamGiac[30].dinh2 = 27;
   
   thapNhiDien.mangTamGiac[31].dinh0 = 6;
   thapNhiDien.mangTamGiac[31].dinh1 = 26;
   thapNhiDien.mangTamGiac[31].dinh2 = 31;

   thapNhiDien.mangTamGiac[32].dinh0 = 6;
   thapNhiDien.mangTamGiac[32].dinh1 = 17;
   thapNhiDien.mangTamGiac[32].dinh2 = 26;
   
   thapNhiDien.mangTamGiac[33].dinh0 = 6;
   thapNhiDien.mangTamGiac[33].dinh1 = 22;
   thapNhiDien.mangTamGiac[33].dinh2 = 17;
   
   thapNhiDien.mangTamGiac[34].dinh0 = 6;
   thapNhiDien.mangTamGiac[34].dinh1 = 27;
   thapNhiDien.mangTamGiac[34].dinh2 = 22;
   // ----
   thapNhiDien.mangTamGiac[35].dinh0 = 7;
   thapNhiDien.mangTamGiac[35].dinh1 = 27;
   thapNhiDien.mangTamGiac[35].dinh2 = 28;
   
   thapNhiDien.mangTamGiac[36].dinh0 = 7;
   thapNhiDien.mangTamGiac[36].dinh1 = 22;
   thapNhiDien.mangTamGiac[36].dinh2 = 27;

   thapNhiDien.mangTamGiac[37].dinh0 = 7;
   thapNhiDien.mangTamGiac[37].dinh1 = 18;
   thapNhiDien.mangTamGiac[37].dinh2 = 22;

   thapNhiDien.mangTamGiac[38].dinh0 = 7;
   thapNhiDien.mangTamGiac[38].dinh1 = 23;
   thapNhiDien.mangTamGiac[38].dinh2 = 18;
   
   thapNhiDien.mangTamGiac[39].dinh0 = 7;
   thapNhiDien.mangTamGiac[39].dinh1 = 28;
   thapNhiDien.mangTamGiac[39].dinh2 = 23;
   // ----
   thapNhiDien.mangTamGiac[40].dinh0 = 8;
   thapNhiDien.mangTamGiac[40].dinh1 = 28;
   thapNhiDien.mangTamGiac[40].dinh2 = 29;

   thapNhiDien.mangTamGiac[41].dinh0 = 8;
   thapNhiDien.mangTamGiac[41].dinh1 = 23;
   thapNhiDien.mangTamGiac[41].dinh2 = 28;

   thapNhiDien.mangTamGiac[42].dinh0 = 8;
   thapNhiDien.mangTamGiac[42].dinh1 = 19;
   thapNhiDien.mangTamGiac[42].dinh2 = 23;

   thapNhiDien.mangTamGiac[43].dinh0 = 8;
   thapNhiDien.mangTamGiac[43].dinh1 = 24;
   thapNhiDien.mangTamGiac[43].dinh2 = 19;
   
   thapNhiDien.mangTamGiac[44].dinh0 = 8;
   thapNhiDien.mangTamGiac[44].dinh1 = 29;
   thapNhiDien.mangTamGiac[44].dinh2 = 24;
   // ----
   thapNhiDien.mangTamGiac[45].dinh0 = 9;
   thapNhiDien.mangTamGiac[45].dinh1 = 29;
   thapNhiDien.mangTamGiac[45].dinh2 = 30;
   
   thapNhiDien.mangTamGiac[46].dinh0 = 9;
   thapNhiDien.mangTamGiac[46].dinh1 = 24;
   thapNhiDien.mangTamGiac[46].dinh2 = 29;

   thapNhiDien.mangTamGiac[47].dinh0 = 9;
   thapNhiDien.mangTamGiac[47].dinh1 = 20;
   thapNhiDien.mangTamGiac[47].dinh2 = 24;

   thapNhiDien.mangTamGiac[48].dinh0 = 9;
   thapNhiDien.mangTamGiac[48].dinh1 = 25;
   thapNhiDien.mangTamGiac[48].dinh2 = 20;
   
   thapNhiDien.mangTamGiac[49].dinh0 = 9;
   thapNhiDien.mangTamGiac[49].dinh1 = 30;
   thapNhiDien.mangTamGiac[49].dinh2 = 25;
   // ----
   thapNhiDien.mangTamGiac[50].dinh0 = 10;
   thapNhiDien.mangTamGiac[50].dinh1 = 30;
   thapNhiDien.mangTamGiac[50].dinh2 = 31;
   
   thapNhiDien.mangTamGiac[51].dinh0 = 10;
   thapNhiDien.mangTamGiac[51].dinh1 = 25;
   thapNhiDien.mangTamGiac[51].dinh2 = 30;
   
   thapNhiDien.mangTamGiac[52].dinh0 = 10;
   thapNhiDien.mangTamGiac[52].dinh1 = 21;
   thapNhiDien.mangTamGiac[52].dinh2 = 25;

   thapNhiDien.mangTamGiac[53].dinh0 = 10;
   thapNhiDien.mangTamGiac[53].dinh1 = 26;
   thapNhiDien.mangTamGiac[53].dinh2 = 21;

   thapNhiDien.mangTamGiac[54].dinh0 = 10;
   thapNhiDien.mangTamGiac[54].dinh1 = 31;
   thapNhiDien.mangTamGiac[54].dinh2 = 26;
   // ----
   thapNhiDien.mangTamGiac[55].dinh0 = 11;
   thapNhiDien.mangTamGiac[55].dinh1 = 28;
   thapNhiDien.mangTamGiac[55].dinh2 = 27;
   
   thapNhiDien.mangTamGiac[56].dinh0 = 11;
   thapNhiDien.mangTamGiac[56].dinh1 = 29;
   thapNhiDien.mangTamGiac[56].dinh2 = 28;

   thapNhiDien.mangTamGiac[57].dinh0 = 11;
   thapNhiDien.mangTamGiac[57].dinh1 = 30;
   thapNhiDien.mangTamGiac[57].dinh2 = 29;

   thapNhiDien.mangTamGiac[58].dinh0 = 11;
   thapNhiDien.mangTamGiac[58].dinh1 = 31;
   thapNhiDien.mangTamGiac[58].dinh2 = 30;
   
   thapNhiDien.mangTamGiac[59].dinh0 = 11;
   thapNhiDien.mangTamGiac[59].dinh1 = 27;
   thapNhiDien.mangTamGiac[59].dinh2 = 31;

   baoBi->gocCucTieu.x = -0.98224695f*beRong;
   baoBi->gocCucDai.x = 0.98224695f*beRong;
   baoBi->gocCucTieu.y = -0.79465451f*beCao;
   baoBi->gocCucDai.y = 0.79465451f*beCao;
   baoBi->gocCucTieu.z = -0.93417235f*beDai;
   baoBi->gocCucDai.z = 0.93417235f*beDai;
   
   return thapNhiDien;
}
