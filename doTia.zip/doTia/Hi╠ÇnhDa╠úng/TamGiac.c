#include "TamGiac.h"
#include "../HangSo.h"


#pragma mark ---- Tam Giác
Vecto tinhPhapTuyenChoTamGiac( Vecto *tamGiac ) {
   
   Vecto canh_01;
   Vecto canh_02;

   canh_01.x = tamGiac[1].x - tamGiac[0].x;
   canh_01.y = tamGiac[1].y - tamGiac[0].y;
   canh_01.z = tamGiac[1].z - tamGiac[0].z;

   canh_02.x = tamGiac[2].x - tamGiac[0].x;
   canh_02.y = tamGiac[2].y - tamGiac[0].y;
   canh_02.z = tamGiac[2].z - tamGiac[0].z;

   Vecto phapTuyen = tichCoHuong( &canh_01, &canh_02 );
   donViHoa( &phapTuyen );
   
   return phapTuyen;
}

#define kCACH_TOI_THIEU 1e-5f

// ---- Giải thuật Möller–Trumbore cho xem tia có cắt tam gíac
float xemCatTamGiacMT( Vecto *mangDinhTamGiac, Tia *tia ) {
   
   float khoangCach = kVO_CUC;
   // ---- tính vectơ hai cạnh từ đỉnh 0 điểm
   Vecto canh_01;
   canh_01.x = mangDinhTamGiac[1].x - mangDinhTamGiac[0].x;
   canh_01.y = mangDinhTamGiac[1].y - mangDinhTamGiac[0].y;
   canh_01.z = mangDinhTamGiac[1].z - mangDinhTamGiac[0].z;
   
   Vecto canh_02;
   canh_02.x = mangDinhTamGiac[2].x - mangDinhTamGiac[0].x;
   canh_02.y = mangDinhTamGiac[2].y - mangDinhTamGiac[0].y;
   canh_02.z = mangDinhTamGiac[2].z - mangDinhTamGiac[0].z;

   // ---- tích có hướng tia với cạnh 02
   Vecto ketQua = tichCoHuong( &(tia->huong), &canh_02 );
   
   // ---- xem nếu tích vô hướng tia và vectơ vuông góc cùng hướng
   float tichVoHuong = ketQua.x*canh_01.x + ketQua.y*canh_01.y + ketQua.z*canh_01.z;
   
   // ---- songๆ hay gần song với mặt phẳng tam giác
   if( tichVoHuong < kCACH_TOI_THIEU && -tichVoHuong > kCACH_TOI_THIEU )
      return khoangCach;
   // ---- nếu tích vô hướng > 0.0f, tìm điểm cắt mẳt phẳng tam giác
   else {
      // ---- đảo nghịch tích vô hướng
      float daoNghichTichVoHuong = 1.0f/tichVoHuong;
      
      // ---- tính vectơ từ điểm nhìn đỉnh 0
      Vecto vectoDiemNhinDenDinh0;
      vectoDiemNhinDenDinh0.x = tia->goc.x - mangDinhTamGiac[0].x;
      vectoDiemNhinDenDinh0.y = tia->goc.y - mangDinhTamGiac[0].y;
      vectoDiemNhinDenDinh0.z = tia->goc.z - mangDinhTamGiac[0].z;
      
      // ---- tính tọa độ u
      float u = vectoDiemNhinDenDinh0.x*ketQua.x + vectoDiemNhinDenDinh0.y*ketQua.y +
      vectoDiemNhinDenDinh0.z*ketQua.z;
      u *= daoNghichTichVoHuong;
      
      // ---- nếu u < 0,0 hay u > 1,0, không cắt tam giác
      if( u < 0.0f || u > 1.0f)
         return khoangCach;
      else {
         // ---- tính tọa độ v
         ketQua = tichCoHuong( &vectoDiemNhinDenDinh0, &canh_01 );
         
         float v = tia->huong.x*ketQua.x + tia->huong.y*ketQua.y + tia->huong.z*ketQua.z;
         v *= daoNghichTichVoHuong;
         
         // ---- nếu v < 0,0 hay v > 1,0, không cắt tam giác
         if( v < 0.0f || (u + v) > 1.0f)
            khoangCach = kVO_CUC;
         
         else {
            float t = canh_02.x*ketQua.x + canh_02.y*ketQua.y + canh_02.z*ketQua.z;
            t *= daoNghichTichVoHuong;
            
            // ---- nếu t > CÁCH_TỐI_THIỂU
            if( t > 0.01f )
               khoangCach = t;
         }
         
      }
   }
   
   return khoangCach;
}


float xemCatVatTheTamGiac( Vecto *mangDinh, TamGiac *mangTamGiac, unsigned short soLuongTamGiac, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {
   
   float nghiemGanNhat = kVO_CUC;
   //   printf( "Tia %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f\n", tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z );
   
   unsigned char cat = kSAI;
   unsigned char soMat = 0;
   while ( soMat < soLuongTamGiac ) {
      // ---- tám giac 0
      Vecto tamGiac[3];
      tamGiac[0] = mangDinh[mangTamGiac[soMat].dinh0];
      tamGiac[1] = mangDinh[mangTamGiac[soMat].dinh1];
      tamGiac[2] = mangDinh[mangTamGiac[soMat].dinh2];
      
      Vecto ketQua = tinhPhapTuyenChoTamGiac( tamGiac );
      //      printf( "%d/%d  dinh %d %d %d\n", soMat, soLuongTamGiac, mangTamGiac[soMat].dinh0, mangTamGiac[soMat].dinh1, mangTamGiac[soMat].dinh2 );
      //      printf( "    PT %5.3f %5.3f %5.3f\n", ketQua.x, ketQua.y, ketQua.z );
      
      float nghiem = xemCatTamGiacMT( tamGiac, tia );
      
      if( nghiem < nghiemGanNhat ) {  // mặt 0
         nghiemGanNhat = nghiem;
         Vecto phapTuyenTamGiac = tinhPhapTuyenChoTamGiac( tamGiac );
         phapTuyen->x = phapTuyenTamGiac.x;
         phapTuyen->y = phapTuyenTamGiac.y;
         phapTuyen->z = phapTuyenTamGiac.z;
         diemTrung->x = tia->goc.x + nghiem*tia->huong.x;
         diemTrung->y = tia->goc.y + nghiem*tia->huong.y;
         diemTrung->z = tia->goc.z + nghiem*tia->huong.z;
      }
      soMat++;
   }
   
   return nghiemGanNhat;
}
