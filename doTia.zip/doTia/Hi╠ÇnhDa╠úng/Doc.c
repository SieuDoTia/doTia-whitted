#include "Doc.h"

#pragma mark ---- Dốc
// hướng lên -z
Doc datDoc( float beRong, float beCao, float beDai, BaoBi *baoBiVT ) {
   
   Doc doc;
   
   doc.soLuongTamGiac = 8;
   float nuaBeRong = 0.5f*beRong;
   float nuaBeCao = 0.5f*beCao;
   float nuaBeDai = 0.5f*beDai;

   // ---- hai đỉnh cao
   doc.mangDinh[0].x = nuaBeRong;
   doc.mangDinh[0].y = nuaBeCao;
   doc.mangDinh[0].z = nuaBeDai;

   doc.mangDinh[1].x = -nuaBeRong;
   doc.mangDinh[1].y = nuaBeCao;
   doc.mangDinh[1].z = nuaBeDai;
   // ---- bốn đỉnh đấy
   doc.mangDinh[2].x = nuaBeRong;
   doc.mangDinh[2].y = -nuaBeCao;
   doc.mangDinh[2].z = nuaBeDai;
   
   doc.mangDinh[3].x = -nuaBeRong;
   doc.mangDinh[3].y = -nuaBeCao;
   doc.mangDinh[3].z = nuaBeDai;
   
   doc.mangDinh[4].x = -nuaBeRong;
   doc.mangDinh[4].y = -nuaBeCao;
   doc.mangDinh[4].z = -nuaBeDai;

   doc.mangDinh[5].x = nuaBeRong;
   doc.mangDinh[5].y = -nuaBeCao;
   doc.mangDinh[5].z = -nuaBeDai;
   
   // ---- mảng tam giác
   // mặt trên nghiêng
   doc.mangTamGiac[0].dinh0 = 1;
   doc.mangTamGiac[0].dinh1 = 0;
   doc.mangTamGiac[0].dinh2 = 5;
   
   doc.mangTamGiac[1].dinh0 = 5;
   doc.mangTamGiac[1].dinh1 = 4;
   doc.mangTamGiac[1].dinh2 = 1;
   // mặt +x
   doc.mangTamGiac[2].dinh0 = 0;
   doc.mangTamGiac[2].dinh1 = 2;
   doc.mangTamGiac[2].dinh2 = 5;
   // mặt -x
   doc.mangTamGiac[3].dinh0 = 4;
   doc.mangTamGiac[3].dinh1 = 3;
   doc.mangTamGiac[3].dinh2 = 1;
   // mặt +z
   doc.mangTamGiac[4].dinh0 = 0;
   doc.mangTamGiac[4].dinh1 = 1;
   doc.mangTamGiac[4].dinh2 = 3;
   
   doc.mangTamGiac[5].dinh0 = 2;
   doc.mangTamGiac[5].dinh1 = 0;
   doc.mangTamGiac[5].dinh2 = 3;
   // mặt -y
   doc.mangTamGiac[6].dinh0 = 5;
   doc.mangTamGiac[6].dinh1 = 2;
   doc.mangTamGiac[6].dinh2 = 3;
   
   doc.mangTamGiac[7].dinh0 = 3;
   doc.mangTamGiac[7].dinh1 = 4;
   doc.mangTamGiac[7].dinh2 = 5;
   // 
   baoBiVT->gocCucTieu.x = -nuaBeRong;
   baoBiVT->gocCucDai.x = nuaBeRong;
   baoBiVT->gocCucTieu.y = -nuaBeCao;
   baoBiVT->gocCucDai.y = nuaBeCao;
   baoBiVT->gocCucTieu.z = -nuaBeDai;
   baoBiVT->gocCucDai.z = nuaBeDai;
   
   return doc;
}
