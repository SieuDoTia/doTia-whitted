#pragma once

#include "TamGiac.h"
#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../XemCắt/BaoBi.h"


/* Hình Chóp */
typedef struct {
   Vecto *mangDinh;   // mảng đỉnh
   TamGiac *mangTamGiac;  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} HinhChop;


// ---- hình chóp
HinhChop datHinhChop( float banKinhDuoi, float banKinhTren, float beCao, unsigned char soLuongMat, BaoBi *baoBiVT );  // đặt hình lăng trụ
