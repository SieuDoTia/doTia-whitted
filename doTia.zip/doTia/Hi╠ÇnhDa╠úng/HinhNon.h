#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../XemCắt/BaoBi.h"


/* Hình Nón */
typedef struct {
   float banKinhTren;  // bán kính trên
   float banKinhDuoi;  // bán kính dưới
   float beCao;    // bề cao quanh trung tâm
   float hopQuanh[6];   // hộp quanh
} HinhNon;


// ---- hình nón
HinhNon datHinhNon( float banKinhTren, float banKinhDuoi, float beCao, BaoBi *baoBiVT );
float xemCatHinhNon( HinhNon *hinhNon, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );  // xem cắt hình trụ
unsigned char xemDiemTrongHinhNon( HinhNon *hinhNon, Vecto *diem );
