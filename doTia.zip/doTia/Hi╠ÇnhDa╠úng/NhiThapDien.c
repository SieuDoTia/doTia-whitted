#include "NhiThapDien.h"

#pragma mark ---- Nhị Thập Điện
NhiThapDien datNhiThapDien( float beRong, float beCao, float beDai, BaoBi *baoBiVT ) {
   NhiThapDien nhiThapDien;
   nhiThapDien.soLuongTamGiac = 20;
   
   float nuaBeRong = 0.5f*beRong;
   float nuaBeCao = 0.5f*beCao;
   float nuaBeDai = 0.5f*beDai;

   // ---- đỉnh trên
   nhiThapDien.mangDinh[0].x = 0.00000f;   nhiThapDien.mangDinh[0].y = 0.00000f;   nhiThapDien.mangDinh[0].z = 1.00000f*nuaBeDai;
   
   nhiThapDien.mangDinh[1].x = -0.72360*nuaBeRong;  nhiThapDien.mangDinh[1].y = -0.52572f*nuaBeCao;  nhiThapDien.mangDinh[1].z = 0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[2].x = 0.27639f*nuaBeRong;   nhiThapDien.mangDinh[2].y = -0.85064f*nuaBeCao;  nhiThapDien.mangDinh[2].z = 0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[3].x = 0.89442f*nuaBeRong;   nhiThapDien.mangDinh[3].y = 0.00000;   nhiThapDien.mangDinh[3].z = 0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[4].x = 0.27639f*nuaBeRong;   nhiThapDien.mangDinh[4].y = 0.85064f*nuaBeCao;   nhiThapDien.mangDinh[4].z = 0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[5].x = -0.72360*nuaBeRong;  nhiThapDien.mangDinh[5].y = 0.52572f*nuaBeCao;   nhiThapDien.mangDinh[5].z = 0.44721f*nuaBeDai;
   
   nhiThapDien.mangDinh[6].x = -0.89442f*nuaBeRong;  nhiThapDien.mangDinh[6].y = 0.00000;   nhiThapDien.mangDinh[6].z = -0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[7].x = -0.27639f*nuaBeRong;  nhiThapDien.mangDinh[7].y = -0.85064f*nuaBeCao;  nhiThapDien.mangDinh[7].z = -0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[8].x = 0.72360*nuaBeRong;   nhiThapDien.mangDinh[8].y = -0.52572f*nuaBeCao;  nhiThapDien.mangDinh[8].z = -0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[9].x = 0.72360*nuaBeRong;   nhiThapDien.mangDinh[9].y = 0.52572f*nuaBeCao;   nhiThapDien.mangDinh[9].z = -0.44721f*nuaBeDai;
   nhiThapDien.mangDinh[10].x = -0.27639f*nuaBeRong;  nhiThapDien.mangDinh[10].y = 0.85064f*nuaBeCao;   nhiThapDien.mangDinh[10].z = -0.44721f*nuaBeDai;
   // ---- đỉnh dưới
   nhiThapDien.mangDinh[11].x = 0.00000f;   nhiThapDien.mangDinh[11].y = 0.00000f;   nhiThapDien.mangDinh[11].z = -1.00000f*nuaBeDai;
   
   // ---- mảng tam giác (đỉnh gai trước, hai điểm của dấy tam giác sau; mỗi gai có ba tam giác)
   nhiThapDien.mangTamGiac[0].dinh0 = 0;   nhiThapDien.mangTamGiac[0].dinh1 = 1;   nhiThapDien.mangTamGiac[0].dinh2 = 2;
   nhiThapDien.mangTamGiac[1].dinh0 = 0;   nhiThapDien.mangTamGiac[1].dinh1 = 2;   nhiThapDien.mangTamGiac[1].dinh2 = 3;
   nhiThapDien.mangTamGiac[2].dinh0 = 0;   nhiThapDien.mangTamGiac[2].dinh1 = 3;   nhiThapDien.mangTamGiac[2].dinh2 = 4;
   nhiThapDien.mangTamGiac[3].dinh0 = 0;   nhiThapDien.mangTamGiac[3].dinh1 = 4;   nhiThapDien.mangTamGiac[3].dinh2 = 5;
   nhiThapDien.mangTamGiac[4].dinh0 = 0;   nhiThapDien.mangTamGiac[4].dinh1 = 5;   nhiThapDien.mangTamGiac[4].dinh2 = 1;

   nhiThapDien.mangTamGiac[5].dinh0 = 6;   nhiThapDien.mangTamGiac[5].dinh1 = 1;   nhiThapDien.mangTamGiac[5].dinh2 = 5;
   nhiThapDien.mangTamGiac[6].dinh0 = 7;   nhiThapDien.mangTamGiac[6].dinh1 = 2;   nhiThapDien.mangTamGiac[6].dinh2 = 1;
   nhiThapDien.mangTamGiac[7].dinh0 = 8;   nhiThapDien.mangTamGiac[7].dinh1 = 3;   nhiThapDien.mangTamGiac[7].dinh2 = 2;
   nhiThapDien.mangTamGiac[8].dinh0 = 9;   nhiThapDien.mangTamGiac[8].dinh1 = 4;   nhiThapDien.mangTamGiac[8].dinh2 = 3;
   nhiThapDien.mangTamGiac[9].dinh0 = 10;   nhiThapDien.mangTamGiac[9].dinh1 = 5;   nhiThapDien.mangTamGiac[9].dinh2 = 4;

   nhiThapDien.mangTamGiac[10].dinh0 = 6;  nhiThapDien.mangTamGiac[10].dinh1 = 7;  nhiThapDien.mangTamGiac[10].dinh2 = 1;
   nhiThapDien.mangTamGiac[11].dinh0 = 7;  nhiThapDien.mangTamGiac[11].dinh1 = 8;  nhiThapDien.mangTamGiac[11].dinh2 = 2;
   nhiThapDien.mangTamGiac[12].dinh0 = 8;  nhiThapDien.mangTamGiac[12].dinh1 = 9;  nhiThapDien.mangTamGiac[12].dinh2 = 3;
   nhiThapDien.mangTamGiac[13].dinh0 = 9;  nhiThapDien.mangTamGiac[13].dinh1 = 10;  nhiThapDien.mangTamGiac[13].dinh2 = 4;
   nhiThapDien.mangTamGiac[14].dinh0 = 10;  nhiThapDien.mangTamGiac[14].dinh1 = 6;  nhiThapDien.mangTamGiac[14].dinh2 = 5;
   // ----
   nhiThapDien.mangTamGiac[15].dinh0 = 6;  nhiThapDien.mangTamGiac[15].dinh1 = 11;  nhiThapDien.mangTamGiac[15].dinh2 = 7;
   nhiThapDien.mangTamGiac[16].dinh0 = 7;  nhiThapDien.mangTamGiac[16].dinh1 = 11;  nhiThapDien.mangTamGiac[16].dinh2 = 8;
   nhiThapDien.mangTamGiac[17].dinh0 = 8;  nhiThapDien.mangTamGiac[17].dinh1 = 11;  nhiThapDien.mangTamGiac[17].dinh2 = 9;
   nhiThapDien.mangTamGiac[18].dinh0 = 9;  nhiThapDien.mangTamGiac[18].dinh1 = 11;   nhiThapDien.mangTamGiac[18].dinh2 = 10;
   nhiThapDien.mangTamGiac[19].dinh0 = 10;  nhiThapDien.mangTamGiac[19].dinh1 = 11;   nhiThapDien.mangTamGiac[19].dinh2 = 6;

   // ---- bao bì
   baoBiVT->gocCucTieu.x = -0.44721f*nuaBeRong;
   baoBiVT->gocCucDai.x = 0.44721f*nuaBeRong;
   baoBiVT->gocCucTieu.y = -0.42532f*nuaBeCao;
   baoBiVT->gocCucDai.y = 0.42532f*nuaBeCao;
   baoBiVT->gocCucTieu.z = -0.50000f*nuaBeDai;
   baoBiVT->gocCucDai.z = 0.50000f*nuaBeDai;
   return nhiThapDien;
}
