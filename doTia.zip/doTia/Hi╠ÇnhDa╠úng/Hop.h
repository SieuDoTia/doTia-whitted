#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../XemCắt/BaoBi.h"


/* Hộp */
typedef struct {
   float beRong;   // bề rộng (x)
   float beCao;    // bề cao  (y)
   float beDai;    // bề dày  (z)
   float hopQuanh[6];   // hộp quanh
} Hop;


// ---- hộp
Hop datHop( float rong, float cao, float dai, BaoBi *baoBiVT );  // đặt hộp
float xemCatHop( Hop *hop, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );  // xem cắt hộp
unsigned char xemDiemTrongHop( Hop *hop, Vecto *diem );
