#include "HinhTru.h"
#include "../HangSo.h"
#include <math.h>


#pragma mark ---- Hình Trụ
HinhTru datHinhTru( float banKinh, float beCao, BaoBi *baoBiVT ) {

   HinhTru hinhTru;
   hinhTru.banKinh = banKinh;
   hinhTru.beCao = beCao;

   baoBiVT->gocCucTieu.x = -banKinh;
   baoBiVT->gocCucDai.x = banKinh;
   baoBiVT->gocCucTieu.y = -0.5*beCao;
   baoBiVT->gocCucDai.y = 0.5f*beCao;
   baoBiVT->gocCucTieu.z = -banKinh;
   baoBiVT->gocCucDai.z = banKinh;
   return hinhTru;
}

// ---- cho biết cắt nắp nào
float xemCatHinhTru( HinhTru *hinhTru, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {
   
   float nghiemGanNhat = kVO_CUC;

   // ---- tính vectơ từ trung tâm hình cầu đến điểm nhìn
   Vecto huongDenHinhTru;   // hướng đến trung tâm hình trụ
   huongDenHinhTru.x = tia->goc.x;
//   huongDenHinhTru.y = tia->goc.y ; // <---- không xài này
   huongDenHinhTru.z = tia->goc.z;
   
   // ---- tính bán kính bình vì xài nhiều lần
   float banKinhBinh = hinhTru->banKinh*hinhTru->banKinh;
   
   // ---- xem cất hình cao vô cung
   float A = tia->huong.x*tia->huong.x + tia->huong.z*tia->huong.z;
   float B = 2.0f*(tia->huong.x*huongDenHinhTru.x + tia->huong.z*huongDenHinhTru.z);
   float C = huongDenHinhTru.x*huongDenHinhTru.x + huongDenHinhTru.z*huongDenHinhTru.z - banKinhBinh;
   float D = B*B - 4.0f*A*C;

   if( D > 0.0f ) {
      
      // ---- tính nghiệm và nghiệm gần nhất, xài giải thuật chính xác hơn
      float Q;
      if( B < 0.0f )
         Q = -0.5f*(B - sqrtf(D) );
      else
         Q = -0.5f*(B + sqrtf(D) );
      
      float nghiem0 = Q/A;
      float nghiem1 = C/Q;

      // ---- coi trừng nghiệm âm và khác không vỉ tia coi thể bắt đẩu tại mặt của hình cầu
      if( nghiem0 < 0.001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.001f )
         nghiem1 = kVO_CUC;
      
      // ---- gởi lại nghiệm nhỏ nhất mà dương
      if( nghiem0 < nghiem1 )
         nghiemGanNhat = nghiem0;
      else
         nghiemGanNhat = nghiem1;
   }

   // ---- biết có cắt trụ cao vô cụng nhưng chư biết có cắt trụ ở trên và ở dưới hai mặt của hình trụ
   unsigned char catNap = kSAI;  // cắt nắp
   if( nghiemGanNhat < kVO_CUC ) {

      float yMatTren = 0.5f*hinhTru->beCao;
      float yMatDuoi = -0.5f*hinhTru->beCao;
      // ---- tính trúng mặt tường hình trụ ở đâu
      float toaDoY = tia->goc.y + nghiemGanNhat*tia->huong.y;
      float nghiemTren = (yMatTren - tia->goc.y)/tia->huong.y;
      float nghiemDuoi = (yMatDuoi - tia->goc.y)/tia->huong.y;
      if( nghiemTren < 0.001f )
         nghiemTren = kVO_CUC;
      if( nghiemDuoi < 0.001f )
         nghiemDuoi = kVO_CUC;
      
      // ---- nếu trúng mặt phải trụng cái nào gần hơn
      unsigned char nap;
      float nghiemYGanNhat;
      if( nghiemDuoi < nghiemTren ) {
         nghiemYGanNhat = nghiemDuoi;
         nap = kTRUNG_DUOI;
      }
      else {
         nghiemYGanNhat = nghiemTren;
         nap = kTRUNG_TREN;
      }
      
      Vecto diemTrungGan;
      diemTrungGan.x = tia->goc.x + nghiemYGanNhat*tia->huong.x;
      //    diemTrungTren.y = tia->goc.y + nghiemYGanNhat*tia->huong.y;    không xài
      diemTrungGan.z = tia->goc.z + nghiemYGanNhat*tia->huong.z;
      // ---- tính cách từ tâm trên nắp
      float cachTamTrenNap = diemTrungGan.x*diemTrungGan.x + diemTrungGan.z*diemTrungGan.z;
      
      // ---- cắt tường
      if( toaDoY < yMatTren && toaDoY > yMatDuoi ) {
         // ---- cho tường hợp tia ở trong hình trụ
         if( (nghiemYGanNhat < nghiemGanNhat) && (cachTamTrenNap < banKinhBinh) ) {
            catNap = nap;
            nghiemGanNhat = nghiemYGanNhat;
            diemTrung->x = diemTrungGan.x;
            diemTrung->y = tia->goc.y + nghiemYGanNhat*tia->huong.y;
            diemTrung->z = diemTrungGan.z;
         }
         else
            catNap = kSAI;
      }
      // ---- xem cắt nắp hay tường hay không cắt luôn
      else {

         if( cachTamTrenNap < banKinhBinh ) {
            catNap = nap;
            nghiemGanNhat = nghiemYGanNhat;
            diemTrung->x = diemTrungGan.x;
            diemTrung->y = tia->goc.y + nghiemYGanNhat*tia->huong.y;
            diemTrung->z = diemTrungGan.z;
         }
         else
            nghiemGanNhat = kVO_CUC;

      }
   }
   
   // ---- pháp tuyến cho tường hình trụ
   if( nghiemGanNhat < kVO_CUC && !catNap ) {
      // ---- tính điểm gần nhất
      diemTrung->x = tia->goc.x + nghiemGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + nghiemGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + nghiemGanNhat*tia->huong.z;
      // ---- vectơ vuông góc cho phát tia tiếp
      phapTuyen->x = diemTrung->x;
      phapTuyen->y = 0.0f;
      phapTuyen->z = diemTrung->z;
      donViHoa( phapTuyen );
   }
   else if( catNap == kTRUNG_TREN ) {  // cắt nắp trên
      phapTuyen->x = 0.0f;
      phapTuyen->y = 1.0f;
      phapTuyen->z = 0.0f;
   }
   else if( catNap == kTRUNG_DUOI ) {  // cắt nắp dưới
      phapTuyen->x = 0.0f;
      phapTuyen->y = -1.0f;
      phapTuyen->z = 0.0f;
   }

   return nghiemGanNhat;
}


unsigned char xemDiemTrongHinhTru( HinhTru *hinhTru, Vecto *diem ) {
   
   unsigned char diemTrong = kDUNG;
   if( diem->x*diem->x + diem->z*diem->z > hinhTru->banKinh*hinhTru->banKinh )
      diemTrong = kSAI;
   
   float nuaBeCao = hinhTru->beCao*0.5f;
   
   if( diemTrong ) {
      if( diem->y < -nuaBeCao )
         diemTrong = kSAI;
      else if( diem->y > nuaBeCao )
         diemTrong = kSAI;
   }
//   printf( "xemTrongHinhTru %d   diem %5.3f %5.3f %5.3f\n", diemTrong, diem->x, diem->y, diem->z );
   return diemTrong;
}
