#pragma once

// ---- Lọai Hình Dạng
#define kLOAI_HINH_DANG__HINH_CAU   1 // hình cầu
#define kLOAI_HINH_DANG__MAT_PHANG  2 // mặt phẩng
#define kLOAI_HINH_DANG__HOP        3 // hợp
#define kLOAI_HINH_DANG__HINH_TRU   4 // hình trụ
#define kLOAI_HINH_DANG__HINH_NON   5 // hình trụ
#define kLOAI_HINH_DANG__MAT_HYPERBOL  6 // mặt hyperbol
#define kLOAI_HINH_DANG__MAT_SONG      7
#define kLOAI_HINH_DANG__MAT_PARABOL   8 // mặt parabol
#define kLOAI_HINH_DANG__HINH_XUYEN    9 // hình xuyến
#define kLOAI_HINH_DANG__TU_DIEN      10 // tú diện
#define kLOAI_HINH_DANG__BAT_DIEN     11 // bát diện
#define kLOAI_HINH_DANG__THAP_NHI_DIEN 12 // thập nhị diện
#define kLOAI_HINH_DANG__KIM_TU_THAP  13 // kim tư tháp
#define kLOAI_HINH_DANG__DOC          14 // dốc
#define kLOAI_HINH_DANG__NHI_THAP_DIEN  15 // nhị thập diện
#define kLOAI_HINH_DANG__SAO_GAI        16 // sao gai

#define kLOAI_VAT_THE__GHEP  101    // vật thể ghép
#define kLOAI_VAT_THE__BOOL  102    // vật thể bool

#include "HinhCau.h"
#include "Hop.h"
#include "HinhTru.h"
#include "HinhNon.h"
#include "MatHyperbol.h"
#include "MatParabol.h"
#include "MatSong.h"
#include "HinhXuyen.h"
#include "TuDien.h"
#include "BatDien.h"
#include "ThapNhiDien.h"
#include "KimTuThap.h"
#include "Doc.h"
#include "NhiThapDien.h"
#include "SaoGai.h"

typedef union {
   HinhCau hinhCau;    // hình cầu
   Hop hop;            // hộp
//   MatPhang matPhang;  // mặt phẳng
   HinhTru hinhTru;    // hình trụ
   HinhNon hinhNon;    // hình nón
   MatHyperbol matHyperbol; // mặt hyperbol
   MatParabol matParabol;   // mặt hyperbol
   MatSong matSong;         // mặt sóng
   HinhXuyen hinhXuyen;     // hình xuyến
   TuDien tuDien;     // tứ diện
   BatDien batDien;   // bát diện
   ThapNhiDien thapNhiDien;  // thập nhị diện
   KimTuThap kimTuThap;  // kim tư tháp
   Doc doc;              // dốc
   NhiThapDien nhiThapDien;  // nhị thập diện
   SaoGai saoGai;       //  sai gai
} HinhDang;             // hình dạng
