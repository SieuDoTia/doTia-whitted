#include "MatHyperbol.h"
#include "../HangSo.h"
#include <math.h>


#pragma mark ---- Mặt Hyberbol
// (x-x_0)^2 + (z-z_0)^2 = R^2 + B*(y-y_0)^2
// B - Biên Độ
MatHyperbol datMatHyperbol( float banKinhBinh, float bienDo, float beCao, BaoBi *baoBiVT ) {
   MatHyperbol matHyperbol;

   matHyperbol.banKinhBinh = banKinhBinh;  // số này có thể có giá trị âm
   matHyperbol.bienDo = bienDo;
   matHyperbol.beCao = beCao;

   float bietThuc = banKinhBinh + bienDo*0.25f*beCao*beCao;
   float banKinhCucDai = 0.0f;
   if( bietThuc > 0.0f )
      banKinhCucDai = sqrtf( bietThuc );
   else
      banKinhCucDai = sqrtf( bienDo*0.25f*beCao*beCao );

   baoBiVT->gocCucTieu.x = -banKinhCucDai;
   baoBiVT->gocCucDai.x = banKinhCucDai;
   baoBiVT->gocCucTieu.y = -0.5f*beCao;
   baoBiVT->gocCucDai.y = 0.5f*beCao;
   baoBiVT->gocCucTieu.z = -banKinhCucDai;
   baoBiVT->gocCucDai.z = banKinhCucDai;
   
   printf( "matHyperbol.banKinhBinh %5.3f\n", matHyperbol.banKinhBinh );

   return matHyperbol;
}

float xemCatMatHyperbol( MatHyperbol *matHyperbol, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {

   float nghiemGanNhat = kVO_CUC;
   
   // ---- tính vectơ từ trung tâm hình cầu đến điểm nhìn
   Vecto huongDenMatHyperbol;   // hướng đến trung tâm hình trụ
   huongDenMatHyperbol.x = tia->goc.x;
   huongDenMatHyperbol.y = tia->goc.y;
   huongDenMatHyperbol.z = tia->goc.z;
   
   float A = tia->huong.x*tia->huong.x - tia->huong.y*tia->huong.y*matHyperbol->bienDo + tia->huong.z*tia->huong.z;
   float B = 2.0f*(tia->huong.x*huongDenMatHyperbol.x - tia->huong.y*huongDenMatHyperbol.y*matHyperbol->bienDo + tia->huong.z*huongDenMatHyperbol.z);
   float C = huongDenMatHyperbol.x*huongDenMatHyperbol.x + huongDenMatHyperbol.z*huongDenMatHyperbol.z - huongDenMatHyperbol.y*huongDenMatHyperbol.y*matHyperbol->bienDo
                + matHyperbol->banKinhBinh;
   float D = B*B - 4.0f*A*C;
   
   if( D > 0.0f ) {
      // ---- tính nghiệm và nghiệm gần nhất, xài giải thuật chính xác hơn
      float Q;
      if( B < 0.0f )
         Q = -0.5f*(B - sqrtf(D) );
      else
         Q = -0.5f*(B + sqrtf(D) );
      
      float nghiem0 = Q/A;
      float nghiem1 = C/Q;
      
      // ---- coi trừng nghiệm âm và khác không vỉ tia coi thể bắt đẩu tại mặt của hình cầu
      if( nghiem0 < 0.01f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.01f )
         nghiem1 = kVO_CUC;
      
      // ---- gởi lại nghiệm nhỏ nhất mà dương
      if( nghiem0 < nghiem1 )
         nghiemGanNhat = nghiem0;
      else
         nghiemGanNhat = nghiem1;
   }

   // ---- biết có cắt trụ cao vô cụng nhưng chưa biết có cắt trụ ở trên và ở dưới hai mặt của hình hyberbol
   unsigned char catNap = kSAI;  // cắt nắp
   if( nghiemGanNhat < kVO_CUC ) {
      // ---- kiểm tra tọa độ y của điểm trúng
      float toaDoY = tia->goc.y + nghiemGanNhat*tia->huong.y;
      float yMatTren = matHyperbol->beCao*0.5f;
      float yMatDuoi = -matHyperbol->beCao*0.5f;
      
      if( (toaDoY > yMatTren ) && (tia->huong.y < 0.0f) ) {   // tọa độ y cao hơn mà tia đang bay xuống
         float nghiemY = (yMatTren - tia->goc.y)/tia->huong.y;
         Vecto diemTrungTuongDoi;
         diemTrungTuongDoi.x = tia->goc.x + nghiemY*tia->huong.x;
         diemTrungTuongDoi.y = tia->goc.y + nghiemY*tia->huong.y;
         diemTrungTuongDoi.z = tia->goc.z + nghiemY*tia->huong.z;
         // ---- tính bán kính cắt ngang
         if( diemTrungTuongDoi.x*diemTrungTuongDoi.x + diemTrungTuongDoi.z*diemTrungTuongDoi.z < matHyperbol->banKinhBinh
            + matHyperbol->bienDo*diemTrungTuongDoi.y*diemTrungTuongDoi.y ) {
            catNap = kTRUNG_TREN;
            nghiemGanNhat = nghiemY;
            diemTrung->x = tia->goc.x + nghiemY*tia->huong.x;
            diemTrung->y = tia->goc.y + nghiemY*tia->huong.y;
            diemTrung->z = tia->goc.z + nghiemY*tia->huong.z;
         }
         else
            nghiemGanNhat = kVO_CUC;
      }
      else if( (toaDoY < yMatDuoi) && (tia->huong.y > 0.0f) ) { // tọa độ y thấp hơn mà tia đang bay lên
         float nghiemY = (yMatDuoi - tia->goc.y)/tia->huong.y;
         Vecto diemTrungTuongDoi;
         diemTrungTuongDoi.x = tia->goc.x + nghiemY*tia->huong.x;
         diemTrungTuongDoi.y = tia->goc.y + nghiemY*tia->huong.y;
         diemTrungTuongDoi.z = tia->goc.z + nghiemY*tia->huong.z;
         if( diemTrungTuongDoi.x*diemTrungTuongDoi.x + diemTrungTuongDoi.z*diemTrungTuongDoi.z < matHyperbol->banKinhBinh
            + matHyperbol->bienDo*diemTrungTuongDoi.y*diemTrungTuongDoi.y ) {
            catNap = kTRUNG_DUOI;
            nghiemGanNhat = nghiemY;
            diemTrung->x = tia->goc.x + nghiemY*tia->huong.x;
            diemTrung->y = tia->goc.y + nghiemY*tia->huong.y;
            diemTrung->z = tia->goc.z + nghiemY*tia->huong.z;
         }
         else
            nghiemGanNhat = kVO_CUC;
      }
      else if( (toaDoY < yMatTren) && (toaDoY > yMatDuoi) )
         catNap = kSAI;
      else
         nghiemGanNhat = kVO_CUC;    // không cắt hình trụ
   }

   // ---- pháp tuyến cho tường hình trụ
   if( nghiemGanNhat < kVO_CUC && !catNap ) {
      diemTrung->x = tia->goc.x + nghiemGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + nghiemGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + nghiemGanNhat*tia->huong.z;
      // ---- vectơ vuông góc cho phát tia tiếp
      phapTuyen->x = diemTrung->x;
      phapTuyen->y = -diemTrung->y*matHyperbol->bienDo;
      phapTuyen->z = diemTrung->z;
      donViHoa( phapTuyen );
   }
   else if( catNap == kTRUNG_TREN ) {  // cắt nắp trên
      phapTuyen->x = 0.0f;
      phapTuyen->y = 1.0f;
      phapTuyen->z = 0.0f;
   }
   else if( catNap == kTRUNG_DUOI ) {  // cắt nắp dưới
      phapTuyen->x = 0.0f;
      phapTuyen->y = -1.0f;
      phapTuyen->z = 0.0f;
   }

   return nghiemGanNhat;
}
