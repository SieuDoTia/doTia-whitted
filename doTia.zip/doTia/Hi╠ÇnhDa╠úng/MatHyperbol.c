#include "MatHyperbol.h"
#include "../HangSo.h"
#include <math.h>


//     R^2 > 0     R^2 = 0    R^2 < 0
//     +-------+     +-----+    +-----+
//      \     /       \   /      \   /
//       \   /         \ /        ---
//        | |           x
//       /   \         / \        ---
//      /     \       /   \      /   \
//     +-------+     +-----+    +-----+


#pragma mark ---- Mặt Hyberbol
// (x-x_0)^2 + (z-z_0)^2 = R^2 + B*(y-y_0)^2
//  B - Biên Độ

// • pháp tuyến
//  ∇ (x-x_0)^2 + (z-z_0)^2 - R^2 - B*(y-y_0)^2 = 0
//  2(x-x_0)i; 2(z-z_0); -2B(y-y_0)
//  (x-x_0)i; (z-z_0); -B(y-y_0)


MatHyperbol datMatHyperbol( float banKinhBinh, float bienDo, float beCao, BaoBi *baoBiVT ) {
   MatHyperbol matHyperbol;

   matHyperbol.banKinhBinh = banKinhBinh;  // số này có thể có giá trị âm
   matHyperbol.bienDo = bienDo;
   matHyperbol.beCao = beCao;

   // ---- tính bao bì
   tinhBaoBiMatHyperbol( &matHyperbol, baoBiVT );

   return matHyperbol;
}

float xemCatMatHyperbol( MatHyperbol *matHyperbol, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {

   float nghiemGanNhat = kVO_CUC;
   
   // ---- tính vectơ từ trung tâm hình cầu đến điểm nhìn
   Vecto huongDenMatHyperbol;   // hướng đến trung tâm hình trụ
   huongDenMatHyperbol.x = tia->goc.x;
   huongDenMatHyperbol.y = tia->goc.y;
   huongDenMatHyperbol.z = tia->goc.z;
   
//   printf( "matHyperbol: tia %5.3f %5.3f %5.3f   %5.3f %5.3f %5.3f    beCao %5.3f\n", tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z, matHyperbol->beCao );
   
   float A = tia->huong.x*tia->huong.x - tia->huong.y*tia->huong.y*matHyperbol->bienDo + tia->huong.z*tia->huong.z;
   float B = 2.0f*(tia->huong.x*huongDenMatHyperbol.x - tia->huong.y*huongDenMatHyperbol.y*matHyperbol->bienDo + tia->huong.z*huongDenMatHyperbol.z);
   float C = huongDenMatHyperbol.x*huongDenMatHyperbol.x + huongDenMatHyperbol.z*huongDenMatHyperbol.z - huongDenMatHyperbol.y*huongDenMatHyperbol.y*matHyperbol->bienDo
                - matHyperbol->banKinhBinh;
   float D = B*B - 4.0f*A*C;
   
//   printf( "D %5.f\n", D );
   
   if( D > 0.0f ) {
      // ---- tính nghiệm và nghiệm gần nhất, xài giải thuật chính xác hơn
      float Q;
      if( B < 0.0f )
         Q = -0.5f*(B - sqrtf(D) );
      else
         Q = -0.5f*(B + sqrtf(D) );
      
      float nghiem0 = Q/A;
      float nghiem1 = C/Q;
      
      // ---- coi trừng nghiệm âm và khác không vỉ tia coi thể bắt đẩu tại mặt của hình cầu
      if( nghiem0 < 0.01f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.01f )
         nghiem1 = kVO_CUC;
      
      // ---- gởi lại nghiệm nhỏ nhất mà dương
      if( nghiem0 < nghiem1 )
         nghiemGanNhat = nghiem0;
      else {
         nghiemGanNhat = nghiem1;
         nghiem1 = nghiem0;
         nghiem0 = nghiemGanNhat;
      }
//      printf( " nghiem0 %5.3f  nghiem1 %5.3f\n", nghiem0, nghiem1 );
      // ---- xem nếu hai nghiệm điểm trúng mặt hyperbol ±0,5*bềCao
      if( nghiem0 < kVO_CUC ) {
         float nuaBeCao = 0.5f*matHyperbol->beCao;
         float diemTrung_y = tia->goc.y + nghiem0*tia->huong.y;
//         printf( " diemTrung_y0 %5.3f  nuaBeCao %5.3f\n", diemTrung_y, nuaBeCao );
         if( (diemTrung_y > nuaBeCao ) || (diemTrung_y < -nuaBeCao ) ) {
            // ---- xem nghiệm 1
            diemTrung_y = tia->goc.y + nghiem1*tia->huong.y;
//            printf( " diemTrung_y1 %5.3f  -nuaBeCao %5.3f\n", diemTrung_y, -nuaBeCao );
            if( (diemTrung_y > nuaBeCao ) || (diemTrung_y < -nuaBeCao ) )
               nghiemGanNhat = kVO_CUC;
            else
               nghiemGanNhat = nghiem1;
         }
      }
      //   còn một trường hợp nhưng không thể trúng mặt
      //     +-----+
      //      \   /
      //       ---
      //   ---------->
      //       ---
      //      /   \
      //     +-----+

   }
//   printf( "matHperbol: (mặt) nghiemGanNhat %5.3f\n", nghiemGanNhat );

   // ==== xem trúng nắp mà không trúng mặt hyperbol (qua lỗ)
   //        |
   //        v
   //     +-----+
   //      \   /
   //       | |
   //      /   \
   //     +-----+
   //        ^
   //        |

   // ==== tìm nghiệm hai
   // ---- nắp trên
   float yNapTren = matHyperbol->beCao*0.5f;
   float nghiemNapTren = (yNapTren - tia->goc.y)/tia->huong.y;
   Vecto diemTrungNapTren;
   diemTrungNapTren.x = tia->goc.x + nghiemNapTren*tia->huong.x;
   diemTrungNapTren.y = yNapTren;
   diemTrungNapTren.z = tia->goc.z + nghiemNapTren*tia->huong.z;
   
   float banKinhDiemTrungNapBinh = diemTrungNapTren.x*diemTrungNapTren.x + diemTrungNapTren.z*diemTrungNapTren.z;
   float banKinhNapBinh = matHyperbol->banKinhBinh + matHyperbol->bienDo*yNapTren*yNapTren;
   // ---- xem nếu trúng nắp trên
   if( banKinhNapBinh < banKinhDiemTrungNapBinh )
      nghiemNapTren = kVO_CUC;
   
   // ---- nắp trên
   float yNapDuoi = -matHyperbol->beCao*0.5f;
   float nghiemNapDuoi = (yNapDuoi - tia->goc.y)/tia->huong.y;
   Vecto diemTrungNapDuoi;
   diemTrungNapDuoi.x = tia->goc.x + nghiemNapDuoi*tia->huong.x;
   diemTrungNapDuoi.y = yNapDuoi;
   diemTrungNapDuoi.z = tia->goc.z + nghiemNapDuoi*tia->huong.z;
         
   banKinhDiemTrungNapBinh = diemTrungNapDuoi.x*diemTrungNapDuoi.x + diemTrungNapDuoi.z*diemTrungNapDuoi.z;
   banKinhNapBinh = matHyperbol->banKinhBinh + matHyperbol->bienDo*yNapDuoi*yNapDuoi;
   // ---- xem nếu trúng nắp trên
   if( banKinhNapBinh < banKinhDiemTrungNapBinh )
      nghiemNapDuoi = kVO_CUC;
       

   // ---- coi trừng nghiệm âm và khác không vỉ tia coi thể bắt đẩu tại mặt của hình cầu
   if( nghiemNapTren < 0.01f )
      nghiemNapTren = kVO_CUC;
   if( nghiemNapDuoi < 0.01f )
      nghiemNapDuoi = kVO_CUC;
   
   // ---- gởi lại nghiệm nhỏ nhất mà dương
   float nghiemNap0;
   float nghiemNap1;
   unsigned char napGan = kSAI;

   if( nghiemNapDuoi < nghiemNapTren ) {
      nghiemNap0 = nghiemNapDuoi;
      nghiemNap1 = nghiemNapTren;
      napGan = kTRUNG_DUOI;
   }
   else {
      nghiemNap1 = nghiemNapDuoi;
      nghiemNap0 = nghiemNapTren;
      napGan = kTRUNG_TREN;
   }

   // ==== xem điểm nào gần nhất
   unsigned char catNap = kSAI;  // cắt nắp
   if( nghiemNap0 < nghiemGanNhat ) {
      nghiemGanNhat = nghiemNap0;
      catNap = napGan;
   }

   // ---- pháp tuyến cho mặt hyperbol
   if( nghiemGanNhat < kVO_CUC && !catNap ) {
      diemTrung->x = tia->goc.x + nghiemGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + nghiemGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + nghiemGanNhat*tia->huong.z;
      // ---- vectơ vuông góc cho phát tia tiếp
      phapTuyen->x = diemTrung->x;
      phapTuyen->y = -diemTrung->y*matHyperbol->bienDo;
      phapTuyen->z = diemTrung->z;
      donViHoa( phapTuyen );
   }
   else if( catNap == kTRUNG_TREN ) {  // cắt nắp trên
      diemTrung->x = diemTrungNapTren.x;
      diemTrung->y = diemTrungNapTren.y;
      diemTrung->z = diemTrungNapTren.z;
      phapTuyen->x = 0.0f;
      phapTuyen->y = 1.0f;
      phapTuyen->z = 0.0f;
   }
   else if( catNap == kTRUNG_DUOI ) {  // cắt nắp dưới
      diemTrung->x = diemTrungNapDuoi.x;
      diemTrung->y = diemTrungNapDuoi.y;
      diemTrung->z = diemTrungNapDuoi.z;
      phapTuyen->x = 0.0f;
      phapTuyen->y = -1.0f;
      phapTuyen->z = 0.0f;
   }

//   printf( "nghiemGanNhat (cuoi) %5.3f   phapTuyen %5.3f %5.3f %5.3f\n", nghiemGanNhat, phapTuyen->x, phapTuyen->y, phapTuyen->z );
//   exit(0);
   return nghiemGanNhat;
}


void tinhBaoBiMatHyperbol( MatHyperbol *matHyperbol, BaoBi *baoBiVT ) {
   
   float nuaBeCao = matHyperbol->beCao;

   // ---- tính bao bì
   float bietThuc = matHyperbol->banKinhBinh + matHyperbol->bienDo*nuaBeCao*nuaBeCao;  // biệt thức
   float banKinhCucDai = 0.0f;
   if( bietThuc > 0.0f )
      banKinhCucDai = sqrtf( bietThuc );
   
//   printf( "banKinhCucDai %5.3f\n", banKinhCucDai );

   baoBiVT->gocCucTieu.x = -banKinhCucDai;
   baoBiVT->gocCucDai.x = banKinhCucDai;
   baoBiVT->gocCucTieu.y = -nuaBeCao;
   baoBiVT->gocCucDai.y = nuaBeCao;
   baoBiVT->gocCucTieu.z = -banKinhCucDai;
   baoBiVT->gocCucDai.z = banKinhCucDai;
   
//   printf( "MatHyperbol: baoBiVT->gocCucDai.z %5.3f\n", baoBiVT->gocCucDai.z );
}