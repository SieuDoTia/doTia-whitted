#pragma once

#include "../Toán/Vecto.h"
#include "TamGiac.h"
#include "../XemCắt/BaoBi.h"

/* Bát Diện */
typedef struct {
   Vecto mangDinh[6];   // mảng đỉnh
   TamGiac mangTamGiac[8];  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} BatDien;

// ---- bát diện
BatDien datBatDien( float beRong, float beCao, float beDai, BaoBi *baoBiVT ); // đặt bát diện