#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../XemCat/BaoBi.h"


/* Mat Hyperbol */
typedef struct {
   float banKinh;  // bán kính
   float cachXa;   // cách xa
   float beCao;    // bề cao quanh trung tâm
   float hopQuanh[6];   // hộp quanh
} MatHyperbol;

// ---- mặt hyberbol
MatHyperbol datMatHyperbol( float banKinh, float cachXa, float beCao, BaoBi *baoBiVT ); // đặt mặt hypperbol
float xemCatMatHyperbol( MatHyperbol *matHyperbol, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );  // xem cắt mặt hyperbol
