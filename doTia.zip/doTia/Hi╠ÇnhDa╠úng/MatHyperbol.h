#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../XemCat/BaoBi.h"


/* Mat Hyperbol */
typedef struct {
   float banKinhBinh;  // bán kính bình
   float bienDo;   // biên độ
   float beCao;    // bề cao quanh trung tâm
   float hopQuanh[6];   // hộp quanh
} MatHyperbol;

// ---- mặt hyberbol
MatHyperbol datMatHyperbol( float banKinhBinh, float bienDo, float beCao, BaoBi *baoBiVT ); // đặt mặt hypperbol
float xemCatMatHyperbol( MatHyperbol *matHyperbol, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );  // xem cắt mặt hyperbol
