#include "KimTuThap.h"

#pragma mark ---- Kim Tư Tháp
KimTuThap datKimTuThap( float beRong, float beCao, float beDai, BaoBi *baoBi ) {
   
   KimTuThap kimTuThap;
   
   kimTuThap.soLuongTamGiac = 6;
   
   float nuaBeRong = 0.5f*beRong;
   float nuaBeCao = 0.5f*beCao;
   float nuaBeDai = 0.5f*beDai;

   // ---- đỉnh cực
   kimTuThap.mangDinh[0].x = 0.0f;
   kimTuThap.mangDinh[0].y = nuaBeCao;
   kimTuThap.mangDinh[0].z = 0.0f;
   // ---- bốn đỉnh đấy
   kimTuThap.mangDinh[1].x = nuaBeRong;
   kimTuThap.mangDinh[1].y = -nuaBeCao;
   kimTuThap.mangDinh[1].z = nuaBeDai;
   
   kimTuThap.mangDinh[2].x = nuaBeRong;
   kimTuThap.mangDinh[2].y = -nuaBeCao;
   kimTuThap.mangDinh[2].z = -nuaBeDai;
   
   kimTuThap.mangDinh[3].x = -nuaBeRong;
   kimTuThap.mangDinh[3].y = -nuaBeCao;
   kimTuThap.mangDinh[3].z = -nuaBeDai;
   
   kimTuThap.mangDinh[4].x = -nuaBeRong;
   kimTuThap.mangDinh[4].y = -nuaBeCao;
   kimTuThap.mangDinh[4].z = nuaBeDai;
   
   // ---- mảng tam giác
   // 4 mặt trên
   kimTuThap.mangTamGiac[0].dinh0 = 0;
   kimTuThap.mangTamGiac[0].dinh1 = 1;
   kimTuThap.mangTamGiac[0].dinh2 = 2;
   
   kimTuThap.mangTamGiac[1].dinh0 = 0;
   kimTuThap.mangTamGiac[1].dinh1 = 2;
   kimTuThap.mangTamGiac[1].dinh2 = 3;
   
   kimTuThap.mangTamGiac[2].dinh0 = 0;
   kimTuThap.mangTamGiac[2].dinh1 = 3;
   kimTuThap.mangTamGiac[2].dinh2 = 4;
   
   kimTuThap.mangTamGiac[3].dinh0 = 0;
   kimTuThap.mangTamGiac[3].dinh1 = 4;
   kimTuThap.mangTamGiac[3].dinh2 = 1;
   // 2 tam giác cho đấy
   kimTuThap.mangTamGiac[4].dinh0 = 1;
   kimTuThap.mangTamGiac[4].dinh1 = 3;
   kimTuThap.mangTamGiac[4].dinh2 = 2;
   
   kimTuThap.mangTamGiac[5].dinh0 = 3;
   kimTuThap.mangTamGiac[5].dinh1 = 1;
   kimTuThap.mangTamGiac[5].dinh2 = 4;
   
   baoBi->gocCucTieu.x = -nuaBeRong;
   baoBi->gocCucDai.x = nuaBeRong;
   baoBi->gocCucTieu.y = -nuaBeCao;
   baoBi->gocCucDai.y = nuaBeCao;
   baoBi->gocCucTieu.z = -nuaBeDai;
   baoBi->gocCucDai.z = nuaBeDai;

   return kimTuThap;
}
