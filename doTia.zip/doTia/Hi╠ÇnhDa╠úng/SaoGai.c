#include "SaoGai.h"

#pragma mark ---- Sao gai     XÀI bán kính 1,88
SaoGai datSaoGai( BaoBi *baoBiVT ) {
   SaoGai saoGai;
   saoGai.soLuongTamGiac = 60;
   // ---- các gai
   saoGai.mangDinh[0].x = -1.15180f;   saoGai.mangDinh[0].y = 0.00000f;    saoGai.mangDinh[0].z = 1.50772f;
   saoGai.mangDinh[1].x = -0.35593f;   saoGai.mangDinh[1].y = -1.09542f;   saoGai.mangDinh[1].z = 1.50772f;
   saoGai.mangDinh[2].x = 0.93182f;    saoGai.mangDinh[2].y = -0.67702f;   saoGai.mangDinh[2].z = 1.50772f;
   saoGai.mangDinh[3].x = 0.93182f;    saoGai.mangDinh[3].y = 0.67702f;    saoGai.mangDinh[3].z = 1.50772f;
   saoGai.mangDinh[4].x = -0.35593f;   saoGai.mangDinh[4].y = 1.09542f;    saoGai.mangDinh[4].z = 1.50772f;
   
   saoGai.mangDinh[5].x = -1.86364f;   saoGai.mangDinh[5].y = 0.00000f;    saoGai.mangDinh[5].z = 0.35592f;
   saoGai.mangDinh[6].x = -0.57590f;   saoGai.mangDinh[6].y = -1.77242f;   saoGai.mangDinh[6].z = 0.35592f;
   saoGai.mangDinh[7].x = 1.50771f;    saoGai.mangDinh[7].y = -1.09543f;   saoGai.mangDinh[7].z = 0.35592f;
   saoGai.mangDinh[8].x = 1.50771f;    saoGai.mangDinh[8].y = 1.09543f;    saoGai.mangDinh[8].z = 0.35592f;
   saoGai.mangDinh[9].x = -0.57590f;   saoGai.mangDinh[9].y = 1.77242f;    saoGai.mangDinh[9].z = 0.35592f;

   saoGai.mangDinh[10].x = -1.50771f;  saoGai.mangDinh[10].y = -1.09543f;  saoGai.mangDinh[10].z = -0.35592f;
   saoGai.mangDinh[11].x = 0.57590f;   saoGai.mangDinh[11].y = -1.77242f;  saoGai.mangDinh[11].z = -0.35592f;
   saoGai.mangDinh[12].x = 1.86364f;   saoGai.mangDinh[12].y = 0.00000f;   saoGai.mangDinh[12].z = -0.35592f;
   saoGai.mangDinh[13].x = 0.57590f;   saoGai.mangDinh[13].y = 1.77242f;   saoGai.mangDinh[13].z = -0.35592f;
   saoGai.mangDinh[14].x = -1.50771f;  saoGai.mangDinh[14].y = 1.09543f;   saoGai.mangDinh[14].z = -0.35592f;

   saoGai.mangDinh[15].x = -0.93182f;  saoGai.mangDinh[15].y = -0.67702f;  saoGai.mangDinh[15].z = -1.50772f;
   saoGai.mangDinh[16].x = 0.35593f;   saoGai.mangDinh[16].y = -1.09542f;  saoGai.mangDinh[16].z = -1.50772f;
   saoGai.mangDinh[17].x = 1.15180f;   saoGai.mangDinh[17].y = 0.00000f;   saoGai.mangDinh[17].z = -1.50772f;
   saoGai.mangDinh[18].x = 0.35593f;   saoGai.mangDinh[18].y = 1.09542f;   saoGai.mangDinh[18].z = -1.50772f;
   saoGai.mangDinh[19].x = -0.93182f;  saoGai.mangDinh[19].y = 0.67702f;   saoGai.mangDinh[19].z = -1.50772f;

   // ==== nhị thập diện
   // ---- đỉnh trên
   saoGai.mangDinh[20].x = 0.00000f;   saoGai.mangDinh[20].y = 0.00000f;   saoGai.mangDinh[20].z = 0.50000f;
   
   saoGai.mangDinh[21].x = -0.36180f;  saoGai.mangDinh[21].y = -0.26286f;  saoGai.mangDinh[21].z = 0.22361f;
   saoGai.mangDinh[22].x = 0.13819f;   saoGai.mangDinh[22].y = -0.42532f;  saoGai.mangDinh[22].z = 0.22361f;
   saoGai.mangDinh[23].x = 0.44721f;   saoGai.mangDinh[23].y = 0.00000f;   saoGai.mangDinh[23].z = 0.22361f;
   saoGai.mangDinh[24].x = 0.13819f;   saoGai.mangDinh[24].y = 0.42532f;   saoGai.mangDinh[24].z = 0.22361f;
   saoGai.mangDinh[25].x = -0.36180f;  saoGai.mangDinh[25].y = 0.26286f;   saoGai.mangDinh[25].z = 0.22361f;

   saoGai.mangDinh[26].x = -0.44721f;  saoGai.mangDinh[26].y = 0.00000f;   saoGai.mangDinh[26].z = -0.22361f;
   saoGai.mangDinh[27].x = -0.13819f;  saoGai.mangDinh[27].y = -0.42532f;  saoGai.mangDinh[27].z = -0.22361f;
   saoGai.mangDinh[28].x = 0.36180f;   saoGai.mangDinh[28].y = -0.26286f;  saoGai.mangDinh[28].z = -0.22361f;
   saoGai.mangDinh[29].x = 0.36180f;   saoGai.mangDinh[29].y = 0.26286f;   saoGai.mangDinh[29].z = -0.22361f;
   saoGai.mangDinh[30].x = -0.13819f;  saoGai.mangDinh[30].y = 0.42532f;   saoGai.mangDinh[30].z = -0.22361f;
   // ---- đỉnh dưới
   saoGai.mangDinh[31].x = 0.00000f;   saoGai.mangDinh[31].y = 0.00000f;   saoGai.mangDinh[31].z = -0.50000f;
   
   // ---- mảng tam giác (đỉnh gai trước, hai điểm của dấy tam giác sau; mỗi gai có ba tam giác)
   saoGai.mangTamGiac[0].dinh0 = 0;   saoGai.mangTamGiac[0].dinh1 = 21;   saoGai.mangTamGiac[0].dinh2 = 20;
   saoGai.mangTamGiac[1].dinh0 = 0;   saoGai.mangTamGiac[1].dinh1 = 20;   saoGai.mangTamGiac[1].dinh2 = 25;
   saoGai.mangTamGiac[2].dinh0 = 0;   saoGai.mangTamGiac[2].dinh1 = 25;   saoGai.mangTamGiac[2].dinh2 = 21;

   saoGai.mangTamGiac[3].dinh0 = 1;   saoGai.mangTamGiac[3].dinh1 = 22;   saoGai.mangTamGiac[3].dinh2 = 20;
   saoGai.mangTamGiac[4].dinh0 = 1;   saoGai.mangTamGiac[4].dinh1 = 20;   saoGai.mangTamGiac[4].dinh2 = 21;
   saoGai.mangTamGiac[5].dinh0 = 1;   saoGai.mangTamGiac[5].dinh1 = 21;   saoGai.mangTamGiac[5].dinh2 = 22;

   saoGai.mangTamGiac[6].dinh0 = 2;   saoGai.mangTamGiac[6].dinh1 = 23;   saoGai.mangTamGiac[6].dinh2 = 20;
   saoGai.mangTamGiac[7].dinh0 = 2;   saoGai.mangTamGiac[7].dinh1 = 20;   saoGai.mangTamGiac[7].dinh2 = 22;
   saoGai.mangTamGiac[8].dinh0 = 2;   saoGai.mangTamGiac[8].dinh1 = 22;   saoGai.mangTamGiac[8].dinh2 = 23;

   saoGai.mangTamGiac[9].dinh0 = 3;   saoGai.mangTamGiac[9].dinh1 = 24;   saoGai.mangTamGiac[9].dinh2 = 20;
   saoGai.mangTamGiac[10].dinh0 = 3;  saoGai.mangTamGiac[10].dinh1 = 20;  saoGai.mangTamGiac[10].dinh2 = 23;
   saoGai.mangTamGiac[11].dinh0 = 3;  saoGai.mangTamGiac[11].dinh1 = 23;  saoGai.mangTamGiac[11].dinh2 = 24;

   saoGai.mangTamGiac[12].dinh0 = 4;  saoGai.mangTamGiac[12].dinh1 = 25;  saoGai.mangTamGiac[12].dinh2 = 20;
   saoGai.mangTamGiac[13].dinh0 = 4;  saoGai.mangTamGiac[13].dinh1 = 20;  saoGai.mangTamGiac[13].dinh2 = 24;
   saoGai.mangTamGiac[14].dinh0 = 4;  saoGai.mangTamGiac[14].dinh1 = 24;  saoGai.mangTamGiac[14].dinh2 = 25;
   // ----
   saoGai.mangTamGiac[15].dinh0 = 5;  saoGai.mangTamGiac[15].dinh1 = 21;  saoGai.mangTamGiac[15].dinh2 = 25;
   saoGai.mangTamGiac[16].dinh0 = 5;  saoGai.mangTamGiac[16].dinh1 = 25;  saoGai.mangTamGiac[16].dinh2 = 26;
   saoGai.mangTamGiac[17].dinh0 = 5;  saoGai.mangTamGiac[17].dinh1 = 26;  saoGai.mangTamGiac[17].dinh2 = 21;

   saoGai.mangTamGiac[18].dinh0 = 6;  saoGai.mangTamGiac[18].dinh1 = 22;   saoGai.mangTamGiac[18].dinh2 = 21;
   saoGai.mangTamGiac[19].dinh0 = 6;  saoGai.mangTamGiac[19].dinh1 = 21;   saoGai.mangTamGiac[19].dinh2 = 27;
   saoGai.mangTamGiac[20].dinh0 = 6;  saoGai.mangTamGiac[20].dinh1 = 27;   saoGai.mangTamGiac[20].dinh2 = 22;
   
   saoGai.mangTamGiac[21].dinh0 = 7;  saoGai.mangTamGiac[21].dinh1 = 23;  saoGai.mangTamGiac[21].dinh2 = 22;
   saoGai.mangTamGiac[22].dinh0 = 7;  saoGai.mangTamGiac[22].dinh1 = 22;  saoGai.mangTamGiac[22].dinh2 = 28;
   saoGai.mangTamGiac[23].dinh0 = 7;  saoGai.mangTamGiac[23].dinh1 = 28;  saoGai.mangTamGiac[23].dinh2 = 23;

   saoGai.mangTamGiac[24].dinh0 = 8; saoGai.mangTamGiac[24].dinh1 = 24;   saoGai.mangTamGiac[24].dinh2 = 23;
   saoGai.mangTamGiac[25].dinh0 = 8; saoGai.mangTamGiac[25].dinh1 = 23;   saoGai.mangTamGiac[25].dinh2 = 29;
   saoGai.mangTamGiac[26].dinh0 = 8; saoGai.mangTamGiac[26].dinh1 = 29;   saoGai.mangTamGiac[26].dinh2 = 24;

   saoGai.mangTamGiac[27].dinh0 = 9; saoGai.mangTamGiac[27].dinh1 = 25;   saoGai.mangTamGiac[27].dinh2 = 24;
   saoGai.mangTamGiac[28].dinh0 = 9; saoGai.mangTamGiac[28].dinh1 = 24;   saoGai.mangTamGiac[28].dinh2 = 30;
   saoGai.mangTamGiac[29].dinh0 = 9; saoGai.mangTamGiac[29].dinh1 = 30;   saoGai.mangTamGiac[29].dinh2 = 25;
   // ----
   saoGai.mangTamGiac[30].dinh0 = 10;  saoGai.mangTamGiac[30].dinh1 = 27;  saoGai.mangTamGiac[30].dinh2 = 21;
   saoGai.mangTamGiac[31].dinh0 = 10;  saoGai.mangTamGiac[31].dinh1 = 21;  saoGai.mangTamGiac[31].dinh2 = 26;
   saoGai.mangTamGiac[32].dinh0 = 10;  saoGai.mangTamGiac[32].dinh1 = 26;  saoGai.mangTamGiac[32].dinh2 = 27;

   saoGai.mangTamGiac[33].dinh0 = 11;  saoGai.mangTamGiac[33].dinh1 = 28;   saoGai.mangTamGiac[33].dinh2 = 22;
   saoGai.mangTamGiac[34].dinh0 = 11;  saoGai.mangTamGiac[34].dinh1 = 22;   saoGai.mangTamGiac[34].dinh2 = 27;
   saoGai.mangTamGiac[35].dinh0 = 11;  saoGai.mangTamGiac[35].dinh1 = 27;   saoGai.mangTamGiac[35].dinh2 = 28;

   saoGai.mangTamGiac[36].dinh0 = 12;  saoGai.mangTamGiac[36].dinh1 = 29;   saoGai.mangTamGiac[36].dinh2 = 23;
   saoGai.mangTamGiac[37].dinh0 = 12;  saoGai.mangTamGiac[37].dinh1 = 23;   saoGai.mangTamGiac[37].dinh2 = 28;
   saoGai.mangTamGiac[38].dinh0 = 12;  saoGai.mangTamGiac[38].dinh1 = 28;   saoGai.mangTamGiac[38].dinh2 = 29;
   
   saoGai.mangTamGiac[39].dinh0 = 13;  saoGai.mangTamGiac[39].dinh1 = 30;   saoGai.mangTamGiac[39].dinh2 = 24;
   saoGai.mangTamGiac[40].dinh0 = 13;  saoGai.mangTamGiac[40].dinh1 = 24;   saoGai.mangTamGiac[40].dinh2 = 29;
   saoGai.mangTamGiac[41].dinh0 = 13;  saoGai.mangTamGiac[41].dinh1 = 29;   saoGai.mangTamGiac[41].dinh2 = 30;

   saoGai.mangTamGiac[42].dinh0 = 14;  saoGai.mangTamGiac[42].dinh1 = 26;   saoGai.mangTamGiac[42].dinh2 = 25;
   saoGai.mangTamGiac[43].dinh0 = 14;  saoGai.mangTamGiac[43].dinh1 = 25;   saoGai.mangTamGiac[43].dinh2 = 30;
   saoGai.mangTamGiac[44].dinh0 = 14;  saoGai.mangTamGiac[44].dinh1 = 30;   saoGai.mangTamGiac[44].dinh2 = 26;
   // ----
   saoGai.mangTamGiac[45].dinh0 = 15;  saoGai.mangTamGiac[45].dinh1 = 27;    saoGai.mangTamGiac[45].dinh2 = 26;
   saoGai.mangTamGiac[46].dinh0 = 15;  saoGai.mangTamGiac[46].dinh1 = 26;    saoGai.mangTamGiac[46].dinh2 = 31;
   saoGai.mangTamGiac[47].dinh0 = 15;  saoGai.mangTamGiac[47].dinh1 = 31;    saoGai.mangTamGiac[47].dinh2 = 27;

   saoGai.mangTamGiac[48].dinh0 = 16;   saoGai.mangTamGiac[48].dinh1 = 28;   saoGai.mangTamGiac[48].dinh2 = 27;
   saoGai.mangTamGiac[49].dinh0 = 16;   saoGai.mangTamGiac[49].dinh1 = 27;   saoGai.mangTamGiac[49].dinh2 = 31;
   saoGai.mangTamGiac[50].dinh0 = 16;   saoGai.mangTamGiac[50].dinh1 = 31;   saoGai.mangTamGiac[50].dinh2 = 28;

   saoGai.mangTamGiac[51].dinh0 = 17;   saoGai.mangTamGiac[51].dinh1 = 29;   saoGai.mangTamGiac[51].dinh2 = 28;
   saoGai.mangTamGiac[52].dinh0 = 17;   saoGai.mangTamGiac[52].dinh1 = 28;   saoGai.mangTamGiac[52].dinh2 = 31;
   saoGai.mangTamGiac[53].dinh0 = 17;   saoGai.mangTamGiac[53].dinh1 = 31;   saoGai.mangTamGiac[53].dinh2 = 29;

   saoGai.mangTamGiac[54].dinh0 = 18;   saoGai.mangTamGiac[54].dinh1 = 30;   saoGai.mangTamGiac[54].dinh2 = 29;
   saoGai.mangTamGiac[55].dinh0 = 18;   saoGai.mangTamGiac[55].dinh1 = 29;   saoGai.mangTamGiac[55].dinh2 = 31;
   saoGai.mangTamGiac[56].dinh0 = 18;   saoGai.mangTamGiac[56].dinh1 = 31;   saoGai.mangTamGiac[56].dinh2 = 30;

   saoGai.mangTamGiac[57].dinh0 = 19;   saoGai.mangTamGiac[57].dinh1 = 26;   saoGai.mangTamGiac[57].dinh2 = 30;
   saoGai.mangTamGiac[58].dinh0 = 19;   saoGai.mangTamGiac[58].dinh1 = 30;   saoGai.mangTamGiac[58].dinh2 = 31;
   saoGai.mangTamGiac[59].dinh0 = 19;   saoGai.mangTamGiac[59].dinh1 = 31;   saoGai.mangTamGiac[59].dinh2 = 26;
   
   // ---- hợp quanh
   baoBiVT->gocCucTieu.x = -1.86364f;
   baoBiVT->gocCucDai.x = 1.86364f;
   baoBiVT->gocCucTieu.y = -1.77242f;
   baoBiVT->gocCucDai.y = 1.77242f;
   baoBiVT->gocCucTieu.z = -1.50722f;
   baoBiVT->gocCucDai.z = 1.50722f;
   return saoGai;
}
