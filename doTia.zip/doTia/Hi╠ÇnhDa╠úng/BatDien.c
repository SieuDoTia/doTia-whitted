#include "BatDien.h"
#include "../HangSo.h"

#pragma mark ---- Bát Diện
BatDien datBatDien( float beRong, float beCao, float beDai, BaoBi *baoBi ) {
   
   BatDien batDien;
   batDien.soLuongTamGiac = 8;
   float nuaBeRong = 0.5f*beRong;
   float nuaBeDai = 0.5f*beDai;
   
   // ---- cực trên
   batDien.mangDinh[0].x = 0.0;
   batDien.mangDinh[0].y = 0.5f*beCao;
   batDien.mangDinh[0].z = 0.0;
   // ---- xích đạo
   batDien.mangDinh[1].x = nuaBeRong;
   batDien.mangDinh[1].y = 0.0;
   batDien.mangDinh[1].z = nuaBeDai;
   
   batDien.mangDinh[2].x = nuaBeRong;
   batDien.mangDinh[2].y = 0.0f;
   batDien.mangDinh[2].z = -nuaBeDai;

   batDien.mangDinh[3].x = -nuaBeRong;
   batDien.mangDinh[3].y = 0.0f;
   batDien.mangDinh[3].z = -nuaBeDai;

   batDien.mangDinh[4].x = -nuaBeRong;
   batDien.mangDinh[4].y = 0.0f;
   batDien.mangDinh[4].z = nuaBeDai;
   // ---- cực dưới
   batDien.mangDinh[5].x = 0.0;
   batDien.mangDinh[5].y = -0.5f*beCao;
   batDien.mangDinh[5].z = 0.0f;
   
   // ---- mảng tam giác
   // 4 mặt trên
   batDien.mangTamGiac[0].dinh0 = 0;
   batDien.mangTamGiac[0].dinh1 = 1;
   batDien.mangTamGiac[0].dinh2 = 2;
   
   batDien.mangTamGiac[1].dinh0 = 0;
   batDien.mangTamGiac[1].dinh1 = 2;
   batDien.mangTamGiac[1].dinh2 = 3;
   
   batDien.mangTamGiac[2].dinh0 = 0;
   batDien.mangTamGiac[2].dinh1 = 3;
   batDien.mangTamGiac[2].dinh2 = 4;

   batDien.mangTamGiac[3].dinh0 = 0;
   batDien.mangTamGiac[3].dinh1 = 4;
   batDien.mangTamGiac[3].dinh2 = 1;
   // 4 mặt dưới
   batDien.mangTamGiac[4].dinh0 = 2;
   batDien.mangTamGiac[4].dinh1 = 1;
   batDien.mangTamGiac[4].dinh2 = 5;

   batDien.mangTamGiac[5].dinh0 = 3;
   batDien.mangTamGiac[5].dinh1 = 2;
   batDien.mangTamGiac[5].dinh2 = 5;

   batDien.mangTamGiac[6].dinh0 = 4;
   batDien.mangTamGiac[6].dinh1 = 3;
   batDien.mangTamGiac[6].dinh2 = 5;

   batDien.mangTamGiac[7].dinh0 = 1;
   batDien.mangTamGiac[7].dinh1 = 4;
   batDien.mangTamGiac[7].dinh2 = 5;

   baoBi->gocCucTieu.x = -nuaBeRong;
   baoBi->gocCucDai.x = nuaBeRong;
   baoBi->gocCucTieu.y = -0.5f*beCao;
   baoBi->gocCucDai.y = 0.5f*beCao;
   baoBi->gocCucTieu.z = -nuaBeDai;
   baoBi->gocCucDai.z = nuaBeDai;

   return batDien;
}
