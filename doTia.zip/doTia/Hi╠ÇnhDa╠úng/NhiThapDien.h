#pragma once

#include "TamGiac.h"
#include "../Toán/Vecto.h"
#include "../XemCat/BaoBi.h"


/* Nhi Thập Diên */
typedef struct {
   Vecto mangDinh[12];   // mảng đỉnh
   TamGiac mangTamGiac[20];  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} NhiThapDien;

NhiThapDien datNhiThapDien( float beRong, float beCao, float beDai, BaoBi *baoBiVT );