#import "HinhXuyen.h"
#include "../HangSo.h"
#include "../Toán/Vecto.h"
#include <math.h>


#pragma mark ---- Hình Xuyến
// R - bán kính vòng
// r - bán kính ống
// (x^2 + y^2 + z^2 + R^2 - r^2)^2 - 4*R^2*(x^2 + z^2) = 0
// [(x_0 + x_h*t)^2 + (y_0 + y_h*t)^2 + (z_0 + z_h*t)^2 + R^2 - r^2]^2 - 4*R^2*((x_0 + x_h*t)^2 + (z_0 + z_h*t)^2)
// [(x_0^2 + y_0^2 + z_0^2 + R^2 - r^2) + 2.0*(x_0*x_h + y_0*y_h + z_0*z_h)*t + (x_h^2 + y_h^2 + z_h^2)*t^2]^2 -
//          4*R^2*[(x_0^2 + z_0^2) + 2.0*(x_0*x_h + z_0*z_h)*t + (x_h^2 + z_h^2)*t^2] = 0
// A_0 = x_0^2 + y_0^2 + z_0^2 + R^2 - r^2
// A_1 = 2.0*(x_0*x_h + y_0*y_h + z_0*z_h)
// A_2 = x_h^2 + y_h^2 + z_h^2
// B_0 = x_0^2 + z_0^2
// B_1 = 2.0*(x_0*x_h + z_0*z_h)
// B_2 = x_h^2 + z_h^2
//  thay vào
// [A_0 + A_1*t + A_2*t^2]^2 - 4*R^2*[B_0 + B_1*t + B_2*t^2] = 0
// [A_0*A_0 + 2*A_1*A_0*t + A_1*A_1*t^2 + 2*A_2*A_1*t^3 + A_2*A_2*t^4 - 4*R^2*[B_0 + B_1*t + B_2*t^2] = 0
//

// ---- Pháp tuyến
// C = (x^2 + y^2 + z^2 + R^2 - r^2)
// Thay thế vào:
// C^2 - 4*R^2*(z^2 + z^2)
// ∇
// 2C*dCX/dx - 8*R^2*x; 2C*dC/dy; 2C*dX/dz - 8*R^2*z
// 4C*x - 8*R^2*x; 4C*y; 4C*z - 8*R^2*z
// C*x - 2*R^2*x; C*y; C*z - 2*R^2*z

HinhXuyen datHinhXuyen( float banKinhVong, float banKinhOng, BaoBi *baoBiVT ) {
   HinhXuyen hinhXuyen;
   hinhXuyen.banKinhVong = banKinhVong;
   hinhXuyen.banKinhOng = banKinhOng;
   
   baoBiVT->gocCucTieu.x = -banKinhVong - banKinhOng;
   baoBiVT->gocCucDai.x = banKinhVong + banKinhOng;
   baoBiVT->gocCucTieu.y = -banKinhOng;
   baoBiVT->gocCucDai.y = banKinhOng;
   baoBiVT->gocCucTieu.z = baoBiVT->gocCucTieu.x;
   baoBiVT->gocCucDai.z = baoBiVT->gocCucDai.x;
   
   return hinhXuyen;
}

typedef struct {
   float thuc;
   float ao;
} SoPhuc;

// ---- có lẻ xài hai hình trụ xem cắt trước này không?
unsigned char timNghiemBacBa( float c_2, float c_1, float c_0, SoPhuc *mangNghiem );

float xemCatHinhXuyen( HinhXuyen *hinhXuyen, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {
   
//   float cachXa = kVO_CUC;
 //  printf( "---- tia %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f\n", tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z );
   
   // ---- tính bình
   float xGocBinh = tia->goc.x*tia->goc.x;
   float yGocBinh = tia->goc.y*tia->goc.y;
   float zGocBinh = tia->goc.z*tia->goc.z;

   float xHuongBinh = tia->huong.x*tia->huong.x;
   float yHuongBinh = tia->huong.y*tia->huong.y;
   float zHuongBinh = tia->huong.z*tia->huong.z;

   float banKinhVongBinh = hinhXuyen->banKinhVong*hinhXuyen->banKinhVong;
   float banKinhOngBinh = hinhXuyen->banKinhOng*hinhXuyen->banKinhOng;
   
   // ---- tính hệ số cho cộng thức
   float A_0 = xGocBinh + yGocBinh + zGocBinh + banKinhVongBinh - banKinhOngBinh;
   float A_1 = 2.0f*(tia->goc.x*tia->huong.x + tia->goc.y*tia->huong.y + tia->goc.z*tia->huong.z);
   float A_2 = xHuongBinh + yHuongBinh + zHuongBinh;
   
   float B_0 = xGocBinh + zGocBinh;
   float B_1 = 2.0f*(tia->goc.x*tia->huong.x + tia->goc.z*tia->huong.z);
   float B_2 = xHuongBinh + zHuongBinh;

   float h_0 = A_0*A_0 - 4.0f*banKinhVongBinh*B_0;
   float h_1 = 2.0f*A_0*A_1 - 4.0f*banKinhVongBinh*B_1;
   float h_2 = A_1*A_1 + 2.0f*A_0*A_2 - 4.0f*banKinhVongBinh*B_2;
   float h_3 = 2.0f*A_1*A_2;
   float h_4 = A_2*A_2;
   
   // ---- giải nghiệm (có 4 cho bậc 4)
   h_0 /= h_4;
   h_1 /= h_4;
   h_2 /= h_4;
   h_3 /= h_4;
//   printf( "1.0*t^4 + %5.3f*t^3 + %5.3f*t^2 + %5.3f*t + %5.3f = 0\n", h_3, h_2, h_1, h_0 );

//   h_3 = -0.25f;
//   h_2 = -0.85f;
//   h_1 = 1.45f;
//   h_0 = -4.35f;
   // ----
   float p = h_2 - 0.375f*h_3*h_3;
   float q = 0.125f*h_3*h_3*h_3 - 0.5f*h_3*h_2 + h_1;
   float r = -3.0f*h_3*h_3*h_3*h_3/256.0f - 0.25f*h_3*h_1 + 0.0625f*h_3*h_3*h_2 + h_0;
//   printf( "p %5.3f  q %5.3f  r %5.3f\n", p, q ,r );
   
   // ---- chỉ cần tìm một nghiệm thực, phải có ít nhất một
   SoPhuc mangNghiemBacBa[3];
//   timNghiemBacBa( p, 0.25f*p*p - r, -0.125f*q*q, mangNghiemBacBa );
//   float z = mangNghiemBacBa[0].thuc;
   
   // ====
   unsigned char soLuongNghiemBacBaThat = timNghiemBacBa( p*0.5f, 0.0625f*p*p - 0.25f*r, -q*q/64.0f, mangNghiemBacBa );
//   printf( "soLuongNghiemThat %d\n", soLuongNghiemBacBaThat );
   // ---- cần căn số của hai nghiệm
   SoPhuc canSoZ;
   SoPhuc canSoU;
   if( soLuongNghiemBacBaThat == 1 ) {
      float doLonZ = sqrtf( mangNghiemBacBa[2].thuc*mangNghiemBacBa[2].thuc + mangNghiemBacBa[2].ao*mangNghiemBacBa[2].ao );
      float phanThucZ = mangNghiemBacBa[2].thuc;
      
      canSoZ.thuc = sqrtf(0.5*(doLonZ + phanThucZ));
      canSoZ.ao = sqrtf(0.5*(doLonZ - phanThucZ));
      
      // ---- hai nghiệm luôn giống nhau mà nghịch dấu
      canSoU.thuc = canSoZ.thuc;
      canSoU.ao = -canSoZ.ao;
   }
   else { // chỉ có nghiệm số phức, không trúng hình xuyên
      if( mangNghiemBacBa[2].thuc < 0.0f ) {
         canSoZ.thuc = 0.0f;
         canSoZ.ao = sqrtf( -mangNghiemBacBa[2].thuc );
      }
      else {
         canSoZ.thuc = sqrtf( mangNghiemBacBa[2].thuc );
         canSoZ.ao = 0.0f;
      }
      // ----
      if( mangNghiemBacBa[1].thuc < 0.0f ) {
         canSoU.thuc = 0.0f;
         canSoU.ao = sqrtf( -mangNghiemBacBa[1].thuc );
      }
      else {
         canSoU.thuc = sqrtf( mangNghiemBacBa[1].thuc );
         canSoU.ao = 0.0f;
      }
   }

//   printf( "canSoZ %5.3f + %5.3fi\n", canSoZ.thuc, canSoZ.ao );

//   printf( "canSoU %5.3f + %5.3fi\n", canSoU.thuc, canSoU.ao );
   // ---- nhân số phức, chỉ thành phân thực khác không
   float tich = canSoZ.thuc*canSoU.thuc - canSoZ.ao*canSoU.ao;
//   printf( "tich %5.3f\n", tich );
   float v = -0.125f*q/tich;
//   printf( "V %5.3f\n", v );
   float x = 0.25f*h_3;  // hangSo
//   printf( "X %5.3f\n", x );
   // ----
   SoPhuc mangNghiemBac_4[4];
   mangNghiemBac_4[0].thuc = canSoZ.thuc + canSoU.thuc + v - x;
   mangNghiemBac_4[0].ao = canSoZ.ao + canSoU.ao;
   mangNghiemBac_4[1].thuc = canSoZ.thuc - canSoU.thuc - v - x;
   mangNghiemBac_4[1].ao = canSoZ.ao - canSoU.ao;
   mangNghiemBac_4[2].thuc = -canSoZ.thuc + canSoU.thuc - v - x;
   mangNghiemBac_4[2].ao = -canSoZ.ao + canSoU.ao;
   mangNghiemBac_4[3].thuc = -canSoZ.thuc - canSoU.thuc + v - x;
   mangNghiemBac_4[3].ao = -canSoZ.ao - canSoU.ao;
//   printf( "  %5.3f + %5.3fi\n", mangNghiemBac_4[0].thuc, mangNghiemBac_4[0].ao );
//   printf( "  %5.3f + %5.3fi\n", mangNghiemBac_4[1].thuc, mangNghiemBac_4[1].ao );
//   printf( "  %5.3f + %5.3fi\n", mangNghiemBac_4[2].thuc, mangNghiemBac_4[2].ao );
//   printf( "  %5.3f + %5.3fi\n", mangNghiemBac_4[3].thuc, mangNghiemBac_4[3].ao );

   unsigned char soNghiem = 0;
   unsigned char soLuongNghiemBac_4_Thuc = 0;  // số lượng nghiệm bậc 4 thực
   float cachGanNhat = kVO_CUC;
   while( soNghiem < 4 ) {
      if( mangNghiemBac_4[soNghiem].ao == 0.0f ) {
         soLuongNghiemBac_4_Thuc++;
         float cachXaMoi = mangNghiemBac_4[soNghiem].thuc;
         if( (cachXaMoi > 0.001f) && (cachXaMoi < cachGanNhat) ) {
            cachGanNhat = cachXaMoi;
         }
      }
      soNghiem++;
   }

   if( (soLuongNghiemBac_4_Thuc) < 4 && (soLuongNghiemBacBaThat == 3) ) {
//      printf( "kVO_CUC\n" );
      return kVO_CUC;
   }
   else if( cachGanNhat < kVO_CUC ) {
      diemTrung->x = tia->goc.x + cachGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + cachGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + cachGanNhat*tia->huong.z;
      
      // ---- C*x - 2*R^2*x; C*y; C*z - 2*R^2*z
      float C = diemTrung->x*diemTrung->x + diemTrung->y*diemTrung->y + diemTrung->z*diemTrung->z + banKinhVongBinh - banKinhOngBinh;
      phapTuyen->x = (C - 2.0f*banKinhVongBinh)*diemTrung->x;
      phapTuyen->y = C*diemTrung->y;
      phapTuyen->z = (C - 2.0f*banKinhVongBinh)*diemTrung->z;
      donViHoa( phapTuyen );
   }
   
//   printf( "cachGanNhat %5.3f  soLuongNghiemBac_4_Thuc %d  soLuongNghiemBac_3_Thuc %d\n", cachGanNhat, soLuongNghiemBac_4_Thuc, soLuongNghiemBacBaThat );
   //   if( cachXa == kVO_CUC )
//   exit(0);

   return cachGanNhat;
}


unsigned char timNghiemBacBa( float c_2, float c_1, float c_0, SoPhuc *mangNghiem ) {
   
   // ---- chia hệ số
//   c_2 /= c_3;
//   c_1 /= c_3;
//   c_0 /= c_3;
//   printf( "1.0*t^3 + %5.3f*t^2 + %5.3f*t + %5.3f\n", c_2, c_1, c_0 );
   
   // ---- tính biệt thức
   float p = -c_2*c_2/9.0f + c_1*0.3333333f;
   float q = c_2*c_2*c_2/27.0f - c_2*c_1/6.0f + c_0*0.5f;
   float p_mu3 = p*p*p;
   float D = q*q + p_mu3;
//   printf( "p %5.3f   q %5.3f  D %5.3f\n", p, q, D );
   
   // ---- tùy biệt thức
   if( D <= 0.0f  ) {
      float goc = acosf(-q/sqrtf(-p_mu3));
      float haiNhanCanSo_p = 2.0f*sqrtf(-p);
      // ---- trừ hàng số để quay lại biến số gốc x
      float hangSo = c_2*0.3333333f;
      
      mangNghiem[0].thuc = haiNhanCanSo_p*cosf( goc*0.3333333f ) - hangSo;
      mangNghiem[0].ao = 0.0f;
      mangNghiem[1].thuc = -haiNhanCanSo_p*cosf( (goc + 3.1415927f)*0.3333333f ) - hangSo;
      mangNghiem[1].ao = 0.0f;
      mangNghiem[2].thuc = -haiNhanCanSo_p*cosf( (goc - 3.1415927f)*0.3333333f ) - hangSo;
      mangNghiem[2].ao = 0.0f;

      // ---- sắp thứ tự
      if( fabsf(mangNghiem[1].thuc) < fabsf(mangNghiem[0].thuc) ) {
         float giaTriTraoDoi = mangNghiem[1].thuc;
         mangNghiem[1].thuc = mangNghiem[0].thuc;
         mangNghiem[0].thuc = giaTriTraoDoi;
      }
      if( fabsf(mangNghiem[2].thuc) < fabsf(mangNghiem[1].thuc) ) {
         float giaTriTraoDoi = mangNghiem[2].thuc;
         mangNghiem[2].thuc = mangNghiem[1].thuc;
         mangNghiem[1].thuc = giaTriTraoDoi;
      }
      if( fabsf(mangNghiem[1].thuc) < fabsf(mangNghiem[0].thuc) ) {
         float giaTriTraoDoi = mangNghiem[1].thuc;
         mangNghiem[1].thuc = mangNghiem[0].thuc;
         mangNghiem[0].thuc = giaTriTraoDoi;
      }
         
//      printf( "  LP %5.3f;  %5.3f;  %5.3f\n", mangNghiem[0].thuc, mangNghiem[1].thuc, mangNghiem[2].thuc );
      return 3;
   }
   else {
      // ---- coi chừng
      float u = -q + sqrtf(D);
      if( u < 0.0 )
         u = -powf( -u, 0.3333333f );
      else
         u = powf( u, 0.3333333f );
      
      float v = -q - sqrtf(D); // tạm thời xài v giỡ giá trị giùm
      if( v <= 0.0f )
         v = -powf( -v, 0.3333333f );
      else
         v = powf( v, 0.3333333f );
            
      float hangSo = c_2*0.3333333f;
      mangNghiem[0].thuc = u + v - hangSo;
      mangNghiem[0].ao = 0.0f;
      mangNghiem[1].thuc = -(u + v)*0.5f - hangSo;
      mangNghiem[1].ao = 0.866025f*(u-v);   // 0.866025 = √3/2
      mangNghiem[2].thuc = mangNghiem[1].thuc;
      mangNghiem[2].ao = -mangNghiem[1].ao;
//      printf( "  LP %5.3f;  %5.3f + %5.3fi  %5.3f + %5.3fi\n", mangNghiem[0].thuc, mangNghiem[1].thuc, mangNghiem[1].ao, mangNghiem[2].thuc, mangNghiem[2].ao );
      return 1;
   }
}
