#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"

/* Tam Giác */
typedef struct {
   unsigned short dinh0;
   unsigned short dinh1;
   unsigned short dinh2;
   Vecto phapTuyen;
} TamGiac;

/* Tính Pháp Tuyến cho Tam Giác */
Vecto tinhPhapTuyenChoTamGiac( Vecto *tamGiac );

/* xem cắt tam giác MT (Möller–Trumbore) */
float xemCatTamGiacMT( Vecto *mangDinhTamGiac, Tia *tia );

/* xem cắt vật thể tam giác */
float xemCatVatTheTamGiac( Vecto *mangDinh, TamGiac *mangTamGiac, unsigned short soLuongTamGiac, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );