#pragma once

#include "../Toán/Vecto.h"
#include "TamGiac.h"
#include "../XemCat/BaoBi.h"

/* Sao Gai */
typedef struct {
   Vecto mangDinh[32];   // mảng đỉnh
   TamGiac mangTamGiac[60];  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} SaoGai;


// ---- sao gai
SaoGai datSaoGai( BaoBi *baoBiVT, float doMap );