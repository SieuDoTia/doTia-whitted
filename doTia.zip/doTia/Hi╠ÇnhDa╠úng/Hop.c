#include "Hop.h"
#include "../HangSo.h"

#pragma mark --- Hộp
#define kHUONG_AM_X    0
#define kHUONG_DUONG_X 1
#define kHUONG_AM_Y    2
#define kHUONG_DUONG_Y 3
#define kHUONG_AM_Z    4
#define kHUONG_DUONG_Z 5

Hop datHop( float rong, float cao, float dai, BaoBi *baoBiVT ) {

   Hop hop;
   hop.beRong = rong;
   hop.beCao = cao;
   hop.beDai = dai;

   baoBiVT->gocCucTieu.x = -0.5f*rong;
   baoBiVT->gocCucDai.x = 0.5f*rong;
   baoBiVT->gocCucTieu.y = -0.5f*cao;
   baoBiVT->gocCucDai.y = 0.5f*cao;
   baoBiVT->gocCucTieu.z = -0.5f*dai;
   baoBiVT->gocCucDai.z = 0.5f*dai;

   return hop;
}

// ---- Phương pháp của Smits
float xemCatHop( Hop *hop, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {

   unsigned char huongPhapTuyen;
   phapTuyen->x = 0.0f;
   phapTuyen->y = 0.0f;
   phapTuyen->z = 0.0f;

   float nghiemGanNhat = kVO_CUC;  // gần nhất và dương
   float nuaBeRong = 0.5f*hop->beRong;
   float nuaBeCao = 0.5f*hop->beCao;
   float nuaBeDai = 0.5f*hop->beDai;

   // ---- tính nghiệm cho hướng x
   if( tia->huong.x != 0.0f ) {
      // ---- tính hai nghiệm
      float nghiem0 = (-nuaBeRong - tia->goc.x) / tia->huong.x;
      float nghiem1 = (nuaBeRong - tia->goc.x) / tia->huong.x;

      // ----
      if( nghiem0 < 0.0001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.0001f )
         nghiem1 = kVO_CUC;
      
      float nghiemX;
      unsigned char huongPhapTuyenX;
      if( nghiem0 < nghiem1 ) {
         nghiemX = nghiem0;
         huongPhapTuyenX = kHUONG_AM_X;
      }
      else {
         nghiemX = nghiem1;
         huongPhapTuyenX = kHUONG_DUONG_X;
      }
//      printf("hop: nghiemX %5.3f\n", nghiemX );
      if( nghiemX < nghiemGanNhat ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungX;
         diemTrungX.x = tia->goc.x + nghiemX*tia->huong.x;
         diemTrungX.y = tia->goc.y + nghiemX*tia->huong.y;
         diemTrungX.z = tia->goc.z + nghiemX*tia->huong.z;
//      printf("nghiemX %5.3f  %5.3f\n", nghiemX, nghiemGanNhat );
         if( diemTrungX.y > nuaBeCao )
            nghiemX = kVO_CUC;
         else if( diemTrungX.y < -nuaBeCao )
            nghiemX = kVO_CUC;
         else if( diemTrungX.z > nuaBeDai )
            nghiemX = kVO_CUC;
         else if( diemTrungX.z < -nuaBeDai )
            nghiemX = kVO_CUC;

//      printf("hop: diemTrungX %5.3f %5.3f %5.3f\n", diemTrungX.x, diemTrungX.y, diemTrungX.z );
         if( nghiemX < nghiemGanNhat ) {
            nghiemGanNhat = nghiemX;
            huongPhapTuyen = huongPhapTuyenX;
            diemTrung->x = diemTrungX.x;
            diemTrung->y = diemTrungX.y;
            diemTrung->z = diemTrungX.z;
         }
      }
   }
   
   // ---- tính nghiệm cho hướng y
   if( tia->huong.y != 0.0f ) {
      // ---- tính hai nghiệm
      float nghiem0 = (-nuaBeCao - tia->goc.y) / tia->huong.y;
      float nghiem1 = (nuaBeCao - tia->goc.y) / tia->huong.y;

      // ----
      if( nghiem0 < 0.0001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.0001f )
         nghiem1 = kVO_CUC;
      
      float nghiemY;
      unsigned char huongPhapTuyenY;
      if( nghiem0 < nghiem1 ) {
         nghiemY = nghiem0;
         huongPhapTuyenY = kHUONG_AM_Y;
      }
      else {
         nghiemY = nghiem1;
         huongPhapTuyenY = kHUONG_DUONG_Y;
      }
//      printf("hop: nghiemY %5.3f\n", nghiemY );
      if( nghiemY < nghiemGanNhat ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungY;
         diemTrungY.x = tia->goc.x + nghiemY*tia->huong.x;
         diemTrungY.y = tia->goc.y + nghiemY*tia->huong.y;
         diemTrungY.z = tia->goc.z + nghiemY*tia->huong.z;
         
         if( diemTrungY.x > nuaBeRong )
            nghiemY = kVO_CUC;
         else if( diemTrungY.x < -nuaBeRong )
            nghiemY = kVO_CUC;
         else if( diemTrungY.z > nuaBeDai )
            nghiemY = kVO_CUC;
         else if( diemTrungY.z < -nuaBeDai )
            nghiemY = kVO_CUC;
         
         if( nghiemY < nghiemGanNhat ) {
            nghiemGanNhat = nghiemY;
            huongPhapTuyen = huongPhapTuyenY;
            diemTrung->x = diemTrungY.x;
            diemTrung->y = diemTrungY.y;
            diemTrung->z = diemTrungY.z;
         }
      }
   }

   // ---- tính nghiệm cho hướng z
   if( tia->huong.z != 0.0f ) {
      // ---- tính hai nghiệm
      float nghiem0 = (-nuaBeDai - tia->goc.z) / tia->huong.z;
      float nghiem1 = (nuaBeDai - tia->goc.z) / tia->huong.z;

      // ----
      if( nghiem0 < 0.0001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.0001f )
         nghiem1 = kVO_CUC;
      
      float nghiemZ;
      unsigned char huongPhapTuyenZ;
      if( nghiem0 < nghiem1 ) {
         nghiemZ = nghiem0;
         huongPhapTuyenZ = kHUONG_AM_Z;
      }
      else {
         nghiemZ = nghiem1;
         huongPhapTuyenZ = kHUONG_DUONG_Z;
      }
 //     printf("hop: nghiemZ %5.3f\n", nghiemZ );
      if( nghiemZ < nghiemGanNhat ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungZ;
         diemTrungZ.x = tia->goc.x + nghiemZ*tia->huong.x;
         diemTrungZ.y = tia->goc.y + nghiemZ*tia->huong.y;
         diemTrungZ.z = tia->goc.z + nghiemZ*tia->huong.z;

         if( diemTrungZ.x > nuaBeRong )
            nghiemZ = kVO_CUC;
         else if( diemTrungZ.x < -nuaBeRong )
            nghiemZ = kVO_CUC;
         else if( diemTrungZ.y > nuaBeCao )
            nghiemZ = kVO_CUC;
         else if( diemTrungZ.y < -nuaBeCao )
            nghiemZ = kVO_CUC;

//      printf("hop: diemTrungZ %5.3f %5.3f %5.3f   nghiemZ %5.3f\n", diemTrungZ.x, diemTrungZ.y, diemTrungZ.z, nghiemZ );
         if( nghiemZ < nghiemGanNhat ) {
            huongPhapTuyen = huongPhapTuyenZ;
            diemTrung->x = diemTrungZ.x;
            diemTrung->y = diemTrungZ.y;
            diemTrung->z = diemTrungZ.z;
            nghiemGanNhat = nghiemZ;
         }
      }
   }

   if( nghiemGanNhat < kVO_CUC ) {
      // ---- tạo pháp tuyến
      if( huongPhapTuyen == kHUONG_AM_X ) {
         phapTuyen->x = -1.0f;
         phapTuyen->y = 0.0f;
         phapTuyen->z = 0.0f;
      }
      else if( huongPhapTuyen == kHUONG_DUONG_X ) {
         phapTuyen->x = 1.0f;
         phapTuyen->y = 0.0f;
         phapTuyen->z = 0.0f;
      }
      else if( huongPhapTuyen == kHUONG_AM_Y ) {
         phapTuyen->x = 0.0;
         phapTuyen->y = -1.0f;
         phapTuyen->z = 0.0f;
      }
      else if( huongPhapTuyen == kHUONG_DUONG_Y ) {
         phapTuyen->x = 0.0;
         phapTuyen->y = 1.0f;
         phapTuyen->z = 0.0f;
      }
      else if( huongPhapTuyen == kHUONG_AM_Z ) {
         phapTuyen->x = 0.0;
         phapTuyen->y = 0.0f;
         phapTuyen->z = -1.0f;
      }
      else if( huongPhapTuyen == kHUONG_DUONG_Z ) {
         phapTuyen->x = 0.0;
         phapTuyen->y = 0.0f;
         phapTuyen->z = 1.0f;
      }
   }
//   printf( "Hop: nghiemGanNhat %5.3f\n", nghiemGanNhat );
   return nghiemGanNhat;
}

unsigned char xemDiemTrongHop( Hop *hop, Vecto *diem ) {
   float nuaBeRong = 0.5f*hop->beRong;
   float nuaBeCao = 0.5f*hop->beCao;
   float nuaBeDai = 0.5f*hop->beDai;
   
   unsigned char diemTrong = kDUNG;
   if( diem->x < -nuaBeRong )
      diemTrong = kSAI;
   else if( diem->x > nuaBeRong )
      diemTrong = kSAI;
   else if( diem->y < -nuaBeCao )
      diemTrong = kSAI;
   else if( diem->y > nuaBeCao )
      diemTrong = kSAI;
   else if( diem->z < -nuaBeDai )
      diemTrong = kSAI;
   else if( diem->z > nuaBeDai )
      diemTrong = kSAI;
   
   return diemTrong;
}
