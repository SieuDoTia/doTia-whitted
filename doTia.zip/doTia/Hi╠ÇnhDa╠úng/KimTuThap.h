#pragma once

#include "TamGiac.h"
#include "../Toán/Vecto.h"
#include "../XemCat/BaoBi.h"


/* Kim Tư Tháp */
typedef struct {
   Vecto mangDinh[5];   // mảng đỉnh
   TamGiac mangTamGiac[6];  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} KimTuThap;

// ---- kim tư tháp
KimTuThap datKimTuThap( float beRong, float beCao, float beDai, BaoBi *baoBiVT ); // đặt kim tư tháp