#include "MatSong.h"
#include "../HangSo.h"
#include <math.h>


#pragma mark ---- Mặt Sóng
MatSong datMatSong( float beRong, float beDai, float bienDo0, float bienDo1, float tanSo0, float tanSo1, float tanSo0_x, float tanSo1_x, float tanSo0_z, float tanSo1_z, unsigned char tron, BaoBi *baoBiVT ) {

   MatSong matSong;

   if( tron ) {
      // ---- tính bán kính
      float banKinh = 0.25f*(beRong + beDai);
      matSong.banKinhBinhBP = banKinh*banKinh;
   }
   else {
      matSong.nuaBeRong = 0.5f*beRong;
      matSong.nuaBeDai = 0.5f*beDai;
   }

   matSong.thoiGian = 0;

   matSong.bienDo0 = bienDo0;
   matSong.bienDo1 = bienDo1;

   matSong.bienDoNhat = bienDo0 + bienDo1;

   matSong.tanSo0 = tanSo0;
   matSong.tanSo1 = tanSo1;
   matSong.tanSo0_x = tanSo0_x;
   matSong.tanSo1_x = tanSo1_x;
   matSong.tanSo0_z = tanSo0_z;
   matSong.tanSo1_z = tanSo1_z;
   
   matSong.tron = tron;

   baoBiVT->gocCucTieu.x = -0.5f*beRong;
   baoBiVT->gocCucDai.x = 0.5f*beRong;
   baoBiVT->gocCucTieu.y = -matSong.bienDoNhat;
   baoBiVT->gocCucDai.y = matSong.bienDoNhat;
   baoBiVT->gocCucTieu.z = -0.5f*beDai;
   baoBiVT->gocCucDai.z = 0.5f*beDai;

   return matSong;
}

// y = a*sin(A_0*x + B_0*z + C_0*t) + b*sin(A_1*x + B_1*z + C_1*t) + c*sin(A_2*x + B_2*z + C_2*t)
// -a*cos(A_0*x + B_0*z + C_0*t)*A_0 + b*cos(A_1*x + B_1*z + C_1*t)*A_1 + c*cos(A_2*x + B_2*z + C_2*t)*A_2,
//  1,
// -a*cos(A_0*x + B_0*z + C_0*t)*B_0 + b*cos(A_1*x + B_1*z + C_1*t)*B_1 + c*cos(A_2*x + B_2*z + C_2*t)*B_2
//#define kA_0  1.0f
//#define kB_0  -0.3f
//#define kC_0  0.8f

//#define kA_1  0.5f
//#define kB_1  0.3f
//#define kC_1  0.5f
float xemCatMatSong( MatSong *matSong, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {
   
   float cachXa = kVO_CUC;

   float cachTren = 0.5f;
   float cachDuoi = 0.01f;
   
   // ---- tính điểm gần
   float xDuoi = tia->goc.x + cachDuoi*tia->huong.x;
   float yDuoi = tia->goc.y + cachDuoi*tia->huong.y;
   float zDuoi = tia->goc.z + cachDuoi*tia->huong.z;
   
   // ---- tính độ cao (y) điểm trên sóng cùng tọa đồ (x; z)
   unsigned int thoiGian = matSong->thoiGian;
   float ketQuaDuoi = matSong->bienDo0*sinf( matSong->tanSo0_x*xDuoi + matSong->tanSo0_z*zDuoi - matSong->tanSo0*thoiGian ) +
   matSong->bienDo1*sinf( matSong->tanSo1_x*xDuoi + matSong->tanSo1_z*zDuoi - matSong->tanSo1*thoiGian )
   - yDuoi;

   unsigned char trenAm = kSAI;
   unsigned char duoiAm = kSAI;
   if( ketQuaDuoi < 0.0f )
      duoiAm = kDUNG;
   else
      duoiAm = kSAI;
   
   // ---- kiếm điểm trúng
   unsigned char xong = kSAI;
   while( !xong ) {
      // ---- tính điểm xa
      float xTren = tia->goc.x + cachTren*tia->huong.x;
      float yTren = tia->goc.y + cachTren*tia->huong.y;
      float zTren = tia->goc.z + cachTren*tia->huong.z;
      
      // ---- tính độ cao (y) điểm trên sóng cùng tọa đồ (x; z)
      float ketQuaTren = matSong->bienDo0*sinf( matSong->tanSo0_x*xTren + matSong->tanSo0_z*zTren - matSong->tanSo0*thoiGian ) +
                  matSong->bienDo1*sinf( matSong->tanSo1_x*xTren + matSong->tanSo1_z*zTren - matSong->tanSo1*thoiGian ) - yTren;

      // ---- âm hay dương
      if( ketQuaTren < 0.0f )
         trenAm = kDUNG;
      else
         trenAm = kSAI;
      
      // ==== xem nếu hai điểm dưới và trên cùng bên
      if( trenAm != duoiAm )
         xong = kDUNG;   // ---- hai điểm ở hai bên mặt sóng, tia cắt mặt sóng trong khúc này
      else {
         cachTren += 2.0f;  // ---- hai điểm ở một bên mặt sóng, khúc này không cắt mặt sóng, tìm khúc tiếp
      }
      //         printf( "cachDuoi %5.3f  cachTren %5.3f  ketQuaDuoi %5.3f  ketQuaTren %5.3f\n", cachDuoi, cachTren, ketQuaDuoi, ketQuaTren );
      // ---- qúa xa là xong, cho tính nhanh hơn
      if( cachTren > 400.0f )
         xong = kDUNG;
   }
   
   // ==== nếu tia cắt mặt sóng, tìm điểm cắt
   if( trenAm != duoiAm ) {
      unsigned char soLuongTinh = 0;
      xong = kSAI;
      while( !xong ) {
         // ---- trung điểm
         float cachTrung = (cachTren + cachDuoi)*0.5f;
         float xTrung = tia->goc.x + cachTrung*tia->huong.x;
         float yTrung = tia->goc.y + cachTrung*tia->huong.y;
         float zTrung = tia->goc.z + cachTrung*tia->huong.z;
         float ketQuaTrung = matSong->bienDo0*sinf( matSong->tanSo0_x*xTrung + matSong->tanSo0_z*zTrung - matSong->tanSo0*thoiGian ) +
         matSong->bienDo1*sinf( matSong->tanSo1_x*xTrung + matSong->tanSo1_z*zTrung - matSong->tanSo1*thoiGian )
         - yTrung;
         
         unsigned char trungAm = kSAI;
         if( ketQuaTrung < 0.0f )
            trungAm = kDUNG;
         
         if( trungAm == trenAm )
            cachTren = cachTrung;
         if( trungAm == duoiAm )
            cachDuoi = cachTrung;
         
         float cach = cachTren - cachDuoi;
         if( cach < 0.0f )
            cach = -cach;
         
         if( cach < 0.001f ) {
            xong = kDUNG;
            // ---- tính điểm trúng
            cachXa = (cachTren + cachDuoi)*0.5f;
            diemTrung->x = tia->goc.x + cachXa*tia->huong.x;
            diemTrung->y = tia->goc.y + cachXa*tia->huong.y;
            diemTrung->z = tia->goc.z + cachXa*tia->huong.z;

            // ---- xem điểm ớ trong phạm vi mặt sóng
            if( matSong->tron ) {
               float banKinhBinhBP = diemTrung->x*diemTrung->x + diemTrung->z*diemTrung->z;
               if( banKinhBinhBP > matSong->banKinhBinhBP )
                  cachXa = kVO_CUC;
               else {
                  
                  phapTuyen->x = -matSong->bienDo0*matSong->tanSo0_x*cosf( matSong->tanSo0_x*diemTrung->x + matSong->tanSo0_z*diemTrung->z - matSong->tanSo0*thoiGian )
                  -matSong->bienDo1*matSong->tanSo1_x*cosf( matSong->tanSo1_x*diemTrung->x + matSong->tanSo1_z*diemTrung->z - matSong->tanSo1*thoiGian );
                  phapTuyen->y = 1.0f;
                  phapTuyen->z = -matSong->bienDo0*matSong->tanSo0_z*cosf( matSong->tanSo0_x*diemTrung->x + matSong->tanSo0_z*diemTrung->z - matSong->tanSo0*thoiGian )
                  -matSong->bienDo1*matSong->tanSo1_z*cosf( matSong->tanSo1_x*diemTrung->x + matSong->tanSo1_z*diemTrung->z - matSong->tanSo1*thoiGian );
                  donViHoa( phapTuyen );
               }
            }
            else {
               if( diemTrung->x < -matSong->nuaBeRong ) {
                  cachXa = kVO_CUC;
               }
               else if( diemTrung->x > matSong->nuaBeRong ) {
                  cachXa = kVO_CUC;
               }
               else if( diemTrung->z < -matSong->nuaBeDai ) {
                  cachXa = kVO_CUC;
               }
               else if( diemTrung->z > matSong->nuaBeDai ) {
                  cachXa = kVO_CUC;
               }
               else {
                  
                  phapTuyen->x = -matSong->bienDo0*matSong->tanSo0_x*cosf( matSong->tanSo0_x*diemTrung->x + matSong->tanSo0_z*diemTrung->z - matSong->tanSo0*thoiGian )
                  -matSong->bienDo1*matSong->tanSo1_x*cosf( matSong->tanSo1_x*diemTrung->x + matSong->tanSo1_z*diemTrung->z - matSong->tanSo1*thoiGian );
                  phapTuyen->y = 1.0f;
                  phapTuyen->z = -matSong->bienDo0*matSong->tanSo0_z*cosf( matSong->tanSo0_x*diemTrung->x + matSong->tanSo0_z*diemTrung->z - matSong->tanSo0*thoiGian )
                  -matSong->bienDo1*matSong->tanSo1_z*cosf( matSong->tanSo1_x*diemTrung->x + matSong->tanSo1_z*diemTrung->z - matSong->tanSo1*thoiGian );
                  donViHoa( phapTuyen );
               }
            }
         }
         
         // ---- đừng tính quá lâu
         if( soLuongTinh > 50 )
            xong = kDUNG;
         
         soLuongTinh++;
      }

   }

//   printf( "cachXa %5.3f\n", cachXa );
   return cachXa;
}
