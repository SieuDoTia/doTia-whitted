#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../XemCat/BaoBi.h"

/* Mat Parabol */
typedef struct {
   float banKinh;  // bán kính
   float beCao;
   float hopQuanh[6];   // hộp quanh
} MatParabol;


// ---- mặt parabol
MatParabol datMatParabol( float banKinh, float beCao, BaoBi *baoBiVT ); // đặt mặt parabol
float xemCatMatParabol( MatParabol *matParabol, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );  // xem cắt mặt parabol
