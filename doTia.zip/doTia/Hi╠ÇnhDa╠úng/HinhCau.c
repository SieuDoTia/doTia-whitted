#include "HinhCau.h"
#include "../HangSo.h"
#include <math.h>

#pragma mark ---- Hình Cầu
HinhCau datHinhCau( float banKinh, BaoBi *baoBiVT ) {
   
   HinhCau hinhCau;
   
   hinhCau.banKinh = banKinh;
   
   // ---- tính hợp bao bì
   baoBiVT->gocCucTieu.x = -banKinh;
   baoBiVT->gocCucDai.x = banKinh;
   baoBiVT->gocCucTieu.y = -banKinh;
   baoBiVT->gocCucDai.y = banKinh;
   baoBiVT->gocCucTieu.z = -banKinh;
   baoBiVT->gocCucDai.z = banKinh;
   
   return hinhCau;
}

float xemCatHinhCau( HinhCau *hinhCau, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {
   
   float nghiemGanNhat = kVO_CUC;

   // ---- tính vectơ từ trung tâm hình cầu đến điểm nhìn
   Vecto huongDenHinhCau;
   huongDenHinhCau.x = tia->goc.x;
   huongDenHinhCau.y = tia->goc.y;
   huongDenHinhCau.z = tia->goc.z;

   float A = tia->huong.x*tia->huong.x + tia->huong.y*tia->huong.y + tia->huong.z*tia->huong.z;
   float B = 2.0f*(tia->huong.x*huongDenHinhCau.x + tia->huong.y*huongDenHinhCau.y + tia->huong.z*huongDenHinhCau.z);
   float C = huongDenHinhCau.x*huongDenHinhCau.x + huongDenHinhCau.y*huongDenHinhCau.y + huongDenHinhCau.z*huongDenHinhCau.z -
                 hinhCau->banKinh*hinhCau->banKinh;
   float D = B*B - 4.0f*A*C;


   if( D > 0.0f ) {
     
      // ---- tính nghiệm và nghiệm gần nhất, xài giải thuật chính xác hơn
      float Q;
      if( B < 0.0f )
         Q = -0.5f*(B - sqrtf(D) );
      else
         Q = -0.5f*(B + sqrtf(D) );
   
      float nghiem0 = Q/A;
      float nghiem1 = C/Q;

      // ---- coi trừng nghiệm âm và khác không vỉ tia coi thể bắt đẩu tại mặt của hình cầu
      if( nghiem0 < 0.001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.001f )
         nghiem1 = kVO_CUC;

      // ---- gởi lại nghiệm nhỏ nhất mà dương
      if( nghiem0 < nghiem1 )
         nghiemGanNhat = nghiem0;
      else
         nghiemGanNhat = nghiem1;
   }

   if( nghiemGanNhat < kVO_CUC ) {
      diemTrung->x = tia->goc.x + nghiemGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + nghiemGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + nghiemGanNhat*tia->huong.z;
      // ---- vectơ vuông góc cho phát tia tiếp
      phapTuyen->x = diemTrung->x;
      phapTuyen->y = diemTrung->y;
      phapTuyen->z = diemTrung->z;

      donViHoa( phapTuyen );
   }
//   printf( "HinhCau: nghiemGanNhat %5.3f\n", nghiemGanNhat );
   return nghiemGanNhat;
}

unsigned char xemDiemTrongHinhCau( HinhCau *hinhCau, Vecto *diem ) {
   
   if( diem->x*diem->x + diem->y*diem->y + diem->z*diem->z < hinhCau->banKinh*hinhCau->banKinh )
      return kDUNG;
   else
      return kSAI;
}
