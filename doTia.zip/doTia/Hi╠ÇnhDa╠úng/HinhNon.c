#include "HinhNon.h"
#include "../HangSo.h"
#include <math.h>


#pragma mark ---- Hình Nón
HinhNon datHinhNon( float banKinhDuoi, float banKinhTren, float beCao, BaoBi *baoBi ) {
   
   HinhNon hinhNon;
   
   hinhNon.banKinhDuoi = banKinhDuoi;
   hinhNon.banKinhTren = banKinhTren;
   hinhNon.beCao = beCao;
   
   // ---- cần bán kín lớn nhất cho bao bì
   float banKinhLonNhat = banKinhDuoi > banKinhTren ? banKinhDuoi : banKinhTren;
   
   baoBi->gocCucTieu.x = -banKinhLonNhat;
   baoBi->gocCucDai.x = banKinhLonNhat;
   baoBi->gocCucTieu.y = -0.5f*beCao;
   baoBi->gocCucDai.y = 0.5f*beCao;
   baoBi->gocCucTieu.z = -banKinhLonNhat;
   baoBi->gocCucDai.z = banKinhLonNhat;
   
   return hinhNon;
}


// bán kính: B(y) = B_1 + (B_2 - B_1)/C (y - y_0 + C/2)
// B_1 bán kính 1   B_2 bán kính 2   C bề cao
// cộng thức: (x - x_0)^2 + (z - z_0)^2 = B(y)^2
// Thử kiếm điểm gần nhất cắt nắp hình nón nếu có, xong
// thử kiếm điểm gần nhất cắt mặt nghiêng hình nón nếu có
// Xong rồi gởi lại điểm nào gần nhất của nắp hay mặt
float xemCatHinhNon( HinhNon *hinhNon, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung ) {
   
   // ==== KIẾM NGHIỆM NẮP
   float nghiemGanNhatNap = kVO_CUC;
   Vecto phapTuyenGanNhatNap;   // pháp tuyến gần nhật cho nắp trên
   
   Vecto phapTuyenNapTren;   // pháp tuyến cho nắp trên
   Vecto phapTuyenNapDuoi;   // pháp tuyến cho nắp dưới
   
   float nuaBeCao = hinhNon->beCao*0.5f;
   
   // ---- nếu có nghiệm nó phải ở trng phạm vị này
   float nghiemNapTren = kVO_CUC;
   float nghiemNapDuoi = kVO_CUC;
   
   if( tia->huong.y != 0.0f ) {  // ---- không thể cắt mặt trên hay dưới nếu tia không có thành phân y (lên/xuống)
      nghiemNapTren = (nuaBeCao - tia->goc.y)/tia->huong.y;
      nghiemNapDuoi = (-nuaBeCao - tia->goc.y)/tia->huong.y;
      
      if( nghiemNapTren > 0.01f ) { // chỉ được cắt nắp trên nếu hướng tia < 0
         diemTrung->x = tia->goc.x + nghiemNapTren*tia->huong.x;
         diemTrung->y = tia->goc.y + nghiemNapTren*tia->huong.y;
         diemTrung->z = tia->goc.z + nghiemNapTren*tia->huong.z;
         //         printf( "xemCatHinhNon: banKinhTrenBinh %5.3f\n", hinhNon->banKinhTren*hinhNon->banKinhTren );
         if( (diemTrung->x*diemTrung->x + diemTrung->z*diemTrung->z) < hinhNon->banKinhTren*hinhNon->banKinhTren ) {
            //            printf( "xemCatHinhNon: trungNapTren %5.3f\n", nghiemNapTren );
            phapTuyenNapTren.x = 0.0f;
            phapTuyenNapTren.y = 1.0f;
            phapTuyenNapTren.z = 0.0f;
         }
         else
            nghiemNapTren = kVO_CUC;
      }
      else
         nghiemNapTren = kVO_CUC;
      
      if( nghiemNapDuoi > 0.01f ) { // chỉ được cắt nắp trên nếu hướng tia < 0
         diemTrung->x = tia->goc.x + nghiemNapDuoi*tia->huong.x;
         diemTrung->y = tia->goc.y + nghiemNapDuoi*tia->huong.y;
         diemTrung->z = tia->goc.z + nghiemNapDuoi*tia->huong.z;
         //        printf( "xemCatHinhNon: banKinhDuoiBinh %5.3f\n", hinhNon->banKinhDuoi*hinhNon->banKinhDuoi );
         if( (diemTrung->x*diemTrung->x + diemTrung->z*diemTrung->z) < hinhNon->banKinhDuoi*hinhNon->banKinhDuoi ) {
            //           printf( "xemCatHinhNon: trungNapDuoi %5.3f\n", nghiemNapDuoi );
            phapTuyenNapDuoi.x = 0.0f;
            phapTuyenNapDuoi.y = -1.0f;
            phapTuyenNapDuoi.z = 0.0f;
         }
         else
            nghiemNapDuoi = kVO_CUC;
      }
      else
         nghiemNapDuoi = kVO_CUC;
      
   }
   // ---- giữ nghệm gần nhất
   if( nghiemNapDuoi < nghiemNapTren ) {
      nghiemGanNhatNap = nghiemNapDuoi;
      phapTuyenGanNhatNap = phapTuyenNapDuoi;
   }
   else {
      nghiemGanNhatNap = nghiemNapTren;
      phapTuyenGanNhatNap = phapTuyenNapTren;
   }
   
 //  printf( "xemCatHinhNon: nghiemGanNhatNap %5.3f nghiemNapTren %5.3f napDuoi %5.3f\n", nghiemGanNhatNap, nghiemNapTren, nghiemNapDuoi );
//   printf( "xemCatHinhNon: phapTuyenGanNhatNap %5.3f %5.3f %5.3f\n", phapTuyenGanNhatNap.x, phapTuyenGanNhatNap.y, phapTuyenGanNhatNap.z );
   
   // ==== KIẾM NGHIỆM MẶT
   float nghiemGanNhatMat = kVO_CUC;
   
   // ---- tính trị số dốc
   float triSoDoc = (hinhNon->banKinhTren - hinhNon->banKinhDuoi)/hinhNon->beCao;
   // ---- tính vectơ từ trung tâm hình cầu đến điểm nhìn
   Vecto huongDenHinhNon;   // hướng đến trung tâm hình trụ
   huongDenHinhNon.x = tia->goc.x;
   huongDenHinhNon.y = (tia->goc.y + nuaBeCao)*triSoDoc + hinhNon->banKinhDuoi;
   huongDenHinhNon.z = tia->goc.z;
   
   float A = tia->huong.x*tia->huong.x - tia->huong.y*tia->huong.y*triSoDoc*triSoDoc + tia->huong.z*tia->huong.z;
   float B = 2.0f*(tia->huong.x*huongDenHinhNon.x - tia->huong.y*triSoDoc*huongDenHinhNon.y + tia->huong.z*huongDenHinhNon.z);
   float C = huongDenHinhNon.x*huongDenHinhNon.x + huongDenHinhNon.z*huongDenHinhNon.z - huongDenHinhNon.y*huongDenHinhNon.y;
   float D = B*B - 4.0f*A*C;
   
   if( D > 0.0f ) {
      // ---- tính nghiệm và nghiệm gần nhất, xài giải thuật chính xác hơn
      float Q;
      if( B < 0.0f )
         Q = -0.5f*(B - sqrtf(D) );
      else
         Q = -0.5f*(B + sqrtf(D) );
      
      float nghiemMat0 = Q/A;
      float nghiemMat1 = C/Q;
//      printf( "xemCatHinhNon: nghiemMat %5.3f  %5.3f\n", nghiemMat0, nghiemMat1 );
      
      // ---- coi trừng nghiệm âm và khác không vỉ tia coi thể bắt đẩu tại mặt của hình cầu
      if( nghiemMat0 < 0.01f )
         nghiemMat0 = kVO_CUC;
      if( nghiemMat1 < 0.01f )
         nghiemMat1 = kVO_CUC;
      
      // ---- xem tia cắt mặt trong phạm vi hình non
      if( nghiemMat0 < kVO_CUC ) {
         float diemTrung0Y = tia->goc.y + nghiemMat0*tia->huong.y;
         
         if( diemTrung0Y > nuaBeCao )
            nghiemMat0 = kVO_CUC;
         else if( diemTrung0Y < -nuaBeCao )
            nghiemMat0 = kVO_CUC;
      }
      
      if( nghiemMat1 < kVO_CUC ) {
         float diemTrung1Y = tia->goc.y + nghiemMat1*tia->huong.y;
         if( diemTrung1Y > nuaBeCao )
            nghiemMat1 = kVO_CUC;
         else if( diemTrung1Y < -nuaBeCao )
            nghiemMat1 = kVO_CUC;
      }
      
      // ---- gởi lại nghiệm nhỏ nhất mà dương
      if( nghiemMat0 < nghiemMat1 ) {
         nghiemGanNhatMat = nghiemMat0;
      }
      else {
         nghiemGanNhatMat = nghiemMat1;

      }
      
   }
//   printf( "xemCatHinhNon: nghiemGanNhatMat %5.3f  nghiemGanNhatNap %5.3f\n", nghiemGanNhatMat, nghiemGanNhatNap );
   
   // ---- kiểm tra điểm gần nhất
   float nghiemGanNhat = kVO_CUC;
   
   if( nghiemGanNhatMat < nghiemGanNhatNap ) {
      nghiemGanNhat = nghiemGanNhatMat;
      // ---- vectơ vuông góc cho phát tia tiếp
      diemTrung->x = tia->goc.x + nghiemGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + nghiemGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + nghiemGanNhat*tia->huong.z;
      phapTuyen->x = diemTrung->x;
      phapTuyen->y = -(hinhNon->banKinhTren + triSoDoc*(diemTrung->y - nuaBeCao))*triSoDoc;
      phapTuyen->z = diemTrung->z;
      
      donViHoa( phapTuyen );
   }
   else if(nghiemGanNhatNap < nghiemGanNhatMat ) {
      nghiemGanNhat = nghiemGanNhatNap;
      // ---- vectơ vuông góc cho phát tia tiếp
      diemTrung->x = tia->goc.x + nghiemGanNhat*tia->huong.x;
      diemTrung->y = tia->goc.y + nghiemGanNhat*tia->huong.y;
      diemTrung->z = tia->goc.z + nghiemGanNhat*tia->huong.z;
      phapTuyen->x = phapTuyenGanNhatNap.x;
      phapTuyen->y = phapTuyenGanNhatNap.y;
      phapTuyen->z = phapTuyenGanNhatNap.z;
      
      donViHoa( phapTuyen );
   }
   
   
//   printf( "++xemCatHinhNon: phapTuyen %5.3f %5.3f %5.3f\n", phapTuyen->x, phapTuyen->y, phapTuyen->z );
//   printf( "++xemCatHinhNon: nghiemGanNhat %5.3f\n", nghiemGanNhat );
   
   // ---- kết qủa
   return nghiemGanNhat;
}


unsigned char xemDiemTrongHinhNon( HinhNon *hinhNon, Vecto *diem ) {
   
   unsigned char diemTrong = kDUNG;
   // ---- tính trị số dốc
   
   float nuaBeCao = hinhNon->beCao*0.5f;
   float triSoDoc = (hinhNon->banKinhTren - hinhNon->banKinhDuoi)/hinhNon->beCao;
   // ---- bán kín: B(y) = B_1 + (B_2 - B_1)/C (y + C/2)   y tương đối với tâm hình nón
   float banKinh = hinhNon->banKinhDuoi + triSoDoc*(diem->y + nuaBeCao);
   
   if( diem->x*diem->x + diem->z*diem->z > banKinh*banKinh )
      diemTrong = kSAI;
   
   if( diemTrong ) {
      if( diem->y < -nuaBeCao )
         diemTrong = kSAI;
      else if( diem->y > nuaBeCao )
         diemTrong = kSAI;
   }
//   printf( "xemTrongHinhNon %d   diem %5.3f %5.3f %5.3f\n", diemTrong, diem->x, diem->y, diem->z );
   return diemTrong;
}
