#pragma once

#include "TamGiac.h"
#include "../XemCat/BaoBi.h"
#include "../Toán/Vecto.h"


typedef struct {
   Vecto mangDinh[6];   // mảng đỉnh
   TamGiac mangTamGiac[8];  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} Doc;

Doc datDoc( float beRong, float beCao, float beDai, BaoBi *baoBiVT );  // đặt dốc