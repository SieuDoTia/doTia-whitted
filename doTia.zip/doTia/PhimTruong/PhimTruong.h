#pragma once

#include "../VatThe/MayQuayPhim.h"
#include "../VatThe/MatTroi.h"
#include "../VatThe/VatThe.h"
#include "../XemCat/BaoBi.h"
#include "../HoaTiet/HoaTietBauTroi.h"
#include "../HangSo.h"


typedef struct {
   unsigned short so;                   // số phim trường

   unsigned char moTa[256];            // mô tả phim trường
   MayQuayPhim mayQuayPhim;            // máy quay phim
   VatThe *danhSachVatThe;             // danh sách vật thể
   unsigned short mangChiSoVatTheSapXep[kSO_LUONG_VAT_THE_TOI_DA];       // mảng chỉ số vật thể
   // xài cho được đổi thứ tự vật thể khi tạo cây tầng bậc mà không đổi vị trí trong mảngVậtThể vì chỉ số cho vật thể cần nâng cấp hoạt hình sẽ không cấp vật thể không đúng.

   unsigned short nhanVat[128];        // mảng nhân vật (chỉ số vật thể hoạt động)
   unsigned short soLuongVatThe;       // số lượng vật thể
   unsigned short soLuongVatTheHoatHinh; // số lượng vật thể hoạt hình
   
   unsigned short soHoatHinhDau;     // số hoạt hình đầu, xài cho quản lý hoạt hình
   unsigned short soHoatHinhHienTai; // số hoạt hình hiện tại, xài cho quản lý hoạt hình
   unsigned short soHoatHinhCuoi;    // số hoạt hình cuối, xài cho quản lý hoạt hình
   
   unsigned char soNhoiToiDa;   // số nhồi tối đa

   BaoBi baoBi;      // bao bì cho phim trường
   MatTroi matTroi;
   HoaTietBauTroi hoaTietBauTroi;   // họa tiết bầu trời, cho tô màu trời

} PhimTruong;
