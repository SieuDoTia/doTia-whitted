#include "PhimTruong.h"

PhimTruong datPhimTruongSoTN( unsigned int argc, char **argv );
void nangCapPhimTruongTN( PhimTruong *phimTruong );