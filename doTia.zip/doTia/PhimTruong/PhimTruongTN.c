#include "PhimTruongTN.h"
#include "../DocThamSo.h"
#include "../Toan/BienHoa.h"
//#include "../Mau.h"
#include <stdlib.h>

#pragma mark ---- PHIM TRƯỜNG THỬ NGHIỆM
void chuanBiMayQuayPhimVaMatTroiPhimTruongTN( PhimTruong *phimTruong );
unsigned short chuanBiLapPhuong_HinhCau5x5x5( VatThe *danhSachVat );
unsigned short chuanBiLapPhuong_LapPhuong5x5x5( VatThe *danhSachVat );
unsigned short datDayMatPhang( VatThe *danhSachVat, unsigned short soLuongMatPhang, Vecto *viTri, Vecto *dich, unsigned char huong,
                              float cachGiua, float beRong, float beCao, float beDai, Mau *mau );
unsigned short chuanBiHinhNon( VatThe *danhSachVat );
unsigned short thuHoaTiet_caoRoSauMau( VatThe *danhSachVat );

void nangCapPhimTruongTN_mayQuayPhim( PhimTruong *phimTruong );
void nangCapPhimTruongTN_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh );
void nangCapNhomMatPhangY( VatThe *danhSachVat, unsigned short soHoatHinh );
void nangCapNhomMatPhangX( VatThe *danhSachVat, unsigned short soHoatHinh );


#define kNHAN_VAT__NHOM_MAT_PHANG_Y 3
#define kNHAN_VAT__NHOM_MAT_PHANG_X 4

// ---- nên dùng số chẵn néu số lớp lập phương hình cầu là lẻ
#define kSO_LUONG__MAT_PHANG_Y 12
#define kSO_LUONG__MAT_PHANG_X 14


#define kVAN_TOC__MAT_PHANG 2.0f


PhimTruong datPhimTruongSoTN( unsigned int argc, char **argv ) {
   
   PhimTruong phimTruong;
   phimTruong.soNhoiToiDa = 5;
   
   unsigned int soHoatHinhDau = 0;
   unsigned int soHoatHinhCuoi = 769;     // số bức ảnh cuối cho phim trường này
   
   docThamSoHoatHinh( argc, argv, &soHoatHinhDau, &soHoatHinhCuoi );
 //  if( soHoatHinhDau < 10 )
 //    soHoatHinhDau = 10;
   if( soHoatHinhCuoi > 793 )     // số bức ảnh cuối cho phim trường này
      soHoatHinhCuoi = 793;
   
   phimTruong.soHoatHinhDau = soHoatHinhDau;
   phimTruong.soHoatHinhHienTai = soHoatHinhDau;
   phimTruong.soHoatHinhCuoi = soHoatHinhCuoi;
   
   phimTruong.soLuongVatThe = 0;
   phimTruong.danhSachVatThe = malloc( kSO_LUONG_VAT_THE_TOI_DA*sizeof(VatThe) );
   
   // ---- chuẩn bị máy quay phim
   chuanBiMayQuayPhimVaMatTroiPhimTruongTN( &phimTruong );
   Mau mauChanTroiTay;
   Mau mauChanTroiDong;
   Mau mauDayTroi;
   Mau mauDinhTroi;
   
   // ---- đấy và đỉnh
   mauDayTroi.d = 0.85f;  mauDayTroi.l = 0.85f;   mauDayTroi.x = 0.85f;    mauDayTroi.dd = 1.0f;
   mauDinhTroi.d = 0.85f;  mauDinhTroi.l = 0.85f;   mauDinhTroi.x = 0.85f;    mauDinhTroi.dd = 1.0f;
   
   // ---- chân trời
   mauChanTroiTay.d = 0.85f;   mauChanTroiTay.l = 0.85f;   mauChanTroiTay.x = 0.85f;   mauChanTroiTay.dd = 1.0f;
   mauChanTroiDong.d = 0.85f;   mauChanTroiDong.l = 0.85f;   mauChanTroiDong.x = 0.85f;   mauChanTroiDong.dd = 1.0f;

   phimTruong.hoaTietBauTroi = datHoaTietBauTroi( &mauDayTroi, &mauDinhTroi, &mauChanTroiTay, &mauChanTroiDong, 0.0f );
   
   VatThe *danhSachVat = phimTruong.danhSachVatThe;
   
   // ---- đặt vất thể trong phim trường
   phimTruong.soLuongVatThe = chuanBiLapPhuong_HinhCau5x5x5( &(danhSachVat[phimTruong.soLuongVatThe]) );
   
   // ---- đặt các mặt phẳng
   float banKinhHinhCau = 0.3f;
   float cachGiua = 1.5f;

   Mau mauMatPhang;
   mauMatPhang.d = 1.0f;   mauMatPhang.l = 1.0f;   mauMatPhang.x = 1.0f;   mauMatPhang.dd = 1.0f;   mauMatPhang.p = 0.0f;

   Vecto dich;
   dich.x = -5.0f;
   dich.y = -5.0f;
   dich.z = -5.0f;
   
   // ----
   Vecto viTriMatPhang;
   viTriMatPhang.x = -192.0f;   viTriMatPhang.y = 0.0f;   viTriMatPhang.z = 6.0f;
   phimTruong.nhanVat[kNHAN_VAT__NHOM_MAT_PHANG_Y] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datDayMatPhang( &(danhSachVat[phimTruong.soLuongVatThe]), kSO_LUONG__MAT_PHANG_Y,
                                              &viTriMatPhang, &dich, kTRUC_Y, 3.0f, 200.0f, 0.1f, 2.0f, &mauMatPhang );
   // ----
   viTriMatPhang.x = 0.0f;   viTriMatPhang.y = -192.0f;   viTriMatPhang.z = 6.0f;
   phimTruong.nhanVat[kNHAN_VAT__NHOM_MAT_PHANG_X] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datDayMatPhang( &(danhSachVat[phimTruong.soLuongVatThe]), kSO_LUONG__MAT_PHANG_X,
                                              &viTriMatPhang, &dich, kTRUC_X, 3.0f, 0.1f, 200.0f, 2.0f, &mauMatPhang );

   // ---- nâng cấp mô phỏng cho các trái banh và nhân vật
   unsigned short soHoatHinh = 0;
   while ( soHoatHinh < phimTruong.soHoatHinhDau ) {
      nangCapPhimTruongTN_nhanVat( &phimTruong, soHoatHinh );
      soHoatHinh++;
   }

   return phimTruong;
}

void chuanBiMayQuayPhimVaMatTroiPhimTruongTN( PhimTruong *phimTruong ) {
   
   // ==== máy quay phim
   phimTruong->mayQuayPhim.kieuChieu = kKIEU_CHIEU__TOAN_CANH;
   // ---- vị trí bắt đầu cho máy quay phim
   phimTruong->mayQuayPhim.viTri.x = 0.0f;
   phimTruong->mayQuayPhim.viTri.y = 0.0f;
   phimTruong->mayQuayPhim.viTri.z = 10.0f;
   phimTruong->mayQuayPhim.cachManChieu = 5.0f;
   Vecto trucQuayMayQuayPhim;
   trucQuayMayQuayPhim.x = 0.0f;
   trucQuayMayQuayPhim.y = 1.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, 3.14159f );
   quaternionSangMaTran( &quaternion, phimTruong->mayQuayPhim.xoay );
   
   // ---- mặt trời
   Vecto anhSangMatTroi;
   anhSangMatTroi.x = -1.0f;
   anhSangMatTroi.y = -1.0f;
   anhSangMatTroi.z = -0.5f;
   donViHoa( &anhSangMatTroi );
   phimTruong->matTroi.huongAnh = anhSangMatTroi;
   phimTruong->matTroi.mauAnh.d = 1.0f;
   phimTruong->matTroi.mauAnh.l = 1.0f;
   phimTruong->matTroi.mauAnh.x = 1.0f;
   phimTruong->matTroi.mauAnh.dd = 1.0f;
}

#pragma mark ---- CÁC THỬ NGHIỆM
unsigned short chuanBiLapPhuong_HinhCau5x5x5( VatThe *danhSachVat ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- màu
   Mau mauHinhCau;
   mauHinhCau.d = 1.0f;   mauHinhCau.l = 0.0f;   mauHinhCau.x = 0.0f;
   mauHinhCau.dd = 1.0f;    mauHinhCau.p = 0.05f;
   // ----
   Vecto viTri;
   viTri.x = -6.0f;    viTri.y = -6.0f;     viTri.z = 6.0f;
   
   unsigned short soLuongVat = 0;

   unsigned char soLop = 0;
   
   while( soLop < 5 ) {
      viTri.y = -6.0f;
      
      unsigned char soHang = 0;
      while( soHang < 5 ) {
         viTri.x = -6.0f;
         
         unsigned char soCot = 0;
         while( soCot < 5 ) {
            danhSachVat[soLuongVat].hinhDang.hinhCau = datHinhCau( 1.0f, &(danhSachVat[soLuongVat].baoBiVT));
            danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_CAU;
            danhSachVat[soLuongVat].chietSuat = 1.0f;
            datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
            danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauHinhCau );
            danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
            soLuongVat++;
            
            viTri.x += 3.0f;
            soCot++;
         }
         viTri.y += 3.0f;
         soHang++;
      }
      viTri.z -= 3.0f;
      soLop++;
      
      // ----
      if( soLop == 1 ) {
         mauHinhCau.d = 1.0f;   mauHinhCau.l = 0.5f;
      }
      else if( soLop == 2 ) {
         mauHinhCau.d = 1.0f;   mauHinhCau.l = 1.0f;
      }
      else if( soLop == 3 ) {
         mauHinhCau.d = 0.5f;   mauHinhCau.l = 1.0f;
      }
      else if( soLop == 4 ) {
         mauHinhCau.d = 0.0f;   mauHinhCau.l = 1.0f;
      }
   }

   return soLuongVat;
}

// ---- cho chiếu phối cảnh: 4096 x 2160  0.0043    (768 x 405  0.023)
// ---- cho chiếu toàn cảnh: 4096 x 2160  0.00070   (768 x 405  0.0037)
// ---- cho chiếu trực giao: 4096 x 2160  0.00788   (768 x 405  0.042)
unsigned short chuanBiLapPhuong_LapPhuong5x5x5( VatThe *danhSachVat ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- màu
   Mau mauLapPhuong;
   mauLapPhuong.d = 0.0f;   mauLapPhuong.l = 0.0f;   mauLapPhuong.x = 0.0f;
   mauLapPhuong.dd = 1.0f;    mauLapPhuong.p = 0.05f;
   
   float buocMau = 0.2f;
   
   // ----
   Vecto viTri;
   viTri.x = -6.0f;    viTri.y = -6.0f;     viTri.z = 6.0f;
   
   unsigned short soLuongVat = 0;
   
   unsigned char soLop = 0;
   
   while( soLop < 5 ) {
      viTri.y = -6.0f;
      mauLapPhuong.l = 0.0f;
      
      unsigned char soHang = 0;
      while( soHang < 5 ) {
         viTri.x = -6.0f;
         mauLapPhuong.x = 0.0f;
         
         unsigned char soCot = 0;
         while( soCot < 5 ) {
            danhSachVat[soLuongVat].hinhDang.hop = datHop( 1.4f, 1.4f, 1.4f, &(danhSachVat[soLuongVat].baoBiVT));
            danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
            danhSachVat[soLuongVat].chietSuat = 1.0f;
            datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
            danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauLapPhuong );
            danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
            soLuongVat++;
            
            viTri.x += 3.0f;
            soCot++;
            mauLapPhuong.x += buocMau;
         }
         viTri.y += 3.0f;
         soHang++;
         mauLapPhuong.l += buocMau;
      }
      viTri.z -= 3.0f;
      soLop++;
      mauLapPhuong.d += buocMau;
   }

   return soLuongVat;
}

unsigned short thuHoaTiet_caoRoSauMau( VatThe *danhSachVat ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- màu
   Mau mau0_x;
   Mau mau1_x;
   Mau mau0_y;
   Mau mau1_y;
   Mau mau0_z;
   Mau mau1_z;
   mau0_x.d = 0.0f;   mau0_x.l = 0.0f;   mau0_x.x = 1.0f;    mau0_x.dd = 1.0f;    mau0_x.p = 0.00f;
   mau1_x.d = 0.0f;   mau1_x.l = 0.0f;   mau1_x.x = 0.5f;    mau1_x.dd = 1.0f;    mau1_x.p = 0.00f;
   mau0_y.d = 0.0f;   mau0_y.l = 1.0f;   mau0_y.x = 0.0f;    mau0_y.dd = 1.0f;    mau0_y.p = 0.00f;
   mau1_y.d = 0.0f;   mau1_y.l = 0.5f;   mau1_y.x = 0.0f;    mau1_y.dd = 1.0f;    mau1_y.p = 0.00f;
   mau0_z.d = 1.0f;   mau0_z.l = 0.0f;   mau0_z.x = 0.0f;    mau0_z.dd = 1.0f;    mau0_z.p = 0.00f;
   mau1_z.d = 0.5f;   mau1_z.l = 0.0f;   mau1_z.x = 0.0f;    mau1_z.dd = 1.0f;    mau1_z.p = 0.00f;

   // ----
   Vecto viTri;
   viTri.x = -4.0f;    viTri.y = -4.0f;     viTri.z = 0.0f;
   
   unsigned short soLuongVat = 0;

   danhSachVat[soLuongVat].hinhDang.hop = datHop( 5.0f, 5.0f, 5.0f, &(danhSachVat[soLuongVat].baoBiVT));
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRoSauMau = datHoaTietCaRoSauMau( &mau0_x, &mau1_x, &mau0_y, &mau1_y, &mau0_z, &mau1_z, 0.5f, 0.5f,0.5f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO_SAU_MAU;
   soLuongVat++;
   
   return soLuongVat;
}

unsigned short datDayMatPhang( VatThe *danhSachVat, unsigned short soLuongMatPhang,  Vecto *viTri, Vecto *dich,
                  unsigned char huong, float cachGiua, float beRong, float beCao, float beDai, Mau *mau ) {

   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   float viTriDau;
   if( soLuongMatPhang & 0x01 )
      viTriDau = cachGiua*(soLuongMatPhang >> 1);
   else
      viTriDau = cachGiua*((float)(soLuongMatPhang >> 1) - 0.5f);
   
   Vecto viTriMatPhang;
   if( huong == kTRUC_X ) {
      viTriMatPhang.x = viTri->x - viTriDau;
      viTriMatPhang.y = viTri->y;
      viTriMatPhang.z = viTri->z;
   }
   else if( huong == kTRUC_Y ) {
      viTriMatPhang.x = viTri->x;
      viTriMatPhang.y = viTri->y - viTriDau;
      viTriMatPhang.z = viTri->z;
   }
   else {  // if( huong == kTRUC_Z ) {
      viTriMatPhang.x = viTri->x;
      viTriMatPhang.y = viTri->y;
      viTriMatPhang.z = viTri->z - viTriDau;
   }

   unsigned short soLuongVat = 0;
   while( soLuongVat < soLuongMatPhang ) {
      danhSachVat[soLuongVat].hinhDang.hop = datHop( beRong, beCao, beDai, &(danhSachVat[soLuongVat].baoBiVT));
      danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVat].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTriMatPhang );
      danhSachVat[soLuongVat].hoaTiet.hoaTietKhong = datHoaTietKhong( mau );
      danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__KHONG;
//      printf( "ViTriMatPhang %5.3f %5.3f %5.3f\n", viTriMatPhang.x, viTriMatPhang.y, viTriMatPhang.z );
      
      if( huong == kTRUC_X ) {
         viTriMatPhang.x += cachGiua;
         viTriMatPhang.y += dich->z;
      }
      else if( huong == kTRUC_Y ) {
         viTriMatPhang.y += cachGiua;
         viTriMatPhang.x += dich->x;
      }
      else { // if( huong == kTRUC_Z )
         viTriMatPhang.z += cachGiua;
         viTriMatPhang.y += dich->x;
      }
         
      soLuongVat++;
   }
   
   return soLuongVat;
}


// cho phim trường 2
unsigned short chuanBiHinhNon( VatThe *danhSachVat ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 1.0f;    vectoXoay.y = 0.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- màu
   Mau mauNen;
   mauNen.d = 1.0f;    mauNen.l = 1.0f;    mauNen.x = 1.0f;    mauNen.dd = 1.0f;   mauNen.p = 0.1f;
   
   Mau mauOc0;
   mauOc0.d = 1.0f;    mauOc0.l = 0.75f;    mauOc0.x = 0.39f;    mauOc0.dd = 1.0f;   mauOc0.p = 0.1f;
   
   Mau mauOc1;
   mauOc1.d = 1.0f;    mauOc1.l = 0.26f;    mauOc1.x = 0.26f;    mauOc1.dd = 1.0f;   mauOc1.p = 0.1f;
   
   Mau mauOc2;
   mauOc2.d = 1.00f;    mauOc2.l = 0.06f;    mauOc2.x = 0.77f;    mauOc2.dd = 1.0f;   mauOc2.p = 0.1f;

   // ----
   Vecto viTri;
   viTri.x = 0.0f;    viTri.y = 0.0f;     viTri.z = 0.0f;

   unsigned short soLuongVat = 0;

   danhSachVat[soLuongVat].hinhDang.hinhNon = datHinhNon( 3.0f, 1.0, 3.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen, &mauOc0, &mauOc1, &mauOc2, 0.15f, 0.15f, 0.15f, 2.0f, 0.0f, 1 );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__QUAN_XOAY;
   soLuongVat++;
   
   return soLuongVat;
}


#pragma mark ---- NÂNG CẤP PHIM TRƯỜNG TN
void nangCapPhimTruongTN( PhimTruong *phimTruong ) {
   
   //   printf( "phimTruong->soHoatHinhDau; %d\n", phimTruong->soHoatHinhDau );
   nangCapPhimTruongTN_mayQuayPhim( phimTruong );
   nangCapPhimTruongTN_nhanVat( phimTruong, phimTruong->soHoatHinhDau );
   
   // ---- tăng số hoạt hình
   phimTruong->soHoatHinhDau++;
}


void nangCapPhimTruongTN_mayQuayPhim( PhimTruong *phimTruong ) {
   
   Vecto viTriMatQuayPhim;
   MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);

   unsigned short soHoatHinh = phimTruong->soHoatHinhDau;
   
   float buocGoc = 3.14159f/96.0f;
   float cachXaMayQuayPhim = 16.0f;
   Vecto huongNhin;
   
   // ---- máy quay phim đi lui
   if( soHoatHinh < 48 ) {
      // ---- vị trí - di chuyển từ 10.0f đến cachXaMayQuayPhim
      mayQuayPhim->viTri.y = 0.0f;
      mayQuayPhim->viTri.x = 0.0f;
      mayQuayPhim->viTri.z = 8.0f + soHoatHinh*0.16666666667f;
      
      // ---- hướng nhìn
      huongNhin.x = 0.0;
      huongNhin.y = 0.0f;
      huongNhin.z = -1.0f;
   }
   // ---- các mặt phẳng trục Y di chuyển vào 
   else if( soHoatHinh < 408 ) {
      // ---- vị trí
      mayQuayPhim->viTri.y = 0.0f;
      mayQuayPhim->viTri.x = 0.0f;
      mayQuayPhim->viTri.z = cachXaMayQuayPhim;
      
      // ---- hướng nhìn
      huongNhin.x = 0.0;
      huongNhin.y = 0.0f;
      huongNhin.z = -1.0f;
   }
   // ---- đi vòng lập phương
   else if( soHoatHinh < 600 ) {
      float goc = (soHoatHinh - 408)*buocGoc;
      float cosGoc = cosf( goc );
      float sinGoc = sinf( goc );
      
      // ---- vị trí
      mayQuayPhim->viTri.y = 0.0f;
      mayQuayPhim->viTri.x = cachXaMayQuayPhim*sinGoc;
      mayQuayPhim->viTri.z = cachXaMayQuayPhim*cosGoc;
      
      // ---- hướng nhìn
      huongNhin.x = -sinGoc;
      huongNhin.y = 0.0f;
      huongNhin.z = -cosGoc;
   }
   else if( soHoatHinh < 792 ) {
      float goc = (soHoatHinh - 600)*buocGoc;
      float cosGoc = cosf( goc );
      float sinGoc = sinf( goc );
      
      Vecto viTriMatQuayPhim;
      viTriMatQuayPhim.y = sinGoc;
      viTriMatQuayPhim.x = sinGoc;
      viTriMatQuayPhim.z = cosGoc;
      donViHoa( &viTriMatQuayPhim);

      // ---- vị trí
      mayQuayPhim->viTri.y = cachXaMayQuayPhim*viTriMatQuayPhim.y;
      mayQuayPhim->viTri.x = cachXaMayQuayPhim*viTriMatQuayPhim.x;
      mayQuayPhim->viTri.z = cachXaMayQuayPhim*viTriMatQuayPhim.z;
      
      // ---- hướng nhìn
      huongNhin.x = -viTriMatQuayPhim.x;
      huongNhin.y = -viTriMatQuayPhim.y;
      huongNhin.z = -viTriMatQuayPhim.z;
   }
   else {
      mayQuayPhim->viTri.y = 0.0f;
      mayQuayPhim->viTri.x = 0.0f;
      mayQuayPhim->viTri.z = cachXaMayQuayPhim;
      
      // ---- hướng nhìn
      huongNhin.x = 0.0f;
      huongNhin.y = 0.0f;
      huongNhin.z = -1.0f;
   }
   
   dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
}

void nangCapPhimTruongTN_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh ) {

   // ---- nhóm mặt phặng y
   nangCapNhomMatPhangY( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__NHOM_MAT_PHANG_Y]]), soHoatHinh );
   nangCapNhomMatPhangX( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__NHOM_MAT_PHANG_X]]), soHoatHinh );
  
   // ---- bỏ hai nhóm mặt phẳng trước khi đi quanh lập phương
   if( soHoatHinh == 408 ) {
      phimTruong->soLuongVatThe = phimTruong->nhanVat[kNHAN_VAT__NHOM_MAT_PHANG_Y];
   }

}

void nangCapNhomMatPhangY( VatThe *danhSachVat, unsigned short soHoatHinh ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   if( soHoatHinh < 48 ) {
      ;  // nghỉ ngơi
   }
   else if( soHoatHinh < 144 ) {  // vào
   
      unsigned char chiSoMatPhang = 0;
      while( chiSoMatPhang < kSO_LUONG__MAT_PHANG_Y ) {
         // ---- tính vị trí mới
         Vecto viTri = viTriVatThe( &(danhSachVat[chiSoMatPhang]) );
         viTri.x += kVAN_TOC__MAT_PHANG;
         // ---- đặt vị trí mới
         datBienHoaChoVat( &(danhSachVat[chiSoMatPhang]), &phongTo, &quaternion, &viTri );
         chiSoMatPhang++;
      }
   }
   else if ( soHoatHinh < 240 ) {
      ;  // nghỉ ngơi
   }
   else if( soHoatHinh < 360 ) {  // ra

      unsigned char chiSoMatPhang = 0;
      while( chiSoMatPhang < kSO_LUONG__MAT_PHANG_Y ) {
         // ---- lấy vị trí hiện tại
         Vecto viTri = viTriVatThe( &(danhSachVat[chiSoMatPhang]) );
         viTri.x += kVAN_TOC__MAT_PHANG;
         // ---- đặt vị trí mới
         datBienHoaChoVat( &(danhSachVat[chiSoMatPhang]), &phongTo, &quaternion, &viTri );
         chiSoMatPhang++;
      }
   }
   else {
      ; // nghỉ ngơi
   }

}

void nangCapNhomMatPhangX( VatThe *danhSachVat, unsigned short soHoatHinh ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   if( soHoatHinh < 96 ) {
      ;  // nghỉ ngơi
   }
   else if( soHoatHinh < 192 ) {  // vào
      
      unsigned char chiSoMatPhang = 0;
      while( chiSoMatPhang < kSO_LUONG__MAT_PHANG_X ) {
         // ---- tính vị trí mới
         Vecto viTri = viTriVatThe( &(danhSachVat[chiSoMatPhang]) );
         viTri.y += kVAN_TOC__MAT_PHANG;
         // ---- đặt vị trí mới
         datBienHoaChoVat( &(danhSachVat[chiSoMatPhang]), &phongTo, &quaternion, &viTri );
         chiSoMatPhang++;
      }
   }
   else if ( soHoatHinh < 288 ) {
      ;  // nghỉ ngơi
   }
   else if( soHoatHinh < 408 ) {  // ra
      
      unsigned char chiSoMatPhang = 0;
      while( chiSoMatPhang < kSO_LUONG__MAT_PHANG_X ) {
         // ---- tính vị trí mới
         Vecto viTri = viTriVatThe( &(danhSachVat[chiSoMatPhang]) );
         viTri.y += kVAN_TOC__MAT_PHANG;
         // ---- đặt vị trí mới
         datBienHoaChoVat( &(danhSachVat[chiSoMatPhang]), &phongTo, &quaternion, &viTri );
         chiSoMatPhang++;
      }
   }
   else {
      ; // nghỉ ngơi
   }
}
