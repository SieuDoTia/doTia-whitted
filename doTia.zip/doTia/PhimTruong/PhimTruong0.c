#include "PhimTruong0.h"
#include "../HangSo.h"
#include "../NhanVat.h"
#include "../DocThamSo.h"
#include "../Toan/Bezier.h"
#include "../Toan/BienHoa.h"
#include "../XemCat/TinhBaoBi.h"
#include "../HoaTiet/HoaTiet.h"
#include <stdlib.h>


#pragma mark ---- PHIM TRƯỜNG 0
#define kNHAN_VAT__VAI_CHANH           0       // nhân vật vai chánh
#define kNHAN_VAT__SAO_GAI             1       // nhân vật sao gai
#define kNHAN_VAT__TRAI_BANH_BI_GIET   2  // nhân vật sao gai
#define kNHAN_VAT__KIEN_LONG_SAO_GAI_DO  3  // nhân vật kiến lồng sao gai đỏ
#define kNHAN_VAT__HAT_THUY_TINH_BAY   4  // nhân vật hạt thủy tinh bay
#define kNHAN_VAT__BAY_TRAI_BANH_DAU   5  // nhân vật bài trái banh đầu
#define kNHAN_VAT__BAY_TRAI_BANH_CUOI  6  // nhân vật bài trái banh cuối
#define kNHAN_VAT__BONG_BONG_DAU       7  // nhân vật bong bóng đầu
#define kNHAN_VAT__BONG_BONG_CUOI      8  // nhân vật bong bóng cuối
#define kNHAN_VAT__BAT_DIEN_XOAY_DAU   9  // nhân vật bong bóng đầu
#define kNHAN_VAT__BAT_DIEN_XOAY_CUOI 10  // nhân vật bong bóng cuối
#define kNHAN_VAT__COT_NHAY_DAU       11  // nhân vật hình trụ nhảy
#define kNHAN_VAT__COT_NHAY_CUOI      12  // nhân vật hình trụ nhảy
#define kNHAN_VAT__MAT_SONG           13  // nhân vật mặt sóng

// ---- hằng số
#define kTOC_DO_TRAI_BANH_PHIM_TRUONG0 0.5f
#define kBAN_KINH__VONG_NOI_BINH  95.0f  // bán kính vòng nội binh cho trái banh quanh vòng xoay   10.0
#define kBAN_KINH__VONG_NGOAI_BINH 190.0f   // bán kính vòng ngoại binh cho trái banh quanh vòng xoay 14,14

void chuanBiMayQuayPhimVaMatTroiPhimTruong0();

// ---- vật thể không chuyển động
unsigned short datMatBien( VatThe *danhSachVat );
unsigned short datCanhGocBoBien( VatThe *danhSachVatThe );
unsigned short datCotNghiengSauLongGai( VatThe *danhSachVatThe );
unsigned short datDuongLo( VatThe *danhSachVat );
unsigned short datLanCanDuongLo( VatThe *danhSachVat );

unsigned short datThapVongXoay( VatThe *danhSachVat );
unsigned short datDayCotQuangVongXoay( VatThe *danhSachVat );
unsigned short datLongSaoGaiDo( VatThe *danhSachVat );
unsigned short datVuonQuangDatLongSaoGaiDo( VatThe *danhSachVat );
unsigned short datLanCanNgoaiQuanhLongSaoGaiDo( VatThe *danhSachVat );
unsigned short datLanCanTrongQuanhLongSaoGaiDo( VatThe *danhSachVat );
unsigned short datBonThapVuonSaoGaiDo( VatThe *danhSachVat );
unsigned short datCacCotVuongLong( VatThe *danhSachVat );
unsigned short datKimTuThapThuyTinh( VatThe *danhSachVat );
unsigned short datDayHinhNonHuongX( VatThe *danhSachVat );
unsigned short datDayHinhNonHuongZ( VatThe *danhSachVat );

// ---- nhân vật (vật thể chuyển động)
unsigned short datKienLongSaoGaiDo( VatThe *danhSachVat );
unsigned short datHinhNonBayQuanhThap( VatThe *danhSachVat );
unsigned short datCacTraiBanhTrenLoHuongZ( VatThe *danhSachVat );
unsigned short datCacTraiBanhTrenLoHuongX( VatThe *danhSachVat );
unsigned short datTraiBanhBiGiet( VatThe *danhSachVat );
unsigned short datBongBong( VatThe *danhSachVat );
unsigned short datCacBatDienXoay( VatThe *danhSachVat );
unsigned short datCotNhay( VatThe *danhSachVat );

void moPhongTraiBanhGiaoThong( VatThe *danhSachVatThe, unsigned short soTraiBanhDau, unsigned short soTraiBanhCuoi, Vecto *viTriSaoGai );
void nangCapPhimTruong0_mayQuayPhim( PhimTruong *phimTruong );
void nangCapPhimTruong0_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh );
void nangCapVaiChanh( VatThe *vaiChanh, unsigned short soHoatHinh );
void nangCapSaoGaiDo( VatThe *saoGai, unsigned short soHoatHinh );
void nangCapTraiBanhBiGiet( VatThe *traiBanh, unsigned short soHoatHinh );
void nangCapKienLongSaoGaiDo( VatThe *kienLongSaoGai, unsigned short soHoatHinh );
void nangCapHatBayQuanhVongXoay( VatThe *vaiChanh, unsigned short soHoatHinh );
void nangCapBongBongBay( VatThe *danhSachBongBong, unsigned short soLuongVatThe, unsigned short soHoatHinh );
void nangCapCacBatDienXoay( VatThe *danhSachBatDien, unsigned short soLuongBatDien, unsigned short soHoatHinh );
void nangCapCotNhay( VatThe *danhSachBatDien, unsigned short soLuongBatDien, unsigned short soHoatHinh );
void nangCapMatSong( VatThe *matSong, unsigned short soHoatHinh );

Vecto vanTocChoViTriChoPhimTruong0( Vecto *viTri, unsigned char duongVao, unsigned char duongRa, unsigned char *thaiTrang, Vecto *trucXoay );
Vecto vanTocNeSaoGaiDoRaDuongZ( Vecto *viTriTraiBanh, unsigned char *thaiTrang, Vecto *trucXoay, Vecto *viTriSaoGai );
Vecto vanTocNeSaoGaiDoTrongVongXoay( Vecto *viTriTraiBanh, Vecto *trucXoay, float quangBinh );

#define kVI_TRI__VAI_CHANH_DAU_X  1.5f
#define kVI_TRI__VAI_CHANH_DAU_Y 10.8f
#define kVI_TRI__VAI_CHANH_DAU_Z -7.5f

PhimTruong datPhimTruongSo0( unsigned int argc, char **argv ) {
   
   PhimTruong phimTruong;
   phimTruong.soNhoiToiDa = 5;

   unsigned int soHoatHinhDau = 0;
   unsigned int soHoatHinhCuoi = 1520;     // số bức ảnh cuối cho phim trường này

   docThamSoHoatHinh( argc, argv, &soHoatHinhDau, &soHoatHinhCuoi );
   if( soHoatHinhDau > 1519 )
      soHoatHinhDau = 1519;
   if( soHoatHinhCuoi > 1520 )     // số bức ảnh cuối cho phim trường này
      soHoatHinhCuoi = 1520;
   
   phimTruong.soHoatHinhDau = soHoatHinhDau;
   phimTruong.soHoatHinhHienTai = soHoatHinhDau;
   phimTruong.soHoatHinhCuoi = soHoatHinhCuoi;
   
   phimTruong.soLuongVatThe = 0;
   phimTruong.danhSachVatThe = malloc( kSO_LUONG_VAT_THE_TOI_DA*sizeof(VatThe) );

   // ---- chuẩn bị máy quay phim
   chuanBiMayQuayPhimVaMatTroiPhimTruong0( &phimTruong );
   Mau mauDinhTroi;
   mauDinhTroi.d = 0.0f;   mauDinhTroi.l = 0.0f;   mauDinhTroi.x = 0.5f;   mauDinhTroi.dd = 1.0f;
   Mau mauChanTroi;  // chỉ có một;
   mauChanTroi.d = 0.7f;  mauChanTroi.l = 0.7f;   mauChanTroi.x = 1.0f;    mauChanTroi.dd = 1.0f;
   phimTruong.hoaTietBauTroi = datHoaTietBauTroi( &mauDinhTroi, &mauDinhTroi, &mauChanTroi, &mauChanTroi, 0.0f );

   VatThe *danhSachVat = phimTruong.danhSachVatThe;

   // ---- cảnh
   phimTruong.soLuongVatThe += datCanhGocBoBien( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datCotNghiengSauLongGai( &(danhSachVat[phimTruong.soLuongVatThe]) );

   phimTruong.soLuongVatThe += datDuongLo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datLanCanDuongLo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datThapVongXoay( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datDayCotQuangVongXoay( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- lồng sao gai
   phimTruong.soLuongVatThe += datLongSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datVuonQuangDatLongSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datLanCanNgoaiQuanhLongSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datLanCanTrongQuanhLongSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datBonThapVuonSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]) );

   // ---- kim tư tháp
   phimTruong.soLuongVatThe += datKimTuThapThuyTinh( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- dãy hình nón
   phimTruong.soLuongVatThe += datDayHinhNonHuongX( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datDayHinhNonHuongZ( &(danhSachVat[phimTruong.soLuongVatThe]) );

   // ---- CÁC NHÂN VẬT
   // sao gai
   // Cái sẽ bị hư gì hệ thống tăng tốc độ kết xuất sẽ đổi thứ tự vật thề <---------
   phimTruong.nhanVat[kNHAN_VAT__MAT_SONG] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datMatBien( &(danhSachVat[phimTruong.soLuongVatThe]) );

   phimTruong.nhanVat[kNHAN_VAT__SAO_GAI] = phimTruong.soLuongVatThe;
   Vecto viTri;
   viTri.x = -52.0f;      viTri.y = 27.5f;        viTri.z = -52.0f;
   phimTruong.soLuongVatThe += datKeThuSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   // ---- kiến long
   phimTruong.nhanVat[kNHAN_VAT__KIEN_LONG_SAO_GAI_DO] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datKienLongSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- hình nón bay quanh tháp
   phimTruong.nhanVat[kNHAN_VAT__HAT_THUY_TINH_BAY] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datHinhNonBayQuanhThap( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- bày trái banh
   phimTruong.nhanVat[kNHAN_VAT__BAY_TRAI_BANH_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datCacTraiBanhTrenLoHuongZ( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datCacTraiBanhTrenLoHuongX( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.nhanVat[kNHAN_VAT__BAY_TRAI_BANH_CUOI] = phimTruong.soLuongVatThe;

   // ---- vai chánh
   viTri.x = kVI_TRI__VAI_CHANH_DAU_X;  viTri.y = kVI_TRI__VAI_CHANH_DAU_Y; viTri.z = kVI_TRI__VAI_CHANH_DAU_Z;
   phimTruong.nhanVat[kNHAN_VAT__VAI_CHANH] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datVaiChanh( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   
   // ---- trái bị giết
   phimTruong.nhanVat[kNHAN_VAT__TRAI_BANH_BI_GIET] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datTraiBanhBiGiet( &(danhSachVat[phimTruong.soLuongVatThe]) );

   // ---- các bong bóng
   phimTruong.nhanVat[kNHAN_VAT__BONG_BONG_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datBongBong( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.nhanVat[kNHAN_VAT__BONG_BONG_CUOI] = phimTruong.soLuongVatThe;
   
   // ---- bát diận xoay
   phimTruong.nhanVat[kNHAN_VAT__BAT_DIEN_XOAY_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datCacBatDienXoay( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.nhanVat[kNHAN_VAT__BAT_DIEN_XOAY_CUOI] = phimTruong.soLuongVatThe;
   
   // ---- cột nhẩ quanh vòng xuyên
   phimTruong.nhanVat[kNHAN_VAT__COT_NHAY_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datCotNhay( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.nhanVat[kNHAN_VAT__COT_NHAY_CUOI] = phimTruong.soLuongVatThe;

   // ---- nâng cấp mô phỏng cho các trái banh và nhân vật
   unsigned short soHoatHinh = 0;
   while ( soHoatHinh < phimTruong.soHoatHinhDau ) {
      nangCapPhimTruong0_nhanVat( &phimTruong, soHoatHinh );
      soHoatHinh++;
   }

   return phimTruong;
}

void chuanBiMayQuayPhimVaMatTroiPhimTruong0( PhimTruong *phimTruong ) {
   
   // ==== máy quay phim
   phimTruong->mayQuayPhim.kieuChieu = kKIEU_CHIEU__PHOI_CANH;
   // ---- vị trí bắt đầu cho máy quay phim
   phimTruong->mayQuayPhim.viTri.x = 0.0f;
   phimTruong->mayQuayPhim.viTri.y = 3.0f;
   phimTruong->mayQuayPhim.viTri.z = 500.0f;
   phimTruong->mayQuayPhim.cachManChieu = 5.0f;
   Vecto trucQuayMayQuayPhim;
   trucQuayMayQuayPhim.x = 0.0f;
   trucQuayMayQuayPhim.y = 1.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   phimTruong->mayQuayPhim.quaternion = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, 3.1415926f );
   quaternionSangMaTran( &(phimTruong->mayQuayPhim.quaternion), phimTruong->mayQuayPhim.xoay );
   //   mayQuayPhim.diChuyen = ();
   
   // ---- mặt trời
   Vecto anhSangMatTroi;
   anhSangMatTroi.x = -1.0f;
   anhSangMatTroi.y = -1.0f;
   anhSangMatTroi.z = -0.5f;
   donViHoa( &anhSangMatTroi );
   phimTruong->matTroi.huongAnh = anhSangMatTroi;
   phimTruong->matTroi.mauAnh.d = 1.0f;
   phimTruong->matTroi.mauAnh.l = 1.0f;
   phimTruong->matTroi.mauAnh.x = 1.0f;
   phimTruong->matTroi.mauAnh.dd = 1.0f;
}

unsigned short datMatBien( VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   // ---- mặt biển
   Mau mauBien;
   mauBien.d = 0.5f;
   mauBien.l = 0.5f;
   mauBien.x = 0.5f;
   mauBien.dd = 1.0f;
   mauBien.p = 0.8f;
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   danhSachVat[0].hinhDang.matSong = datMatSong( 3000.0f, 3000.0f, 0.3f, 0.3f, 0.8f, 0.5f, 1.0f, 1.0f, -0.3f, 0.3f, kSAI, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__MAT_SONG;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauBien );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;

   viTri.z = -3000.0f;
   danhSachVat[1].hinhDang.matSong = datMatSong( 3000.0f, 3000.0f, 0.3f, 0.3f, 0.8f, 0.5f, 1.0f, 1.0f, -0.3f, 0.3f,kSAI, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__MAT_SONG;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauBien );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;

   return 2;
}

unsigned short datCanhGocBoBien( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== bờ đất
   Mau mauDat0;
   mauDat0.d = 0.2f;   mauDat0.l = 1.0f;   mauDat0.x = 0.2f;   mauDat0.dd = 1.0f;   mauDat0.p = 0.0f;
   Mau mauDat1;
   mauDat1.d = 0.5f;   mauDat1.l = 1.0f;   mauDat1.x = 0.5f;   mauDat1.dd = 1.0f;   mauDat1.p = 0.0f;

   unsigned short soLuongVat = 0;

   // ---- mặt đất chánh gần - mặt trên cao 10,0
   viTri.x = -100.0f;      viTri.y = 5.0f;        viTri.z = -80.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 239.999f, 9.999f, 199.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 5.0f, 5.0f, 5.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ---- mặt đất cao
   mauDat0.d = 0.3f;   mauDat0.l = 1.0f;   mauDat0.x = 0.2f;
   mauDat1.d = 0.7f;   mauDat1.l = 1.0f;   mauDat1.x = 0.5f;
   viTri.x = -157.0f;   viTri.y = 7.5f;      viTri.z = -260.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 119.999f, 14.999f, 99.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 10.0f, 10.0f, 10.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   // ---- mặt đất bên +z
   mauDat0.d = 0.2f;   mauDat0.l = 1.0f;   mauDat0.x = 0.2f;
   mauDat1.d = 0.5f;   mauDat1.l = 1.0f;   mauDat1.x = 0.5f;
   viTri.x = -22.0f;      viTri.y = 2.0f;        viTri.z = 12.0f;

   danhSachVat[soLuongVat].hinhDang.hop = datHop( 100.0f, 6.0f, 40.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 2.999f, 2.999f, 2.999f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   // ---- 3 mặt đất thấp bên +x (bờ biển)
   viTri.x = 26.0f;      viTri.y = 4.0f;        viTri.z = -140.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 16.0f, 8.0f, 300.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 3.0f, 3.0f, 3.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = 26.0f;      viTri.y = 3.0f;        viTri.z = -490.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 15.0f, 6.0f, 400.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 3.0f, 3.0f, 3.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = 26.0f;      viTri.y = 3.5f;        viTri.z = -790.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 17.0f, 7.0f, 200.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 3.0f, 3.0f, 3.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
      
   // ---- mặt đất cao xa
   mauDat0.d = 1.0f;   mauDat0.l = 0.5f;   mauDat0.x = 0.2f;
   mauDat1.d = 1.0f;   mauDat1.l = 0.9f;   mauDat1.x = 0.5f;
   viTri.x = -170.0f;   viTri.y = 15.0f;     viTri.z = -820.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 200.0f, 10.0f, 800.0f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   // ---- đất hướng xa -z
   mauDat0.d = 0.3f;   mauDat0.l = 1.0f;   mauDat0.x = 0.2f;
   mauDat1.d = 0.7f;   mauDat1.l = 1.0f;   mauDat1.x = 0.5f;
   viTri.x = -100.0f;   viTri.y = 5.0f;      viTri.z = -330.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 239.999f, 9.999f, 299.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ---- đòi bên lề đường
   mauDat0.d = 1.0f;   mauDat0.l = 0.5f;   mauDat0.x = 0.2f;
   mauDat1.d = 1.0f;   mauDat1.l = 0.9f;   mauDat1.x = 0.5f;
   viTri.x = -35.0f;   viTri.y = 12.5f;      viTri.z = -300.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 29.999f, 4.999f, 29.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = -40.0f;   viTri.y = 15.0f;      viTri.z = -290.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 14.999f, 9.999f, 14.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = -110.0f;   viTri.y = 14.0f;      viTri.z = -330.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 44.999f, 7.999f, 54.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ---- đất hướng xa (màu cam) -z
   mauDat0.d = 1.0f;   mauDat0.l = 0.5f;   mauDat0.x = 0.2f;
   mauDat1.d = 1.0f;   mauDat1.l = 0.9f;   mauDat1.x = 0.5f;
   viTri.x = -100.0f;   viTri.y = 5.0f;      viTri.z = -730.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 239.999f, 9.999f, 499.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ---- hai đòi trên đất cao xa
   viTri.x = -170.0f;   viTri.y = 25.0f;      viTri.z = -630.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 139.999f, 9.999f, 199.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = -50.0f;   viTri.y = 12.0f;      viTri.z = -750.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 49.999f, 3.999f, 399.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   viTri.x = -20.0f;   viTri.y = 11.0f;      viTri.z = -730.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 14.999f, 2.999f, 199.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   viTri.x = -170.0f;   viTri.y = 45.0f;      viTri.z = -530.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 39.999f, 69.999f, 79.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   viTri.x = -170.0f;   viTri.y = 45.0f;      viTri.z = -1030.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 139.999f, 49.999f, 179.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

//   mauDat1.d = 1.0f;   mauDat1.l = 0.9f;   mauDat1.x = 0.5f;
   viTri.x = -165.0f;   viTri.y = 5.0f;      viTri.z = -1230.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 399.999f, 9.999f, 499.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 20.0f, 20.0f, 20.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   // ---- mặt đất chân trời
   viTri.x = -165.0f;   viTri.y = 5.0f;      viTri.z = -1780.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 399.999f, 9.999f, 1099.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 40.0f, 40.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ---- núi chân trời -x
   viTri.x = -215.0f;   viTri.y = 25.0f;      viTri.z = -1780.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 399.999f, 39.999f, 499.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 40.0f, 40.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   // ---- hai đòi chân trời +x
   viTri.x = 35.0f;   viTri.y = 15.0f;      viTri.z = -1300.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 29.999f, 29.999f, 59.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 40.0f, 40.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   viTri.x = 45.0f;   viTri.y = 25.0f;      viTri.z = -1315.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 29.999f, 49.999f, 29.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 40.0f, 40.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   viTri.x = 65.0f;   viTri.y = 10.0f;      viTri.z = -1305.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 79.999f, 19.999f, 79.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 40.0f, 40.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   viTri.x = 35.0f;   viTri.y = 12.5f;      viTri.z = -2000.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 29.999f, 24.999f, 59.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 40.0f, 40.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   // ---- mặt đất bên -x, mặt trên cao 10,0
   mauDat0.d = 0.3f;   mauDat0.l = 1.0f;   mauDat0.x = 0.2f;
   mauDat1.d = 0.7f;   mauDat1.l = 1.0f;   mauDat1.x = 0.5f;
   viTri.x = -340.0f;      viTri.y = 5.0f;        viTri.z = -80.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 239.999f, 9.999f, 299.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 8.0f, 8.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ----  -x
   mauDat0.d = 0.2f;   mauDat0.l = 1.0f;   mauDat0.x = 0.2f;   mauDat0.dd = 1.0f;   mauDat0.p = 0.0f;
   mauDat1.d = 0.5f;   mauDat1.l = 1.0f;   mauDat1.x = 0.5f;   mauDat1.dd = 1.0f;   mauDat1.p = 0.0f;
   viTri.x = -290.0f;      viTri.y = 15.0f;        viTri.z = 40.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 49.999f, 9.999f, 29.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 8.0f, 8.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = -255.0f;      viTri.y = 12.0f;        viTri.z = 45.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 29.999f, 3.999f, 29.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 8.0f, 8.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   // ---- đảo nhỏ
   viTri.x = -170.0f;      viTri.y = 7.0f;        viTri.z = 48.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 19.999f, 16.999f, 19.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 8.0f, 8.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = -175.0f;      viTri.y = 10.0f;        viTri.z = 53.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 19.999f, 21.999f, 19.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 8.0f, 8.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ---- đảo nhỏ
   viTri.x = -20.0f;      viTri.y = 1.5f;        viTri.z = 48.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 29.999f, 4.999f, 19.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 3.0f, 3.0f, 3.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   // ---- cao nguyên thấp bên -x, mặt trên cao 14,0
   mauDat0.d = 0.6f;   mauDat0.l = 1.0f;   mauDat0.x = 0.25f;
   mauDat1.d = 0.8f;   mauDat1.l = 1.0f;   mauDat1.x = 0.55f;
   viTri.x = -360.0f;      viTri.y = 14.0f;        viTri.z = -160.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 299.999f, 7.999f, 299.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 10.0f, 10.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;
   
   viTri.x = -360.0f;      viTri.y = 22.0f;        viTri.z = -100.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 99.999f, 7.999f, 99.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 10.0f, 10.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   viTri.x = -300.0f;      viTri.y = 22.0f;        viTri.z = -160.0f;
   danhSachVat[soLuongVat].hinhDang.hop = datHop( 59.999f, 19.999f, 69.999f, &(danhSachVat[soLuongVat].baoBiVT) );
   danhSachVat[soLuongVat].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVat].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVat]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVat].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 10.0f, 10.0f, 8.0f );
   danhSachVat[soLuongVat].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVat++;

   return soLuongVat;
}

unsigned short datCotNghiengSauLongGai( VatThe *danhSachVat ) {
   
   Vecto vectoQuay;
   vectoQuay.x = 0.707f;  vectoQuay.y = 0.707f;   vectoQuay.z = 0.1f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoQuay, -45.0f );

   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- màu cột
   Mau mauDat0;
   mauDat0.d = 0.2f;   mauDat0.l = 1.0f;   mauDat0.x = 1.0f;   mauDat0.dd = 1.0f;   mauDat0.p = 0.0f;
   Mau mauDat1;
   mauDat1.d = 0.5f;   mauDat1.l = 1.0f;   mauDat1.x = 1.0f;   mauDat1.dd = 1.0f;   mauDat1.p = 0.0f;
   
   float mangViTri_x[150] = {
      -204.60f, -160.00f, -150.40f, -185.40f, -129.40f, -169.00f, -150.60f, -133.00f, -139.00f, -190.60f,
      -131.40f, -203.60f, -128.40f, -159.40f, -198.80f, -220.40f, -162.20f, -168.60f, -141.60f, -206.00f,
      -141.80f, -126.00f, -166.60f, -131.60f, -133.60f, -136.00f, -169.20f, -215.40f, -212.40f, -199.60f,
      -130.40f, -134.20f, -189.40f, -198.00f, -179.60f, -217.20f, -173.00f, -136.20f, -168.00f, -218.80f,
      -160.80f, -131.00f, -213.00f, -171.80f, -207.80f, -145.40f, -134.40f, -129.00f, -145.60f, -202.80f,
      -200.80f, -145.80f, -176.60f, -188.60f, -130.60f, -149.80f, -176.00f, -164.20f, -171.40f, -126.20f,
      -121.00f, -164.00f, -163.80f, -150.80f, -184.60f, -131.60f, -141.80f, -123.20f, -217.60f, -175.60f,
      -189.00f, -190.80f, -143.00f, -156.60f, -144.20f, -120.60f, -218.60f, -145.40f, -172.20f, -132.40f,
      -148.20f, -217.40f, -155.60f, -125.40f, -188.00f, -147.20f, -206.20f, -192.40f, -176.80f, -135.60f,
      -141.20f, -125.80f, -173.40f, -163.00f, -152.20f, -185.20f, -195.00f, -148.20f, -186.00f, -207.00f,
};
   float mangViTri_y[100] = {
      11.25f, 29.00f, 16.25f, 19.25f, 10.75f, 11.75f, 21.50f, 15.75f, 23.00f, 12.00f,
      17.25f, 24.00f, 25.50f, 15.25f, 42.25f, 46.75f, 18.50f, 19.25f, 33.75f, 12.00f,
       9.25f, 18.75f, 20.75f, 17.50f, 16.25f, 35.25f, 30.25f, 24.75f, 17.25f, 15.00f,
       9.50f, 25.25f, 25.50f, 14.00f, 14.50f, 13.50f, 37.25f, 17.00f, 17.00f, 23.50f,
      14.75f, 20.75f, 12.25f, 15.00f, 20.00f, 15.50f, 37.00f, 14.75f, 18.75f, 26.00f,
      22.50f, 21.75f, 15.25f, 19.50f,  9.75f, 19.00f, 10.00f, 18.00f, 12.75f, 22.25f,
      17.00f, 25.50f, 14.25f, 24.25f,  8.75f, 19.25f, 18.75f, 12.50f, 13.50f, 29.00f,
      14.50f, 26.25f, 14.50f, 25.75f, 16.75f, 18.50f, 29.75f, 17.00f, 27.50f, 16.00f,
      24.50f, 19.25f, 21.75f, 10.50f, 17.50f, 22.50f, 21.25f, 11.25f,  9.25f, 14.00f,
      12.50f, 15.00f, 20.25f, 43.75f, 16.25f, 13.75f, 32.50f, 16.50f, 13.30f, 25.00f,
};

   float mangViTri_z[100] = {
      -63.40f,-122.00f,  -48.00f, -74.60f, -29.00f,-114.00f, -85.60f, -73.80f, -61.80f, -86.20f,
      -46.40f, -56.00f,  -65.80f, -55.20f, -51.00f, -66.40f,-118.60f, -65.60f, -87.40f, -65.00f,
     -122.20f, -70.60f,  -45.80f, -74.20f, -44.40f -106.80f,-116.40f, -47.20f,-119.60f,-101.40f,
      -72.60f, -37.60f, -120.20f, -59.20f, -43.00f, -98.20f, -72.80f, -91.40f,-107.80f, -67.00f,
      -52.40f, -58.60f, -113.00f, -77.80f, -60.60f, -55.80f, -77.20f,-106.20f, -63.00f,-110.40f,
      -66.40f,-107.00f,  -63.40f, -40.00f, -66.40f,-117.60f, -70.00f, -89.00f, -31.40f,-111.60f,
      -30.80f, -54.60f,  -78.60f, -61.40f, -64.20f, -59.40f, -51.40f, -90.40f, -59.00f,-115.60f,
      -57.00f, -57.00f, -120.20f, -62.60f, -59.20f, -60.40f, -42.60f, -92.60f,-118.20f, -85.40f,
      -21.80f, -49.20f, -112.20f, -75.40f,-119.20f, -51.80f, -97.80f,-102.60f, -97.60f,-115.00f,
     -111.60f, -46.80f, -118.80f,-102.20f, -94.40f, -54.60f, -63.40f, -46.40f, -63.20f, -31.80f
};
   
   float mangBeDai[100] = {
      24.999f, 17.999f, 16.999f, 22.999f, 19.999f, 22.999f, 17.999f, 17.999f, 22.999f, 16.999f,
      22.999f, 24.999f, 22.999f, 18.999f, 27.999f, 15.999f, 19.999f, 25.999f, 16.999f, 20.999f,
      18.999f, 20.999f, 29.999f, 14.999f, 22.999f, 28.999f, 26.999f, 21.999f, 15.999f, 21.999f,
      21.999f, 23.999f, 16.999f, 28.999f, 16.999f, 29.999f, 17.999f, 29.999f, 25.999f, 21.999f,
      26.999f, 27.999f, 24.999f, 23.999f, 22.999f, 26.999f, 22.999f, 15.999f, 16.999f, 15.999f,
      27.999f, 17.999f, 18.999f, 15.999f, 14.999f, 28.999f, 27.999f, 16.999f, 25.999f, 15.999f,
      28.999f, 22.999f, 14.999f, 20.999f, 29.999f, 29.999f, 22.999f, 17.999f, 16.999f, 25.999f,
      14.999f, 15.999f, 17.999f, 17.999f, 15.999f, 14.999f, 14.999f, 26.999f, 18.999f, 22.999f,
      17.999f, 22.999f, 28.999f, 22.999f, 17.999f, 18.999f, 22.999f, 22.999f, 19.999f, 23.999f,
      15.999f, 25.999f, 14.999f, 28.999f, 16.999f, 26.999f, 15.999f, 22.999f, 18.999f, 24.999f,
};

   float mangBeRong[100] = {6.999f, 9.999f, 7.999f, 8.999f, 4.999f, 11.999f, 6.999f, 9.999f, 9.999f, 9.999f,
      8.999f, 11.999f, 5.999f, 9.999f, 5.999f, 9.999f, 9.999f, 6.999f, 4.999f, 4.999f,
      5.999f, 4.999f, 7.999f, 8.999f, 7.999f, 6.999f, 11.999f, 9.999f, 4.999f, 10.999f,
      10.999f, 10.999f, 10.999f, 10.999f, 8.999f, 7.999f, 11.999f, 8.999f, 5.999f, 4.999f,
      8.999f, 9.999f, 10.999f, 5.999f, 11.999f, 9.999f, 7.999f, 5.999f, 7.999f, 7.999f,
      7.999f, 10.999f, 5.999f, 5.999f, 8.999f, 10.999f, 4.999f, 7.999f, 11.999f, 4.999f,
      4.999f, 6.999f, 6.999f, 10.999f, 4.999f, 8.999f, 10.999f, 7.999f, 7.999f, 5.999f,
      6.999f, 11.999f, 7.999f, 11.999f, 6.999f, 8.999f, 10.999f, 4.999f, 10.999f, 10.999f,
      10.999f, 7.999f, 6.999f, 8.999f, 4.999f, 11.999f, 6.999f, 5.999f, 4.999f, 11.999f,
      5.999f, 4.999f, 11.999f, 5.999f, 7.999f, 11.999f, 9.999f, 8.999f, 8.999f, 9.999f
};

   unsigned short soVatThe = 0;
   while( soVatThe < 100 ) {
   // ---- mặt đất chánh gần - mặt trên cao 10,0
      
      viTri.x = mangViTri_x[soVatThe];
      viTri.y = mangViTri_y[soVatThe];
      viTri.z = mangViTri_z[soVatThe];
      float beDai = mangBeDai[soVatThe];
      float beRong = mangBeRong[soVatThe];
//      printf( "%d , viTri , %5.3f , %5.3f , %5.3f  beDai , %5.3f  beRong , %5.3f\n", soVatThe, viTri.x, viTri.y, viTri.z, beDai, beRong );
      danhSachVat[soVatThe].hinhDang.hop = datHop( beRong, beDai, beRong, &(danhSachVat[soVatThe].baoBiVT) );
      danhSachVat[soVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 5.0f, 5.0f, 5.0f );
      danhSachVat[soVatThe].soHoaTiet = kHOA_TIET__CA_RO;
      soVatThe++;
   }
   return soVatThe;
}

unsigned short datDuongLo( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   Vecto viTri;
   
   Mau mauQuan0;
   Mau mauQuan1;
   Mau mauQuan2;
   
   mauQuan0.d = 0.70f;   mauQuan0.l = 0.70f;   mauQuan0.x = 0.70f;   mauQuan0.dd = 1.0f;   mauQuan0.p = 0.0f;
   mauQuan1.d = 0.75f;   mauQuan1.l = 0.75f;   mauQuan1.x = 0.75f;   mauQuan1.dd = 1.0f;   mauQuan1.p = 0.0f;
   mauQuan2.d = 0.72f;   mauQuan2.l = 0.72f;   mauQuan2.x = 0.72f;   mauQuan2.dd = 1.0f;   mauQuan2.p = 0.0f;

   // ==== đường lộ
   // ---- đầy vòng xoay
   Mau mauDuongLo;
   mauDuongLo.d = 0.6f;   mauDuongLo.l = 0.6f;   mauDuongLo.x = 0.6f;   mauDuongLo.dd = 1.0f;   mauDuongLo.p = 0.0f;
   viTri.x = 0.0f;      viTri.y = 10.05f;    viTri.z = 0.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[0].hinhDang.hinhTru = datHinhTru( 15.0f, 0.1f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietQuanSongTiaPhai = datHoaTietQuanSongTiaPhai( &mauDuongLo, &mauQuan0, &mauQuan1, &mauQuan2, 0.15f, 0.15f, 0.15f, 0.2f, 0.05f, 0.0f, 16, 10.0f, 15.0f );
   danhSachVat[0].soHoaTiet = kHOA_TIET__QUAN_SONG_TIA_PHAI;
   
   Vecto huongNgang;
   huongNgang.x = 0.0f;   huongNgang.y = 1.0f;   huongNgang.z = 0.0f;
   Vecto huongDoc;
   huongDoc.x = 1.0f;   huongDoc.y = 0.0f;   huongDoc.z = 0.0f;
   // ---- đường hướng -x
   viTri.x = -112.0f;      viTri.y = 10.05f;        viTri.z = 0.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[1].hinhDang.hop = datHop( 200.0f, 0.1f, 10.0f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mauDuongLo, &mauQuan0, &mauQuan1, &mauQuan2, 0.2f, 0.2f, 0.2f, 3.0f, 3.0f, 0.7f, 0.0f, 10.0f );
   danhSachVat[1].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   
   // ---- đường hướng -x
   viTri.x = -212.0f;      viTri.y = 10.05f;        viTri.z = 0.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[2].hinhDang.hop = datHop( 200.0f, 0.1f, 10.0f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mauDuongLo, &mauQuan0, &mauQuan1, &mauQuan2, 0.2f, 0.2f, 0.2f, 3.0f, 3.0f, 0.7f, 0.0f, 10.0f );
   danhSachVat[2].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;

   // ---- đường hướng -z
   viTri.x = 0.0f;      viTri.y = 10.05f;    viTri.z = -112.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   huongNgang.x = 1.0f;   huongNgang.y = 0.0f;   huongNgang.z = 0.0f;
   huongDoc.x = 0.0f;   huongDoc.y = 0.0f;   huongDoc.z = 1.0f;

   unsigned short soDoan = 0;
   unsigned short chiSo = 3;
   while ( soDoan < 10 ) {
      danhSachVat[chiSo].hinhDang.hop = datHop( 10.0f, 0.1f, 200.0f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mauDuongLo, &mauQuan0, &mauQuan1, &mauQuan2, 0.2f, 0.2f, 0.2f, 3.0f, 3.0f, 0.7f, 0.0f, 10.0f );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
      viTri.z -= 200.0f;
      soDoan++;
      chiSo++;
   }
 
   return soDoan + 3;
}

unsigned short datLanCanDuongLo( VatThe *danhSachVat ) {
   Quaternion quaternion;
   quaternion.w = 1.0f;
   quaternion.x = 0.0f;
   quaternion.y = 0.0f;
   quaternion.z = 0.0f;
   
   Vecto viTri;
   Vecto phongTo;
   
   // ==== bờ đất
   Mau mauNen0;
   Mau mauNen1;
   mauNen0.d = 0.3f;   mauNen0.l = 1.0f;   mauNen0.x = 0.2f;   mauNen0.dd = 1.0f;   mauNen0.p = 0.0f;
   mauNen1.d = 0.5f;   mauNen1.l = 1.0f;   mauNen1.x = 0.5f;   mauNen1.dd = 1.0f;   mauNen1.p = 0.0f;
   
   // ---- cho họa tiết chấm bi
   Mau mauChamBi0;
   Mau mauChamBi1;
   mauChamBi0.d = 0.5f;   mauChamBi0.l = 1.0f;   mauChamBi0.x = 0.5f;   mauChamBi0.dd = 1.0f;   mauChamBi0.p = 0.0f;
   mauChamBi1.d = 1.0f;   mauChamBi1.l = 1.0f;   mauChamBi1.x = 0.4f;   mauChamBi1.dd = 1.0f;   mauChamBi1.p = 0.0f;

   Vecto viTri0;
   Vecto viTri1;
   viTri0.x = 1.0f;   viTri0.y = 0.8f;   viTri0.z = 0.5f;
   viTri1.x = -1.5f;   viTri1.y = 2.5f;   viTri1.z = 0.0f;


   // ---- mặt đất chánh gần - mặt trên cao 5,0 cm
   // ---- đường hướng -x
   viTri.x = -116.0f;      viTri.y = 10.6f;        viTri.z = 0.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   danhSachVat[0].hinhDang.hop = datHop( 200.0f, 1.0f, 0.5f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietHaiChamBi = datHoaTietHaiChamBi( &mauNen0, &mauChamBi0, &mauChamBi1, 0.8f, 3.0f, &viTri0, &viTri1, 10.0f, 5.0f, 5.0f );
   danhSachVat[0].soHoaTiet = kHOA_TIET__HAI_CHAM_BI;
   
   // ---- đường hướng -z
   viTri.x = 0.0f;      viTri.y = 10.6f;    viTri.z = -116.0f;
   phongTo.x = 1.0f;    phongTo.y = 1.0f;    phongTo.z = 1.0f;
   
   // ---- cho họa tiết chấm bi
   mauChamBi0.d = 0.3f;   mauChamBi0.l = 0.3f;   mauChamBi0.x = 1.0f;   mauChamBi0.dd = 1.0f;   mauChamBi0.p = 0.0f;
   mauChamBi1.d = 0.5f;   mauChamBi1.l = 0.5f;   mauChamBi1.x = 1.0f;   mauChamBi1.dd = 1.0f;   mauChamBi1.p = 0.0f;
   
   viTri0.x = 0.0f;   viTri0.y = 2.8f;   viTri0.z = -1.5f;
   viTri1.x = 0.0f;   viTri1.y = 0.3f;   viTri1.z = 2.5f;
   
   unsigned short soDoan = 0;
   unsigned short chiSo = 1;
   while ( soDoan < 10 ) {
      danhSachVat[chiSo].hinhDang.hop = datHop( 0.5f, 1.0f, 200.0f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietHaiChamBi = datHoaTietHaiChamBi( &mauNen0, &mauChamBi0, &mauChamBi1, 3.0f, 0.5f, &viTri0, &viTri1, 5.0f, 5.0f, 10.0f );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__HAI_CHAM_BI;
      viTri.z -= 200.0f;
      soDoan++;
      chiSo++;
   }
   
   return soDoan + 1;
}

unsigned short datThapVongXoay( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri;
   
   // ---- đấy
   mau.d = 0.5f;      mau.l = 0.0f;      mau.x = 0.8f;      mau.dd = 1.0f;     mau.p = 0.25f;
   viTri.x = 0.0f;       viTri.y = 10.2f;       viTri.z = 0.0f;
   danhSachVat[0].hinhDang.hinhTru = datHinhTru( 7.5f, 0.2f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   
   mau.d = 0.1f;      mau.l = 0.0f;      mau.x = 0.35f;      mau.dd = 1.0f;     mau.p = 0.0f;
   Mau mauOc0;
   mauOc0.d = 0.8f;      mauOc0.l = 0.5f;      mauOc0.x = 0.3f;      mauOc0.dd = 1.0f;      mauOc0.p = 0.2f;
   Mau mauOc1;
   mauOc1.d = 0.8f;      mauOc1.l = 0.25f;      mauOc1.x = 0.15f;      mauOc1.dd = 1.0f;      mauOc1.p = 0.2f;
   Mau mauOc2;
   mauOc2.d = 0.3f;      mauOc2.l = 0.0f;      mauOc2.x = 0.3f;      mauOc2.dd = 1.0f;      mauOc2.p = 0.2f;
   viTri.x = 0.0f;       viTri.y = 10.4f;       viTri.z = 0.0f;
   danhSachVat[1].hinhDang.hinhTru = datHinhTru( 7.2f, 0.2f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.05f, 0.08f, 0.15f, 0.0f, 0.165f, 16 );
   danhSachVat[1].soHoaTiet = kHOA_TIET__QUAN_XOAY;
   
   // ---- lớp trên đấy
   viTri.x = 0.0f;       viTri.y = 11.25f;       viTri.z = 0.0f;
   danhSachVat[2].hinhDang.hinhNon = datHinhNon( 7.2f, 4.5f, 1.5f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.05f, 0.08f, 0.15f, 0.3f, 0.0f, 16 );
   danhSachVat[2].soHoaTiet = kHOA_TIET__QUAN_XOAY;
   
   // ---- lớp trên đấy
   mau.d = 1.0f;      mau.l = 0.4f;      mau.x = 0.0f;      mau.dd = 1.0f;    mau.p = 0.25f;
   viTri.x = 0.0f;       viTri.y = 12.15f;       viTri.z = 0.0f;
   danhSachVat[3].hinhDang.hinhNon = datHinhNon( 4.5f, 5.0f, 0.3f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTri );
   danhSachVat[3].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[3].soHoaTiet = kHOA_TIET__KHONG;

   viTri.x = 0.0f;       viTri.y = 12.45f;       viTri.z = 0.0f;
   danhSachVat[4].hinhDang.hinhTru = datHinhTru( 5.0f, 0.3f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTri );
   danhSachVat[4].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[4].soHoaTiet = kHOA_TIET__KHONG;
   
   // ---- hai vòng trên
   mau.d = 0.92f;      mau.l = 0.72f;      mau.x = 1.0f;      mau.dd = 1.0f;    mau.p = 0.25f;
   viTri.x = 0.0f;       viTri.y = 12.65f;       viTri.z = 0.0f;
   danhSachVat[5].hinhDang.hinhTru = datHinhTru( 4.5f, 0.1f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[5].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.x = 0.0f;       viTri.y = 12.75f;       viTri.z = 0.0f;
   danhSachVat[6].hinhDang.hinhTru = datHinhTru( 4.2f, 0.1f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[6].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &quaternion, &viTri );
   danhSachVat[6].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[6].soHoaTiet = kHOA_TIET__KHONG;

   // ---- đấy tháp
   mau.d = 0.3f;      mau.l = 0.0f;      mau.x = 0.15f;      mau.dd = 1.0f;      mau.p = 0.25f;
   mauOc0.d = 0.55f;     mauOc0.l = 0.0f;      mauOc0.x = 0.35f;     mauOc0.dd = 1.0f;   mauOc0.p = 0.25f;
   mauOc1.d = 0.55f;     mauOc1.l = 0.0f;      mauOc1.x = 0.35f;     mauOc1.dd = 1.0f;   mauOc1.p = 0.25f;
   mauOc2.d = 0.35f;     mauOc2.l = 0.0f;      mauOc2.x = 0.18f;     mauOc2.dd = 1.0f;   mauOc2.p = 0.25f;
   viTri.x = 0.0f;       viTri.y = 14.85f;       viTri.z = 0.0f;
   danhSachVat[7].hinhDang.hinhNon = datHinhNon( 2.0f, 0.5f, 4.1f, &(danhSachVat[7].baoBiVT) );
   danhSachVat[7].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[7].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &quaternion, &viTri );
   danhSachVat[7].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.1f, 0.1f, 0.1f, 3.0f, 0.0f, 2 );
   danhSachVat[7].soHoaTiet = kHOA_TIET__QUAN_XOAY;

   // ---- đỉnh tháp
   mau.d = 1.0f;      mau.l = 0.8f;      mau.x = 0.0f;      mau.dd = 1.0f;     mau.p = 0.25f;
   mauOc0.d = 1.0f;     mauOc0.l = 0.8f;      mauOc0.x = 0.4f;     mauOc0.dd = 1.0f;   mauOc0.p = 0.25f;
   mauOc1.d = 1.0f;     mauOc1.l = 0.8f;      mauOc1.x = 0.4f;     mauOc1.dd = 1.0f;   mauOc1.p = 0.25f;
   mauOc2.d = 1.0f;     mauOc2.l = 0.6f;      mauOc2.x = 0.0f;     mauOc2.dd = 1.0f;   mauOc2.p = 0.25f;
   viTri.x = 0.0f;     viTri.y = 18.15f;    viTri.z = 0.0f;
   danhSachVat[8].hinhDang.hinhNon = datHinhNon( 0.4f, 0.0f, 2.5f, &(danhSachVat[8].baoBiVT) );
   danhSachVat[8].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[8].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[8]), &phongTo, &quaternion, &viTri );
   danhSachVat[8].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.15f, 0.15f, 0.15f, 4.0f, 0.0f, 2 );
   danhSachVat[8].soHoaTiet = kHOA_TIET__QUAN_XOAY;
   
   // ---- các hình nón quanh tháp
   mau.d = 0.1f;      mau.l = 0.0f;      mau.x = 0.33f;      mau.dd = 1.0f;     mau.p = 0.0f;
   mauOc0.d = 0.8f;      mauOc0.l = 0.5f;      mauOc0.x = 0.3f;      mauOc0.dd = 1.0f;   mauOc0.p = 0.0f;
   mauOc1.d = 1.0f;      mauOc1.l = 0.5f;      mauOc1.x = 0.3f;      mauOc1.dd = 1.0f;   mauOc1.p = 0.0f;
   mauOc2.d = 0.3f;      mauOc2.l = 0.0f;      mauOc2.x = 0.3f;      mauOc2.dd = 1.0f;   mauOc2.p = 0.0f;
   float goc = 0.0f;
   unsigned char soHinhNon = 0;
   while ( soHinhNon < 8 ) {
      unsigned char chiSo = 9 + soHinhNon;
      viTri.x = 3.0f*cosf( goc );       viTri.y = 13.55f;       viTri.z = 3.0f*sinf( goc );
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 0.7f, 0.0f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.1f, 0.1f, 0.15f, 2.0f, 0.0f, 2 );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      soHinhNon++;
      goc += 3.14159f/4.0f;
   }
   
   return 17;
}

unsigned short datDayCotQuangVongXoay( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   mau.d = 0.5f;    mau.l = 0.3f;    mau.x = 0.6f;    mau.dd = 1.0f;    mau.p = 0.5f;
   Vecto viTri;
   
   float goc = 3.1415926f*0.8f;

   unsigned short soVatThe = 0;
   unsigned char soCot = 0;
   while ( soCot < 12 ) {
      viTri.x = 17.5f*cosf( goc );       viTri.y = 10.2f;       viTri.z = 17.5f*sinf( goc );

      danhSachVat[soVatThe].hinhDang.hinhTru = datHinhTru( 1.2f, 0.4f, &(danhSachVat[soVatThe].baoBiVT) );
      danhSachVat[soVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soVatThe++;
      
      viTri.y += 0.25f;
      danhSachVat[soVatThe].hinhDang.hinhNon = datHinhNon( 1.2f, 1.1f, 0.1f, &(danhSachVat[soVatThe].baoBiVT) );
      danhSachVat[soVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soVatThe++;
   
      soCot++;
      goc += -3.14159f*0.1f;
   }

   return soVatThe;
}

unsigned short datLongSaoGaiDo( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Mau mauNoi;
   Mau mauNgoai;
   Mau mauVanh;
   Vecto viTri;
  
   // ---- đấy - lớp 0
   unsigned short soLuongVatThe = 0;
   mau.d = 1.0f;      mau.l = 0.8f;      mau.x = 0.8f;      mau.dd = 1.0f;     mau.p = 0.15f;
   mauNoi.d = 1.0f;   mauNoi.l = 0.3f;   mauNoi.x = 0.35f;   mauNoi.dd = 1.0f;   mauNoi.p = 0.05f;
   mauNgoai.d = 1.0f; mauNgoai.l = 0.7f; mauNgoai.x = 0.7f; mauNgoai.dd = 1.0f; mauNgoai.p = 0.05f;
   mauVanh.d = 1.0f;  mauVanh.l = 0.2f;  mauVanh.x = 0.33f;  mauVanh.dd = 1.0f;  mauVanh.p = 0.01f;
   viTri.x = -52.0f;      viTri.y = 12.15f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 32.0f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietBongVong = datHoaTietBongVong( &mau, &mauNoi, &mauNgoai, &mauVanh, 29.0f, 30.5f, 30.7f, &mauNoi, &mauNgoai, 0.5f, 85 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__BONG_VONG;
   soLuongVatThe++;

   // ---- đấy - lớp 1
   mau.d = 1.0f;      mau.l = 0.0f;      mau.x = 0.1f;      mau.dd = 1.0f;
   mauNoi.d = 1.0f;   mauNoi.l = 0.2f;   mauNoi.x = 0.25f;   mauNoi.dd = 1.0f;   mauNoi.p = 0.05f;
   mauNgoai.d = 0.7f; mauNgoai.l = 0.0f; mauNgoai.x = 0.05f; mauNgoai.dd = 1.0f; mauNgoai.p = 0.05f;
   mauVanh.d = 1.0f;  mauVanh.l = 0.5f;  mauVanh.x = 0.55f;  mauVanh.dd = 1.0f;  mauVanh.p = 0.01f;
   viTri.x = -52.0f;      viTri.y = 12.45f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 26.0f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietBongVong = datHoaTietBongVong( &mau, &mauNoi, &mauNgoai, &mauVanh, 23.0f, 24.5f, 24.7f, &mauNoi, &mauNgoai, 0.5f, 69 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__BONG_VONG;
   soLuongVatThe++;

   // ---- đấy - lớp 2
   mau.d = 1.0f;      mau.l = 0.8f;      mau.x = 0.8f;      mau.dd = 1.0f;
   mauNoi.d = 1.0f;   mauNoi.l = 0.3f;   mauNoi.x = 0.35f;   mauNoi.dd = 1.0f;   mauNoi.p = 0.05f;
   mauNgoai.d = 1.0f; mauNgoai.l = 0.7f; mauNgoai.x = 0.7f; mauNgoai.dd = 1.0f; mauNgoai.p = 0.05f;
   mauVanh.d = 1.0f;  mauVanh.l = 0.2f;  mauVanh.x = 0.33f;  mauVanh.dd = 1.0f;  mauVanh.p = 0.01f;
   viTri.x = -52.0f;      viTri.y = 12.75f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 20.0f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietBongVong = datHoaTietBongVong( &mau, &mauNoi, &mauNgoai, &mauVanh, 17.0f, 18.5f, 18.7f, &mauNoi, &mauNgoai, 0.5f, 53 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__BONG_VONG;
   soLuongVatThe++;
   
   // ---- đấy - lớp 3
   mau.d = 1.0f;      mau.l = 0.0f;      mau.x = 0.1f;      mau.dd = 1.0f;
   mauNoi.d = 1.0f;   mauNoi.l = 0.2f;   mauNoi.x = 0.25f;   mauNoi.dd = 1.0f;   mauNoi.p = 0.05f;
   mauNgoai.d = 0.7f; mauNgoai.l = 0.0f; mauNgoai.x = 0.05f; mauNgoai.dd = 1.0f; mauNgoai.p = 0.05f;
   mauVanh.d = 1.0f;  mauVanh.l = 0.5f;  mauVanh.x = 0.55f;  mauVanh.dd = 1.0f;  mauVanh.p = 0.01f;
   viTri.x = -52.0f;      viTri.y = 13.05f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 15.0f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietBongVong = datHoaTietBongVong( &mau, &mauNoi, &mauNgoai, &mauVanh, 12.0f, 13.5f, 13.7f, &mauNoi, &mauNgoai, 0.5f, 40 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__BONG_VONG;
   soLuongVatThe++;

   // ---- đấy - lớp 4
   mau.d = 1.0f;      mau.l = 0.8f;      mau.x = 0.8f;      mau.dd = 1.0f;
   mauNoi.d = 1.0f;   mauNoi.l = 0.3f;   mauNoi.x = 0.35f;   mauNoi.dd = 1.0f;   mauNoi.p = 0.05f;
   mauNgoai.d = 1.0f; mauNgoai.l = 0.7f; mauNgoai.x = 0.7f; mauNgoai.dd = 1.0f; mauNgoai.p = 0.05f;
   mauVanh.d = 1.0f;  mauVanh.l = 0.2f;  mauVanh.x = 0.33f;  mauVanh.dd = 1.0f;  mauVanh.p = 0.01f;
   viTri.x = -52.0f;      viTri.y = 13.35f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 11.0f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietBongVong = datHoaTietBongVong( &mau, &mauNoi, &mauNgoai, &mauVanh, 8.0f, 9.5f, 9.7f, &mauNoi, &mauNgoai, 0.5f, 29 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__BONG_VONG;
   soLuongVatThe++;
   
   // ---- đấy - lớp 5
   mau.d = 0.6f;      mau.l = 0.0f;      mau.x = 0.1f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 13.85f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 6.0f, 1.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ---- nền cho cột
   mau.d = 0.6f;      mau.l = 0.0f;      mau.x = 0.1f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 14.6f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 5.3f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 15.25f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 5.3f, 4.5f, 0.8f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   // ---- cột chánh
   mau.d = 1.0f;      mau.l = 0.7f;      mau.x = 0.5f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 18.1f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.0f, 4.9f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = -52.0f;      viTri.y = 20.7f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 4.0f, 3.7f, 0.3, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   // ----
   mau.d = 0.0f;      mau.l = 0.35f;      mau.x = 1.0f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 20.9f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.4f, 3.5f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 21.15f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 3.5f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 21.4f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.5f, 3.4f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ----
   mau.d = 0.933f;    mau.l = 0.533f;    mau.x = 0.367f;    mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 21.6f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.7f, 4.0f, 0.3, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 21.9f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.0f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 22.2f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 4.0f, 3.7f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
 
   // ----
   mau.d = 0.1f;      mau.l = 0.40f;      mau.x = 1.0f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 22.4f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.4f, 3.5f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 22.65f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 3.5f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 22.9f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.5f, 3.4f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   // ----
   mau.d = 0.867f;    mau.l = 0.367f;    mau.x = 0.233f;    mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 23.1f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.7f, 4.0f, 0.3, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = -52.0f;      viTri.y = 23.4f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.0f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 23.7f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 4.0f, 3.7f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   // ---- 
   mau.d = 0.2f;      mau.l = 0.45f;      mau.x = 1.0f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 23.9f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.4f, 3.5f, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = -52.0f;      viTri.y = 24.15f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 3.5f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = -52.0f;      viTri.y = 24.35f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.5f, 3.4, 0.1f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   // ---- trên cột chánh
   mau.d = 0.8f;      mau.l = 0.2f;      mau.x = 0.1f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 24.55f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.7f, 4.0f, 0.3, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 24.95f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.0f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = -52.0f;      viTri.y = 25.325f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 4.0f, 3.75f, 0.25f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 25.575f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.7f, 3.45f, 0.25f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ---- sàn lồng - vật thể bool
   mau.d = 1.0f;      mau.l = 0.1f;      mau.x = 0.05f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 25.75f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[soLuongVatThe].mucDichBool = 1;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   
   danhSachVat[soLuongVatThe].soLuongVatThe = 2;
   danhSachVat[soLuongVatThe].danhSachVatThe = malloc( 2*sizeof(VatThe) );
   
   // vị trí tương đối
   viTri.x = 0.0f;      viTri.y = 0.0f;        viTri.z = 0.0f;
   danhSachVat[soLuongVatThe].danhSachVatThe[0].hinhDang.hinhTru = datHinhTru( 3.2f, 0.1f, &(danhSachVat[soLuongVatThe].danhSachVatThe[0].baoBiVT) );
   danhSachVat[soLuongVatThe].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].danhSachVatThe[0].giaTri = 1;
   
   viTri.x = 0.0f;      viTri.y = 0.05f;        viTri.z = 0.0f;
   danhSachVat[soLuongVatThe].danhSachVatThe[1].hinhDang.hinhTru = datHinhTru( 1.5f, 0.1f, &(danhSachVat[soLuongVatThe].danhSachVatThe[1].baoBiVT) );
   danhSachVat[soLuongVatThe].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].danhSachVatThe[1].giaTri = -1;
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
   soLuongVatThe++;

   // ---- nắp lồng
   mau.d = 0.0f;      mau.l = 0.0f;      mau.x = 0.85f;
   viTri.x = -52.0f;      viTri.y = 29.65f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.2f, 3.5f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

    mau.d = 0.9f;      mau.l = 0.2f;      mau.x = 0.1f;      mau.dd = 1.0f;
   viTri.x = -52.0f;      viTri.y = 30.0f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.0f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = -52.0f;      viTri.y = 30.5f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 4.0f, 3.5f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ---- đỉnh nắp
   mau.d = 1.0f;      mau.l = 0.2f;      mau.x = 0.0f;    mau.p = 0.4f;
   viTri.x = -52.0f;      viTri.y = 31.0f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 1.5f, 1.0f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = -52.0f;      viTri.y = 31.35f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 0.8f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = -52.0f;      viTri.y = 31.85f;        viTri.z = -52.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 0.8f, 0.0f, 0.8f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   return soLuongVatThe;
}

unsigned short datVuonQuangDatLongSaoGaiDo( VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   Vecto viTri;
   
   // ---- màu cho ca rô
   Mau mau0;
   Mau mau1;

   // ---- nền cho lầng sao gai
   mau0.d = 1.0f;   mau0.l = 0.1f;   mau0.x = 0.2f;   mau0.dd = 1.0f;   mau0.p = 0.0f;
   mau1.d = 1.0f;   mau1.l = 0.15f;   mau1.x = 0.25f;   mau1.dd = 1.0f;   mau1.p = 0.0f;
   viTri.x = -52.0f;      viTri.y = 11.0f;        viTri.z = -52.0f;
   danhSachVat[0].hinhDang.hop = datHop( 74.999f, 1.999f, 74.999f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 2.0f, 2.0f, 2.0f );
   danhSachVat[0].soHoaTiet = kHOA_TIET__CA_RO;

   // ---- lối ra phía trước
   viTri.x = -11.0f;      viTri.y = 11.0f;        viTri.z = -52.0f;
   danhSachVat[1].hinhDang.hop = datHop( 9.999f, 1.999f, 9.999f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 2.0f, 2.0f, 2.0f );
   danhSachVat[1].soHoaTiet = kHOA_TIET__CA_RO;
   
   // ---- lối ra phía sau
   viTri.x = -93.0f;      viTri.y = 11.0f;        viTri.z = -52.0f;
   danhSachVat[2].hinhDang.hop = datHop( 9.999f, 1.999f, 9.999f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 2.0f, 2.0f, 2.0f );
   danhSachVat[2].soHoaTiet = kHOA_TIET__CA_RO;

   // ====
   // ---- hình nón sáng
   Mau mauNen0;
   Mau mauOc00;
   Mau mauOc01;
   Mau mauOc02;

   mauNen0.d = 1.0f;   mauNen0.l = 0.8f;   mauNen0.x = 0.8f;  mauNen0.dd = 1.0f;    mauNen0.p = 0.0f;
   mauOc00.d = 1.0f;    mauOc00.l = 0.4f;    mauOc00.x = 0.4f;   mauOc00.dd = 1.0f;     mauOc00.p = 0.0f;
   mauOc01.d = 1.0f;    mauOc01.l = 0.6f;    mauOc01.x = 0.6f;   mauOc01.dd = 1.0f;     mauOc01.p = 0.0f;
   mauOc02.d = 1.0f;    mauOc02.l = 0.7f;    mauOc02.x = 0.7f;   mauOc02.dd = 1.0f;     mauOc02.p = 0.0f;

   // ---- hình nón tối
   Mau mauNen1;
   Mau mauOc10;
   Mau mauOc11;
   Mau mauOc12;
   mauNen1.d = 0.5f;     mauNen1.l = 0.15f;    mauNen1.x = 0.25f;   mauNen1.dd = 1.0f;   mauNen1.p = 0.0f;
   mauOc10.d = 0.45f;    mauOc10.l = 0.13f;    mauOc10.x = 0.21f;   mauOc10.dd = 1.0f;   mauOc10.p = 0.0f;
   mauOc11.d = 0.41f;    mauOc11.l = 0.115f;   mauOc11.x = 0.15f;   mauOc11.dd = 1.0f;   mauOc11.p = 0.0f;
   mauOc12.d = 0.37f;    mauOc12.l = 0.1f;     mauOc12.x = 0.1f;    mauOc12.dd = 1.0f;   mauOc12.p = 0.0f;

   // ---- cạnh +x
   viTri.y = 10.5f;
   viTri.z = -52.0f + 32.0f;
   unsigned char chiSo = 3;
   while( chiSo < 20 ) {  // 17 cái
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 5.0f, 1.5f, 2.0f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;

      if( chiSo & 0x01 ) {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen0, &mauOc00, &mauOc01, &mauOc02, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.x = -52.0f + 42.5f;
      }
      else {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen1, &mauOc10, &mauOc11, &mauOc12, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.x = -52.0f + 40.5f;
      }
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      viTri.z -= 4.0f;
      chiSo++;
   }

   // ---- cạnh -x

   viTri.z = -52.0f + 32.0f;
   while( chiSo < 37 ) {  // 15 cái
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 5.0f, 1.5f, 2.0f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      if( chiSo & 0x01 ) {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen0, &mauOc00, &mauOc01, &mauOc02, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.x = -52.0f - 40.5f;
      }
      else {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen1, &mauOc10, &mauOc11, &mauOc12, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.x = -52.0f - 42.5f;
      }
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      
      viTri.z -= 4.0f;
      chiSo++;
   }
   
   // ---- cạnh +z
   viTri.x = -52.0f + 32.0f;
   viTri.y = 10.5f;

   while( chiSo < 54 ) {  // 15 cái
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 5.0f, 1.5f, 2.0f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      if( chiSo & 0x01 ) {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen0, &mauOc00, &mauOc01, &mauOc02, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.z = -52.0f + 42.5f;
      }
      else {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen1, &mauOc10, &mauOc11, &mauOc12, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.z = -52.0f + 40.5f;
      }
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      viTri.x -= 4.0f;
      chiSo++;
   }
   
   // ---- cạnh -z
   viTri.x = -52.0f + 32.0f;
   viTri.y = 10.5f;

   while( chiSo < 71 ) {  // 15 cái
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 5.0f, 1.5f, 2.0f , &(danhSachVat[chiSo].baoBiVT));
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      if( chiSo & 0x01 ) {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen0, &mauOc00, &mauOc01, &mauOc02, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.z = -52.0f - 40.5f;
      }
      else {
         danhSachVat[chiSo].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mauNen1, &mauOc10, &mauOc11, &mauOc12, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 1 );
         viTri.z = -52.0f - 42.5f;
      }
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      viTri.x -= 4.0f;
      chiSo++;
   }
   return 71;
}


unsigned short datLanCanNgoaiQuanhLongSaoGaiDo( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri;

   // ---- đấy đỏ
   mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.2f;    mau.dd = 1.0f;

   float buocGoc = 3.1415926f/12.0f;
   float goc = buocGoc;
   unsigned char chiSo = 0;
   while( chiSo < 66 ) {  // 11 cái * 6 bộ phần
      mau.d = 0.7f;   mau.l = 0.0f;   mau.x = 0.1f;    mau.dd = 1.0f;    mau.p = 0.0f;
      viTri.x = 29.0f*cosf( goc ) - 52.0f;     viTri.z = 29.0f*sinf( goc ) - 52.0f;
      viTri.y = 12.6f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.6f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;

      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.2f;
      viTri.y += 1.05f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.0f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;

      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;   mau.p = 0.1f;
      viTri.y += 0.85f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 1.7f, 0.2f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      viTri.y += 0.45f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.7f, 1.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.0f;    mau.dd = 0.8f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.0f, 0.7f, 0.3f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
   
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;    mau.dd = 1.0f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 0.7f, 0.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      goc += buocGoc;
   }
   
   goc = 3.1415926f + buocGoc;
   while( chiSo < 132 ) {  // 11 cái * 6 bộ phần
      mau.d = 0.7f;   mau.l = 0.0f;   mau.x = 0.1f;    mau.dd = 1.0f;    mau.p = 0.0f;
      viTri.x = 29.0f*cosf( goc ) - 52.0f;       viTri.z = 29.0f*sinf( goc ) - 52.0f;
      viTri.y = 12.6f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.6f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.2f;
      viTri.y += 1.05f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.0f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;    mau.p = 0.1f;
      viTri.y += 0.85f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 1.7f, 0.2f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;

      viTri.y += 0.45f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.7f, 1.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;

      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.0f;    mau.dd = 0.8f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.0f, 0.7f, 0.3f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;    mau.dd = 1.0f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 0.7f, 0.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      goc += buocGoc;
   }

   // ---- đấy trắng
   mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;    mau.dd = 1.0f;   mau.p = 0.0f;
   goc = buocGoc*1.5f;

   while( chiSo < 152 ) {  // 10 cái * 2 bộ phần
      viTri.x = 29.0f*cosf( goc ) - 52.0f;      viTri.z = 29.0f*sinf( goc ) - 52.0f;
      
      viTri.y = 12.59f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.58f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;

      viTri.y = 13.8f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.2f, 0.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      goc += buocGoc;
      chiSo++;
   }
   
   goc = 3.1415926f + buocGoc*1.5f;
   while( chiSo < 172 ) {  // 10 cái * 2 bộ phần
      viTri.x = 29.0f*cosf( goc ) - 52.0f;    viTri.z = 29.0f*sinf( goc ) - 52.0f;

      viTri.y = 12.59f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.58f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;

      viTri.y = 13.8f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.2f, 0.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      goc += buocGoc;
      chiSo++;
   }

   return 172;
}


unsigned short datBonThapVuonSaoGaiDo( VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri;
   
   Mau mauOc0;
   Mau mauOc1;
   Mau mauOc2;

   mauOc0.d = 0.5f;     mauOc0.l = 0.0f;     mauOc0.x = 0.0f;    mauOc0.dd = 1.0f;    mauOc0.p = 0.05f;
   mauOc1.d = 1.0f;     mauOc1.l = 0.25f;     mauOc1.x = 0.35f;    mauOc1.dd = 1.0f;    mauOc1.p = 0.05f;
   mauOc2.d = 1.0f;     mauOc2.l = 0.55f;     mauOc2.x = 0.65f;    mauOc2.dd = 1.0f;    mauOc2.p = 0.05f;
   
   // ---- 
   float viTriX[4] = {-21.0f, -21.0f, -83.0f, -83.0f};
   float viTriZ[4] = {-21.0f, -83.0f, -83.0f, -21.0f};
   
   unsigned short soLuongVatThe = 0;
   unsigned char soThap = 0;

     // ---- THÁP SỐ 0
   while ( soThap < 4 ) {

      // ---- nền tháp
      mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;    mau.dd = 1.0f;    mau.p = 0.1f;
      viTri.x = viTriX[soThap];      viTri.y = 12.125f;        viTri.z = viTriZ[soThap];
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 5.0f, 0.25f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
 
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;   mau.p = 0.5f;
      viTri.y += 0.25f;
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.7f, 0.25f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      // ---- ba hình nón chất lên
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.1f;    mau.p = 0.1f;
      viTri.y += 0.375;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 4.0f, 3.8f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;

      viTri.y += 0.5;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.6f, 3.4f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      viTri.y += 0.5;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 3.2f, 3.0f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;

      mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;
      viTri.y += 0.4f;
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 2.3f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      // ---- đỉnh tháp
      mau.d = 0.8f;   mau.l = 0.0f;   mau.x = 0.0f;
      viTri.y += 2.15f;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 1.7f, 0.0f, 4.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 2 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      soLuongVatThe++;

      soThap++;
   }

   // ----                góc (-21.0; -21.0f)    (21.0f, -83.0f)  (-83.0f; -83.0f)  (-21.0f, -83.0f)
   float viTriX_thapNho[8] = {-30.0f, -18.0f,   -18.0f, -30.0f,   -74.0, -86.0f,   -86.0f, -74.0f};
   float viTriZ_thapNho[8] = {-18.0f, -30.0f,   -74.0f, -86.0f,   -86.0, -74.0f,   -30.0f, -18.0f};
   
   soThap = 0;
   while ( soThap < 8 ) {
      // ---- nền tháp
      mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;    mau.dd = 1.0f;    mau.p = 0.1f;
      viTri.x = viTriX_thapNho[soThap];      viTri.y = 12.125f;        viTri.z = viTriZ_thapNho[soThap];
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 2.0f, 0.25f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      mau.d = 1.0f;   mau.l = 0.8f;   mau.x = 0.8f;   mau.p = 0.3f;
      viTri.y += 0.25f;
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 1.7f, 0.25f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      // ---- hình nón chất lên
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.1f;    mau.p = 0.1f;
      viTri.y += 0.625;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 1.4f, 1.0f, 1.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;

      // ---- đỉnh tháp
      mau.d = 0.8f;   mau.l = 0.0f;   mau.x = 0.0f;
      viTri.y += 1.5f;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 0.8f, 0.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.1f, 0.1f, 0.1f, 2.0f, 0.0f, 2 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      soLuongVatThe++;

      soThap++;
   }
   
   // ----                     góc (-21.0; -21.0f)    (21.0f, -83.0f)  (-83.0f; -83.0f)  (-21.0f, -83.0f)
   float viTriX_thapNhoNhat[8] = {-39.0f, -17.0f,   -17.0f, -39.0f,   -65.0, -87.0f,    -87.0f, -65.0f};
   float viTriZ_thapNhoNhat[8] = {-17.0f, -39.0f,   -65.0f, -87.0f,   -87.0f, -65.0f,   -39.0f, -17.0f};

   soThap = 0;
   while ( soThap < 8 ) {
      // ---- nền tháp
      mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;    mau.dd = 1.0f;    mau.p = 0.1f;
      viTri.x = viTriX_thapNhoNhat[soThap];      viTri.y = 12.125f;        viTri.z = viTriZ_thapNhoNhat[soThap];
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 1.0f, 0.25f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      // ---- hình nón chất lên
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.1f;    mau.p = 0.1f;
      viTri.y += 0.625;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 0.7f, 0.5f, 1.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      soLuongVatThe++;
      
      // ---- đỉnh tháp
      mau.d = 0.8f;   mau.l = 0.0f;   mau.x = 0.0f;
      viTri.y += 1.5f;
      danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 0.4f, 0.0f, 2.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.2f, 0.2f, 0.12f, 2.0f, 0.0f, 2 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_XOAY;
      soLuongVatThe++;
      
      soThap++;
   }

   
   return soLuongVatThe;
}

unsigned short datLanCanTrongQuanhLongSaoGaiDo( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri;
   
   // ---- đấy đỏ
   mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.2f;    mau.dd = 1.0f;   mau.p = 0.0f;
   
   float buocGoc = 3.1415926f/8.0f;
   float goc = buocGoc;
   unsigned char chiSo = 0;
   while( chiSo < 42 ) {  // 7 cái * 6 bộ phần
      mau.d = 0.7f;   mau.l = 0.0f;   mau.x = 0.1f;    mau.dd = 1.0f;     mau.p = 0.0f;
      viTri.x = 17.5f*cosf( goc ) - 52.0f;     viTri.z = 17.5f*sinf( goc ) - 52.0f;
      viTri.y = 13.2f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.6f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.2f;
      viTri.y += 1.05f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.0f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;   mau.p = 0.1f;
      viTri.y += 0.85f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 1.7f, 0.2f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      viTri.y += 0.45f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.7f, 1.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.0f;    mau.dd = 0.5f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.0f, 0.7f, 0.3f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;    mau.dd = 1.0f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 0.7f, 0.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      goc += buocGoc;
   }

   goc = 3.1415926f + buocGoc;
   while( chiSo < 84 ) {  // 7 cái * 6 bộ phần
      mau.d = 0.7f;   mau.l = 0.0f;   mau.x = 0.1f;    mau.dd = 1.0f;    mau.p = 0.0f;
      viTri.x = 17.5f*cosf( goc ) - 52.0f;       viTri.z = 17.5f*sinf( goc ) - 52.0f;
      viTri.y = 13.2f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.6f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.2f;    mau.dd = 1.0f;
      viTri.y += 1.05f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.0f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;    mau.dd = 1.0f;    mau.p = 0.1f;
      viTri.y += 0.85f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 1.7f, 0.2f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      viTri.y += 0.45f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.7f, 1.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.0f;    mau.dd = 0.5f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 1.0f, 0.7f, 0.3f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      mau.d = 1.0f;   mau.l = 0.5f;   mau.x = 0.5f;    mau.dd = 1.0f;
      viTri.y += 0.5f;
      danhSachVat[chiSo].hinhDang.hinhNon = datHinhNon( 0.7f, 0.0f, 0.7f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      goc += buocGoc;
   }

   // ---- đấy trắng
   mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;    mau.dd = 1.0f;   mau.p = 0.0f;
   goc = buocGoc*1.5f;
   
   while( chiSo < 96 ) {  // 6 cái * 2 bộ phần
      viTri.x = 17.5f*cosf( goc ) - 52.0f;      viTri.z = 17.5f*sinf( goc ) - 52.0f;
      
      viTri.y = 13.19f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.58f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      viTri.y = 14.6f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.2f, 0.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      goc += buocGoc;
      chiSo++;
   }

   goc = 3.1415926f + buocGoc*1.5f;
   while( chiSo < 108 ) {  // 6 cái * 2 bộ phần
      viTri.x = 17.5f*cosf( goc ) - 52.0f;    viTri.z = 17.5f*sinf( goc ) - 52.0f;
      
      viTri.y = 13.19f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.3f, 0.58f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      
      viTri.y = 14.6f;
      danhSachVat[chiSo].hinhDang.hinhTru = datHinhTru( 2.2f, 0.5f, &(danhSachVat[chiSo].baoBiVT) );
      danhSachVat[chiSo].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSo].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      goc += buocGoc;
      chiSo++;
   }

   return chiSo;
}


unsigned short datCacCotVuongLong( VatThe *danhSachVat ) {
   
   Vecto vectoXoay;
   vectoXoay.x = 0.0f;    vectoXoay.y = 1.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri;
   
   // ----
   mau.d = 0.3f;   mau.l = 1.0f;   mau.x = 0.3f;    mau.dd = 0.2f;    mau.p = 0.8f;
   viTri.x = -15.0f;      viTri.y = 11.0f;      viTri.z = -10.0f;
   
   danhSachVat[0].hinhDang.hinhTru = datHinhTru( 1.5f, 1.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[0].chietSuat = 1.4f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.x = -10.0f;      viTri.y = 11.0f;      viTri.z = -15.0f;
   danhSachVat[1].hinhDang.hinhTru = datHinhTru( 1.5f, 1.0f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[1].chietSuat = 1.4f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;
   
   return 2;
}


unsigned short datKimTuThapThuyTinh( VatThe *danhSachVat ) {
 
   Vecto vectoXoay;
   vectoXoay.x = 0.0f;    vectoXoay.y = 1.0f;     vectoXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &vectoXoay, 0.0f );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri;
   
   // ---- 
   mau.d = 0.3f;   mau.l = 0.3f;   mau.x = 0.3f;    mau.dd = 1.0f;   mau.p = 0.8f;
   viTri.x = 15.0f;      viTri.y = 8.5f;      viTri.z = 13.0f;

   danhSachVat[0].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[0].chietSuat = 1.4f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;

   unsigned short soHang = 0;
   unsigned short chiSo = 1;
   
   viTri.x = 14.25f;
   viTri.y += 0.75f;
   viTri.z = 14.25f;
   soHang = 0;
   while ( soHang < 2 ) {
      unsigned short soCot = 0;
      while (soCot < 2 ) {
         danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
         danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
         danhSachVat[chiSo].chietSuat = 1.4f;
         datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
         danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
         viTri.x += 1.5f;
         chiSo++;  //
         soCot++;
      }
      viTri.x = 14.25f;
      viTri.z += 1.5f;
      soHang++;
   }

   viTri.x = 13.5f;
   viTri.y += 0.75f;
   viTri.z = 13.5f;
   soHang = 0;
   while ( soHang < 3 ) {
      unsigned short soCot = 0;
      while (soCot < 3 ) {
         danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
         danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
         danhSachVat[chiSo].chietSuat = 1.4f;
         datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
         danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
         viTri.x += 1.5f;
         chiSo++;  //
         soCot++;
      }
      viTri.x = 13.5f;
      viTri.z += 1.5f;
      soHang++;
   }
   
   viTri.x = 12.75f;
   viTri.y += 0.75f;
   viTri.z = 12.75f;
   
   soHang = 0;
   while ( soHang < 4 ) {
      unsigned short soCot = 0;
      while (soCot < 4 ) {
         danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
         danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
         danhSachVat[chiSo].chietSuat = 1.4f;
         datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
         danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
         viTri.x += 1.5f;
         chiSo++;  //
         soCot++;
      }
      viTri.x = 12.75f;
      viTri.z += 1.5f;
      soHang++;
   }

   viTri.x = 12.0f;
   viTri.y += 0.75f;
   viTri.z = 12.0f;
   soHang = 0;
   while ( soHang < 5 ) {
      unsigned short soCot = 0;
      while (soCot < 5 ) {
         danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
         danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
         danhSachVat[chiSo].chietSuat = 1.4f;
         datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
         danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
         viTri.x += 1.5f;
         chiSo++;  // 
         soCot++;
      }
      viTri.x = 12.0f;
      viTri.z += 1.5f;
      soHang++;
   }

   viTri.x = 12.75f;
   viTri.y += 0.75f;
   viTri.z = 12.75f;
   soHang = 0;
   while ( soHang < 4 ) {
      unsigned short soCot = 0;
      while (soCot < 4 ) {
         danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
         danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
         danhSachVat[chiSo].chietSuat = 1.4f;
         datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
         danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
         viTri.x += 1.5f;
         chiSo++;  //
         soCot++;
      }
      viTri.x = 12.75f;
      viTri.z += 1.5f;
      soHang++;
   }

   viTri.x = 13.5f;
   viTri.y += 0.75f;
   viTri.z = 13.5f;
   soHang = 0;
   while ( soHang < 3 ) {
      unsigned short soCot = 0;
      while (soCot < 3 ) {
         danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
         danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
         danhSachVat[chiSo].chietSuat = 1.4f;
         datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
         danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
         viTri.x += 1.5f;
         chiSo++;  //
         soCot++;
      }
      viTri.x = 13.5f;
      viTri.z += 1.5f;
      soHang++;
   }

   viTri.x = 14.25f;
   viTri.y += 0.75f;
   viTri.z = 14.25f;
   soHang = 0;
   while ( soHang < 2 ) {
      unsigned short soCot = 0;
      while (soCot < 2 ) {
         danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
         danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
         danhSachVat[chiSo].chietSuat = 1.4f;
         datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
         danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
         danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
         viTri.x += 1.5f;
         chiSo++;  //
         soCot++;
      }
      viTri.x = 14.25f;
      viTri.z += 1.5f;
      soHang++;
   }

   viTri.x = 15.0f;
   viTri.y += 0.75f;
   viTri.z = 15.0f;
   danhSachVat[chiSo].hinhDang.batDien = datBatDien( 1.5f, 1.5f, 1.5f, &(danhSachVat[chiSo].baoBiVT) );
   danhSachVat[chiSo].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[chiSo].chietSuat = 1.4f;
   datBienHoaChoVat( &(danhSachVat[chiSo]), &phongTo, &quaternion, &viTri );
   danhSachVat[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[chiSo].soHoaTiet = kHOA_TIET__KHONG;
   return 55 + 16 + 9 + 4 + 1;
}

unsigned short datDayHinhNonHuongX( VatThe *danhSachVat ) {
   
   Vecto truc;
   truc.x = 1.0f;    truc.y = 1.0f;    truc.z = 0.0f;
   Quaternion xoay;
   xoay.w = 1.0f;   xoay.x = 0.0f;    xoay.y = 0.0f;    xoay.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   
   unsigned short chiSo = 0;
   unsigned short chiSoVathThe = 0;
   while ( chiSo < 15 ) {
      Vecto tam;
      tam.x = -20.0f - chiSo*35.0f;
      tam.y = 10.2f;
      tam.z = 15.0f;
      Mau mau;
      //      mau.d = 1.0f;   mau.l = 0.3f;   mau.x = 0.3f;   mau.dd = 1.0f;   mau.p = 0.3f;
      mau.d = 0.7f;   mau.l = 1.0f;   mau.x = 1.0f;   mau.dd = 1.0f;   mau.p = 0.3f;
      // ---- nền
      danhSachVat[chiSoVathThe].hinhDang.hop = datHop( 5.0f, 0.4f, 5.0f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;

      // ---- đấy
      //     mau.d = 1.0f;   mau.l = 0.7f;   mau.x = 0.7f;   mau.dd = 1.0f;   mau.p = 0.3f;
      mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;   mau.dd = 1.0f;   mau.p = 0.3f;
      tam.y += 0.3f;
      danhSachVat[chiSoVathThe].hinhDang.hinhTru = datHinhTru( 2.3f, 0.2f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;

      tam.y += 0.6f;
      danhSachVat[chiSoVathThe].hinhDang.hinhNon = datHinhNon( 2.3f, 1.3f, 1.0f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;

      // ---- phần giữa
      //      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.3f;   mau.dd = 1.0f;   mau.p = 0.3f;
      mau.d = 0.0f;   mau.l = 1.0f;   mau.x = 0.3f;   mau.dd = 1.0f;   mau.p = 0.3f;
      tam.y += 0.6f;
      danhSachVat[chiSoVathThe].hinhDang.hinhTru = datHinhTru( 1.1f, 0.2f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;

      tam.y += 0.3f;
      danhSachVat[chiSoVathThe].hinhDang.hinhNon = datHinhNon( 1.1f, 0.7f, 0.4f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;

      // ---- nắp
      tam.y += 0.3f;
      //      mau.d = 1.0f;   mau.l = 0.0f;   mau.x = 0.3f;   mau.dd = 0.4f;   mau.p = 0.3f;
      mau.d = 0.0f;   mau.l = 0.0f;   mau.x = 0.9f;   mau.dd = 1.0f;   mau.p = 0.8f;
      danhSachVat[chiSoVathThe].hinhDang.hinhTru = datHinhTru( 0.5f, 0.2f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSoVathThe].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;
   
      tam.y += 0.35f;
//      mau.d = 1.0f;   mau.l = 0.8f;   mau.x = 0.9f;   mau.dd = 1.0f;
      danhSachVat[chiSoVathThe].hinhDang.hinhNon = datHinhNon( 0.5f, 0.0f, 0.5f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;

      chiSo++;
   }
   
   return chiSoVathThe;
}


unsigned short datDayHinhNonHuongZ( VatThe *danhSachVat ) {
   
   Vecto truc;
   truc.x = 1.0f;    truc.y = 1.0f;    truc.z = 0.0f;
   Quaternion xoay;
   xoay.w = 1.0f;   xoay.x = 0.0f;    xoay.y = 0.0f;    xoay.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   
   unsigned short chiSo = 0;
   unsigned short chiSoVathThe = 0;
   while ( chiSo < 20 ) {
      Vecto tam;
      tam.x = 15.0f;
      tam.y = 10.2f;
      tam.z = -20.0f - chiSo*60.0f;
      Mau mau;
      mau.d = 0.5f;   mau.l = 1.0f;   mau.x = 0.3f;   mau.dd = 1.0f;   mau.p = 0.3f;
      // ---- nền
      danhSachVat[chiSoVathThe].hinhDang.hop = datHop( 5.0f, 0.4f, 5.0f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;
      
      // ---- đấy
      mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;

      tam.y += 0.3f;
      danhSachVat[chiSoVathThe].hinhDang.hinhTru = datHinhTru( 2.3f, 0.2f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;

      tam.y += 0.6f;
      danhSachVat[chiSoVathThe].hinhDang.hinhNon = datHinhNon( 2.3f, 1.3f, 1.0f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;
      
      // ---- phần giữa
      mau.d = 0.0f;   mau.l = 0.8f;   mau.x = 1.0f;
      tam.y += 0.6f;
      danhSachVat[chiSoVathThe].hinhDang.hinhTru = datHinhTru( 1.1f, 0.2f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_TRU;

      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;
      
      tam.y += 0.3f;
      danhSachVat[chiSoVathThe].hinhDang.hinhNon = datHinhNon( 1.1f, 0.7f, 0.4f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;
      
      // ---- nắp
      tam.y += 0.3f;
      mau.d = 0.5f;   mau.l = 0.0f;   mau.x = 1.0f;   mau.dd = 1.0f;   mau.p = 0.8f;
      danhSachVat[chiSoVathThe].hinhDang.hinhTru = datHinhTru( 0.5f, 0.2f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[chiSoVathThe].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;
      
      tam.y += 0.35f;
      //      mau.d = 1.0f;   mau.l = 0.8f;   mau.x = 0.9f;   mau.dd = 1.0f;   mau.p = 0.8f;
      danhSachVat[chiSoVathThe].hinhDang.hinhNon = datHinhNon( 0.5f, 0.0f, 0.5f, &(danhSachVat[chiSoVathThe].baoBiVT) );
      danhSachVat[chiSoVathThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[chiSoVathThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoVathThe]), &phongTo, &xoay, &tam );
      danhSachVat[chiSoVathThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[chiSoVathThe].soHoaTiet = kHOA_TIET__KHONG;
      chiSoVathThe++;
      
      chiSo++;
   }
   
   return chiSoVathThe;
}



#pragma mark ---- Nhân Vật
unsigned short datKienLongSaoGaiDo( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   Vecto viTri;
   
   // ---- kiến lồng - vật thể ghép
   mau.d = 0.4f;      mau.l = 0.7f;      mau.x = 1.0f;      mau.dd = 0.15f;   mau.p = 0.1f;
   viTri.x = -52.0f;      viTri.y = 27.7f;        viTri.z = -52.0f;

   danhSachVat[0].loai = kLOAI_VAT_THE__GHEP;
   danhSachVat[0].chietSuat = 1.4f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[0].viTriDau = viTri;
   
   danhSachVat[0].soLuongVatThe = 20;
   danhSachVat[0].danhSachVatThe = malloc( 20*sizeof(VatThe) );

   // ---- các thành phân trong vật ghép
   VatThe *danhSachVatThe = danhSachVat[0].danhSachVatThe;
   Vecto trucQuay;
   trucQuay.x = 0.0f;
   trucQuay.y = 1.0f;
   trucQuay.z = 0.0f;
   float buocGoc = 0.31415927f;    // 2π/20
   
   unsigned char chiSo = 0;
   while ( chiSo < 20 ) {
      float gocXoay = buocGoc*chiSo ;
      // ---- tính vị trí tương đối
      viTri.x = 3.3f*sinf( gocXoay );
      viTri.y = 0.0f;
      viTri.z = 3.3f*cosf( gocXoay );
      
      quaternion = datQuaternionTuVectoVaGocQuay( &trucQuay,  gocXoay );
      danhSachVatThe[chiSo].hinhDang.hop = datHop( 1.0f, 3.5f, 0.2f, &(danhSachVatThe[chiSo].baoBiVT) );
      danhSachVatThe[chiSo].loai = kLOAI_HINH_DANG__HOP;
      danhSachVatThe[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachVatThe[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachVatThe[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVatThe[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
   }

   // ---- đừng quên tính bao bì vật thể cho vật thể ghép
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[0]) );

   return 1;
}

unsigned short datHinhNonBayQuanhThap( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   mau.d = 0.3f;   mau.l = 0.0f;   mau.x = 0.2f;    mau.dd = 0.2f;   mau.p = 0.1f;
   Vecto viTri;
   viTri.x = 0.0f;        viTri.y = 16.5f;     viTri.z = 0.0f;
   
   danhSachVat[0].loai = kLOAI_VAT_THE__GHEP;
   danhSachVat[0].chietSuat = 1.4f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   
   danhSachVat[0].soLuongVatThe = 16;
   danhSachVat[0].danhSachVatThe = malloc( 16*sizeof(VatThe) );
   
   // ---- các thành phân trong vật ghép
   VatThe *danhSachBoPhan = danhSachVat[0].danhSachVatThe;

   float buocGoc = 6.283184f/8.0f;
   float goc = 0;

   unsigned short chiSo = 0;
   while( chiSo < 16 ) {
      // ---- tính vị trí tương đối
      viTri.x = 3.3f*sinf( goc );  // 2π/20
      viTri.y = sinf( goc );
      viTri.z = 3.3f*cosf( goc );
      // ---- đấy
      danhSachBoPhan[chiSo].hinhDang.hinhNon = datHinhNon( 0.0f, 0.5f, 0.5f, &(danhSachBoPhan[chiSo].baoBiVT) );
      danhSachBoPhan[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachBoPhan[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachBoPhan[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachBoPhan[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachBoPhan[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      chiSo++;
      // ---- nắp
      viTri.y += 1.0f;
      danhSachBoPhan[chiSo].hinhDang.hinhNon = datHinhNon( 0.5f, 0.0f, 1.5f, &(danhSachBoPhan[chiSo].baoBiVT) );
      danhSachBoPhan[chiSo].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachBoPhan[chiSo].chietSuat = 1.4f;
      datBienHoaChoVat( &(danhSachBoPhan[chiSo]), &phongTo, &quaternion, &viTri );
      danhSachBoPhan[chiSo].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachBoPhan[chiSo].soHoaTiet = kHOA_TIET__KHONG;
      // ---- tiếp
      goc += buocGoc;
      chiSo++;
   }
   
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[0]) );

   return 1;
}


#define kDUONG_X  0
#define kDUONG_Z  1
#define kTHAI_TRANG__VAO_VONG    0
#define kTHAI_TRANG__TRONG_VONG  1
#define kTHAI_TRANG__RA_VONG     2

unsigned short datCacTraiBanhTrenLoHuongX( VatThe *danhSachVat ) {
   
   float danhSachViTri[] = {-10.0f, -14.0f, -18.0f, -34.0f, -37.0,
       -40.0f,  -43.0f,  -48.0f,  -52.0f,  -74.0f,  // 10
       -82.0f,  -90.0f,  -94.0f,  -98.0f,  -105.5f,
      -109.0f, -112.5f, -121.0f, -123.5f, -126.0f,  // 20
      -128.5f, -147.5f, -152.5f, -157.5f, -169.5f,
       -172.5f, -176.5f, -180.0f, -183.5f, -195.0f, // 30
       -198.5f, -219.0f, -222.5f, -226.0f, -234.0f,
       -238.0f, -248.0f, -260.0f, -290.0f, -296.0f, // 40
      
      -302.0f, -312.5f, -316.0f, -351.0f, -356.0f,
      -359.0f, -363.0f, -372.0f, -376.0f, -410.0f,  // 50
   
      -415.0f, -420.0f, -425.0f, -460.0f, -465.0f,
      -469.0f, -472.0f, -475.0f, -478.0f, -481.0f,  // 60
      -506.0f, -509.0f, -512.0f, -520.0f, -523.5f,
      -569.0f, -575.0f, -580.0f, -583.5f, -587.0f,  // 70
      -600.0f, -605.0f, -609.0f, -615.0f, -620.0f, 
   };
   
   float danhSachBanKinh[] = { 1.50f, 1.50f, 1.50f, 1.00f, 1.00f,
      1.00f, 1.00f, 0.95f, 0.95f, 1.40f,  // 10
      1.50f, 0.80f, 0.80f, 0.80f, 1.20f,
      1.20f, 1.20f, 1.00f, 1.00f, 1.00f,  // 20
      1.00f, 1.70f, 1.70f, 1.70f, 1.10f,
      1.10f, 1.30f, 1.30f, 1.30f, 1.25f,  // 30
      1.25f, 1.35f, 1.35f, 1.35f, 1.50f,
      1.50f, 1.80f, 1.80f, 2.50f, 2.50f,  // 40
     
      2.50f, 1.30f, 1.30f, 2.00f, 1.10f,
      1.10f, 1.10f, 1.10f, 1.10f, 1.35f,  // 50
   
      1.35f, 1.35f, 1.35f, 1.60f, 1.60f,
      1.15f, 1.15f, 1.15f, 1.15f, 1.15f,  // 60
      1.15f, 1.15f, 1.15f, 0.95f, 1.55f,
      2.05f, 2.05f, 1.05f, 1.05f, 1.05f,  // 79
      0.95f, 1.35f, 1.35f, 1.65f, 1.65f,
   };

   float danhSachDuongRa[] = { kDUONG_X, kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X, // 10
      kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X,
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_X, // 20
      kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X,
      kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, // 30
      kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X,
      kDUONG_X, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X, // 40

      kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X,
      kDUONG_Z, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_X, // 50
   
      kDUONG_X, kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, // 60
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X, // 70
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_X, kDUONG_X,
   };


   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 1.0f;  quaternion.y = 1.0f;  quaternion.z = 1.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   
   unsigned short chiSoTraiBanh = 0;
   unsigned short soLuongTraiBanh = 75;
   while( chiSoTraiBanh < soLuongTraiBanh ) {
      // ---- bán kính
      float banKinh = danhSachBanKinh[chiSoTraiBanh];
      // --- vị trí
      viTri.x = danhSachViTri[chiSoTraiBanh];
      viTri.y = 10.1f + banKinh;
      viTri.z = 3.0f;

      danhSachVat[chiSoTraiBanh].duongVao = kDUONG_X;
      danhSachVat[chiSoTraiBanh].duongRa = danhSachDuongRa[chiSoTraiBanh];
      danhSachVat[chiSoTraiBanh].hinhDang.hinhCau = datHinhCau( banKinh, &(danhSachVat[chiSoTraiBanh].baoBiVT) );
      danhSachVat[chiSoTraiBanh].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[chiSoTraiBanh].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoTraiBanh]), &phongTo, &quaternion, &viTri );
      // ---- chọn họa tiết và cỡ kích trái banh
      chonVaToHoaTietNgauNhien( &(danhSachVat[chiSoTraiBanh].soHoaTiet), &(danhSachVat[chiSoTraiBanh].hoaTiet) );

      chiSoTraiBanh++;
   }

   // ---- CÁC TRÁI BANH ĐANG CHẠY RA khi bắt đầu mô phỏng
   float danhSachViTriChayRa[] = { -14.0f, -17.0f, -20.0f, -30.0f, -32.5f,
      -35.0f, -37.5f, -40.0f, -58.0f, -62.0f,  // 10
      -72.0f, -74.0f, -78.0f, -81.0f, -84.0f,
      -90.0f, -92.0f, -95.0f, -97.5f, -100.0f,  // 20
   };
   
   float danhSachBanKinhChayRa[] = { 1.25f, 1.25f, 1.25f, 1.00f, 1.00f,
      1.00f, 1.00f, 1.00f, 1.95f, 1.95f,  // 10
      1.50f, 1.50f, 1.70f, 1.70f, 1.70f,
      0.90f, 0.90f, 1.25f, 1.25f, 1.25f,  // 20
   };

   unsigned short soLuongTraiBanhTruoc = chiSoTraiBanh;
   soLuongTraiBanh = chiSoTraiBanh + 20;
   while( chiSoTraiBanh < soLuongTraiBanh ) {
      // ---- bán kính
      float banKinh = danhSachBanKinhChayRa[chiSoTraiBanh - soLuongTraiBanhTruoc];
      // --- vị trí
      viTri.x = danhSachViTriChayRa[chiSoTraiBanh - soLuongTraiBanhTruoc];
      viTri.y = 10.1f + banKinh;
      viTri.z = -3.0f;

      danhSachVat[chiSoTraiBanh].duongVao = kDUONG_X;
      danhSachVat[chiSoTraiBanh].duongRa = kDUONG_X; // đang chạy ra đường này
      danhSachVat[chiSoTraiBanh].hinhDang.hinhCau = datHinhCau( banKinh, &(danhSachVat[chiSoTraiBanh].baoBiVT) );
      danhSachVat[chiSoTraiBanh].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[chiSoTraiBanh].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoTraiBanh]), &phongTo, &quaternion, &viTri );
      // ---- trái banh này -ang đi ra ngoài
      danhSachVat[chiSoTraiBanh].thaiTrang = kTHAI_TRANG__RA_VONG;
      // ---- chọn họa tiết và cỡ kích trái banh
      chonVaToHoaTietNgauNhien( &(danhSachVat[chiSoTraiBanh].soHoaTiet), &(danhSachVat[chiSoTraiBanh].hoaTiet) );
      
      chiSoTraiBanh++;
   }
   
   return chiSoTraiBanh;
}

unsigned short datCacTraiBanhTrenLoHuongZ( VatThe *danhSachVat ) {
   
   float danhSachViTri[] = {-12.0f, -15.0f, -18.0f, -21.0f, -24.5f,
      -28.5f,  -32.0f,  -35.5f,   -39.0f,  -42.5f,  // 10
      -46.5f,  -52.0f,  -71.0f,   -73.5f,  -76.0f,
      -78.5f,  -81.0f,  -103.0f, -107.0f, -111.0f,  // 20
      -124.0f, -132.0f, -136.0f, -186.0f, -190.0f,
      -194.0f, -198.0,   -202.0f, -225.0f, -229.0,  // 30
      -250.0f, -254.0f, -258.0f, -262.0f,  -266.0,
      -270.0f, -295.0f, -298.0f, -301.0f,  -330.0,  // 40
      -356.0f, -359.0f, -362.0f, -377.0f,  -382.0f,
      -386.0f, -390.0f, -395.0f, -399.0f,  -414.0f, // 50
      -417.5f, -425.0f, -429.0f, -433.0f,  -437.0f,
      -441.0f, -445.0f, -449.0f, -480.0f, -484.0f,  // 60
      -488.0f, -492.0f, -496.0f, -502.0f, -508.0f,
      -516.0f, -519.0f, -522.0f, -525.0f, -575.0f,  // 70
      -624.0f, -640.0f, -648.0f, -660.0f, -663.0f,
      -667.0f, -671.0f, -696.0f, -699.0f, -702.0f,  // 80
      -714.0f, -745.0f, -748.5f, -755.0f, -759.0f,
      -763.0f, -767.0f, -784.0f, -792.0f, -796.0f,  // 90
      -802.0f, -806.0f, -810.0f, -814.0f, -818.0,
      -822.0f, -835.0f, -838.0,  -850.0f, -854.0f,  // 100
      -858.0f, -862.0f, -866.0, -874.0f, -895.0f,
      -898.0f, -901.0f, -912.0f, -915.0f, -918.0f,  // 110
      -921.0f, -924.5f, -928.5f,  -932.0f,  -935.5f,
      -939.0f,  -942.5f, -946.5f,  -952.0f,  -971.0f,  // 120
      -973.5f,  -976.0f, -978.5f,  -981.0f,  -1003.0f,
      -1007.0f, -1011.0f, -1015.0f, -1025.0f, -1028.0f,  // 130
      -1033.0f, -1047.5f, -1051.5f, -1056.0f, -1060.0f,
      -1065.0f, -1069.0f, -1076.0f, -1082.0f, -1086.0f,  // 140
      -1090.0f, -1094.0f, -1099.0f, -1104.0f, -1109.0f,
      -1117.0f, -1121.0f, -1181.0f, -1185.0f, -1188.0f,  // 150
      -1193.0f, -1197.5f, -1201.5f, -1206.0f, -1210.0f,
      -1215.0f, -1219.0f, -1236.0f, -1242.0f, -1246.0f,  // 160
      -1250.0f, -1254.0f, -1269.0f, -1274.0f, -1279.0f,
      -1287.0f, -1291.0f, -1304.0f, -1312.0f, -1316.0f,  // 170
      -1322.0f, -1326.0f, -1330.0f, -1334.0f, -1338.0,
      -1342.0f, -1345.0f, -1349.0,  -1353.0f, -1364.0f,  // 180
      -1378.0f, -1382.0f,  -1386.0, -1390.0f, -1395.0f,
      -1399.0f, -1401.0f, -1409.0f, -1413.0f, -1419.0f, // 190
   };
   
float danhSachBanKinh[] = { 1.10f, 1.10f, 1.10f, 1.10f, 1.10f,
      1.40f, 1.40f, 1.40f, 1.40f, 1.40f,   // 10
      1.80f, 1.80f, 0.90f, 0.90f, 0.90f,
      0.95f, 0.95f, 1.50f, 1.50f, 1.50f,   // 20
      1.23f, 1.70f, 1.30f, 1.50f, 1.50f,
      1.80f, 1.80f, 1.50f, 1.50f, 1.50f,   // 30
      1.50f, 1.50f, 1.50f, 1.50f, 1.50f,
      2.00f, 1.35f, 1.35f, 1.35f, 2.50f,   // 40
      1.00f, 1.00f, 1.00f, 2.00f, 1.70f,
      1.40f, 1.10f, 1.80f, 1.80f, 1.80f,   // 50
      1.05f, 1.70f, 1.70f, 1.70f, 1.50f,
      1.50f, 1.50f, 1.50f, 1.70f, 1.50f,   // 60
      1.50f, 1.50f, 1.50f, 2.00f, 2.00f,
      1.10f, 1.10f, 1.10f, 1.10f, 2.20f,   // 70
      1.30f, 1.30f, 2.10f, 1.20f, 1.20f,
      1.50f, 1.50f, 1.10f, 1.10f, 1.10f,   // 80
      1.80f, 1.25f, 1.25f, 1.50f, 1.50f,
      1.50f, 1.50f, 1.23f, 1.70f, 1.30f,   // 90
      1.50f, 1.50f, 1.50f, 1.80f, 1.80f,
      1.50f, 1.50f, 1.50f, 1.50f, 1.50f,   // 100
      1.50f, 1.50f, 1.50f, 2.00f, 1.35f,
      1.35f, 1.35f, 1.10f, 1.10f, 1.10f,   // 110
      1.10f, 1.10f, 1.40f, 1.40f, 1.40f,
      1.40f, 1.40f, 1.80f, 1.80f, 0.90f,   // 120
      0.90f, 0.90f, 0.95f, 0.95f, 1.50f,
      1.50f, 1.50f, 1.30f, 1.30f, 1.30f,   // 130
      1.00f, 1.00f, 1.45f, 1.25f, 1.80f,
      1.25f, 1.25f, 1.50f, 2.00f, 1.35f,   // 140
      1.35f, 1.35f, 2.50f, 1.00f, 1.00f,
      1.00f, 2.00f, 1.30f, 1.30f, 1.30f,   // 150
      1.00f, 1.00f, 1.45f, 1.25f, 1.80f,
      1.25f, 1.25f, 1.50f, 2.00f, 1.35f,   // 160
      1.35f, 1.35f, 2.50f, 1.00f, 1.00f,
      1.00f, 2.00f, 1.23f, 1.70f, 1.30f,   // 170
      1.50f, 1.50f, 1.50f, 1.80f, 1.80f,
      1.50f, 1.50f, 1.50f, 1.50f, 1.50f,   // 180
      1.50f, 1.50f, 1.50f, 2.00f, 1.35f,
      1.35f, 1.35f, 1.05f, 1.05f, 1.05f,   // 190
      1.50f, 1.50f, 1.23f, 1.70f, 1.30f,
      1.45f, 1.45f, 1.05f, 1.80f, 1.80f,   // 200
      };

float danhSachDuongRa[] = { kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_X, kDUONG_X, kDUONG_X, kDUONG_X, kDUONG_X,  // 10
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X,  // 20
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X,
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X,  // 30
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,  // 40
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X,  // 50
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X,  // 60
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X,
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X,  // 70
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X,  // 80
      kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_X,
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z,  // 90
      kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X, kDUONG_X,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_Z, kDUONG_Z,  // 100
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,  // 110
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X,
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z,  // 120
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X,
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z,  // 130
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_X,
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_X, kDUONG_Z,  // 140
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,  // 150
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_X,
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_X, kDUONG_Z,  // 160
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_Z,  // 170
      kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X, kDUONG_X,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_Z, kDUONG_Z,  // 180
      kDUONG_Z, kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X, // 190
      kDUONG_X, kDUONG_X, kDUONG_Z, kDUONG_Z, kDUONG_Z,
      kDUONG_Z, kDUONG_Z, kDUONG_X, kDUONG_X, kDUONG_X,  // 200
   };

   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 1.0f;  quaternion.y = 1.0f;  quaternion.z = 1.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   
   unsigned short chiSoTraiBanh = 0;
   unsigned short soLuongTraiBanh = 187;
   while( chiSoTraiBanh < soLuongTraiBanh ) {
      // ---- chọn bán kính
      float banKinh = danhSachBanKinh[chiSoTraiBanh];

      viTri.x = -3.0f;
      viTri.y = 10.1f + banKinh;
      viTri.z = danhSachViTri[chiSoTraiBanh];
      // ---- chọn vị trí cho các trái banh

      danhSachVat[chiSoTraiBanh].duongVao = kDUONG_Z;
      danhSachVat[chiSoTraiBanh].duongRa = danhSachDuongRa[chiSoTraiBanh];
      danhSachVat[chiSoTraiBanh].hinhDang.hinhCau = datHinhCau( banKinh, &(danhSachVat[chiSoTraiBanh].baoBiVT) );
      danhSachVat[chiSoTraiBanh].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[chiSoTraiBanh].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoTraiBanh]), &phongTo, &quaternion, &viTri );
      
      // ---- chọn họa tiết và cỡ kích trái banh
      chonVaToHoaTietNgauNhien( &(danhSachVat[chiSoTraiBanh].soHoaTiet), &(danhSachVat[chiSoTraiBanh].hoaTiet) );
      
      chiSoTraiBanh++;
   }
   
   // ---- CÁC TRÁI BANH ĐANG CHẠY RA khi bắt đầu mô phỏng
   float danhSachViTriChayRa[] = { -24.0f, -26.0f, -31.0f, -35.0f, -38.0f,
      -45.0f, -47.5f, -52.5f, -57.0f, -62.0f,  // 10
      -68.0f, -71.0f, -74.0f, -82.0f, -86.0f,
      -90.0f, -94.0f, -100.0f, -105.0f, -108.0f,  // 20
   };
   
   float danhSachBanKinhChayRa[] = { 0.90f, 0.90f, 1.50f, 1.30f, 1.30f,
      1.00f, 1.00f, 1.00f, 1.95f, 1.95f,  // 10
      1.25f, 1.25f, 1.25f, 1.75f, 1.75f,
      1.75f, 1.75f, 2.35, 1.35f, 1.35f,   // 20
   };
   
   unsigned short soLuongTraiBanhTruoc = chiSoTraiBanh;
   soLuongTraiBanh = chiSoTraiBanh + 20;

   while( chiSoTraiBanh < soLuongTraiBanh ) {
      // ---- chọn bán kính
      float banKinh = danhSachBanKinhChayRa[chiSoTraiBanh - soLuongTraiBanhTruoc];
      
      viTri.x = 3.0f;
      viTri.y = 10.1f + banKinh;
      viTri.z = danhSachViTriChayRa[chiSoTraiBanh - soLuongTraiBanhTruoc];
      // ---- chọn vị trí cho các trái banh

      danhSachVat[chiSoTraiBanh].duongVao = kDUONG_Z;
      danhSachVat[chiSoTraiBanh].duongRa = kDUONG_Z;
      danhSachVat[chiSoTraiBanh].hinhDang.hinhCau = datHinhCau( banKinh, &(danhSachVat[chiSoTraiBanh].baoBiVT) );
      danhSachVat[chiSoTraiBanh].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[chiSoTraiBanh].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[chiSoTraiBanh]), &phongTo, &quaternion, &viTri );
      // ---- đặt thại trạng trái banh này đi ra ngoài
      danhSachVat[chiSoTraiBanh].thaiTrang = kTHAI_TRANG__RA_VONG;
      
      // ---- chọn họa tiết và cỡ kích trái banh
      chonVaToHoaTietNgauNhien( &(danhSachVat[chiSoTraiBanh].soHoaTiet), &(danhSachVat[chiSoTraiBanh].hoaTiet) );
      
      chiSoTraiBanh++;
   }

   return chiSoTraiBanh;
}


unsigned short datBongBong( VatThe *danhSachVat ) {
 
   Vecto truc;
   truc.x = 1.0f;    truc.y = 1.0f;    truc.z = 0.0f;
   Quaternion xoay;
   xoay.w = 1.0f;   xoay.x = 0.0f;    xoay.y = 0.0f;    xoay.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   Mau mauRanh;
   Mau mauTam;

   // ---- trái banh vai chánh
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;    mauRanh.dd = 0.2f;   mauRanh.p = 0.3f;
   mauTam.d = 0.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;    mauTam.dd = 0.0f;   mauTam.p = 0.3f;
   viTri.x = -4.0f;  viTri.y = 5.0f; viTri.z = 470.0f;
   danhSachVat[0].hinhDang.hinhCau = datHinhCau( 0.7f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &xoay, &viTri );
   danhSachVat[0].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[0].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[0].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.8f;    mauRanh.x = 1.0f;
   mauTam.d = 0.5f;    mauTam.l = 1.0f;    mauTam.x = 0.0f;
   viTri.x = -4.8f;  viTri.y = 4.3f; viTri.z = 472.0f;
   danhSachVat[1].hinhDang.hinhCau = datHinhCau( 0.25f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &xoay, &viTri );
   danhSachVat[1].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[1].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[1].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.5f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 0.3f;
   viTri.x = -8.8f;  viTri.y = 3.3f; viTri.z = 465.0f;
   danhSachVat[2].hinhDang.hinhCau = datHinhCau( 0.3f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &xoay, &viTri );
   danhSachVat[2].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[2].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[2].viTriDau = viTri;

   // ----- độc lập
   mauRanh.d = 1.0f;    mauRanh.l = 0.8f;    mauRanh.x = 1.0f;
   mauTam.d = 0.5f;    mauTam.l = 1.0f;    mauTam.x = 0.0f;
   viTri.x = -18.0f;  viTri.y = 6.0f; viTri.z = 445.0f;
   danhSachVat[3].hinhDang.hinhCau = datHinhCau( 0.2f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &xoay, &viTri );
   danhSachVat[3].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[3].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[3].viTriDau = viTri;

   // ---- nhóm
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.3f;    mauTam.x = 1.0f;
   viTri.x = -65.0f;  viTri.y = 10.0f; viTri.z = 420.0f;
   danhSachVat[4].hinhDang.hinhCau = datHinhCau( 0.5f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &xoay, &viTri );
   danhSachVat[4].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[4].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[4].viTriDau = viTri;

   mauRanh.d = 0.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.3f;    mauTam.x = 0.0f;
   viTri.x = -70.0f;  viTri.y = 5.0f; viTri.z = 413.0f;
   danhSachVat[5].hinhDang.hinhCau = datHinhCau( 0.8f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &xoay, &viTri );
   danhSachVat[5].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[5].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[5].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -68.5f;  viTri.y = 5.5f; viTri.z = 410.0f;
   danhSachVat[6].hinhDang.hinhCau = datHinhCau( 0.2f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[6].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &xoay, &viTri );
   danhSachVat[6].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[6].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[6].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -68.0f;  viTri.y = 6.0f; viTri.z = 407.0f;
   danhSachVat[7].hinhDang.hinhCau = datHinhCau( 0.7f, &(danhSachVat[7].baoBiVT) );
   danhSachVat[7].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[7].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &xoay, &viTri );
   danhSachVat[7].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[7].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[7].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -72.0f;  viTri.y = 7.5f; viTri.z = 407.0f;
   danhSachVat[8].hinhDang.hinhCau = datHinhCau( 0.5f, &(danhSachVat[8].baoBiVT) );
   danhSachVat[8].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[8].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[8]), &phongTo, &xoay, &viTri );
   danhSachVat[8].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[8].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[8].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.7f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.5f;    mauTam.x = 1.0f;
   viTri.x = -74.0f;  viTri.y = 5.5f; viTri.z = 405.0f;
   danhSachVat[9].hinhDang.hinhCau = datHinhCau( 0.1f, &(danhSachVat[9].baoBiVT) );
   danhSachVat[9].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[9].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[9]), &phongTo, &xoay, &viTri );
   danhSachVat[9].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[9].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[9].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.3f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -85.0f;  viTri.y = 5.5f; viTri.z = 380.0f;
   danhSachVat[10].hinhDang.hinhCau = datHinhCau( 0.21f, &(danhSachVat[10].baoBiVT) );
   danhSachVat[10].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[10].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10]), &phongTo, &xoay, &viTri );
   danhSachVat[10].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[10].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[10].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 0.0f;
   viTri.x = -88.0f;  viTri.y = 4.0f; viTri.z = 372.0f;
   danhSachVat[11].hinhDang.hinhCau = datHinhCau( 0.5f, &(danhSachVat[11].baoBiVT) );
   danhSachVat[11].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[11].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[11]), &phongTo, &xoay, &viTri );
   danhSachVat[11].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[11].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[11].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.5f;    mauTam.l = 1.0f;    mauTam.x = 0.5f;
   viTri.x = -90.0f;  viTri.y = 6.0f; viTri.z = 372.0f;
   danhSachVat[12].hinhDang.hinhCau = datHinhCau( 0.32f, &(danhSachVat[12].baoBiVT) );
   danhSachVat[12].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[12].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[12]), &phongTo, &xoay, &viTri );
   danhSachVat[12].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[12].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[12].viTriDau = viTri;

   mauRanh.d = 0.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -102.0f;  viTri.y = 4.0f; viTri.z = 372.0f;
   danhSachVat[13].hinhDang.hinhCau = datHinhCau( 0.4f, &(danhSachVat[13].baoBiVT) );
   danhSachVat[13].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[13].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[13]), &phongTo, &xoay, &viTri );
   danhSachVat[13].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[13].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[13].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.8f;    mauRanh.x = 0.8f;
   mauTam.d = 0.0f;    mauTam.l = 0.3f;    mauTam.x = 1.0f;
   viTri.x = -130.0f;  viTri.y = 5.8f; viTri.z = 350.0f;
   danhSachVat[14].hinhDang.hinhCau = datHinhCau( 0.28f, &(danhSachVat[14].baoBiVT) );
   danhSachVat[14].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[14].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[14]), &phongTo, &xoay, &viTri );
   danhSachVat[14].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[14].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[14].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -131.0f;  viTri.y = 5.0f; viTri.z = 350.5f;
   danhSachVat[15].hinhDang.hinhCau = datHinhCau( 0.30f, &(danhSachVat[15].baoBiVT) );
   danhSachVat[15].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[15].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[15]), &phongTo, &xoay, &viTri );
   danhSachVat[15].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[15].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[15].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -143.0f;  viTri.y = 10.0f; viTri.z = 350.5f;
   danhSachVat[16].hinhDang.hinhCau = datHinhCau( 0.25f, &(danhSachVat[16].baoBiVT) );
   danhSachVat[16].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[16].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[16]), &phongTo, &xoay, &viTri );
   danhSachVat[16].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[16].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[16].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -158.0f;  viTri.y = 18.0f; viTri.z = 351.0f;
   danhSachVat[17].hinhDang.hinhCau = datHinhCau( 0.3f, &(danhSachVat[17].baoBiVT) );
   danhSachVat[17].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[17].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[17]), &phongTo, &xoay, &viTri );
   danhSachVat[17].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[17].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[17].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -157.0f;  viTri.y = 7.0f; viTri.z = 355.0f;
   danhSachVat[18].hinhDang.hinhCau = datHinhCau( 0.25f, &(danhSachVat[18].baoBiVT) );
   danhSachVat[18].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[18].chietSuat = 11.0f;
   datBienHoaChoVat( &(danhSachVat[18]), &phongTo, &xoay, &viTri );
   danhSachVat[18].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[18].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[18].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -153.0f;  viTri.y = 10.5f; viTri.z = 360.0f;
   danhSachVat[19].hinhDang.hinhCau = datHinhCau( 0.2f, &(danhSachVat[19].baoBiVT) );
   danhSachVat[19].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[19].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[19]), &phongTo, &xoay, &viTri );
   danhSachVat[19].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[19].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[19].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -155.0f;  viTri.y = 15.5f; viTri.z = 306.0f;
   danhSachVat[20].hinhDang.hinhCau = datHinhCau( 0.1f, &(danhSachVat[20].baoBiVT) );
   danhSachVat[20].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[20].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[20]), &phongTo, &xoay, &viTri );
   danhSachVat[20].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[20].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[20].viTriDau = viTri;
   
   // ---- nhóm
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -163.0f;  viTri.y = 13.8f; viTri.z = 275.0f;
   danhSachVat[21].hinhDang.hinhCau = datHinhCau( 0.22f, &(danhSachVat[21].baoBiVT) );
   danhSachVat[21].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[21].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[21]), &phongTo, &xoay, &viTri );
   danhSachVat[21].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[21].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[21].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.8f;    mauTam.x = 1.0f;
   viTri.x = -162.0f;  viTri.y = 14.3f; viTri.z = 280.0f;
   danhSachVat[22].hinhDang.hinhCau = datHinhCau( 0.1f, &(danhSachVat[22].baoBiVT) );
   danhSachVat[22].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[22].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[22]), &phongTo, &xoay, &viTri );
   danhSachVat[22].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[22].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[22].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.5f;    mauTam.x = 0.5f;
   viTri.x = -152.0f;  viTri.y = 14.3f; viTri.z = 278.0f;
   danhSachVat[23].hinhDang.hinhCau = datHinhCau( 0.18f, &(danhSachVat[23].baoBiVT) );
   danhSachVat[23].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[23].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[23]), &phongTo, &xoay, &viTri );
   danhSachVat[23].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[23].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[23].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 0.5f;
   viTri.x = -172.0f;  viTri.y = 17.8f; viTri.z = 275.0f;
   danhSachVat[24].hinhDang.hinhCau = datHinhCau( 0.19f, &(danhSachVat[24].baoBiVT) );
   danhSachVat[24].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[24].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[24]), &phongTo, &xoay, &viTri );
   danhSachVat[24].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[24].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[24].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 0.5f;
   viTri.x = -180.0f;  viTri.y = 15.6f; viTri.z = 270.0f;
   danhSachVat[25].hinhDang.hinhCau = datHinhCau( 0.21f, &(danhSachVat[25].baoBiVT) );
   danhSachVat[25].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[25].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[25]), &phongTo, &xoay, &viTri );
   danhSachVat[25].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[25].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[25].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -130.0f;  viTri.y = 14.6f; viTri.z = 272.0f;
   danhSachVat[26].hinhDang.hinhCau = datHinhCau( 0.35f, &(danhSachVat[26].baoBiVT) );
   danhSachVat[26].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[26].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[26]), &phongTo, &xoay, &viTri );
   danhSachVat[26].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[26].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[26].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -134.0f;  viTri.y = 18.0f; viTri.z = 278.0f;
   danhSachVat[27].hinhDang.hinhCau = datHinhCau( 0.35f, &(danhSachVat[27].baoBiVT) );
   danhSachVat[27].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[27].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[27]), &phongTo, &xoay, &viTri );
   danhSachVat[27].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[27].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[27].viTriDau = viTri;

   // ---- độc lập
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 0.5f;
   viTri.x = -131.0f;  viTri.y = 13.9f; viTri.z = 230.0f;
   danhSachVat[28].hinhDang.hinhCau = datHinhCau( 0.14f, &(danhSachVat[28].baoBiVT) );
   danhSachVat[28].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[28].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[28]), &phongTo, &xoay, &viTri );
   danhSachVat[28].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[28].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[28].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 0.5f;
   viTri.x = -135.0f;  viTri.y = 17.2f; viTri.z = 218.0f;
   danhSachVat[29].hinhDang.hinhCau = datHinhCau( 0.3f, &(danhSachVat[29].baoBiVT) );
   danhSachVat[29].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[29].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[29]), &phongTo, &xoay, &viTri );
   danhSachVat[29].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[29].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[29].viTriDau = viTri;
   
   // ---- nhóm
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 0.5f;
   viTri.x = -140.0f;  viTri.y = 16.0f; viTri.z = 288.0f;
   danhSachVat[30].hinhDang.hinhCau = datHinhCau( 0.13f, &(danhSachVat[30].baoBiVT) );
   danhSachVat[30].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[30].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[30]), &phongTo, &xoay, &viTri );
   danhSachVat[30].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[30].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[30].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.7f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 1.0f;    mauTam.x = 0.5f;
   viTri.x = -143.0f;  viTri.y = 5.5f; viTri.z = 285.0f;
   danhSachVat[31].hinhDang.hinhCau = datHinhCau( 0.3f, &(danhSachVat[31].baoBiVT) );
   danhSachVat[31].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[31].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[31]), &phongTo, &xoay, &viTri );
   danhSachVat[31].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[31].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[31].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -143.0f;  viTri.y = 6.5f; viTri.z = 275.0f;
   danhSachVat[32].hinhDang.hinhCau = datHinhCau( 0.25f, &(danhSachVat[32].baoBiVT) );
   danhSachVat[32].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[32].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[32]), &phongTo, &xoay, &viTri );
   danhSachVat[32].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[32].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[32].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -142.0f;  viTri.y = 6.5f; viTri.z = 284.0f;
   danhSachVat[33].hinhDang.hinhCau = datHinhCau( 0.25f, &(danhSachVat[33].baoBiVT) );
   danhSachVat[33].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[33].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[33]), &phongTo, &xoay, &viTri );
   danhSachVat[33].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[33].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[33].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -130.0f;  viTri.y = 16.5f; viTri.z = 275.0f;
   danhSachVat[34].hinhDang.hinhCau = datHinhCau( 0.1f, &(danhSachVat[34].baoBiVT) );
   danhSachVat[34].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[34].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[34]), &phongTo, &xoay, &viTri );
   danhSachVat[34].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[34].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[34].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -140.0f;  viTri.y = 15.3f; viTri.z = 285.0f;
   danhSachVat[35].hinhDang.hinhCau = datHinhCau( 0.17f, &(danhSachVat[35].baoBiVT) );
   danhSachVat[35].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[35].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[35]), &phongTo, &xoay, &viTri );
   danhSachVat[35].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[35].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[35].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.6f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -148.0f;  viTri.y = 14.0f; viTri.z = 273.0f;
   danhSachVat[36].hinhDang.hinhCau = datHinhCau( 0.13f, &(danhSachVat[36].baoBiVT) );
   danhSachVat[36].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[36].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[36]), &phongTo, &xoay, &viTri );
   danhSachVat[36].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[36].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[36].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.6f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 12.0f;    mauTam.x = 1.0f;
   viTri.x = -158.0f;  viTri.y = 3.8f; viTri.z = 263.0f;
   danhSachVat[37].hinhDang.hinhCau = datHinhCau( 0.3f, &(danhSachVat[37].baoBiVT) );
   danhSachVat[37].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[37].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[37]), &phongTo, &xoay, &viTri );
   danhSachVat[37].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[37].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[37].viTriDau = viTri;
   
   // ----
   mauRanh.d = 0.0f;    mauRanh.l = 0.9f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -155.0f;  viTri.y = 4.8f; viTri.z = 315.0f;
   danhSachVat[38].hinhDang.hinhCau = datHinhCau( 0.35f, &(danhSachVat[38].baoBiVT) );
   danhSachVat[38].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[38].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[38]), &phongTo, &xoay, &viTri );
   danhSachVat[38].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[38].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[38].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.1f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 0.5f;
   viTri.x = -130.0f;  viTri.y = 4.0f; viTri.z = 300.0f;
   danhSachVat[39].hinhDang.hinhCau = datHinhCau( 0.19f, &(danhSachVat[39].baoBiVT) );
   danhSachVat[39].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[39].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[39]), &phongTo, &xoay, &viTri );
   danhSachVat[39].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[39].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[39].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -142.0f;  viTri.y = 3.6f; viTri.z = 302.0f;
   danhSachVat[40].hinhDang.hinhCau = datHinhCau( 0.4f, &(danhSachVat[40].baoBiVT) );
   danhSachVat[40].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[40].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[40]), &phongTo, &xoay, &viTri );
   danhSachVat[40].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[40].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[40].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 1.0f;    mauRanh.x = 0.0f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -132.0f;  viTri.y = 5.6f; viTri.z = 300.0f;
   danhSachVat[41].hinhDang.hinhCau = datHinhCau( 0.4f, &(danhSachVat[41].baoBiVT) );
   danhSachVat[41].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[41].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[41]), &phongTo, &xoay, &viTri );
   danhSachVat[41].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[41].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[41].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.5f;    mauTam.l = 1.0f;    mauTam.x = 0.0f;
   viTri.x = -136.0f;  viTri.y = 6.5f; viTri.z = 280.0f;
   danhSachVat[42].hinhDang.hinhCau = datHinhCau( 0.2f, &(danhSachVat[42].baoBiVT) );
   danhSachVat[42].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[42].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[42]), &phongTo, &xoay, &viTri );
   danhSachVat[42].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[42].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[42].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.1f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 1.0f;    mauTam.x = 0.0f;
   viTri.x = -150.0f;  viTri.y = 7.0f; viTri.z = 295.0f;
   danhSachVat[43].hinhDang.hinhCau = datHinhCau( 0.1f, &(danhSachVat[43].baoBiVT) );
   danhSachVat[43].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[43].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[43]), &phongTo, &xoay, &viTri );
   danhSachVat[43].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[43].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[43].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.7f;    mauRanh.x = 1.0f;
   mauTam.d = 1.0f;    mauTam.l = 1.0f;    mauTam.x = 0.0f;
   viTri.x = -188.0f;  viTri.y = 4.2f; viTri.z = 264.0f;
   danhSachVat[44].hinhDang.hinhCau = datHinhCau( 0.1f, &(danhSachVat[44].baoBiVT) );
   danhSachVat[44].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[44].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[44]), &phongTo, &xoay, &viTri );
   danhSachVat[44].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[44].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[44].viTriDau = viTri;

   mauRanh.d = 0.8f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -193.0f;  viTri.y = 8.0f; viTri.z = 293.0f;
   danhSachVat[45].hinhDang.hinhCau = datHinhCau( 0.22f, &(danhSachVat[45].baoBiVT) );
   danhSachVat[45].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[45].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[45]), &phongTo, &xoay, &viTri );
   danhSachVat[45].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[45].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[45].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.2f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 0.0f;
   viTri.x = -150.0f;  viTri.y = 14.6f; viTri.z = 283.0f;
   danhSachVat[46].hinhDang.hinhCau = datHinhCau( 0.3f, &(danhSachVat[46].baoBiVT) );
   danhSachVat[46].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[46].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[46]), &phongTo, &xoay, &viTri );
   danhSachVat[46].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[46].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[46].viTriDau = viTri;

   
   mauRanh.d = 0.0f;    mauRanh.l = 0.7f;    mauRanh.x = 0.7f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -155.0f;  viTri.y = 10.0f; viTri.z = 308.0f;
   danhSachVat[47].hinhDang.hinhCau = datHinhCau( 0.1f, &(danhSachVat[47].baoBiVT) );
   danhSachVat[47].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[47].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[47]), &phongTo, &xoay, &viTri );
   danhSachVat[47].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[47].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[47].viTriDau = viTri;

   mauRanh.d = 0.4f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -141.0f;  viTri.y = 24.0f; viTri.z = 284.0f;
   danhSachVat[48].hinhDang.hinhCau = datHinhCau( 0.2f, &(danhSachVat[48].baoBiVT) );
   danhSachVat[48].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[48].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[48]), &phongTo, &xoay, &viTri );
   danhSachVat[48].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[48].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[48].viTriDau = viTri;

   // ---- nhóm bong bóng cuối
   mauRanh.d = 0.4f;    mauRanh.l = 0.0f;    mauRanh.x = 1.0f;
   mauTam.d = 0.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -811.0f;  viTri.y = 25.0f; viTri.z = 1132.0f + 30.0f;
   danhSachVat[49].hinhDang.hinhCau = datHinhCau( 0.25f, &(danhSachVat[49].baoBiVT) );
   danhSachVat[49].loai = kLOAI_HINH_DANG__HINH_CAU;

   danhSachVat[49].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[49]), &phongTo, &xoay, &viTri );
   danhSachVat[49].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[49].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[49].viTriDau = viTri;

   mauRanh.d = 0.0f;    mauRanh.l = 0.7f;    mauRanh.x = 0.7f;    mauRanh.dd = 0.3f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;    mauTam.dd = 0.0f;
   viTri.x = -807.0f;  viTri.y = 27.0f; viTri.z = 1135.0f + 30.0f;
   danhSachVat[50].hinhDang.hinhCau = datHinhCau( 0.3f, &(danhSachVat[50].baoBiVT) );
   danhSachVat[50].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[50].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[50]), &phongTo, &xoay, &viTri );
   danhSachVat[50].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[50].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[50].viTriDau = viTri;


   mauRanh.d = 0.0f;    mauRanh.l = 1.0f;    mauRanh.x = 1.0f;    mauRanh.dd = 0.2f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;    mauTam.dd = 0.0f;
   viTri.x = -838.0f;  viTri.y = 31.0f; viTri.z = 1184.0f + 30.0f;
   danhSachVat[51].hinhDang.hinhCau = datHinhCau( 0.25f, &(danhSachVat[51].baoBiVT) );
   danhSachVat[51].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[51].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[51]), &phongTo, &xoay, &viTri );
   danhSachVat[51].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[51].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[51].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -840.0f;  viTri.y = 32.0f; viTri.z = 1175.0f + 30.0f;
   danhSachVat[52].hinhDang.hinhCau = datHinhCau( 0.4f, &(danhSachVat[52].baoBiVT) );
   danhSachVat[52].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[52].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[52]), &phongTo, &xoay, &viTri );
   danhSachVat[52].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[52].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[52].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 0.7f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -870.0f;  viTri.y = 30.0f; viTri.z = 1240.0f + 30.0f;
   danhSachVat[53].hinhDang.hinhCau = datHinhCau( 0.2f, &(danhSachVat[53].baoBiVT) );
   danhSachVat[53].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[53].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[53]), &phongTo, &xoay, &viTri );
   danhSachVat[53].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[53].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[53].viTriDau = viTri;

   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 0.0f;
   mauTam.d = 0.0f;    mauTam.l = 1.0f;    mauTam.x = 1.0f;
   viTri.x = -873.0f;  viTri.y = 31.0f; viTri.z = 1235.0f + 30.0f;
   danhSachVat[54].hinhDang.hinhCau = datHinhCau( 0.5f, &(danhSachVat[54].baoBiVT) );
   danhSachVat[54].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[54].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[54]), &phongTo, &xoay, &viTri );
   danhSachVat[54].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[54].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[54].viTriDau = viTri;
   
   mauRanh.d = 1.0f;    mauRanh.l = 0.0f;    mauRanh.x = 0.7f;
   mauTam.d = 1.0f;    mauTam.l = 0.0f;    mauTam.x = 1.0f;
   viTri.x = -877.0f;  viTri.y = 34.0f; viTri.z = 1238.0f + 30.0f;
   danhSachVat[55].hinhDang.hinhCau = datHinhCau( 0.35f, &(danhSachVat[55].baoBiVT) );
   danhSachVat[55].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[55].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[55]), &phongTo, &xoay, &viTri );
   danhSachVat[55].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
   danhSachVat[55].soHoaTiet = kHOA_TIET__DI_HUONG;
   danhSachVat[55].viTriDau = viTri;

   return 56;
}

unsigned short datCacBatDienXoay( VatThe *danhSachVat ) {
   
   Vecto truc;
   truc.x = 1.0f;    truc.y = 1.0f;    truc.z = 0.0f;
   Quaternion xoay;
   xoay.w = 1.0f;   xoay.x = 0.0f;    xoay.y = 0.0f;    xoay.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   Mau mau;
   mau.d = 1.0f;    mau.l = 1.0f;    mau.x = 1.0f;    mau.dd = 0.1f;     mau.p = 0.5f;


   // ---- hai bát diện tại -x
   viTri.x = -15.0f;  viTri.y = 17.0f; viTri.z = 15.0f;
   danhSachVat[0].hinhDang.batDien = datBatDien( 4.0f, 4.5f, 4.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[0].chietSuat = 2.4f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &xoay, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[0].viTriDau = viTri;
   
   viTri.y = 22.0f;
   danhSachVat[1].hinhDang.batDien = datBatDien( 2.2f, 2.5f, 2.2f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[1].chietSuat = 2.4f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &xoay, &viTri );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[1].viTriDau = viTri;
   
   viTri.y = 26.0f;
   danhSachVat[2].hinhDang.batDien = datBatDien( 1.5f, 1.7f, 1.5f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[2].chietSuat = 2.4f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &xoay, &viTri );
   danhSachVat[2].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[2].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[2].viTriDau = viTri;
   
   // ---- hai bát diện tại -z
   viTri.x = 15.0f;  viTri.y = 17.0f; viTri.z = -15.0f;
   danhSachVat[3].hinhDang.batDien = datBatDien( 4.0f, 4.5f, 4.0f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[3].chietSuat = 2.4f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &xoay, &viTri );
   danhSachVat[3].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[3].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[3].viTriDau = viTri;
   
   viTri.y = 22.0f;
   danhSachVat[4].hinhDang.batDien = datBatDien( 2.2f, 2.5f, 2.2f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[4].chietSuat = 2.4f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &xoay, &viTri );
   danhSachVat[4].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[4].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[4].viTriDau = viTri;

   viTri.y = 26.0f;
   danhSachVat[5].hinhDang.batDien = datBatDien( 1.5f, 1.7f, 1.5f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[5].chietSuat = 2.4f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &xoay, &viTri );
   danhSachVat[5].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[5].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[5].viTriDau = viTri;
   
   return 6;
}

unsigned short datCotNhay( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;    quaternion.x = 0.0f;     quaternion.y = 0.0f;     quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   mau.d = 0.5f;    mau.l = 0.3f;    mau.x = 0.6f;    mau.dd = 1.0f;    mau.p = 0.5f;
   Vecto viTri;
   
   float goc = 3.1415926f*0.8f;
   
   unsigned short soVatThe = 0;
   unsigned char soCot = 0;
   while ( soCot < 12 ) {
      viTri.x = 17.5f*cosf( goc );       viTri.y = 11.0f;       viTri.z = 17.5f*sinf( goc );

      danhSachVat[soVatThe].hinhDang.hinhNon = datHinhNon( 0.7f, 0.8f, 0.1f, &(danhSachVat[soVatThe].baoBiVT) );
      danhSachVat[soVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soVatThe].viTriDau = viTri;
      soVatThe++;
      
      viTri.y += 0.5f;
      danhSachVat[soVatThe].hinhDang.hinhTru = datHinhTru( 0.8f, 0.9f, &(danhSachVat[soVatThe].baoBiVT) );
      danhSachVat[soVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soVatThe].viTriDau = viTri;
      soVatThe++;
      
      viTri.y += 0.5f;
      danhSachVat[soVatThe].hinhDang.hinhNon = datHinhNon( 0.8f, 0.7f, 0.1f, &(danhSachVat[soVatThe].baoBiVT) );
      danhSachVat[soVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soVatThe].viTriDau = viTri;
      soVatThe++;
      
      soCot++;
      goc += -3.14159f*0.1f;
   }
   
   return soVatThe;
}


#pragma mark ---- NÂNG CẤP PHIM TRƯỜNG 0
void nangCapPhimTruong0( PhimTruong *phimTruong ) {

   nangCapPhimTruong0_mayQuayPhim( phimTruong );
   nangCapPhimTruong0_nhanVat( phimTruong, phimTruong->soHoatHinhDau );
   
   // ---- tăng số hoạt hình
   phimTruong->soHoatHinhDau++;
}


void nangCapPhimTruong0_mayQuayPhim( PhimTruong *phimTruong ) {
   
   unsigned short soHoatHinh = phimTruong->soHoatHinhDau;
   MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);
 

    // ---- cho xem từ trời xuống
//    mayQuayPhim->viTri.x = -150.0f;//800.0f - 2.0f*soHoatHinh;
//    mayQuayPhim->viTri.y = 150.0f;
//    mayQuayPhim->viTri.z = -90.0f;
   
//    Vecto huongNhin;
//    huongNhin.x = -0.01f;
//    huongNhin.y = -1.0f;
//    huongNhin.z = -0.0f;  // 1,5 là vận tốc trái banh vai chánh và sao gai
//    dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   // ====== Xài này cho xem các trái banh đi quanh vòng xoay
//   mayQuayPhim->viTri.x = 30.0f;
//   mayQuayPhim->viTri.y = 80.0f;
//   mayQuayPhim->viTri.z = 30.0f;
//   Vecto huongNhin;
//   huongNhin.x = 0.0f - mayQuayPhim->viTri.x;
//   huongNhin.y = 10.0f - mayQuayPhim->viTri.y;
//   huongNhin.z = 0.0f - mayQuayPhim->viTri.z;
//   dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );

 
   // ====== Xài này cho xem trái banh rớt
//    mayQuayPhim->viTri.x = -30.0f;
//    mayQuayPhim->viTri.y = 40.0f;
//    mayQuayPhim->viTri.z = -62.0f;
//    Vecto huongNhin;
//    huongNhin.x = -30.0f - mayQuayPhim->viTri.x;
//    huongNhin.y = 13.0f - mayQuayPhim->viTri.y;
//    huongNhin.z = -50.0f - mayQuayPhim->viTri.z;
//    dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
    

   // ====== Xài này cho xem sao gai rớt
//    mayQuayPhim->viTri.x = -50.0f;
//    mayQuayPhim->viTri.y = 20.0f;
//    mayQuayPhim->viTri.z = -82.0f;
//    Vecto huongNhin;
//    huongNhin.x = -45.0f - mayQuayPhim->viTri.x;
//    huongNhin.y = 20.0f - mayQuayPhim->viTri.y;
//    huongNhin.z = -40.0f - mayQuayPhim->viTri.z;
//    dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );


   // ---- cho 240 hoạt hình đầu di chuyển máy quay phim
   if( soHoatHinh < 240 ) { // 10 giây - đi thẩn đến bờ
      
      float buoc = -400.0f*soHoatHinh/240.0f;
 
      mayQuayPhim->viTri.x = 0.0f;
      mayQuayPhim->viTri.y = 3.0f;
      mayQuayPhim->viTri.z = 500.0 + buoc;
      //      printf( "mayQuayPhim->viTri.z %5.3f\n", mayQuayPhim->viTri.z );
   }
   else if( soHoatHinh < 368 ) {  //  giây - bặt đầu bay lên
      Bezier bezier;
      bezier.diemQuanTri[0].x = 0.0f;
      bezier.diemQuanTri[0].y = 3.0f;
      bezier.diemQuanTri[0].z = 100.0f;
      bezier.diemQuanTri[1].x = 0.0f;
      bezier.diemQuanTri[1].y = 3.0f;
      bezier.diemQuanTri[1].z = 70.0f;
      
      bezier.diemQuanTri[2].x = 13.0f;
      bezier.diemQuanTri[2].y = 22.0f;
      bezier.diemQuanTri[2].z = 37.0f;
      
      bezier.diemQuanTri[3].x = 27.0f;
      bezier.diemQuanTri[3].y = 25.0f;
      bezier.diemQuanTri[3].z = 17.0f;
      float buoc = (soHoatHinh-240)/128.0f;
      // ---- -(1 - x)^3 + 1
      buoc = (1.0f - buoc);
      buoc = -buoc*buoc*buoc + 1;
      
      Vecto viTri = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTri.x;
      mayQuayPhim->viTri.y = viTri.y;
      mayQuayPhim->viTri.z = viTri.z;
      
      float buocY = buoc*(10.0f - 3.0f);
      Vecto huongNhin;
      huongNhin.x = 0.0f - viTri.x;
      huongNhin.y = buocY + 3.0f - viTri.y;
      huongNhin.z = 0.0f - viTri.z;
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 440 ) {  // ngó vòng xoay
      mayQuayPhim->viTri.x = 27.0f;
      mayQuayPhim->viTri.y = 25.0f;
      mayQuayPhim->viTri.z = 17.0f;
      Vecto huongNhin;
      huongNhin.x = 0.0f - mayQuayPhim->viTri.x;
      huongNhin.y = 10.0f - mayQuayPhim->viTri.y;
      huongNhin.z = 0.0f - mayQuayPhim->viTri.z;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );

   }
   else if( soHoatHinh < 550 ) {  // ngó vòng xoay
      Bezier bezier;
      bezier.diemQuanTri[0].x = 27.0f;
      bezier.diemQuanTri[0].y = 25.0f;
      bezier.diemQuanTri[0].z = 17.0f;
      
      bezier.diemQuanTri[1].x = 22.5f;
      bezier.diemQuanTri[1].y = 28.9f;
      bezier.diemQuanTri[1].z =  6.4f;
      
      bezier.diemQuanTri[2].x = 11.0f;
      bezier.diemQuanTri[2].y = 38.0f;
      bezier.diemQuanTri[2].z = 3.0f;
      
      bezier.diemQuanTri[3].x =  9.0f;
      bezier.diemQuanTri[3].y = 38.0f;
      bezier.diemQuanTri[3].z =  3.0f;

      // cho di chuyển mịn
      float chuKy = 550.0f - 440.0f;
      float buoc = -0.5f*cosf( (soHoatHinh-440)*3.14159/chuKy ) + 0.5f;
      
      Vecto viTri = tinhViTriBezier3C( &bezier, buoc );
      mayQuayPhim->viTri.x = viTri.x;
      mayQuayPhim->viTri.y = viTri.y;
      mayQuayPhim->viTri.z = viTri.z;

      float buocNhin = -11.0f/(550.0f - 440.0f);
      Vecto huongNhin;

      huongNhin.x = buocNhin*(soHoatHinh-440) - mayQuayPhim->viTri.x;
      huongNhin.y = 10.0f - mayQuayPhim->viTri.y;
      huongNhin.z = 0.0f - mayQuayPhim->viTri.z;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
//      printf();
   }
   else if( soHoatHinh < 600 ) {   // ngó vai chánh
      mayQuayPhim->viTri.x = 9.0f;
      mayQuayPhim->viTri.y = 38.0f;
      mayQuayPhim->viTri.z = 3.0f;

      Vecto huongNhin;
      
      huongNhin.x = -11.0f - mayQuayPhim->viTri.x;
      huongNhin.y = 10.0f - mayQuayPhim->viTri.y;
      huongNhin.z = 0.0f - mayQuayPhim->viTri.z;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 650 ) {
      
      // cho di chuyển mịn
      float chuKy = 650.0f - 600.0f;

      mayQuayPhim->viTri.x = 9.0;//viTri.x;
      mayQuayPhim->viTri.y = 38.0f;//viTri.y;
      mayQuayPhim->viTri.z = 3.0f;//viTri.z;
      
      float gocNhin = (soHoatHinh-600)*0.5f*3.1415926/chuKy; // 100 = 650 - 550
//      printf( "gocNhin %5.3f\n", gocNhin );
      Vecto huongNhin;
      huongNhin.x = -11.0f*cosf( gocNhin ) - mayQuayPhim->viTri.x;
      huongNhin.y = 10.0f - mayQuayPhim->viTri.y;
      huongNhin.z = -11.0f*sinf( gocNhin ) - mayQuayPhim->viTri.z;
//      printf( "hướngNhìn %5.3f %5.3f %5.3f\n", huongNhin.x, huongNhin.y, huongNhin.z );
      //      printf( "mayQuayPhim %5.3f %5.3f %5.3f\n", mayQuayPhim->viTri.x, mayQuayPhim->viTri.y, mayQuayPhim->viTri.z );
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 660 ) { // xem trái banh bay ra ngoài
      mayQuayPhim->viTri.x = 9.0;//viTri.x;
      mayQuayPhim->viTri.y = 38.0f;//viTri.y;
      mayQuayPhim->viTri.z = 3.0f;//viTri.z;
      
      Vecto huongNhin;
      huongNhin.x = 0.0f - mayQuayPhim->viTri.x;
      huongNhin.y = 10.0f - mayQuayPhim->viTri.y;
      huongNhin.z = -11.0 - mayQuayPhim->viTri.z;

      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 675 ) {   // trá banh trúng kiến lồng sao gai
      mayQuayPhim->viTri.x = -30.0f;
      mayQuayPhim->viTri.y = 23.0f;
      mayQuayPhim->viTri.z = -52.0f;
      
      Vecto huongNhin;
      huongNhin.x = -1.0f;
      huongNhin.y =  0.2f;
      huongNhin.z =  0.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 690 ) {  // nhìn từ trời xuống, trái banh nhồi lại
      mayQuayPhim->viTri.x = -40.0f;
      mayQuayPhim->viTri.y = 50.0f;
      mayQuayPhim->viTri.z = -40.0f;
   
      Vecto huongNhin;
      huongNhin.x = -52.0f - mayQuayPhim->viTri.x;
      huongNhin.y = 8.0f - mayQuayPhim->viTri.y;
      huongNhin.z = -52.0f - mayQuayPhim->viTri.z;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 715 ) {  // nhìn từ trời xuống
      mayQuayPhim->viTri.x = -28.0f;
      mayQuayPhim->viTri.y = 20.0f;
      mayQuayPhim->viTri.z = -54.0f;

      Vecto huongNhin;
      huongNhin.x = -1.0f;
      huongNhin.y = -0.3f;
      huongNhin.z = 1.0f ;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 780 ) {  // sao gai chạy thoát
      mayQuayPhim->viTri.x = -30.0f;
      mayQuayPhim->viTri.y = 23.0f;
      mayQuayPhim->viTri.z = -52.0f;
      
      Vecto huongNhin;
      huongNhin.x = -1.0f;
      huongNhin.y =  0.2f;
      huongNhin.z =  0.0f;
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 820 ) {
      Bezier bezier;
      bezier.diemQuanTri[0].x = -30.0f;
      bezier.diemQuanTri[0].y = 23.0f;
      bezier.diemQuanTri[0].z = -52.0f;
      
      bezier.diemQuanTri[1].x = -30.0f;
      bezier.diemQuanTri[1].y = 23.0f;
      bezier.diemQuanTri[1].z = -52.4f;
      
      bezier.diemQuanTri[2].x = -15.0f;
      bezier.diemQuanTri[2].y = 23.0f;
      bezier.diemQuanTri[2].z = -60.0f;
      
      bezier.diemQuanTri[3].x = -14.0f;
      bezier.diemQuanTri[3].y = 23.0f;
      bezier.diemQuanTri[3].z = -70.0f;

      unsigned short soHoatHinhTuongDoi = soHoatHinh - 780;
      Vecto viTri = tinhViTriBezier3C( &bezier, 0.025*soHoatHinhTuongDoi );  // 0.05 = 1/20
      
      mayQuayPhim->viTri.x = viTri.x;
      mayQuayPhim->viTri.y = viTri.y;
      mayQuayPhim->viTri.z = viTri.z;
   
      Vecto huongNhin;
      huongNhin.x = -1.0f*cosf( soHoatHinhTuongDoi*0.02f );
      huongNhin.y =  0.2f - 0.015f*soHoatHinhTuongDoi;
      huongNhin.z =  1.0f*sinf( soHoatHinhTuongDoi*0.02f );
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 875 ) {
      mayQuayPhim->viTri.x = -14.0f;
      mayQuayPhim->viTri.y = 23.0f;
      mayQuayPhim->viTri.z = -70.0f;

      unsigned short soHoatHinhTuongDoi = 820 - 780;
      Vecto huongNhin;
      huongNhin.x = -1.0f*cosf( soHoatHinhTuongDoi*0.02f );
      huongNhin.y =  0.2f - 0.015f*soHoatHinhTuongDoi;
      huongNhin.z =  1.0f*sinf( soHoatHinhTuongDoi*0.02f );
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 910 ) {
       mayQuayPhim->viTri.x = -48.0f;
       mayQuayPhim->viTri.y = 19.0f;
       mayQuayPhim->viTri.z = -54.0f;
       Vecto huongNhin;
       huongNhin.x = 30.0f - mayQuayPhim->viTri.x;
       huongNhin.y = 5.0f - mayQuayPhim->viTri.y;
       huongNhin.z = -50.0f - mayQuayPhim->viTri.z;
       dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
    }
   else if( soHoatHinh < 1025 ) {
      mayQuayPhim->viTri.x = -10.0f;
      mayQuayPhim->viTri.y = 35.0f;
      mayQuayPhim->viTri.z = -41.0f;
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.4f;

      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1055 ) {
      unsigned short soHoatHinhTuongDoi = soHoatHinh - 1025;
      mayQuayPhim->viTri.x = -3.0f;
      mayQuayPhim->viTri.y = 13.0f + 0.1f*soHoatHinhTuongDoi;
      mayQuayPhim->viTri.z = -50.0f + 0.1f*soHoatHinhTuongDoi;
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = -0.1f;
      huongNhin.z = 1.0f;
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1170 ) {
      float goc = 0.5f + 0.04f*(soHoatHinh - 1055);
      mayQuayPhim->viTri.x = -35.0f*sinf( goc );
      mayQuayPhim->viTri.y = 30.0f;
      mayQuayPhim->viTri.z = -35.0f*cosf( goc );
      Vecto huongNhin;
      huongNhin.x = 0.0f - mayQuayPhim->viTri.x;
      huongNhin.y = 10.0f - mayQuayPhim->viTri.y;
      huongNhin.z = 0.0f - mayQuayPhim->viTri.z;
      
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1280 ) {
      unsigned short soHoatHinhTuongDoi = soHoatHinh - 1170;
      mayQuayPhim->viTri.x = 3.0f;
      mayQuayPhim->viTri.y = 20.0f;
      mayQuayPhim->viTri.z = -13.0f - 1.15f*soHoatHinhTuongDoi;
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = -20.0f;
      huongNhin.z = -25.0f - soHoatHinhTuongDoi*0.4f;  // theo trái bánh và sao gai
      printf( "%d  mayQuayPhim->huongNhin %5.3f %5.3f %5.3f\n", soHoatHinh, huongNhin.x, huongNhin.y, huongNhin.z );
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1335 ) { // giảm tốc độ và bay lên một chút
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;   congBezier.diemQuanTri[0].y = 20.0f;   congBezier.diemQuanTri[0].z = -139.5f;
      congBezier.diemQuanTri[1].x = 3.0f;   congBezier.diemQuanTri[1].y = 20.0f;   congBezier.diemQuanTri[1].z = -162.0f;
      congBezier.diemQuanTri[2].x = 3.0f;   congBezier.diemQuanTri[2].y = 22.4f;   congBezier.diemQuanTri[2].z = -169.3f;
      congBezier.diemQuanTri[3].x = 3.0f;   congBezier.diemQuanTri[3].y = 24.7f;   congBezier.diemQuanTri[3].z = -172.0f;

      float thamSoBezier = ((float)soHoatHinh - 1280.0f)/55.0f;
      Vecto viTri = tinhViTriBezier3C( &congBezier, thamSoBezier );
   
      mayQuayPhim->viTri = viTri;

      unsigned short soHoatHinhTuongDoi = soHoatHinh - 1280;
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = -20.0f;
      huongNhin.z = -69.0f - soHoatHinhTuongDoi*0.4f;
      printf( "%d  mayQuayPhim->huongNhin %5.3f %5.3f %5.3f\n", soHoatHinh, huongNhin.x, huongNhin.y, huongNhin.z );

      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
      
//      printf( "%d  mayQuayPhim->viTri %5.3f %5.3f %5.3f\n", soHoatHinh, mayQuayPhim->viTri.x, mayQuayPhim->viTri.y, mayQuayPhim->viTri.z );
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.y*vanToc.y + vanToc.z*vanToc.z )/55.0f;
      printf( "---> thamSoBezier %5.3f  tocDo mayQuayPhim %5.3f\n", thamSoBezier, tocDo );
   }
   else if( soHoatHinh < 1440 ) {  // nghỉ tới mà vẫn bay lên một chút
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;   congBezier.diemQuanTri[0].y = 24.7f;   congBezier.diemQuanTri[0].z = -172.0f;
      congBezier.diemQuanTri[1].x = 3.0f;   congBezier.diemQuanTri[1].y = 28.3f;   congBezier.diemQuanTri[1].z = -178.8f;
      congBezier.diemQuanTri[2].x = 3.0f;   congBezier.diemQuanTri[2].y = 30.0f;   congBezier.diemQuanTri[2].z = -180.0f;
      congBezier.diemQuanTri[3].x = 3.0f;   congBezier.diemQuanTri[3].y = 30.0f;   congBezier.diemQuanTri[3].z = -180.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1335.0f)/105.0f;
      Vecto viTri = tinhViTriBezier3C( &congBezier, thamSoBezier );
      
      mayQuayPhim->viTri = viTri;

      unsigned short soHoatHinhTuongDoi = soHoatHinh - 1280;
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = -20.0f;
      huongNhin.z = -69.0f - soHoatHinhTuongDoi*0.4f;
      printf( "%d  mayQuayPhim->huongNhin %5.3f %5.3f %5.3f\n", soHoatHinh, huongNhin.x, huongNhin.y, huongNhin.z );

      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
      
 //     printf( "%d  mayQuayPhim->viTri %5.3f %5.3f %5.3f\n", soHoatHinh, mayQuayPhim->viTri.x, mayQuayPhim->viTri.y, mayQuayPhim->viTri.z );
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.y*vanToc.y + vanToc.z*vanToc.z )/105.0f;
      printf( "---> thamSoBezier %5.3f  tocDo mayQuayPhim %5.3f\n", thamSoBezier, tocDo );
   }
   else if( soHoatHinh < 1600 ) {
      
      float goc = (soHoatHinh - 1280)/50.0f;
      
      mayQuayPhim->viTri.x = 3.0f;
      mayQuayPhim->viTri.y = 30.0f;
      mayQuayPhim->viTri.z = -180.0f;//-210.0f;
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = -20.0f;
      huongNhin.z = -133.0f;  // -50 = -10 - 0.4*(1280-1180)
      printf( "%d  mayQuayPhim->huongNhin %5.3f %5.3f %5.3f\n", soHoatHinh, huongNhin.x, huongNhin.y, huongNhin.z );

      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   printf( "mayQuayPhim %5.3f %5.3f %5.3f\n", mayQuayPhim->viTri.x, mayQuayPhim->viTri.y, mayQuayPhim->viTri.z );
 
}

void nangCapPhimTruong0_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh ) {

   // ---- nhân vật - các trai banh
   // ---- cho các trái banh né sao gai
   Vecto viTriSaoGai;
   viTriSaoGai.x = phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__SAO_GAI]].dich[12];
   viTriSaoGai.y = phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__SAO_GAI]].dich[13];
   viTriSaoGai.z = phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__SAO_GAI]].dich[14];
   moPhongTraiBanhGiaoThong( phimTruong->danhSachVatThe, phimTruong->nhanVat[kNHAN_VAT__BAY_TRAI_BANH_DAU],
                               phimTruong->nhanVat[kNHAN_VAT__BAY_TRAI_BANH_CUOI], &viTriSaoGai );

   // ---- nâng cấp các nhân vật
   nangCapVaiChanh( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__VAI_CHANH]]), soHoatHinh );
   nangCapSaoGaiDo( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__SAO_GAI]]), soHoatHinh );
   nangCapTraiBanhBiGiet( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__TRAI_BANH_BI_GIET]]), soHoatHinh );
   nangCapKienLongSaoGaiDo( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__KIEN_LONG_SAO_GAI_DO]]), soHoatHinh );
   nangCapHatBayQuanhVongXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__HAT_THUY_TINH_BAY]]), soHoatHinh );
   nangCapBongBongBay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__BONG_BONG_DAU]]), phimTruong->nhanVat[kNHAN_VAT__BONG_BONG_CUOI] - phimTruong->nhanVat[kNHAN_VAT__BONG_BONG_DAU], soHoatHinh );
   nangCapCacBatDienXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__BAT_DIEN_XOAY_DAU]]), phimTruong->nhanVat[kNHAN_VAT__BAT_DIEN_XOAY_CUOI] - phimTruong->nhanVat[kNHAN_VAT__BAT_DIEN_XOAY_DAU], soHoatHinh );
   nangCapCotNhay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__COT_NHAY_DAU]]), phimTruong->nhanVat[kNHAN_VAT__COT_NHAY_CUOI] - phimTruong->nhanVat[kNHAN_VAT__COT_NHAY_DAU], soHoatHinh );
   nangCapMatSong( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__MAT_SONG]]), soHoatHinh );
   
}

#define kVAI_CHANH__THAI_TRANG_CHAY_TANG_1      0
#define kVAI_CHANH__THAI_TRANG_NHAY_XUONG_1_0   1
#define kVAI_CHANH__THAI_TRANG_CHAY_TANG_0      2
#define kVAI_CHANH__THAI_TRANG_NHAY_XUONG_0_SAN 3
#define kVAI_CHANH__THAI_TRANG_CHAY_SAN         4
#define kVAI_CHANH__THAI_TRANG_NHAY_XUONG_SAN_DAT 5
#define kVAI_CHANH__THAI_TRANG_CHAY_DAT 6


void nangCapVaiChanh( VatThe *vaiChanh, unsigned short soHoatHinh ) {

   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;  // không bao giừ đổi, cần cho nâng các cấp biến hóa
   
   Quaternion xoay;
   xoay.w = 1.0f;    xoay.x = 0.0f;   xoay.y = 0.0f;   xoay.z = 0.0f;

   // ---- vị tri
   Vecto viTriVaiChanh;
   viTriVaiChanh.x = -10.0f;    viTriVaiChanh.y = 10.8f;    viTriVaiChanh.z = 10.0f;  // cần có ví trí sẵn, cho không có giá trị bậy

   // ---- vận tốc
   Vecto vanToc;
   float tocDo = 0.0f;
   // ---- trục xoay
   Vecto trucXoay;
   
   // ---- bán kính
   float banKinh = vaiChanh->hinhDang.hinhCau.banKinh;
   
   // ---- vectơ thẳnh lên (cho tính trục xoay)
   Vecto phapThuyenMatDat;
   phapThuyenMatDat.x = 0.0f;   phapThuyenMatDat.y = 1.0f;   phapThuyenMatDat.z = 0.0f;

   // chạy ẩu trong vòng xoay
   if( soHoatHinh < 30 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -10.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 10.0f;
      congBezier.diemQuanTri[1].x = -11.2f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 6.8f;
      congBezier.diemQuanTri[2].x = -13.9f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 4.4f;
      congBezier.diemQuanTri[3].x = -14.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 2.0f;
      
      float thamSoBezier = (float)soHoatHinh/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 70 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -14.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 2.0f;
      congBezier.diemQuanTri[1].x = -14.0f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -2.4f;
      congBezier.diemQuanTri[2].x = -7.4f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -3.7f;
      congBezier.diemQuanTri[3].x = -7.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -5.6f;
      
      float thamSoBezier = ((float)soHoatHinh - 30.0f)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 85 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -7.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -5.6f;
      congBezier.diemQuanTri[1].x = -6.1f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -8.1f;
      congBezier.diemQuanTri[2].x = -10.8f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -7.7f;
      congBezier.diemQuanTri[3].x = -8.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -10.9f;
      
      float thamSoBezier = ((float)soHoatHinh - 70.0f)/15.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/15.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 115 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -8.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -10.9f;
      congBezier.diemQuanTri[1].x = -5.6f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -13.7f;
      congBezier.diemQuanTri[2].x = -1.6f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -15.0f;
      congBezier.diemQuanTri[3].x = 2.1f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -14.4f;
      
      float thamSoBezier = ((float)soHoatHinh - 85.0f)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 145 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 2.1f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -14.4f;
      congBezier.diemQuanTri[1].x = 6.6f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -13.8f;
      congBezier.diemQuanTri[2].x = 7.6f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -9.5f;
      congBezier.diemQuanTri[3].x = 9.3f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -7.0f;

      float thamSoBezier = ((float)soHoatHinh - 115.0f)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 175 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 9.3f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -7.0f;
      congBezier.diemQuanTri[1].x = 10.9f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -4.5f;
      congBezier.diemQuanTri[2].x = 13.3f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -3.5f;
      congBezier.diemQuanTri[3].x = 13.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 0.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 145.0f)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 210 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 13.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 0.0f;
      congBezier.diemQuanTri[1].x = 12.2f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 8.6f;
      congBezier.diemQuanTri[2].x = 4.4f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 11.6f;
      congBezier.diemQuanTri[3].x = 0.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 11.2f;
      
      float thamSoBezier = ((float)soHoatHinh - 175.0f)/35.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/35.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 260 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 0.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 11.2f;
      congBezier.diemQuanTri[1].x = -6.2f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 11.4f;
      congBezier.diemQuanTri[2].x = -10.9f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 4.9f;
      congBezier.diemQuanTri[3].x = -11.4f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 3.6f;
      
      float thamSoBezier = ((float)soHoatHinh - 210.0f)/50.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/50.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 270 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -11.4f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 3.6f;
      congBezier.diemQuanTri[1].x = -12.1f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 1.9f;
      congBezier.diemQuanTri[2].x = -14.0f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 0.0f;
      congBezier.diemQuanTri[3].x = -14.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 0.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 260.0f)/10.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/10.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 310 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -14.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 0.0f;
      congBezier.diemQuanTri[1].x = -14.0f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -5.0f;
      congBezier.diemQuanTri[2].x = -11.1f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -11.6f;
      congBezier.diemQuanTri[3].x = -8.2f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -8.5f;
//      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 270.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 270.0f)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 350 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -8.2f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -8.5f;
      congBezier.diemQuanTri[1].x = -5.0f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -5.3f;
      congBezier.diemQuanTri[2].x = -3.2f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -8.1f;
      congBezier.diemQuanTri[3].x = 0.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -8.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 310.0f)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 390 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 0.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -8.0f;
      congBezier.diemQuanTri[1].x = 3.2f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -8.6f;
      congBezier.diemQuanTri[2].x = 12.0f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -5.8f;
      congBezier.diemQuanTri[3].x = 12.2f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -1.6f;
      
      float thamSoBezier = ((float)soHoatHinh - 350.0f)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 415 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 12.2f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -1.6f;
      congBezier.diemQuanTri[1].x = 12.4f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 0.7f;
      congBezier.diemQuanTri[2].x = 10.4f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 0.2f;
      congBezier.diemQuanTri[3].x = 10.8f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 4.3f;
      
      float thamSoBezier = ((float)soHoatHinh - 390.0f)/25.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/25.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 455 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 10.8f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 4.3f;
      congBezier.diemQuanTri[1].x = 11.1f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 8.6f;
      congBezier.diemQuanTri[2].x = 5.4f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 13.1f;
      congBezier.diemQuanTri[3].x = 1.6f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 10.5f;
      
      float thamSoBezier = ((float)soHoatHinh - 415.0f)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 475 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 1.6f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 10.5f;
      congBezier.diemQuanTri[1].x = 0.1f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 9.5f;
      congBezier.diemQuanTri[2].x = -0.7f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 12.4f;
      congBezier.diemQuanTri[3].x = -2.5f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 12.1f;
      
      float thamSoBezier = ((float)soHoatHinh - 455.0f)/20.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C(&congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/20.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 495 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -2.5f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 12.1f;
      congBezier.diemQuanTri[1].x = -3.4f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 11.9f;
      congBezier.diemQuanTri[2].x = -3.6;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 9.7;
      congBezier.diemQuanTri[3].x = -5.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 9.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 475.0f)/20.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/20.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 525 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -5.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 9.0f;
      congBezier.diemQuanTri[1].x = -6.6f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 8.2f;
      congBezier.diemQuanTri[2].x = -8.6f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 11.0f;
      congBezier.diemQuanTri[3].x = -10.9f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 9.1f;
      
      float thamSoBezier = ((float)soHoatHinh - 495.0f)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 550 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -10.9f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 9.1f;
      congBezier.diemQuanTri[1].x = -13.6f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 6.7f;
      congBezier.diemQuanTri[2].x = -14.6f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 0.0f;
      congBezier.diemQuanTri[3].x = -14.6f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 0.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 525.0f)/25.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/25.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 585 ) {
      viTriVaiChanh.x = -14.6f;   viTriVaiChanh.y = 10.8f;   viTriVaiChanh.z = 0.0f;
      // ---- tốc độ
      tocDo = 0.0f;
   }
   else if( soHoatHinh < 610 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -14.6f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -0.0f;
      congBezier.diemQuanTri[1].x = -14.6f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -0.0f;
      congBezier.diemQuanTri[2].x = -14.5f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -3.3f;
      congBezier.diemQuanTri[3].x = -14.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -3.8f;
      
      float thamSoBezier = ((float)soHoatHinh - 585.0f)/25.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/25.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 640 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -14.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -3.8f;
      congBezier.diemQuanTri[1].x = -13.1f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -7.1f;
      congBezier.diemQuanTri[2].x = -3.9f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -3.8f;
      congBezier.diemQuanTri[3].x = 0.7f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -11.7f;
      //         printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 610.0f)/30.0f );
      float thamSoBezier = ((float)soHoatHinh - 610.0f)/30.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );

   }
   // ---- BAY LÊN TRỜI ----
   else if( soHoatHinh < 670 ) {  // ------ trái banh bay lên
      Vecto viTriBanDau;   // phải giống điểm cuối cong Bezier ở trên
      viTriBanDau.x = 0.7f;        viTriBanDau.y = 10.8f;        viTriBanDau.z = -10.7f;
      // ---- hướng bay lên kiến lồng sao gai; mục đích là (-52; 27; -52) - bính kính 4
      Vecto huongBay; // tương đối với mặt đất
      huongBay.x = -52.0f - viTriBanDau.x;
      huongBay.y = 0.0f;
      huongBay.z = -52.0f - viTriBanDau.z;
      // ---- tính điểm mục đích
      donViHoa( &huongBay );
      Vecto diemMucDich;
      diemMucDich.x = -52.0f - huongBay.x*4.0f;
      diemMucDich.y = 27.0f;
      diemMucDich.z = -52.0f - huongBay.z*4.0f;
      //      printf( "diemMucDich %5.3f %5.3f %5.3f\n", diemMucDich.x, diemMucDich.y, diemMucDich.z );
      
      Vecto buocBay;
      buocBay.x = (diemMucDich.x - viTriBanDau.x)/30.0f;
      //      buocBay.y = (diemMucDich.y - 10.8f)/30.0f;
      buocBay.z = (diemMucDich.z - viTriBanDau.z)/30.0f;
      //      printf( "buocBay %5.3f %5.3f %5.3f\n", buocBay.x, buocBay.y, buocBay.z );

      float thoiGianBay = soHoatHinh - 640.0f;
      viTriVaiChanh.x = viTriBanDau.x + buocBay.x*thoiGianBay;
      viTriVaiChanh.y = viTriBanDau.y + 1.5f*thoiGianBay + 0.5f*kHAP_DAN*thoiGianBay*thoiGianBay;
      viTriVaiChanh.z = viTriBanDau.z + buocBay.z*thoiGianBay;
      trucXoay.x = huongBay.z;
      trucXoay.y = 0.0f;
      trucXoay.z = -huongBay.x;
      tocDo = 4.0f;
   }
   else if( soHoatHinh < 691 ) {  // trái banh nhồi lại và rớt xuống
      // ---- hướng bay lên kiến lồng sao gai; mục đích là (-52; 27; -52) - bính kính 4
      Vecto huongBay;
      huongBay.x = 52.0f + 2.0f;
      huongBay.y = 0.0f;
      huongBay.z = 52.0f - 13.3f;
      // ---- tính điểm mục đích
      donViHoa( &huongBay );

      float thoiGianBay = soHoatHinh - 670.0f;
      viTriVaiChanh.x = -48.8 + 0.45f*huongBay.x*thoiGianBay;
      viTriVaiChanh.y = 27.0f + 0.45f*kHAP_DAN*thoiGianBay*thoiGianBay;
      viTriVaiChanh.z = -49.7 + 0.45f*huongBay.z*thoiGianBay;

      trucXoay.x = huongBay.z;
      trucXoay.y = 0.0f;
      trucXoay.z = -huongBay.x;
      tocDo = 4.0f;
   }
   else if( soHoatHinh < 713 ) {
      // ---- hướng bay lên kiến lồng sao gai; mục đích là (-52; 27; -52) - bính kính 4
      Vecto huongBay;
      huongBay.x = 52.0f + 2.0f;
      huongBay.y = 0.0f;
      huongBay.z = 52.0f - 13.3f;
      // ---- tính điểm mục đích
      donViHoa( &huongBay );

      float vanTocRotY = (float)(691-670)*kHAP_DAN;
      float vanTocNhoiY = -vanTocRotY*0.51f;
      float thoiGianBay = soHoatHinh - 670.0f;
      float thoiGianNhoi = soHoatHinh - 691.0f;
      viTriVaiChanh.x = -48.8 + 0.45f*huongBay.x*thoiGianBay;
      viTriVaiChanh.y = 13.9f + vanTocNhoiY*thoiGianNhoi + 0.5f*kHAP_DAN*thoiGianNhoi*thoiGianNhoi;  // mặt đất 13,2 và bán kính trái banh = 0,7
      viTriVaiChanh.z = -49.7 + 0.45f*huongBay.z*thoiGianBay;

      trucXoay.x = huongBay.z;
      trucXoay.y = 0.0f;
      trucXoay.z = -huongBay.x;
      donViHoa( &trucXoay );
      tocDo = 3.0f;
   }
   // ---- CHỐNG MẶT đi lang thang
   else if( soHoatHinh < 720 ) {  // trái banh rớt xuống và đi va chạm
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -33.4f;   congBezier.diemQuanTri[0].y = 13.3f;   congBezier.diemQuanTri[0].z = -38.4f;
      congBezier.diemQuanTri[1].x = -32.3f;   congBezier.diemQuanTri[1].y = 13.3f;   congBezier.diemQuanTri[1].z = -38.0f;
      congBezier.diemQuanTri[2].x = -31.7f;   congBezier.diemQuanTri[2].y = 13.3f;   congBezier.diemQuanTri[2].z = -37.7f;
      congBezier.diemQuanTri[3].x = -31.0f;   congBezier.diemQuanTri[3].y = 13.3f;   congBezier.diemQuanTri[3].z = -36.7f;
      //      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 270.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 713.0f)/6.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/6.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 740 ) {  // nhồi lại từ va chạm
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -31.0f;   congBezier.diemQuanTri[0].y = 13.3f;   congBezier.diemQuanTri[0].z = -36.7f;
      congBezier.diemQuanTri[1].x = -32.5f;   congBezier.diemQuanTri[1].y = 13.3f;   congBezier.diemQuanTri[1].z = -37.7f;
      congBezier.diemQuanTri[2].x = -35.7f;   congBezier.diemQuanTri[2].y = 13.3f;   congBezier.diemQuanTri[2].z = -38.4f;
      congBezier.diemQuanTri[3].x = -37.3f;   congBezier.diemQuanTri[3].y = 13.3f;   congBezier.diemQuanTri[3].z = -37.1f;
      //      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 270.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 720.0f)/20.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/20.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 780 ) {  // trái banh nhồi lại và rớt xuống
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -37.3f;   congBezier.diemQuanTri[0].y = 13.3f;   congBezier.diemQuanTri[0].z = -37.1f;
      congBezier.diemQuanTri[1].x = -40.1f;   congBezier.diemQuanTri[1].y = 13.3f;   congBezier.diemQuanTri[1].z = -34.8f;
      congBezier.diemQuanTri[2].x = -33.4f;   congBezier.diemQuanTri[2].y = 13.3f;   congBezier.diemQuanTri[2].z = -35.3f;
      congBezier.diemQuanTri[3].x = -31.8f;   congBezier.diemQuanTri[3].y = 13.3f;   congBezier.diemQuanTri[3].z = -38.9f;
      //      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 740.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 740.0f)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 860 ) {  // trái banh nhồi lại và rớt xuống
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -31.8f;   congBezier.diemQuanTri[0].y = 13.3f;   congBezier.diemQuanTri[0].z = -38.9f;
      congBezier.diemQuanTri[1].x = -30.2f;   congBezier.diemQuanTri[1].y = 13.3f;   congBezier.diemQuanTri[1].z = -42.7f;
      congBezier.diemQuanTri[2].x = -31.8f;   congBezier.diemQuanTri[2].y = 13.3f;   congBezier.diemQuanTri[2].z = -45.4f;
      congBezier.diemQuanTri[3].x = -30.8f;   congBezier.diemQuanTri[3].y = 13.3f;   congBezier.diemQuanTri[3].z = -51.5f;
      //      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 780.0f)/80.0f );

      float thamSoBezier = ((float)soHoatHinh - 780.0f)/80.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/80.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      
      vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_CHAY_TANG_1;
   }
   
   // ---- CHẠY CHỐNG
   else if( soHoatHinh < 920 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -30.8f;   congBezier.diemQuanTri[0].y = 13.3f;   congBezier.diemQuanTri[0].z = -51.5f;
      congBezier.diemQuanTri[1].x = -29.6f;   congBezier.diemQuanTri[1].y = 13.3f;   congBezier.diemQuanTri[1].z = -52.7f;
      congBezier.diemQuanTri[2].x = -7.1f;   congBezier.diemQuanTri[2].y = 13.3f;   congBezier.diemQuanTri[2].z = -52.0f;
      congBezier.diemQuanTri[3].x = -7.1f;   congBezier.diemQuanTri[3].y = 13.3f;   congBezier.diemQuanTri[3].z = -52.0f;
      //      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 860.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 860.0f)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      
      // ---- xuống tầng 0
      Vecto cachTamLong;  // cách tâm lồng
      cachTamLong.x = viTriVaiChanh.x + 52.0f - 0.7f*0.7f;
      cachTamLong.z = viTriVaiChanh.z + 52.0f - 0.7f*0.7f;  // 0,7 bán kính vai chánh * √2
      float quangBinh = cachTamLong.x*cachTamLong.x + cachTamLong.z*cachTamLong.z; // quãng bình
      if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_CHAY_TANG_1 ) {
         if( quangBinh > 676.0f ) {
            vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_NHAY_XUONG_1_0;
            vaiChanh->vanToc.y = 0.0f;
         }
      }
      else if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_NHAY_XUONG_1_0 ) {
         vaiChanh->vanToc.y += kHAP_DAN;
         viTriVaiChanh.y = vaiChanh->dich[13] + vaiChanh->vanToc.y;
         if( viTriVaiChanh.y < 13.0f ) {
            viTriVaiChanh.y = 13.0f;
            vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_CHAY_TANG_0;
         }
      }
      else if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_CHAY_TANG_0 ) {
         viTriVaiChanh.y = 13.0f;
         if( quangBinh > 1024.0f ) {
            vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_NHAY_XUONG_0_SAN;
 
            vaiChanh->vanToc.y = 0.0f;
         }
      }
      else if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_NHAY_XUONG_0_SAN ) {
         vaiChanh->vanToc.y += kHAP_DAN;
         viTriVaiChanh.y = vaiChanh->dich[13] + vaiChanh->vanToc.y;
         if( viTriVaiChanh.y < 12.7f ) {
            viTriVaiChanh.y = 12.7f;
            vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_CHAY_SAN;
         }
      }
      else if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_CHAY_SAN ) {
         viTriVaiChanh.y = 12.7f;
         if( viTriVaiChanh.x > 45.0f - 52.0f + 0.7f*0.7f ) {
            vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_NHAY_XUONG_SAN_DAT;
            vaiChanh->vanToc.y = 0.0f;
         }
      }

   }
   else if( soHoatHinh < 940 ) {  // đứng trước nhảy xuống
      viTriVaiChanh.x = -7.1f;
      viTriVaiChanh.y = 12.7f;
      viTriVaiChanh.z = -52.0f;
      tocDo = 0.0f;
   }
   else if( soHoatHinh < 952 ) { // nhảy xuống
      viTriVaiChanh.x = -7.1f + 0.4f*(soHoatHinh - 940);
      viTriVaiChanh.y = 12.7f;
      viTriVaiChanh.z = -52.0f;

      trucXoay.x = 0.0f;   trucXoay.y = 0.0f;   trucXoay.z = -1.0f;
      tocDo = 0.4f;

      if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_CHAY_SAN ) {
         if( viTriVaiChanh.x > 45.0f - 52.0f + 0.7f*0.7f ) {
            vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_NHAY_XUONG_SAN_DAT;
            vaiChanh->vanToc.y = 0.0f;
         }
      }
      else if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_NHAY_XUONG_SAN_DAT ) {
         vaiChanh->vanToc.y += kHAP_DAN;
         viTriVaiChanh.y = vaiChanh->dich[13] + vaiChanh->vanToc.y;
         if( viTriVaiChanh.y < 10.8f ) {
            viTriVaiChanh.y = 10.8f;
            vaiChanh->thaiTrang = kVAI_CHANH__THAI_TRANG_CHAY_DAT;
         }
      }
      else if( vaiChanh->thaiTrang == kVAI_CHANH__THAI_TRANG_CHAY_DAT ) {
         viTriVaiChanh.y = 10.8f;
      }
   }
   else if( soHoatHinh < 990 ) {  // CHẠY TRÊN ĐƯỜNG
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -2.3f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -52.0f;
      congBezier.diemQuanTri[1].x = -1.3f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -50.5f;
      congBezier.diemQuanTri[2].x = -2.1f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -40.6f;
      congBezier.diemQuanTri[3].x = -2.2f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -32.0f;
      //      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 740.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 952.0f)/48.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/48.0f;
//      printf( "%d vaiChanh tocDo %5.3f\n", soHoatHinh, tocDo );
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1030 ) {  // CHẠY TRÊN ĐƯỜNG
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -2.2f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -32.0f;
      congBezier.diemQuanTri[1].x = -2.3f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -20.4f;
      congBezier.diemQuanTri[2].x = -1.0f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -12.0f;
      congBezier.diemQuanTri[3].x = -5.7f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -9.6f;
      
      float thamSoBezier = ((float)soHoatHinh - 990.0f)/40.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/40.0f;
//      printf( "%d vaiChanh tocDo %5.3f\n", soHoatHinh, tocDo );
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1090 ) {  // CHẠY TRÊN ĐƯỜNG
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = -5.7f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -9.6f;
      congBezier.diemQuanTri[1].x = -16.8f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -3.8f;
      congBezier.diemQuanTri[2].x = -11.6f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 11.1f;
      congBezier.diemQuanTri[3].x = 0.0f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = 11.1f;

      float thamSoBezier = ((float)soHoatHinh - 1030.0f)/60.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/60.0f;
//      printf( "%d vaiChanh tocDo %5.3f\n", soHoatHinh, tocDo );
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1135 ) {  // CHẠY TRÊN ĐƯỜNG
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 0.0f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = 11.1f;
      congBezier.diemQuanTri[1].x = 6.8f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = 11.1f;
      congBezier.diemQuanTri[2].x = 13.7f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = 0.5f;
      congBezier.diemQuanTri[3].x = 6.1f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -6.5f;
       
      float thamSoBezier = ((float)soHoatHinh - 1090.0f)/45.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
//      printf( "%d vaiChanh tocDo %5.3f\n", soHoatHinh, tocDo );
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1145 ) {  // CHẠY TRÊN ĐƯỜNG
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 6.1f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -6.5f;
      congBezier.diemQuanTri[1].x = 4.9f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -7.7f;
      congBezier.diemQuanTri[2].x = 3.2f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -8.3f;
      congBezier.diemQuanTri[3].x = 2.8f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -9.0f;
      //      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 740.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 1135.0f)/15.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/15.0f;
//      printf( "%d vaiChanh tocDo %5.3f\n", soHoatHinh, tocDo );
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1170 ) {  // CHẠY TRÊN ĐƯỜNG
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 2.8f;   congBezier.diemQuanTri[0].y = 10.8f;   congBezier.diemQuanTri[0].z = -9.0f;
      congBezier.diemQuanTri[1].x = 2.2f;   congBezier.diemQuanTri[1].y = 10.8f;   congBezier.diemQuanTri[1].z = -12.5f;
      congBezier.diemQuanTri[2].x = 1.7f;   congBezier.diemQuanTri[2].y = 10.8f;   congBezier.diemQuanTri[2].z = -18.0f;
      congBezier.diemQuanTri[3].x = 1.7f;   congBezier.diemQuanTri[3].y = 10.8f;   congBezier.diemQuanTri[3].z = -28.0f;
//      printf("soHoatHinh %d  %5.3f\n", soHoatHinh, ((float)soHoatHinh - 740.0f)/40.0f );
      
      float thamSoBezier = ((float)soHoatHinh - 1145.0f)/25.0f;
      viTriVaiChanh = tinhViTriBezier3C(&congBezier, thamSoBezier );
      // ---- vận tốc
      vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/25.0f;
//      printf( "%d vaiChanh tocDo %5.3f\n", soHoatHinh, tocDo );
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
   }
   else if( soHoatHinh < 1600 ) {  // CHẠY TRÊN ĐƯỜNG Z

      viTriVaiChanh.x = 1.7f;
      viTriVaiChanh.y = 10.8f;
      viTriVaiChanh.z = -28.0f + 1.3f*(1170 - soHoatHinh);

      trucXoay.x = -1.0f;
      trucXoay.y = 0.0f;
      trucXoay.z = 0.0f;
      tocDo = 0.6f;
   }
   
   
//   printf( "---> %d viTriVaiChanh %d  %5.3f %5.3f %5.3f <---\n", soHoatHinh, vaiChanh->thaiTrang, viTriVaiChanh.x, viTriVaiChanh.y, viTriVaiChanh.z );
   xoay = tinhXoayChoVatThe( &(vaiChanh->quaternion), trucXoay, tocDo, 0.7f );
   // ---- đặt biến hóa cho vai chánh
   datBienHoaChoVat( vaiChanh, &phongTo, &xoay, &viTriVaiChanh );
}

#define kSAO_GAI__BUOC_RA_LONG 0.14f
#define kSAO_GAI__BUOC_RUOT 0.4f

#define kSAO_GAI__THAI_TRANG_DANG_DOI   0
#define kSAO_GAI__THAI_TRANG_THA_XUONG  1
#define kSAO_GAI__THAI_TRANG_RA_LONG    2
#define kSAO_GAI__THAI_TRANG_ROT_XUONG_LONG 3
#define kSAO_GAI__THAI_TRANG_NGO            4
#define kSAO_GAI__THAI_TRANG_CHAY_TANG_4    5
#define kSAO_GAI__THAI_TRANG_NHAY_XUONG_4_3 6
#define kSAO_GAI__THAI_TRANG_CHAY_TANG_3    7
#define kSAO_GAI__THAI_TRANG_NHAY_XUONG_3_2 8
#define kSAO_GAI__THAI_TRANG_CHAY_TANG_2    9
#define kSAO_GAI__THAI_TRANG_NHAY_XUONG_2_1 10
#define kSAO_GAI__THAI_TRANG_CHAY_TANG_1    11
#define kSAO_GAI__THAI_TRANG_NHAY_XUONG_1_0 12
#define kSAO_GAI__THAI_TRANG_CHAY_TANG_0    13
#define kSAO_GAI__THAI_TRANG_NHAY_XUONG_0_SAN 14
#define kSAO_GAI__THAI_TRANG_CHAY_SAN       15
#define kSAO_GAI__THAI_TRANG_NHAY_XUONG_SAN_DAT    16

#define kSAO_GAI__THAI_TRANG_DUONG_VAO_VONG 17
#define kSAO_GAI__THAI_TRANG_DUONG_RA_VONG  18

void nangCapSaoGaiDo( VatThe *saoGai, unsigned short soHoatHinh ) {
   
   Vecto phongTo;
   phongTo.x = saoGai->phongTo[0];   phongTo.y = saoGai->phongTo[5];   phongTo.z = saoGai->phongTo[10];
   
   Quaternion xoay;
   xoay.w = 1.0f;   xoay.x = 0.0f;   xoay.y = 0.0f;   xoay.z = 0.0f;

   Vecto viTriSaoGai;
   viTriSaoGai.x = -52.0f;   viTriSaoGai.y = 27.6f;    viTriSaoGai.z = -52.0f;  // cần có gia trị sẵn cho không có giá trị bậy
   
   float banKinh = kSAO_GAI__BAN_KINH*phongTo.x;
   Vecto trucXoay;
   float tocDo = 0.0f;
   
   unsigned char thaiTrangSaoGai = saoGai->thaiTrang;
   // ----- sao gai thoát lồng
   if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_DANG_DOI ) {
      if( soHoatHinh == 700 )
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_THA_XUONG;
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_THA_XUONG ) {
      float buocXuong = 0.01f;

      viTriSaoGai.x = -52.0f;
      viTriSaoGai.y = saoGai->dich[13] - buocXuong;
      viTriSaoGai.z = -52.0f;
      
      datBienHoaChoVat( saoGai, &phongTo, &xoay, &viTriSaoGai );
      if( saoGai->dich[13] < 27.2f ) {
         viTriSaoGai.y = 27.2f;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_RA_LONG;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_RA_LONG ) {

      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RA_LONG;
      viTriSaoGai.y = 27.2f;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RA_LONG;  // 1.8f bán kính sao gai

      if( saoGai->dich[12] > -52.0f + 4.5f ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_ROT_XUONG_LONG;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_ROT_XUONG_LONG ) {
      saoGai->vanToc.y += kHAP_DAN;

      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RA_LONG;
      viTriSaoGai.y = saoGai->dich[13] + saoGai->vanToc.y;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RA_LONG;  // 1.8f bán kính sao gai

      if( viTriSaoGai.y < 13.5f + banKinh ) {
         viTriSaoGai.y = 13.5f + banKinh;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_NGO;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_NGO ) {  // ngó
      
      viTriSaoGai.x = saoGai->dich[12] + 0.05f;
      viTriSaoGai.y = 13.5f + banKinh;  // 13,5 là độ cao mặt tầng 4
      viTriSaoGai.z = -52.0f;

      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RA_LONG;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[12] > -52.0f + 10.5f ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_CHAY_TANG_4;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_CHAY_TANG_4 ) {

      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = 13.5f + banKinh;  // 13,5 là độ cao mặt tầng 4
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai

      if( saoGai->dich[12] > -52.0f + 11.0f + 0.5f*banKinh ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_NHAY_XUONG_4_3;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_NHAY_XUONG_4_3 ) {
      saoGai->vanToc.y += kHAP_DAN;
   
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = saoGai->dich[13] + saoGai->vanToc.y;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[13] < 13.2f + banKinh ) {
         viTriSaoGai.y = 13.2f + banKinh;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_CHAY_TANG_3;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_CHAY_TANG_3 ) {
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = 13.2f + banKinh;  // 13,5 là độ cao mặt tầng 4
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[12] > -52.0f + 15.0f + 0.5f*banKinh ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_NHAY_XUONG_3_2;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_NHAY_XUONG_3_2 ) {
      saoGai->vanToc.y += kHAP_DAN;
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = saoGai->dich[13] + saoGai->vanToc.y;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[13] < 12.9f + banKinh ) {
         viTriSaoGai.y = 12.9f + banKinh;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_CHAY_TANG_2;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_CHAY_TANG_2 ) {
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = 12.9 + banKinh;  // 12,9 là độ cao mặt tầng 4
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[12] > -52.0f + 20.0f + 0.5f*banKinh ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_NHAY_XUONG_2_1;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_NHAY_XUONG_2_1 ) {
      saoGai->vanToc.y += kHAP_DAN;
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = saoGai->dich[13] + saoGai->vanToc.y;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[13] < 12.6f + banKinh ) {
         viTriSaoGai.y = 12.6f + banKinh;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_CHAY_TANG_1;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_CHAY_TANG_1 ) {
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = 12.6f + banKinh;  // 13,5 là độ cao mặt tầng 4
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[12] > -52.0f + 26.0f + 0.5f*banKinh ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_NHAY_XUONG_1_0;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_NHAY_XUONG_1_0 ) {
      saoGai->vanToc.y += kHAP_DAN;
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = saoGai->dich[13] + saoGai->vanToc.y;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[13] < 12.3f + banKinh ) {
         viTriSaoGai.y = 12.3f + banKinh;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_CHAY_TANG_0;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_CHAY_TANG_0 ) {
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = 12.3f + banKinh;  // 13,5 là độ cao mặt tầng 4
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[12] > -52.0f + 32.0f + 0.5f*banKinh ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_NHAY_XUONG_0_SAN;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_NHAY_XUONG_0_SAN ) {
      saoGai->vanToc.y += kHAP_DAN;
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = saoGai->dich[13] + saoGai->vanToc.y;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[13] < 12.0f + banKinh ) {
         viTriSaoGai.y = 12.0f + banKinh;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_CHAY_SAN;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_CHAY_SAN ) {
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = 12.0f + banKinh;  // 13,5 là độ cao mặt tầng 4
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( saoGai->dich[12] > -52.0f + 45.0f + 0.5f*kSAO_GAI__BAN_KINH ) {
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_NHAY_XUONG_SAN_DAT;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( thaiTrangSaoGai == kSAO_GAI__THAI_TRANG_NHAY_XUONG_SAN_DAT ) {
      saoGai->vanToc.y += kHAP_DAN;
      
      viTriSaoGai.x = saoGai->dich[12] + kSAO_GAI__BUOC_RUOT;
      viTriSaoGai.y = saoGai->dich[13] + saoGai->vanToc.y;
      viTriSaoGai.z = -52.0f;
      
      trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = -1.0f;
      tocDo = kSAO_GAI__BUOC_RUOT;  // 1.8f bán kính sao gai
      
      if( viTriSaoGai.y < 10.1f + banKinh ) {
         viTriSaoGai.y = 10.1f + banKinh;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_DUONG_VAO_VONG;
         saoGai->vanToc.y = 0.0f;
      }
   }
   else if( (soHoatHinh > 961) && (soHoatHinh < 982) ) {
      viTriSaoGai.x = -2.64f;
      viTriSaoGai.y = 10.1f + banKinh;
      viTriSaoGai.z = -52.0f;
   }
   else if( soHoatHinh > 981 ) { // xuống đường lộ
      float toaDoY = 10.1 + banKinh;  // cho chạy trên mặt đường lộ

      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f;    phapThuyenMatDat.y = 1.0f;    phapThuyenMatDat.z = 0.0f;

      if( soHoatHinh < 1010 ) {

         if( soHoatHinh > 990 ) {  // khi ăn trái banh xui
            float tiSoPhongTo = 1.0f + 0.02f*(soHoatHinh - 990);
            phongTo.x = tiSoPhongTo;
            phongTo.y = tiSoPhongTo;
            phongTo.z = tiSoPhongTo;
         }
         viTriSaoGai.x = -2.64f;
         viTriSaoGai.y = 10.1f + banKinh;
         viTriSaoGai.z = -52.0f;
      }
      else if( soHoatHinh < 1050 ) {
         
         Bezier congBezier;  // cong Bezier cho đoạn thời gian này
         congBezier.diemQuanTri[0].x = -2.64f;   congBezier.diemQuanTri[0].y = toaDoY;   congBezier.diemQuanTri[0].z = -52.0f;
         congBezier.diemQuanTri[1].x = -2.64f;   congBezier.diemQuanTri[1].y = toaDoY;   congBezier.diemQuanTri[1].z = -52.0f;
         congBezier.diemQuanTri[2].x = -2.8f;   congBezier.diemQuanTri[2].y = toaDoY;   congBezier.diemQuanTri[2].z = -30.0f;
         congBezier.diemQuanTri[3].x = -3.2f;   congBezier.diemQuanTri[3].y = toaDoY;   congBezier.diemQuanTri[3].z = -16.9f;
         
         float thamSoBezier = ((float)soHoatHinh - 1010)/40.0f;
         viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );

         // ---- vận tốc
         Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
         tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/89.0f;
//         printf( "%d  saoGai tocDo %5.3f  thamSoBezier %5.3f\n", soHoatHinh, tocDo, thamSoBezier );
         trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      }
      else if( soHoatHinh < 1085 ) {
         Bezier congBezier;  // cong Bezier cho đoạn thời gian này
         congBezier.diemQuanTri[0].x = -3.2f;   congBezier.diemQuanTri[0].y = toaDoY;   congBezier.diemQuanTri[0].z = -16.9f;
         congBezier.diemQuanTri[1].x = -3.5f;   congBezier.diemQuanTri[1].y = toaDoY;   congBezier.diemQuanTri[1].z = -8.1f;
         congBezier.diemQuanTri[2].x = -9.4f;   congBezier.diemQuanTri[2].y = toaDoY;   congBezier.diemQuanTri[2].z = -6.7f;
         congBezier.diemQuanTri[3].x = -9.4f;   congBezier.diemQuanTri[3].y = toaDoY;   congBezier.diemQuanTri[3].z = 0.0f;
         
         float thamSoBezier = ((float)soHoatHinh - 1050)/35.0f;
         viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
         // ---- vận tốc
         Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
         tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/35.0f;
//         printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
         trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      }
      else if( soHoatHinh < 1115 ) {
         Bezier congBezier;  // cong Bezier cho đoạn thời gian này
         congBezier.diemQuanTri[0].x = -9.4f;   congBezier.diemQuanTri[0].y = toaDoY;   congBezier.diemQuanTri[0].z = 0.0f;
         congBezier.diemQuanTri[1].x = -9.4f;   congBezier.diemQuanTri[1].y = toaDoY;   congBezier.diemQuanTri[1].z = 5.9f;
         congBezier.diemQuanTri[2].x = -4.8f;   congBezier.diemQuanTri[2].y = toaDoY;   congBezier.diemQuanTri[2].z = 9.8f;
         congBezier.diemQuanTri[3].x = 0.0f;   congBezier.diemQuanTri[3].y = toaDoY;   congBezier.diemQuanTri[3].z = 9.8f;
         
         float thamSoBezier = ((float)soHoatHinh - 1085)/30.0f;
         viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
         // ---- vận tốc
         Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
         tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
//         printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
         trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      }
      else if( soHoatHinh < 1145 ) {
         Bezier congBezier;  // cong Bezier cho đoạn thời gian này
         congBezier.diemQuanTri[0].x = 0.0f;   congBezier.diemQuanTri[0].y = toaDoY;   congBezier.diemQuanTri[0].z = 9.8f;
         congBezier.diemQuanTri[1].x = 4.8f;   congBezier.diemQuanTri[1].y = toaDoY;   congBezier.diemQuanTri[1].z = 9.8f;
         congBezier.diemQuanTri[2].x = 9.9f;   congBezier.diemQuanTri[2].y = toaDoY;   congBezier.diemQuanTri[2].z = 5.3f;
         congBezier.diemQuanTri[3].x = 9.9f;   congBezier.diemQuanTri[3].y = toaDoY;   congBezier.diemQuanTri[3].z = 0.0f;
         
         float thamSoBezier = ((float)soHoatHinh - 1115)/30.0f;
         viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
         // ---- vận tốc
         Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
         tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
//         printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
         trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      }
      else if( soHoatHinh < 1175 ) {
         Bezier congBezier;  // cong Bezier cho đoạn thời gian này
         congBezier.diemQuanTri[0].x = 9.9f;   congBezier.diemQuanTri[0].y = toaDoY;   congBezier.diemQuanTri[0].z = 0.0f;
         congBezier.diemQuanTri[1].x = 9.9f;   congBezier.diemQuanTri[1].y = toaDoY;   congBezier.diemQuanTri[1].z = -5.3f;
         congBezier.diemQuanTri[2].x = 3.0f;   congBezier.diemQuanTri[2].y = toaDoY;   congBezier.diemQuanTri[2].z = -12.7f;
         congBezier.diemQuanTri[3].x = 3.0f;   congBezier.diemQuanTri[3].y = toaDoY;   congBezier.diemQuanTri[3].z = -26.0f;
         
         float thamSoBezier = ((float)soHoatHinh - 1145)/30.0f;
         viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
         // ---- vận tốc
         Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
         tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/30.0f;
//         printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
         trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      }
      else if( soHoatHinh < 1600 ) {
         viTriSaoGai.x = 3.0f;
         viTriSaoGai.y = toaDoY;
         viTriSaoGai.z = -26.0 - 1.3f*(soHoatHinh - 1175);
         trucXoay.x = -1.0;
         trucXoay.y = 0.0;
         trucXoay.z = 0.0;
         donViHoa( &trucXoay );
         tocDo = 0.6f;
         saoGai->thaiTrang = kSAO_GAI__THAI_TRANG_DUONG_RA_VONG;
      }
   }

   xoay = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, tocDo, banKinh );
   datBienHoaChoVat( saoGai, &phongTo, &xoay, &viTriSaoGai );
//   printf( "-----> %d vi tri saoGai  %5.3f %5.3f %5.3f  phongTo %5.3f\n", soHoatHinh, viTriSaoGai.x, viTriSaoGai.y, viTriSaoGai.z, phongTo.x );
}


void nangCapTraiBanhBiGiet( VatThe *traiBanh, unsigned short soHoatHinh ) {
   
   // ---- đi thẳng lên đường z đến nơi gặp sai gai và chết
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;

   Vecto trucXoay;
   trucXoay.x = 1.0f;   trucXoay.y = 0.0f;   trucXoay.z = 0.0f;

   Quaternion xoay;

   Vecto viTriTraiBanh;
   viTriTraiBanh.x = -3.0f;
   viTriTraiBanh.y = 10.1f + traiBanh->hinhDang.hinhCau.banKinh;
   viTriTraiBanh.z = -535.0f;
   float tocDo = 0.0f;
   
   float banKinhTraiBanh = traiBanh->hinhDang.hinhCau.banKinh;
   
   if( soHoatHinh < 965 ) {  // chạy trên lộ bình thường
      viTriTraiBanh.z = -535.0f + kTOC_DO_TRAI_BANH_PHIM_TRUONG0*soHoatHinh;
      tocDo = kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
   }
   else if( soHoatHinh < 970 ) {  // chặm lại khi gặp trái sao gai
      float goc = 6.2831852f*(soHoatHinh - 965)/20.0f;
      viTriTraiBanh.z = -535.0 + kTOC_DO_TRAI_BANH_PHIM_TRUONG0*(965 + 5.0f*sinf( goc )/6.2831852f);
      tocDo = cosf( goc );
   }
   else if( soHoatHinh < 990 ) {  // rung
      float goc = 6.2831852f*(970 - 965)/20.0f;
      viTriTraiBanh.z = -535.0 + kTOC_DO_TRAI_BANH_PHIM_TRUONG0*(965 + 5.0f*sinf( goc )/6.2831852f);
      tocDo = cosf( goc );
      // ---- đổi bán kính
      if( soHoatHinh & 0x02 )
         traiBanh->hinhDang.hinhCau.banKinh += 0.1f;
      else
         traiBanh->hinhDang.hinhCau.banKinh -= 0.1f;
   }
   else if( soHoatHinh < 1010 ) {
      float goc = 6.2831852f*(970 - 965)/20.0f;
      viTriTraiBanh.z = -535.0 + kTOC_DO_TRAI_BANH_PHIM_TRUONG0*(965 + 5.0f*sinf( goc )/6.2831852f);
      tocDo = 0.0f;
      // ---- đừng cho bạn kính = 0
      if( banKinhTraiBanh > 0.1f )
         traiBanh->hinhDang.hinhCau.banKinh -= 0.1f;
   }

   xoay = tinhXoayChoVatThe( &(traiBanh->quaternion), trucXoay, tocDo, banKinhTraiBanh );
   datBienHoaChoVat( traiBanh, &phongTo, &xoay, &viTriTraiBanh );
//   printf( "---> %d vi tri traiBanhBiGiet  %5.3f %5.3f %5.3f\n", soHoatHinh, viTriTraiBanh.x, viTriTraiBanh.y, viTriTraiBanh.z );

}

void nangCapKienLongSaoGaiDo( VatThe *kienLongSaoGai, unsigned short soHoatHinh ) {
   
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;   trucXoay.y = 1.0f;   trucXoay.z = 0.0f;
   
   Quaternion xoay = datQuaternionTuVectoVaGocQuay( &trucXoay, 0.31415926f*0.1f*soHoatHinh );
   
   Vecto viTriKienLongSaoGai;
   viTriKienLongSaoGai.x = -52.0f;   viTriKienLongSaoGai.y = 27.7f;   viTriKienLongSaoGai.z = -52.0f;
   
   // ---- kiến lồng sao gai
   if( soHoatHinh < 675 ) {
      ; // ---- không làm gì đặt biệt ---- chỉ xoay
   }
   else if( soHoatHinh < 750 ) { // mở kiến nhốp sao gai
      
      float buocKeoLen = 3.2f/(750.0f - 675.0f);
      unsigned short soHoatHinhTuongDoi = soHoatHinh - 675.0f;
      // ---- nâng cấp bề cao kiến
      unsigned short chiSo = 0;
      unsigned short soLuongVatThe = kienLongSaoGai->soLuongVatThe;
      while( chiSo < soLuongVatThe ) {
         float beCao = 3.5f - buocKeoLen*soHoatHinhTuongDoi;
         kienLongSaoGai->danhSachVatThe[chiSo].hinhDang.hop = datHop( 1.0f, beCao, 0.2f, &(kienLongSaoGai->danhSachVatThe[chiSo].baoBiVT) );
         chiSo++;
      }
      
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép
      tinhBaoBiVTChoVatTheGhep( kienLongSaoGai );
      
      // ---- nâng cấp vị trí
      viTriKienLongSaoGai.x = -52.0f;
      viTriKienLongSaoGai.y = 27.7f + 0.5f*buocKeoLen*soHoatHinhTuongDoi;
      viTriKienLongSaoGai.z = -52.0f;
//      printf( "beCao %5.3f   viTri %5.3f %5.3f %5.3f  buocKeoLen %5.3f\n", 3.5f - buocKeoLen*(soHoatHinh - 675.0f), viTriKienLongSaoGai.x, viTriKienLongSaoGai.y, viTriKienLongSaoGai.z, buocKeoLen );
   }
   else {  // phải làm này vì không biết cần bắt đầu từ bức ảnh nào
      
      unsigned short chiSo = 0;
      unsigned short soLuongVatThe = kienLongSaoGai->soLuongVatThe;
      while( chiSo < soLuongVatThe ) {
         kienLongSaoGai->danhSachVatThe[chiSo].hinhDang.hop = datHop( 1.0f, 0.3f, 0.2f, &(kienLongSaoGai->danhSachVatThe[chiSo].baoBiVT) );
         chiSo++;
      }
      
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép
      tinhBaoBiVTChoVatTheGhep( kienLongSaoGai );
      
      viTriKienLongSaoGai.x = -52.0f;
      viTriKienLongSaoGai.y = 27.7f + 1.6f;
      viTriKienLongSaoGai.z = -52.0f;
   }
   
   datBienHoaChoVat( kienLongSaoGai, &phongTo, &xoay, &viTriKienLongSaoGai );
}


void nangCapHatBayQuanhVongXoay( VatThe *hatBayQuanh, unsigned short soHoatHinh ) {

   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;   trucXoay.y = 1.0f;   trucXoay.z = 0.0f;
   
   tinhXoayChoVatThe( &(hatBayQuanh->quaternion), trucXoay, 0.31415926f*0.4f, 1.0f );
   tinhBaoBiVTChoVatTheGhep( hatBayQuanh );
   gomBienHoaChoVat( hatBayQuanh );
}

void nangCapBongBongBay( VatThe *danhSachBongBong, unsigned short soLuongBongBong, unsigned short soHoatHinh ) {

   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;   trucXoay.y = 1.0f;   trucXoay.z = 0.0f;
   
   Quaternion xoay;
   xoay.w = 1.0f;    xoay.x = 0.0f;     xoay.y = 0.0f;     xoay.z = 0.0f;
   
   Vecto viTriBongBong;

   unsigned short chiSo = 0;
   while( chiSo < soLuongBongBong ) {
      // ---- xài vị trí đầu cho bong bóng di chuyển hơi khác nhau
      Vecto viTriDau = danhSachBongBong[chiSo].viTriDau;
      viTriBongBong.x = danhSachBongBong[chiSo].viTriDau.x + 2.0f*sinf( soHoatHinh*0.1f + viTriDau.x ) + 0.6f*soHoatHinh;
      viTriBongBong.y = danhSachBongBong[chiSo].viTriDau.y + 2.0f*cosf( soHoatHinh*0.1f + viTriDau.y );
      viTriBongBong.z = danhSachBongBong[chiSo].viTriDau.z + sinf( soHoatHinh*0.1f + viTriDau.z ) - soHoatHinh;

      datBienHoaChoVat( &(danhSachBongBong[chiSo]), &phongTo, &xoay, &viTriBongBong );

      chiSo++;
   }
}

void nangCapCacBatDienXoay( VatThe *danhSachBatDien, unsigned short soLuongBatDien, unsigned short soHoatHinh ) {
   
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;   trucXoay.y = 1.0f;   trucXoay.z = 0.0f;

   
   float gocXoay = soHoatHinh*0.2f;
   
   unsigned short chiSo = 0;
   while( chiSo < soLuongBatDien ) {
      // ---- xài vị trí đầu cho bong bóng di chuyển hơi khác nhau
      Vecto viTriDau = danhSachBatDien[chiSo].viTriDau;
      Quaternion xoay = datQuaternionTuVectoVaGocQuay( &trucXoay, gocXoay );
      datBienHoaChoVat( &(danhSachBatDien[chiSo]), &phongTo, &xoay, &viTriDau );
      
      chiSo++;
   }
}

void nangCapCotNhay( VatThe *danhSachBatDien, unsigned short soLuongBatDien, unsigned short soHoatHinh ) {
   
   Vecto phongTo;
   phongTo.x = 1.0f;   phongTo.y = 1.0f;   phongTo.z = 1.0f;
   
   Vecto trucXoay;
   Quaternion xoay;
   xoay.w = 1.0f;    xoay.x = 0.0f;     xoay.y = 0.0f;     xoay.z = 0.0f;
   
   // ---- mỗi cột có ba thành phần
   unsigned short chiSo = 0;
   while( chiSo < soLuongBatDien ) {
      // ---- xài vị trí đầu cho bong bóng di chuyển hơi khác nhau
      Vecto viTriDau = danhSachBatDien[chiSo].viTriDau;
      viTriDau.y += 0.5f*sinf( (soHoatHinh + chiSo)*0.3f  );
      datBienHoaChoVat( &(danhSachBatDien[chiSo]), &phongTo, &xoay, &viTriDau );
      viTriDau.y += 0.5f;
      datBienHoaChoVat( &(danhSachBatDien[chiSo+1]), &phongTo, &xoay, &viTriDau );
      viTriDau.y += 0.5f;
      datBienHoaChoVat( &(danhSachBatDien[chiSo+2]), &phongTo, &xoay, &viTriDau );
      chiSo +=3;
   }
}

void nangCapMatSong( VatThe *matSong, unsigned short soHoatHinh ) {
   
    matSong->hinhDang.matSong.thoiGian++;
}

// ---- xài vị trí sao gai cho cách trái banh né sao gai 
void moPhongTraiBanhGiaoThong( VatThe *danhSachVatThe, unsigned short soTraiBanhDau, unsigned short soTraiBanhCuoi, Vecto *viTriSaoGai ) {

   VatThe *traiBanh;
   Vecto phongTo;
   phongTo.x = 1.0f;
   phongTo.y = 1.0f;
   phongTo.z = 1.0f;

   // ----
   unsigned short soTraiBanh = soTraiBanhDau;
   while ( soTraiBanh < soTraiBanhCuoi ) {
      //         printf( "%d  1.0\n", soTraiBanh );
      traiBanh = &(danhSachVatThe[soTraiBanh]);
      // ---- vị trí bây giờ
      float *dich = traiBanh->dich;
      Vecto viTriTraiBanh;
      viTriTraiBanh.x = dich[12];
      viTriTraiBanh.y = dich[13];
      viTriTraiBanh.z = dich[14];

      // ---- tính vị trí tơưng đối với sao gai
      Vecto huongDenSaoGai;
      huongDenSaoGai.x = viTriSaoGai->x - viTriTraiBanh.x;
//      huongDenSaoGai.y = viTriSaoGai.y - viTriTraiBanh.y;
      huongDenSaoGai.z = viTriSaoGai->z - viTriTraiBanh.z;
      // ---- không cần toạ độ y vì mô phỏng này chí đi trên đường băng thẳng
      Vecto vanTocTraiBanh;
      Vecto trucXoay;  // cho xoay trái banh đúng hướng
      float cachBinh = huongDenSaoGai.x*huongDenSaoGai.x + huongDenSaoGai.z*huongDenSaoGai.z;
//      printf( "soLuongTraiBanh %d  cachBinh %5.3f\n", soTraiBanh, cachBinh );
      if( cachBinh > 500.0 )  // không cần né sao gai
         vanTocTraiBanh = vanTocChoViTriChoPhimTruong0( &viTriTraiBanh, traiBanh->duongVao, traiBanh->duongRa, &(traiBanh->thaiTrang), &trucXoay );
      else {   // xem nếu cần né, viTriSaoGai->x > 0.0f vì chỉ né khi sao gai chuần bị ra và đã ra vòng
         if( (traiBanh->thaiTrang == kTHAI_TRANG__RA_VONG) && (traiBanh->duongRa == kDUONG_Z) && (viTriSaoGai->x > 0.0f) )
            vanTocTraiBanh = vanTocNeSaoGaiDoRaDuongZ( &viTriTraiBanh, &(traiBanh->thaiTrang), &trucXoay, viTriSaoGai );
         else // đi bình thường
            vanTocTraiBanh = vanTocChoViTriChoPhimTruong0( &viTriTraiBanh, traiBanh->duongVao, traiBanh->duongRa, &(traiBanh->thaiTrang), &trucXoay );

      }

      traiBanh->vanToc.x = vanTocTraiBanh.x;
      // traiBanh->vanToc.y = vanTocTraiBanh.y; 
      traiBanh->vanToc.z = vanTocTraiBanh.z;
      viTriTraiBanh.x += traiBanh->vanToc.x;
      // viTriTraiBanh.y += traiBanh->vanToc.y;
      viTriTraiBanh.z += traiBanh->vanToc.z;
      //         if( soTraiBanh == 5 )
      //         printf( "  %d  %5.3f %5.3f   %5.3f %5.3f   ", soTraiBanh, viTriTraiBanh.x, viTriTraiBanh.z, vanTocMoi.x, vanTocMoi.z );
      // ---- nâng cấp biến hóa dịch
      datDich( traiBanh->dich, viTriTraiBanh.x, viTriTraiBanh.y, viTriTraiBanh.z );
      datDich( traiBanh->nghichDich, -viTriTraiBanh.x, -viTriTraiBanh.y, -viTriTraiBanh.z );
      // ---- tính góc xoay quanh trục
      Quaternion xoay = tinhXoayChoVatThe( &(traiBanh->quaternion), trucXoay, kTOC_DO_TRAI_BANH_PHIM_TRUONG0, traiBanh->hinhDang.hinhCau.banKinh );
      datBienHoaChoVat( traiBanh, &phongTo, &xoay, &viTriTraiBanh );

      soTraiBanh++;
   }

}

Vecto vanTocChoViTriChoPhimTruong0( Vecto *viTri, unsigned char duongVao, unsigned char duongRa, unsigned char *thaiTrang, Vecto *trucXoay ) {
   
   Vecto vanToc;
   vanToc.x = 0.0f;
   vanToc.z = 0.0f;

   if( *thaiTrang == kTHAI_TRANG__VAO_VONG ) {
      if( duongVao == kDUONG_X ) {
         vanToc.x = kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = 0.0f;
         trucXoay->y = 0.0f;
         trucXoay->z = -1.0f;
      }
      else {
         vanToc.z = kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = 1.0f;
         trucXoay->y = 0.0f;
         trucXoay->z = 0.0f;
      }

      // ---- xem trong vào vòng tròn chưa
      float banKinhBinh = viTri->x*viTri->x + viTri->z*viTri->z;
      
      if( banKinhBinh < kBAN_KINH__VONG_NOI_BINH ) {
         if( duongVao == duongRa )   // đi vào sâu hơn
            *thaiTrang = kTHAI_TRANG__TRONG_VONG;
      }
      else if( banKinhBinh < kBAN_KINH__VONG_NGOAI_BINH ) {
         if( duongVao != duongRa ) // không đi vào sâu
            *thaiTrang = kTHAI_TRANG__TRONG_VONG;
      }
   }
   else if( *thaiTrang == kTHAI_TRANG__TRONG_VONG ) {
      float goc = atanf( viTri->z/viTri->x );
      if( viTri->x < 0.0f ) {
         if( viTri->z < 0.0f )
            goc -= 3.1415926f;
         else
            goc += 3.1415926f;
      }
      
      float banKinhBinh = viTri->x*viTri->x + viTri->z*viTri->z;
      float cosGoc = cosf( goc );
      float sinGoc = sinf( goc );
      vanToc.x = kTOC_DO_TRAI_BANH_PHIM_TRUONG0*sinGoc;
      vanToc.z = -kTOC_DO_TRAI_BANH_PHIM_TRUONG0*cosGoc;
      
      trucXoay->x = -cosGoc;
      trucXoay->y = 0.0f;
      trucXoay->z = -sinGoc;
      
      // ---- xem đến lối ra chưa
      if( duongRa == kDUONG_X ) {
         unsigned char trenDuongX = kDUNG;
         if( viTri->z < -3.0f )
            trenDuongX = kSAI;
         else if( viTri->z > 0.0f )
            trenDuongX = kSAI;
         else if( viTri->x > 0.0f )
            trenDuongX = kSAI;

         if( trenDuongX ) {
            *thaiTrang = kTHAI_TRANG__RA_VONG;
            viTri->z = -3.0f;
         }
      }
      else {
         unsigned char trenDuongZ = kDUNG;
         if( viTri->x < 0.0f )
            trenDuongZ = kSAI;
         else if( viTri->x > 3.0f )
            trenDuongZ = kSAI;
         else if( viTri->z > 0.0f )
            trenDuongZ = kSAI;
         
         if( trenDuongZ ) {
            *thaiTrang = kTHAI_TRANG__RA_VONG;
            viTri->x = 3.0f;
         }
      }
   }
   else if( *thaiTrang == kTHAI_TRANG__RA_VONG ) {
      if( duongRa == kDUONG_X ) {
         vanToc.x = -kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = 0.0f;
         trucXoay->y = 0.0f;
         trucXoay->z = 1.0f;
         
         // ---- nếu xa, đi vào nữa; NẾU MUỐN XÀI NÀY PHẢI ĐƯỢC ĐỔI BIẾN ĐƯỜNG VÀO 
//         if( viTri->x < -500.0f ) {
//            viTri->z = 3.0f;
//            *thaiTrang = kTHAI_TRANG__VAO_VONG;
//         }
 
      }
      else {
         vanToc.z = -kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = -1.0f;
         trucXoay->y = 0.0f;
         trucXoay->z = 0.0f;
         // ---- nếu xa, đi vào nữa; NẾU MUỐN XÀI NÀY PHẢI ĐƯỢC ĐỔI BIẾN ĐƯỜNG VÀO 
//         if( viTri->z < -500.0f ) {
//            viTri->x = -3.0f;
//            *thaiTrang = kTHAI_TRANG__VAO_VONG;
//         
      }

   }
   
   // ---- đường hướng z 
   unsigned char trenDuongZ = kDUNG;
   if( viTri->x < -5.0f )
      trenDuongZ = kSAI;
   else if( viTri->x > 0.0f )
      trenDuongZ = kSAI;
   else if( viTri->z > -12.0f )
      trenDuongZ = kSAI;
   
   if( trenDuongZ ) {
      vanToc.z = kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
//      printf( "---> +z " );
      return vanToc;
   }
   
   // ---- không vận tốc
   return vanToc;
}

#define kCACH_XA_TU_GIUA_DUONG 8.0f


Vecto vanTocNeSaoGaiDoRaDuongZ( Vecto *viTriTraiBanh, unsigned char *thaiTrang, Vecto *trucXoay, Vecto *viTriSaoGai ) {
   
   Vecto vanTocTraiBanh;
   vanTocTraiBanh.x = 0.0f;   vanTocTraiBanh.y = 0.0f;    vanTocTraiBanh.z = 0.0f;
   // ---- tính quãng tương đối với trái banh
   float quangTuongDoi = viTriSaoGai->z - viTriTraiBanh->z;

   if( (quangTuongDoi < 12.0f) && (quangTuongDoi > -2.0f) ) {  // sao gai ở đang sau
      if( viTriTraiBanh->x < kCACH_XA_TU_GIUA_DUONG ) {  // đi ra ngoài đường
         vanTocTraiBanh.x = 1.3f*kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         vanTocTraiBanh.z = -1.3f*kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = -0.707f;
         trucXoay->y = 0.0f;
         trucXoay->z = -0.707f;
      }
      else {  // hạy songๆ với đường mà chậm lại một chút
         vanTocTraiBanh.x = 0.0f;
         vanTocTraiBanh.z = -0.9f*kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = -1.0f;
         trucXoay->y = 0.0f;
         trucXoay->z = 0.0f;
      }
   }
   else if( (quangTuongDoi > -15.0f) && (quangTuongDoi < -2.0f) ) { // sao gai ở phía trước

      if( viTriTraiBanh->x > 3.0f ) { // trở lại lằn trên đường
         vanTocTraiBanh.x = -1.2f*kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         vanTocTraiBanh.z = -kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = -1.0f;
         trucXoay->y = 0.0f;
         trucXoay->z = 1.2f;
      }
      else {  // tham gia giao thông bình thường
         viTriTraiBanh->x = 3.0f;  // đặt lại trái vào lằn như trước
         vanTocTraiBanh.x = 0.0f;  // không còn vận tốc hướng x
         vanTocTraiBanh.z = -kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
         trucXoay->x = -1.0f;
         trucXoay->y = 0.0f;
         trucXoay->z = 0.0f;
      }
   }
   else {   // không cần né
      vanTocTraiBanh.x = 0.0f;
      vanTocTraiBanh.z = -kTOC_DO_TRAI_BANH_PHIM_TRUONG0;
      trucXoay->x = -1.0f;
      trucXoay->y = 0.0f;
      trucXoay->z = 0.0f;
   }
//   if( quangTuongDoi < 400.0 )
//      printf( "quangTuongDoi %5.3f  vanTocTraiBanh %5.3f %5.3f\n", quangTuongDoi, vanTocTraiBanh.x, vanTocTraiBanh.z );
   return vanTocTraiBanh;
}
