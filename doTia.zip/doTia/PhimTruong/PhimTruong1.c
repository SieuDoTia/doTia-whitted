#include "PhimTruong1.h"
#include "../VatThe/VatThe.h"
#include "../NhanVat.h"
#include "../HangSo.h"
#include "../XemCat/TinhBaoBi.h"
#include "../DocThamSo.h"
#include "../Toan/Bezier.h"
#include "../Toan/BienHoa.h"
#include "../Toan/Quaternion.h"
#include <stdlib.h>
#include <math.h>

#pragma mark ---- PHIM TRƯỜNG 1
#define kNHAN_VAT__VAI_CHANH           0       // nhân vật vai chánh
#define kNHAN_VAT__SAO_GAI             1       // nhân vật sao gai


void chuanBiMayQuayPhimVaMatTroiPhimTruong1( PhimTruong *phimTruong );
unsigned short datMatDat( VatThe *danhSachVatThe );
unsigned short datCacDoiHinhNonCat( VatThe *danhSachVatThe, float mucDat );
unsigned short datDayNuiParabol( VatThe *danhSachVat, float mucDat );
unsigned short datSongBongBong( VatThe *danhSachVatThe );

unsigned short datQuocLo( VatThe *danhSachVatThe );
unsigned short datCauSongBongBong( VatThe *danhSachVat );
unsigned short datLapPhuong( VatThe *danhSachVat );
unsigned short datDayHinhTru( VatThe *danhSachVat );
unsigned short datNapDayHinhTru( VatThe *danhSachVat );
unsigned short datHinhCauKhongLoXoay( VatThe *danhSachVat );
unsigned short datDayHinhNonHuongZ_PT_1( VatThe *danhSachVat );
unsigned short datHemVucNui( VatThe *danhSachVat );
unsigned short datTuongSong( Vecto viTri, float dichLen, float banKinh, VatThe *danhSachVat );
unsigned short datBayBongBong( VatThe *danhSachVat );

unsigned short datCong( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datCotCong( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datMaiDinhCong( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datHaiKimTuThapXoay( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datHaiThauKinhXoay( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datVuDinhCong( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datChanLaCo( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datLaCo( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datDiaSauLaCo( VatThe *danhSachVat, Vecto viTriDay );
unsigned short datLocXoay( VatThe *danhSachVat, Vecto viTriDay );

void nangCapPhimTruong1_mayQuayPhim( PhimTruong *phimTruong );
void nangCapPhimTruong1_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh );
void nangCapVaiChanh_PT_1( VatThe *vaiChanh, unsigned short soHoatHinh );
void nangCapSaoGai_PT_1( VatThe *saoGai, unsigned short soHoatHinh );
void nangCapHinhCauKhongLoXoay( VatThe *hinhCauKhongLoXoay );
void nangCapNapDayHinhTru( VatThe *mangVatThe, unsigned short soLuongVatThe );
void nangCapBayBongBong( VatThe *danhSachBongBong, unsigned short soLuongBongBong, unsigned short soHoatHinh );
void nangCapHaiKimTuThapXoay( VatThe *kimTuThap );
void nangCapHaiThauKinhXoay( VatThe *kimTuThap );
void nangCapVuDinhCong( VatThe *danhSachVat, unsigned short soHoatHinh );
void nangCapLaCo( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh );
void nangCapLocXoay( VatThe *danhSachVat, unsigned short soHoatHinh );

#define kNHAN_VAT__HINH_CAU_KHONG_LO_XOAY 3
#define kNHAN_VAT__HAI_KIM_TU_THAP_XOAY   4
#define kNHAN_VAT__HAI_THAU_KINH_XOAY     5
#define kNHAN_VAT__VU_DINH_CONG           6
#define kNHAN_VAT__LOC_XOAY_0             7
#define kNHAN_VAT__LOC_XOAY_1             8
#define kNHAN_VAT__LOC_XOAY_2             9
#define kNHAN_VAT__NAP_DAY_HINH_TRU_DAU  10
#define kNHAN_VAT__NAP_DAY_HINH_TRU_CUOI 11
#define kNHAN_VAT__MIEN_LA_CO_DAU        12
#define kNHAN_VAT__MIEN_LA_CO_CUOI       13
#define kNHAN_VAT__BONG_BONG_DAU_PT1     14
#define kNHAN_VAT__BONG_BONG_CUOI_PT1    15

#define kSO_LUONG__BONG_BONG_TRONG_BAY  50  // <----- thường là 7000 nhưng đặt số thấp như 50 để tính lẹ khi không thấy bong bóng
#define kTOC_DO_BONG_BONG_TRONG_BAY     0.004f       // tốc độ bong bóng trong bay
#define kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY  300   // số lượng hạt bay trong lốc xoay

PhimTruong datPhimTruongSo1( unsigned int argc, char **argv ) {
   
   PhimTruong phimTruong;
   phimTruong.soNhoiToiDa = 5;
   
   unsigned int soHoatHinhDau = 0;
   unsigned int soHoatHinhCuoi = 2250;    // số bức ảnh cuối cho phim trường này
   
   docThamSoHoatHinh( argc, argv, &soHoatHinhDau, &soHoatHinhCuoi );
   if( soHoatHinhDau > 2249 )
      soHoatHinhDau = 2249;
   if( soHoatHinhCuoi > 2250 )    // số bức ảnh cuối cho phim trường này
      soHoatHinhCuoi = 2250;
   
   phimTruong.soHoatHinhDau = soHoatHinhDau;
   phimTruong.soHoatHinhHienTai = soHoatHinhDau;
   phimTruong.soHoatHinhCuoi = soHoatHinhCuoi;

   phimTruong.danhSachVatThe = malloc( kSO_LUONG_VAT_THE_TOI_DA*sizeof(VatThe) );
   
   // ---- chuẩn bị máy quay phim
   chuanBiMayQuayPhimVaMatTroiPhimTruong1( &phimTruong );
   Mau mauDinhTroi;
   mauDinhTroi.d = 0.1f;   mauDinhTroi.l = 0.1f;   mauDinhTroi.x = 0.5f;   mauDinhTroi.dd = 1.0f;
   Mau mauChanTroi;  // chỉ có một;
   mauChanTroi.d = 0.9f;  mauChanTroi.l = 0.9f;   mauChanTroi.x = 1.0f;    mauChanTroi.dd = 1.0f;
   phimTruong.hoaTietBauTroi = datHoaTietBauTroi( &mauDinhTroi, &mauDinhTroi, &mauChanTroi, &mauChanTroi, 0.0f );
   
   VatThe *danhSachVat = phimTruong.danhSachVatThe;
   phimTruong.soLuongVatThe = 0;

   // ---- đất
   phimTruong.soLuongVatThe += datMatDat( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.soLuongVatThe += datCacDoiHinhNonCat( &(danhSachVat[phimTruong.soLuongVatThe]), 100.0f );
   phimTruong.soLuongVatThe += datDayNuiParabol( &(danhSachVat[phimTruong.soLuongVatThe]), 100.0f );
   // ---- đường
   phimTruong.soLuongVatThe += datQuocLo( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- cầu
   phimTruong.soLuongVatThe += datCauSongBongBong( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- lập phương
   phimTruong.soLuongVatThe += datLapPhuong( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- dãy hình trụ
   phimTruong.soLuongVatThe += datDayHinhTru( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- dãy hình gần lề đường lộ
//   phimTruong.soLuongVatThe += datDayHinhNonHuongZ_PT_1( &(danhSachVat[phimTruong.soLuongVatThe]) );
   
   phimTruong.soLuongVatThe += datSongBongBong( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- hai tường hẻm núi
   phimTruong.soLuongVatThe += datHemVucNui( &(danhSachVat[phimTruong.soLuongVatThe]) );
   
   // ---- cổng của cầu
   Vecto viTriDay;
   viTriDay.x = 0.0f;   viTriDay.y = 100.0f;   viTriDay.z = 190.0f;
   phimTruong.soLuongVatThe += datCong( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDay );

   // ---- CÁC NHÂN VẬT
   // sao gai
   // Cái sẽ bị hư gì hệ thống tăng tốc độ kết xuất sẽ đổi thứ tự vật thề <---------
   
   Vecto viTri;
   viTri.x = 3.0f;   viTri.y = 100.0f + kSAO_GAI__BAN_KINH*1.4f;     viTri.z = 1420.0f;
   phimTruong.nhanVat[kNHAN_VAT__SAO_GAI] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datKeThuSaoGaiDo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   // ---- vai chánh
   
   viTri.x = 3.0f;   viTri.y = 100.0f + 0.7f;     viTri.z = 1400.0f;  // 0.7 là bán kính vai chánh
   phimTruong.nhanVat[kNHAN_VAT__VAI_CHANH] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datVaiChanh( &(danhSachVat[phimTruong.soLuongVatThe]) , viTri );
   // ---- hình cầu khổng lộ xoay
   phimTruong.nhanVat[kNHAN_VAT__HINH_CAU_KHONG_LO_XOAY] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datHinhCauKhongLoXoay( &(danhSachVat[phimTruong.soLuongVatThe]) );
   // ---- hai kim tư tháp xoay
   phimTruong.nhanVat[kNHAN_VAT__HAI_KIM_TU_THAP_XOAY] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datHaiKimTuThapXoay( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDay );
   // ---- hai thấu kính xoay
   phimTruong.nhanVat[kNHAN_VAT__HAI_THAU_KINH_XOAY] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datHaiThauKinhXoay( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDay );
   // ---- vù đỉnh cổng
   phimTruong.nhanVat[kNHAN_VAT__VU_DINH_CONG] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datVuDinhCong( &(danhSachVat[phimTruong.soLuongVatThe]), viTriDay );

   // ---- các nắp cho dãy hình trụ
   phimTruong.nhanVat[kNHAN_VAT__NAP_DAY_HINH_TRU_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datNapDayHinhTru( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.nhanVat[kNHAN_VAT__NAP_DAY_HINH_TRU_CUOI] = phimTruong.soLuongVatThe;

   // ---- sàn lá cờ
   viTri.x = -18.0f;   viTri.y = 100.0f;     viTri.z = -210.0f;
   phimTruong.soLuongVatThe += datChanLaCo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   viTri.x = 18.0f;
   phimTruong.soLuongVatThe += datChanLaCo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   
   // ---- dĩa sau lá cờ
   viTri.x = -18.0f;   viTri.y = 100.0f;     viTri.z = -222.0f;
   phimTruong.soLuongVatThe += datDiaSauLaCo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   viTri.x = 18.0f;
   phimTruong.soLuongVatThe += datDiaSauLaCo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );

   // ---- hai lá cờ
   viTri.x = -18.0f;   viTri.y = 103.0f;     viTri.z = -210.0f;
   phimTruong.nhanVat[kNHAN_VAT__MIEN_LA_CO_DAU] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datLaCo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   viTri.x = 18.0f;
   phimTruong.soLuongVatThe += datLaCo( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );
   phimTruong.nhanVat[kNHAN_VAT__MIEN_LA_CO_CUOI] = phimTruong.soLuongVatThe;
 
   // ----- các lốc xoay
   viTri.x = -2270.0f;   viTri.y = 101.0f;     viTri.z = -745.0f;
   phimTruong.nhanVat[kNHAN_VAT__LOC_XOAY_0] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datLocXoay( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );

   viTri.x = -4345.0f;   viTri.y = 101.0f;     viTri.z = -680.0f;
   phimTruong.nhanVat[kNHAN_VAT__LOC_XOAY_1] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datLocXoay( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );

   viTri.x = -4000.0f;   viTri.y = 101.0f;     viTri.z = -825.0f;
   phimTruong.nhanVat[kNHAN_VAT__LOC_XOAY_2] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datLocXoay( &(danhSachVat[phimTruong.soLuongVatThe]), viTri );

   // ---- các bong bóng bay trong hẻm núi
   // srand( 0 );
   phimTruong.nhanVat[kNHAN_VAT__BONG_BONG_DAU_PT1] = phimTruong.soLuongVatThe;
   phimTruong.soLuongVatThe += datBayBongBong( &(danhSachVat[phimTruong.soLuongVatThe]) );
   phimTruong.nhanVat[kNHAN_VAT__BONG_BONG_CUOI_PT1] = phimTruong.soLuongVatThe;

   // ---- nâng cấp mô phỏng cho các trái banh và nhân vật
   unsigned short soHoatHinh = 0;
   while ( soHoatHinh < phimTruong.soHoatHinhDau ) {
      nangCapPhimTruong1_nhanVat( &phimTruong, soHoatHinh );
      soHoatHinh++;
   }

   return phimTruong;
}

void chuanBiMayQuayPhimVaMatTroiPhimTruong1( PhimTruong *phimTruong ) {
   // ==== máy quay phim
   phimTruong->mayQuayPhim.kieuChieu = kKIEU_CHIEU__PHOI_CANH;
   // ---- vị trí bắt đầu cho máy quay phim
   phimTruong->mayQuayPhim.viTri.x = 400.0f;
   phimTruong->mayQuayPhim.viTri.y = 200.0f;
   phimTruong->mayQuayPhim.viTri.z = 800.0f;
   phimTruong->mayQuayPhim.cachManChieu = 5.0f;
   Vecto trucQuayMayQuayPhim;
   trucQuayMayQuayPhim.x = 0.0f;
   trucQuayMayQuayPhim.y = 1.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   phimTruong->mayQuayPhim.quaternion = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, 4.71f );
   quaternionSangMaTran( &(phimTruong->mayQuayPhim.quaternion), phimTruong->mayQuayPhim.xoay );
   //   mayQuayPhim.diChuyen = ();

   // ---- mặt trời
   Vecto anhSangMatTroi;
   anhSangMatTroi.x = -1.0f;
   anhSangMatTroi.y = -0.5f;
   anhSangMatTroi.z = -0.5f;
   donViHoa( &anhSangMatTroi );
   phimTruong->matTroi.huongAnh = anhSangMatTroi;
   phimTruong->matTroi.mauAnh.d = 1.0f;
   phimTruong->matTroi.mauAnh.l = 1.0f;
   phimTruong->matTroi.mauAnh.x = 1.0f;
   phimTruong->matTroi.mauAnh.dd = 1.0f;
}


unsigned short datMatDat( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== bờ đất
   Mau mauDat0;
   mauDat0.d = 1.0f;   mauDat0.l = 0.55f;   mauDat0.x = 0.0f;   mauDat0.dd = 1.0f;   mauDat0.p = 0.0f;
   Mau mauDat1;
   mauDat1.d = 1.0f;   mauDat1.l = 1.0f;   mauDat1.x = 1.0f;   mauDat1.dd = 1.0f;   mauDat1.p = 0.0f;
   
   // ---- mặt đất bên +z, mặt trên cao 100,0
   viTri.x = 0.0f;      viTri.y = 50.0f;        viTri.z = 2000.0f;
   danhSachVat[0].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[0].soHoaTiet = kHOA_TIET__CA_RO;

   // ----
   mauDat0.d = 1.0f;   mauDat0.l = 0.6f;   mauDat0.x = 0.2f;   mauDat0.dd = 1.0f;
   viTri.z = 1600.0f;
   danhSachVat[1].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[1].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.z = 1200.0f;
   danhSachVat[2].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[2].soHoaTiet = kHOA_TIET__CA_RO;
   
   mauDat0.d = 1.0f;   mauDat0.l = 0.8f;   mauDat0.x = 0.1f;   mauDat0.dd = 1.0f;  // đỏ hơn một chút
   viTri.z = 800.0f;
   danhSachVat[3].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTri );
   danhSachVat[3].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[3].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.z = 400.0f;
   danhSachVat[4].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTri );
   danhSachVat[4].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[4].soHoaTiet = kHOA_TIET__CA_RO;
   
   // ---- mặt đất bên -z, mặt trên cao 100,0
   viTri.x = 475.0f;  // ngắn hơn bên thường
   viTri.z = -600.0f;
//   danhSachVat[5].hinhDang.hop = datHop( 1549.999f, 99.999f, 399.999f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[5].mucDichBool = 1;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].hoaTiet.hoaTietCaRoMin = datHoaTietCaRoMin( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[5].soHoaTiet = kHOA_TIET__CA_RO_MIN;
   
   danhSachVat[5].soLuongVatThe = 3;
   danhSachVat[5].danhSachVatThe = malloc( sizeof( VatThe )*3 );
   
   viTri.x = 0.0f;   viTri.y = 0.0f;  viTri.z = 0.0f;
   danhSachVat[5].danhSachVatThe[0].hinhDang.hop = datHop( 1559.999f, 99.999f, 399.999f, &(danhSachVat[5].danhSachVatThe[0].baoBiVT) );
   danhSachVat[5].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[5].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5].danhSachVatThe[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].danhSachVatThe[0].giaTri = 1;

   // ---- hình nón lớn
   viTri.x = -580.0f;   viTri.y = 2.0f;  viTri.z = 0.0f;
   danhSachVat[5].danhSachVatThe[1].hinhDang.hinhNon = datHinhNon( 0.0f, 70.0f, 100.0f, &(danhSachVat[5].danhSachVatThe[1].baoBiVT) );
   danhSachVat[5].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[5].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5].danhSachVatThe[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].danhSachVatThe[1].giaTri = -1;

   // ---- hình nón lớn
   viTri.x = -400.0f;   viTri.y = 2.0f;  viTri.z = -100.0f;
   danhSachVat[5].danhSachVatThe[2].hinhDang.hinhNon = datHinhNon( 0.0f, 70.0f, 100.0f, &(danhSachVat[5].danhSachVatThe[2].baoBiVT) );
   danhSachVat[5].danhSachVatThe[2].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[5].danhSachVatThe[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5].danhSachVatThe[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].danhSachVatThe[2].giaTri = -1;

   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[5]) );

   viTri.x = 0.0f;
   viTri.y = 50.0f;
   viTri.z = -1000.0f;
   danhSachVat[6].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[6].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &quaternion, &viTri );
   danhSachVat[6].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[6].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.z = -1400.0f;
   danhSachVat[7].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[7].baoBiVT) );
   danhSachVat[7].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[7].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &quaternion, &viTri );
   danhSachVat[7].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[7].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.z = -1800.0f;
   danhSachVat[8].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[8].baoBiVT) );
   danhSachVat[8].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[8].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[8]), &phongTo, &quaternion, &viTri );
   danhSachVat[8].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[8].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.z = -2200.0f;
   danhSachVat[9].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[9].baoBiVT) );
   danhSachVat[9].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[9].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[9]), &phongTo, &quaternion, &viTri );
   danhSachVat[9].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[9].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.z = -2600.0f;
   danhSachVat[10].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[10].baoBiVT) );
   danhSachVat[10].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[10].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10]), &phongTo, &quaternion, &viTri );
   danhSachVat[10].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[10].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.z = -3000.0f;
   danhSachVat[11].hinhDang.hop = datHop( 2499.999f, 99.999f, 399.999f, &(danhSachVat[11].baoBiVT) );
   danhSachVat[11].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[11].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[11]), &phongTo, &quaternion, &viTri );
   danhSachVat[11].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat0, &mauDat1, 40.0f, 10.0f, 40.0f );
   danhSachVat[11].soHoaTiet = kHOA_TIET__CA_RO;

   return 12;
}

unsigned short datCacDoiHinhNonCat( VatThe *danhSachVat, float mucDat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   float banKinh = 0.0f;
   unsigned short soLuongVatThe = 0;
   Mau mau0;
   Mau mau1;

   // ==== bên +z
   // ---- -x
   mau0.d = 1.0f;   mau0.l = 0.6f;  mau0.x = 0.6f;   mau0.dd = 1.0f;   mau0.p = 0.0f;
   mau1.d = 1.0f;   mau1.l = 1.0f;  mau1.x = 1.0f;   mau1.dd = 1.0f;   mau1.p = 0.0f;

   viTri.x = -100.0f;
   viTri.y = mucDat + 9.0f;
   viTri.z = 430.0f;
   banKinh = 30.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = -70.0f;
   viTri.y = mucDat + 5.0f;
   viTri.z = 310.0f;
   banKinh = 50.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = -270.0f;
   viTri.y = mucDat + 3.0f;
   viTri.z = 350.0f;
   banKinh = 40.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = -275.0f;
   viTri.y = mucDat + 8.0f;
   viTri.z = 358.0f;
   banKinh = 15.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = -550.0f;
   viTri.y = mucDat + 5.0f;
   viTri.z = 380.0f;
   banKinh = 105.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   // ----- +x
   viTri.x = 100.0f;
   viTri.y = mucDat + 5.0f;
   viTri.z = 550.0f;
   banKinh = 20.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = 220.0f;
   viTri.y = mucDat + 3.0f;
   viTri.z = 420.0f;
   banKinh = 60.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = 530.0f;
   viTri.y = mucDat + 3.0f;
   viTri.z = 380.0f;
   banKinh = 20.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = 450.0f;
   viTri.y = mucDat + 5.0f;
   viTri.z = 680.0f;
   banKinh = 100.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = 600.0f;
   viTri.y = mucDat + 2.0f;
   viTri.z = 880.0f;
   banKinh = 150.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   // ==== bên -z
   // -x
   viTri.x = -860.0f;
   viTri.y = mucDat - 4.0f;
   viTri.z = -820.0f;
   banKinh = 350.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = -400.0f;
   viTri.y = mucDat + 8.0f;
   viTri.z = -850.0f;
   banKinh = 180.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = -80.0f;
   viTri.y = mucDat + 10.0f;
   viTri.z = -950.0f;
   banKinh = 50.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 21.0f, banKinh + 0.0f, 30.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   
   viTri.x = -50.0f;
   viTri.y = mucDat + -3.0f;
   viTri.z = -300.0f;
   banKinh = 25.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = -70.0f;
   viTri.y = mucDat + 2.0f;
   viTri.z = -330.0f;
   banKinh = 15.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   
   // ---- +x
   viTri.x = 35.0f;
   viTri.y = mucDat;
   viTri.z = -270.0f;
   banKinh = 20.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 3.5f, banKinh + 0.0f, 5.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = 850.0f;
   viTri.y = mucDat + 5.0f;
   viTri.z = -480.0f;
   banKinh = 80.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = 150.0f;
   viTri.y = mucDat + 5.0f;
   viTri.z = -1050.0f;
   banKinh = 80.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = -450.0f;
   viTri.y = mucDat + 13.0f;
   viTri.z = -800.0f;
   banKinh = 80.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 21.0f, banKinh + 0.0f, 30.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = 750.0f;
   viTri.y = mucDat + 6.5f;
   viTri.z = -680.0f;
   banKinh = 30.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;
   
   viTri.x = 650.0f;
   viTri.y = mucDat + 3.5f;
   viTri.z = -550.0f;
   banKinh = 30.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = 250.0f;
   viTri.y = mucDat + 3.0f;
   viTri.z = -860.0f;
   banKinh = 55.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   viTri.x = 60.0f;
   viTri.y = mucDat + 10.0f;
   viTri.z = -860.0f;
   banKinh = 30.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = 400.0f;
   viTri.y = mucDat + 8.0f;
   viTri.z = -1020.0f;
   banKinh = 80.0f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( banKinh + 14.0f, banKinh + 0.0f, 20.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO;
   soLuongVatThe++;

   return soLuongVatThe;
}

unsigned short datDayNuiParabol( VatThe *danhSachVat, float mucDat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   unsigned short soLuongVatThe = 0;
   Mau mau0;
   Mau mau1;
   
   // bên -x
   mau0.d = 0.1f;   mau0.l = 0.0f;  mau0.x = 0.4f;   mau0.dd = 1.0f;   mau0.p = 0.0f;
   mau1.d = 1.0f;   mau1.l = 1.0f;  mau1.x = 1.0f;   mau1.dd = 1.0f;   mau1.p = 0.0f;
   
   float mangBanKinh[] = { -700.0f, -560.0f, -350.0f,  -300.0f, -350.0f,
      -480.0f, -450.0f, -400.0f,  -350.0f, -500.0f,
      -800.0f, -430.0f, -600.0f, -800.0f, -800.0f,
      -500.0f, -500.0f, -1200.0f, -750.0f};
   
   float mangBeCao[] =   { 100.0f, 580.0,  450.0f,   200.0f, 400.0f,
      280.0f,  800.0f, 400.0f,   250.0f,  500.0f,
      500.0f, 300.0f, 400.0f, 300.0f, 500.0f,
      200.0f, 300.0f, 1000.0f, 550.0f};
   
   float mangViTri_x[] = { -1200.0f, -1000.0f, -500.0f, -1000.0f, -2000.0f,
      -1600.0f, -2500.0f, -300.0f, -2200.0f, -3500.0f,
      -3500.0f, -4400.0f, 350.0f, 800.0f, 1200.0f,
      2200.0f, 1400.0f, 3400.0f, 3000.0f};
   
   float mangViTri_z[] = { -6000.0f, -5500.0f, -3200.0f, -3500.0f, -3600.0f,
      -3700.0f, -3800.0f, -4080.0f, -4200.0f, -5000.0f,
      -5500.0f, 3500.0f, -5075.0f, -4000.0f, -4500.0f,
      -5000.0f, -5200.0f, -5500.0f, -6500.0f, };


   while( soLuongVatThe < 19 ) {
      float beCao = mangBeCao[soLuongVatThe];
      viTri.x = mangViTri_x[soLuongVatThe];
      viTri.y = mucDat + mangBeCao[soLuongVatThe];
      viTri.z = mangViTri_z[soLuongVatThe];

      danhSachVat[soLuongVatThe].hinhDang.matParabol = datMatParabol( mangBanKinh[soLuongVatThe], mangBeCao[soLuongVatThe], &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__MAT_PARABOL;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietCaRoMin = datHoaTietCaRoMin( &mau0, &mau1, 100.0f, 100.0f, 100.0f );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__CA_RO_MIN;
      soLuongVatThe++;
   }

   return soLuongVatThe;
}


unsigned short datSongBongBong( VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;

   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- mặt song
   Mau mauSong;
   mauSong.d = 0.5f;  mauSong.l = 0.5f;  mauSong.x = 0.5f;  mauSong.dd = 1.0f;   mauSong.p = 0.8f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = -170.0f;       viTri.z = -100.0f;
   danhSachVat[0].hinhDang.matSong = datMatSong( 2000.0f, 600.0f, 0.3f, 0.3f, 0.8f, 0.5f, 1.0f, 1.0f, -0.3f, 0.3f, kSAI, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__MAT_SONG;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauSong );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;

   return 1;
}

unsigned short datQuocLo( VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== bờ đất
   Mau mauDat;
   mauDat.d = 1.0f;   mauDat.l = 0.8f;   mauDat.x = 0.4f;   mauDat.dd = 1.0f;   mauDat.p = 0.0f;
   
   float mangViTri_z[] = { 2400.0f, 2000.0f, 1600.0f, 1200.0f, 800.0f, 400.0f,
      -420.0f, -820.0f, -1220.0f, -1620.0f, -2020.0f, -2400.0f, -2800.0f};

   // ==== mặt đường
   Mau mauOc0;
   Mau mauOc1;
   Mau mauOc2;
   mauOc0.d = 0.7f;     mauOc0.l = 0.5f;      mauOc0.x = 0.3f;     mauOc0.dd = 1.0f;    mauOc0.p = 0.0f;
   mauOc1.d = 0.8f;     mauOc1.l = 0.6f;     mauOc1.x = 0.4f;     mauOc1.dd = 1.0f;    mauOc1.p = 0.0f;
   mauOc2.d = 0.85f;     mauOc2.l = 0.7f;      mauOc2.x = 0.4f;     mauOc2.dd = 1.0f;    mauOc2.p = 0.0f;
   
   viTri.x = 0.0f;      viTri.y = 100.1f;
   Vecto huongNgang;
   huongNgang.x = 1.0f;   huongNgang.y = 0.0f;   huongNgang.z = 0.0f;
   Vecto huongDoc;
   huongDoc.x = 0.0f;   huongDoc.y = 0.0f;   huongDoc.z = 1.0f;

   unsigned short soLuongVatThe = 0;
   while( soLuongVatThe < 13 ) {
      viTri.z = mangViTri_z[soLuongVatThe];
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 12.0f, 0.2f, 400.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mauDat, &mauOc0, &mauOc1, &mauOc2, 0.2f, 0.2f, 0.2f, 3.0f, 3.0f, 0.7f, 0.0f, 50.0f );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
      
      soLuongVatThe++;
   }

   // ==== LAN CAN

   Mau mauLanCan;
   mauLanCan.d = 1.0f;    mauLanCan.l = 0.4f;    mauLanCan.x = 0.0f;    mauLanCan.dd = 1.0f;    mauLanCan.p = 0.0f;
   mauOc0.d = 0.8f;     mauOc0.l = 0.3f;     mauOc0.x = 0.0f;     mauOc0.dd = 1.0f;    mauOc0.p = 0.0f;
   mauOc1.d = 0.75f;     mauOc1.l = 0.25f;     mauOc1.x = 0.0f;     mauOc1.dd = 1.0f;    mauOc1.p = 0.0f;
   mauOc2.d = 0.7f;     mauOc2.l = 0.2f;     mauOc2.x = 0.0f;     mauOc2.dd = 1.0f;    mauOc2.p = 0.0f;

   viTri.y = 100.7f;
   while( soLuongVatThe < 26 ) {
      viTri.z = mangViTri_z[soLuongVatThe-13];
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 0.5f, 1.0f, 400.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mauLanCan, &mauOc0, &mauOc1, &mauOc2, 0.1f, 0.1f, 0.1f, 25.0f, 10.0f, 0.2f, 0.0f, 20.0f );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
      
      soLuongVatThe++;
   }

   return soLuongVatThe;
}

unsigned short datCauSongBongBong( VatThe *danhSachVat ) {
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== màu mặt đường
   Mau mauDat;
   mauDat.d = 0.5f;   mauDat.l = 0.2f;   mauDat.x = 0.6f;   mauDat.dd = 1.0f;   mauDat.p = 0.0f;
   Mau mau1;
   mau1.d = 1.0f;   mau1.l = 0.85f;   mau1.x = 1.0f;   mau1.dd = 1.0f;   mau1.p = 0.0f;

   Vecto trucSoc;
   trucSoc.x = 0.0f;   trucSoc.y = 0.0f;   trucSoc.z = 1.0f;
   
   // ---- mặt đường đi
   viTri.x = 0.0f;      viTri.y = 99.2f;        viTri.z = -10.0f;
   danhSachVat[0].hinhDang.hop = datHop( 15.0f, 2.0f, 420.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauDat, &mau1, 20.0f, 0.5f, &trucSoc );
   danhSachVat[0].soHoaTiet = kHOA_TIET__SOC;
   
   // ---- lang cang -x
   mauDat.d = 0.7f;   mauDat.l = 0.35f;   mauDat.x = 0.7f;   mauDat.dd = 1.0f;
   mau1.d = 1.0f;   mau1.l = 0.85f;   mau1.x = 1.0f;   mau1.dd = 1.0f;
   viTri.y = 100.3f;
   viTri.x = -7.5f;
   danhSachVat[1].hinhDang.hop = datHop( 1.0f, 1.0f, 420.0f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauDat, &mau1, 20.0f, 0.5f, &trucSoc );
   danhSachVat[1].soHoaTiet = kHOA_TIET__SOC;

   viTri.y = 99.0f;
   danhSachVat[2].hinhDang.hop = datHop( 1.0f, 1.0f, 420.0f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauDat, &mau1, 20.0f, 0.5f, &trucSoc );
   danhSachVat[2].soHoaTiet = kHOA_TIET__SOC;

   // ---- lang cang +x
   viTri.y = 100.3f;
   viTri.x = 7.5f;
   danhSachVat[3].hinhDang.hop = datHop( 1.0f, 0.8f, 420.0f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTri );
   danhSachVat[3].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauDat, &mau1, 20.0f, 0.5f, &trucSoc );
   danhSachVat[3].soHoaTiet = kHOA_TIET__SOC;

   viTri.y = 99.0f;
   danhSachVat[4].hinhDang.hop = datHop( 1.0f, 1.0f, 420.0f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTri );
   danhSachVat[4].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauDat, &mau1, 20.0f, 0.5f, &trucSoc );
   danhSachVat[4].soHoaTiet = kHOA_TIET__SOC;

   // ---- rao chia lằn đường
   mauDat.d = 0.5f;   mauDat.l = 0.25f;   mauDat.x = 0.3f;
   mau1.d = 1.0f;   mau1.l = 0.8f;   mau1.x = 0.6f;
   viTri.x = 0.0f;    viTri.y = 100.7f;
   danhSachVat[5].hinhDang.hop = datHop( 0.5f, 1.0f, 420.0f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauDat, &mau1, 20.0f, 0.5f, &trucSoc );
   danhSachVat[5].soHoaTiet = kHOA_TIET__SOC;

   return 6;
}

unsigned short datLapPhuong( VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== màu mặt đường
   Mau mauDat;
   mauDat.d = 1.0f;   mauDat.l = 0.0f;   mauDat.x = 0.0f;   mauDat.dd = 1.0f;   mauDat.p = 0.0f;
   Mau mau1;
   mau1.d = 1.0f;   mau1.l = 0.95f;   mau1.x = 0.95f;   mau1.dd = 1.0f;   mau1.p = 0.0f;

   viTri.x = -800.0f;      viTri.y = 300.0f;        viTri.z = 1000.0f;
//   danhSachVat[0].hinhDang.hop = datHop( 15.0f, 0.5f, 400.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[0].mucDichBool = 1;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[0].soHoaTiet = kHOA_TIET__CA_RO;

   danhSachVat[0].soLuongVatThe = 3;
   danhSachVat[0].danhSachVatThe = malloc( sizeof( VatThe )*3 );

   viTri.x = 0.0f;   viTri.y = 0.0f;  viTri.z = 0.0f;
   danhSachVat[0].danhSachVatThe[0].hinhDang.hop = datHop( 399.9f, 399.9f, 399.9f, &(danhSachVat[0].danhSachVatThe[0].baoBiVT) );
   danhSachVat[0].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[0].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0].danhSachVatThe[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].danhSachVatThe[0].giaTri = 1;

   // ---- hình cầu lớn
   viTri.x = 100.0f;   viTri.y = 100.0f;  viTri.z = -100.0f;
   danhSachVat[0].danhSachVatThe[1].hinhDang.hinhCau = datHinhCau( 220.0f, &(danhSachVat[0].danhSachVatThe[1].baoBiVT) );
   danhSachVat[0].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[0].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0].danhSachVatThe[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].danhSachVatThe[1].giaTri = -1;

   // ---- lổ hình cầu nhỏ
   viTri.x = 200.0f;   viTri.y = -120.0f;  viTri.z = 120.0f;
   danhSachVat[0].danhSachVatThe[2].hinhDang.hinhCau = datHinhCau( 50.0f, &(danhSachVat[0].danhSachVatThe[2].baoBiVT) );
   danhSachVat[0].danhSachVatThe[2].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[0].danhSachVatThe[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0].danhSachVatThe[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].danhSachVatThe[2].giaTri = -1;
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[0]) );

   // ---- cao nguyên ở đằng -z từ lập phương
   viTri.x = -900.0f;      viTri.y = 150.0f;        viTri.z = 400.0f;
   danhSachVat[1].hinhDang.hop = datHop( 699.9f, 99.0f, 499.9f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[1].soHoaTiet = kHOA_TIET__CA_RO;
   
   // ---- cao nguyên ở đằng -z từ lập phương
   viTri.x = -750.0f;      viTri.y = 140.0f;        viTri.z = 600.0f;
   danhSachVat[2].hinhDang.hop = datHop( 399.9f, 79.0f, 499.9f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[2].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = -750.0f;      viTri.y = 200.0f;        viTri.z = 1400.0f;
   danhSachVat[3].hinhDang.hop = datHop( 399.9f, 199.0f, 299.9f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTri );
   danhSachVat[3].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[3].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.x = -500.0f;      viTri.y = 165.0f;        viTri.z = 1600.0f;
   danhSachVat[4].hinhDang.hop = datHop( 299.9f, 129.0f, 299.9f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTri );
   danhSachVat[4].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[4].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = -680.0f;      viTri.y = 225.0f;        viTri.z = 2000.0f;
   danhSachVat[5].hinhDang.hop = datHop( 299.9f, 249.0f, 299.9f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[5].soHoaTiet = kHOA_TIET__CA_RO;

   // ---- cao nhuyên nhỏ thấp gần đường lộ
   mauDat.d = 1.0f;   mauDat.l = 0.8f;   mauDat.x = 0.6f;   mauDat.dd = 1.0f;
   mau1.d = 0.5f;   mau1.l = 0.25f;   mau1.x = 0.3f;   mau1.dd = 1.0f;
   viTri.x = -200.0f;      viTri.y = 115.0f;        viTri.z = 1000.0f;
//   danhSachVat[6].hinhDang.hop = datHop( 149.9f, 29.9f, 149.9f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[6].mucDichBool = 1;
   danhSachVat[6].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &quaternion, &viTri );
   danhSachVat[6].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[6].soHoaTiet = kHOA_TIET__CA_RO;

   danhSachVat[6].soLuongVatThe = 2;
   danhSachVat[6].danhSachVatThe = malloc( sizeof( VatThe )*2 );
   
   viTri.x = 0.0f;   viTri.y = 0.0f;  viTri.z = 0.0f;
   danhSachVat[6].danhSachVatThe[0].hinhDang.hop = datHop( 149.9f, 29.9f, 149.9f, &(danhSachVat[6].danhSachVatThe[0].baoBiVT) );
   danhSachVat[6].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[6].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6].danhSachVatThe[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[6].danhSachVatThe[0].giaTri = 1;
   
   // ---- khắc hình cầu lớn
   viTri.x = 50.0f;   viTri.y = 82.0f;  viTri.z = -20.0f;
   danhSachVat[6].danhSachVatThe[1].hinhDang.hinhCau = datHinhCau( 95.0f, &(danhSachVat[6].danhSachVatThe[1].baoBiVT) );
   danhSachVat[6].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[6].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6].danhSachVatThe[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[6].danhSachVatThe[1].giaTri = -1;
   
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[6]) );
   
   viTri.x = -300.0f;      viTri.y = 120.0f;        viTri.z = 1050.0f;
   danhSachVat[7].hinhDang.hop = datHop( 79.9f, 39.9f, 79.9f, &(danhSachVat[7].baoBiVT) );
   danhSachVat[7].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[7].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &quaternion, &viTri );
   danhSachVat[7].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[7].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = -250.0f;      viTri.y = 110.0f;        viTri.z = 1250.0f;
   danhSachVat[8].hinhDang.hop = datHop( 79.9f, 19.9f, 79.9f, &(danhSachVat[8].baoBiVT) );
   danhSachVat[8].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[8].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[8]), &phongTo, &quaternion, &viTri );
   danhSachVat[8].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[8].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.x = -150.0f;      viTri.y = 110.0f;        viTri.z = 1450.0f;
   danhSachVat[9].hinhDang.hop = datHop( 129.9f, 19.9f, 129.9f, &(danhSachVat[9].baoBiVT) );
   danhSachVat[9].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[9].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[9]), &phongTo, &quaternion, &viTri );
   danhSachVat[9].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[9].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.x = -300.0f;      viTri.y = 110.0f;        viTri.z = 650.0f;
   danhSachVat[10].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[10].mucDichBool = 1;
   danhSachVat[10].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10]), &phongTo, &quaternion, &viTri );
   danhSachVat[10].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[10].soHoaTiet = kHOA_TIET__CA_RO;
   
   danhSachVat[10].soLuongVatThe = 3;
   danhSachVat[10].danhSachVatThe = malloc( sizeof( VatThe )*3 );
   
   viTri.x = 0.0f;   viTri.y = 0.0f;  viTri.z = 0.0f;
   danhSachVat[10].danhSachVatThe[0].hinhDang.hop = datHop( 259.9f, 19.9f, 259.9f, &(danhSachVat[10].danhSachVatThe[0].baoBiVT) );
   danhSachVat[10].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[10].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10].danhSachVatThe[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[10].danhSachVatThe[0].giaTri = 1;

   // ---- khắc hình cầu lớn
   viTri.x = -50.0f;   viTri.y = 55.0f;  viTri.z = -70.0f;
   danhSachVat[10].danhSachVatThe[1].hinhDang.hinhCau = datHinhCau( 60.0f, &(danhSachVat[10].danhSachVatThe[1].baoBiVT) );
   danhSachVat[10].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[10].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10].danhSachVatThe[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[10].danhSachVatThe[1].giaTri = -1;
   
   // ---- khắc hình cầu nhỏ
   viTri.x = 50.0f;   viTri.y = 105.0f;  viTri.z = 50.0f;
   danhSachVat[10].danhSachVatThe[2].hinhDang.hinhCau = datHinhCau( 110.0f, &(danhSachVat[10].danhSachVatThe[2].baoBiVT) );
   danhSachVat[10].danhSachVatThe[2].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[10].danhSachVatThe[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10].danhSachVatThe[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[10].danhSachVatThe[2].giaTri = -1;
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[10]) );

   viTri.x = 130.0f;      viTri.y = 110.0f;        viTri.z = 900.0f;
   danhSachVat[11].loai = kLOAI_VAT_THE__BOOL;
   danhSachVat[11].mucDichBool = 1;
   danhSachVat[11].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[11]), &phongTo, &quaternion, &viTri );
   danhSachVat[11].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[11].soHoaTiet = kHOA_TIET__CA_RO;
   
   danhSachVat[11].soLuongVatThe = 2;
   danhSachVat[11].danhSachVatThe = malloc( sizeof( VatThe )*2 );
   
   viTri.x = 0.0f;   viTri.y = 0.0f;  viTri.z = 0.0f;
   danhSachVat[11].danhSachVatThe[0].hinhDang.hop = datHop( 209.9f, 19.9f, 159.9f, &(danhSachVat[11].danhSachVatThe[0].baoBiVT) );
   danhSachVat[11].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[11].danhSachVatThe[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[11].danhSachVatThe[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[11].danhSachVatThe[0].giaTri = 1;
   
   // ---- hình cầu lớn
   viTri.x = -80.0f;   viTri.y = 170.0f;  viTri.z = -60.0f;
   danhSachVat[11].danhSachVatThe[1].hinhDang.hinhCau = datHinhCau( 180.0f, &(danhSachVat[11].danhSachVatThe[1].baoBiVT) );
   danhSachVat[11].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[11].danhSachVatThe[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[11].danhSachVatThe[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[11].danhSachVatThe[1].giaTri = -1;
   // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
   tinhBaoBiVTChoVatTheGhep( &(danhSachVat[11]) );

   viTri.x = -90.0f;      viTri.y = 106.0f;        viTri.z = 1065.0f;
   danhSachVat[12].hinhDang.hop = datHop( 79.9f, 11.9f, 69.9f, &(danhSachVat[12].baoBiVT) );
   danhSachVat[12].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[12].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[12]), &phongTo, &quaternion, &viTri );
   danhSachVat[12].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[12].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.x = -100.0f;      viTri.y = 106.0f;        viTri.z = 850.0f;
   danhSachVat[13].hinhDang.hop = datHop( 79.9f, 11.9f, 69.9f, &(danhSachVat[13].baoBiVT) );
   danhSachVat[13].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[13].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[13]), &phongTo, &quaternion, &viTri );
   danhSachVat[13].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[13].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = 50.0f;      viTri.y = 105.0f;        viTri.z = 600.0f;
   danhSachVat[14].hinhDang.hop = datHop( 29.9f, 10.9f, 29.9f, &(danhSachVat[14].baoBiVT) );
   danhSachVat[14].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[14].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[14]), &phongTo, &quaternion, &viTri );
   danhSachVat[14].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[14].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = -80.0f;      viTri.y = 105.0f;        viTri.z = 590.0f;
   danhSachVat[15].hinhDang.hop = datHop( 59.9f, 10.9f, 59.9f, &(danhSachVat[15].baoBiVT) );
   danhSachVat[15].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[15].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[15]), &phongTo, &quaternion, &viTri );
   danhSachVat[15].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[15].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = -80.0f;      viTri.y = 105.0f;        viTri.z = 650.0f;
   danhSachVat[16].hinhDang.hop = datHop( 29.9f, 10.9f, 29.9f, &(danhSachVat[16].baoBiVT) );
   danhSachVat[16].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[16].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[16]), &phongTo, &quaternion, &viTri );
   danhSachVat[16].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[16].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = 180.0f;      viTri.y = 105.0f;        viTri.z = 1050.0f;
   danhSachVat[17].hinhDang.hop = datHop( 89.9f, 10.9f, 79.9f, &(danhSachVat[17].baoBiVT) );
   danhSachVat[17].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[17].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[17]), &phongTo, &quaternion, &viTri );
   danhSachVat[17].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[17].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.x = 450.0f;      viTri.y = 125.0f;        viTri.z = 1550.0f;
   danhSachVat[18].hinhDang.hop = datHop( 179.9f, 49.9f, 159.9f, &(danhSachVat[18].baoBiVT) );
   danhSachVat[18].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[18].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[18]), &phongTo, &quaternion, &viTri );
   danhSachVat[18].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[18].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.x = 650.0f;      viTri.y = 125.0f;        viTri.z = 2050.0f;
   danhSachVat[19].hinhDang.hop = datHop( 279.9f, 49.9f, 259.9f, &(danhSachVat[19].baoBiVT) );
   danhSachVat[19].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[19].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[19]), &phongTo, &quaternion, &viTri );
   danhSachVat[19].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[19].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.x = 150.0f;      viTri.y = 125.0f;        viTri.z = 1650.0f;
   danhSachVat[20].hinhDang.hop = datHop( 99.9f, 49.9f, 199.9f, &(danhSachVat[20].baoBiVT) );
   danhSachVat[20].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[20].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[20]), &phongTo, &quaternion, &viTri );
   danhSachVat[20].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[20].soHoaTiet = kHOA_TIET__CA_RO;

   return 21;
}


unsigned short datDayHinhTru( VatThe *danhSachVat ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;  quaternion.x = 0.0f;  quaternion.y = 0.0f;  quaternion.z = 0.0f;
   
   Vecto trucQuayMayQuayPhim;
   trucQuayMayQuayPhim.x = 1.0f;
   trucQuayMayQuayPhim.y = 0.0f;
   trucQuayMayQuayPhim.z = 0.0f;
   Quaternion quaternionXoay = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, 1.57f );

   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== màu đỏ và trắng 
   Mau mauDo;
   mauDo.d = 1.0f;   mauDo.l = 0.2f;   mauDo.x = 0.2f;   mauDo.dd = 1.0f;   mauDo.p = 0.0f;
   Mau mauTrang;
   mauTrang.d = 1.0f;   mauTrang.l = 0.95f;   mauTrang.x = 0.95f;   mauTrang.dd = 1.0f;   mauTrang.p = 0.0f;
   
   viTri.x = -435.0f;      viTri.y = 150.0f;        viTri.z = 500.0f;
   danhSachVat[0].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 465.0f;
   danhSachVat[1].hinhDang.hinhTru = datHinhTru( 35.0f, 115.0f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;

   viTri.z = 430.0f;
   danhSachVat[2].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[2].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[2].soHoaTiet = kHOA_TIET__KHONG;

   // ----
   viTri.x = -505.5f;      viTri.y = 220.5f;        viTri.z = 500.0f;
   danhSachVat[3].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[3].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[3].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 465.0f;
   danhSachVat[4].hinhDang.hinhTru = datHinhTru( 35.0f, 115.0f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[4].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[4].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 430.0f;
   danhSachVat[5].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[5].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[5].soHoaTiet = kHOA_TIET__KHONG;
   
   // ----
   viTri.x = -576.0f;      viTri.y = 291.0f;        viTri.z = 500.0f;
   danhSachVat[6].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[6].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[6].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[6].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 465.0f;
   danhSachVat[7].hinhDang.hinhTru = datHinhTru( 35.0f, 115.0f, &(danhSachVat[7].baoBiVT) );
   danhSachVat[7].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[7].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[7].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[7].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 430.0f;
   danhSachVat[8].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[8].baoBiVT) );
   danhSachVat[8].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[8].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[8]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[8].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[8].soHoaTiet = kHOA_TIET__KHONG;
   
   // ----
   viTri.x = -667.0f;      viTri.y = 250.0f;        viTri.z = 500.0f;
   danhSachVat[9].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[9].baoBiVT) );
   danhSachVat[9].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[9].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[9]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[9].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[9].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 465.0f;
   danhSachVat[10].hinhDang.hinhTru = datHinhTru( 35.0f, 115.0f, &(danhSachVat[10].baoBiVT) );
   danhSachVat[10].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[10].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[10].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[10].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 430.0f;
   danhSachVat[11].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[11].baoBiVT) );
   danhSachVat[11].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[11].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[11]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[11].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[11].soHoaTiet = kHOA_TIET__KHONG;
   
   // ----
   viTri.x = -767.0f;      viTri.y = 250.0f;        viTri.z = 500.0f;
   danhSachVat[12].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[12].baoBiVT) );
   danhSachVat[12].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[12].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[12]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[12].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[12].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 465.0f;
   danhSachVat[13].hinhDang.hinhTru = datHinhTru( 35.0f, 115.0f, &(danhSachVat[13].baoBiVT) );
   danhSachVat[13].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[13].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[13]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[13].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[13].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 430.0f;
   danhSachVat[14].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[14].baoBiVT) );
   danhSachVat[14].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[14].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[14]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[14].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[14].soHoaTiet = kHOA_TIET__KHONG;
   
   // ----
   viTri.x = -867.0f;      viTri.y = 250.0f;        viTri.z = 500.0f;
   danhSachVat[15].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[15].baoBiVT) );
   danhSachVat[15].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[15].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[15]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[15].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[15].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 465.0f;
   danhSachVat[16].hinhDang.hinhTru = datHinhTru( 35.0f, 115.0f, &(danhSachVat[16].baoBiVT) );
   danhSachVat[16].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[16].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[16]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[16].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauDo );
   danhSachVat[16].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.z = 430.0f;
   danhSachVat[17].hinhDang.hinhTru = datHinhTru( 50.0f, 35.0f, &(danhSachVat[17].baoBiVT) );
   danhSachVat[17].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[17].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[17]), &phongTo, &quaternionXoay, &viTri );
   danhSachVat[17].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauTrang );
   danhSachVat[17].soHoaTiet = kHOA_TIET__KHONG;

   return 18;
}

unsigned short datNapDayHinhTru( VatThe *danhSachVat ) {
   
   Vecto trucXoay;
   trucXoay.x = 1.0f;
   trucXoay.y = 0.0f;
   trucXoay.z = 0.0f;
   Quaternion quaternionXoay = datQuaternionTuVectoVaGocQuay( &trucXoay, 1.57f );
   Quaternion quaternionKhongXoay;
   quaternionKhongXoay.w = 1.0f;  quaternionKhongXoay.x = 0.0f;  quaternionKhongXoay.y = 0.0f;  quaternionKhongXoay.z = 0.0f;
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto viTriTuongDoiHinhNon;
   viTriTuongDoiHinhNon.x = 0.0f;       viTriTuongDoiHinhNon.y = 0.0f;       viTriTuongDoiHinhNon.z = 0.0f;
   Vecto viTriTuongDoiHop;
   viTriTuongDoiHop.x = 0.0f;       viTriTuongDoiHop.y = 0.1f;       viTriTuongDoiHop.z = 0.0f;

   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== màu đỏ và trắng
   Mau mauDo;
   mauDo.d = 1.0f;   mauDo.l = 0.2f;   mauDo.x = 0.2f;   mauDo.dd = 1.0f;   mauDo.p = 0.0f;
   Mau mauTrang;
   mauTrang.d = 1.0f;   mauTrang.l = 0.95f;   mauTrang.x = 0.95f;   mauTrang.dd = 1.0f;   mauTrang.p = 0.0f;
   
   float mangViTri_x[] = {-435.0f, -505.5f, -576.0f, -667.0f, -767.0f, -867.0f};
   float mangViTri_y[] = {150.0f, 220.5f, 291.0f, 250.0f, 250.0f, 250.0f};
   
   unsigned short soLuongVatThe = 0;
   while ( soLuongVatThe < 12 ) {
      // ---- chọn màu
      Mau mau;
      if( (soLuongVatThe >> 1) & 0x01 )
         mau = mauDo;
      else
         mau = mauTrang;
      
      // ---- chọn góc xoay sẵn cho hộp
      float gocXoay = 6.28f*rand()/kSO_NGUYEN_TOI_DA;
      trucXoay.x = 0.0;   trucXoay.y = 0.0f;    trucXoay.z = 1.0f;
      Quaternion quaternionTuongDoi = datQuaternionTuVectoVaGocQuay( &trucXoay, gocXoay );
      Quaternion xoayGom = nhanQuaternionVoiQuaternion( &quaternionXoay, &quaternionTuongDoi );
      
      // ---- VẬT THỂ BOOL
      viTri.x = mangViTri_x[soLuongVatThe >> 1];      viTri.y = mangViTri_y[soLuongVatThe >> 1];      viTri.z = 524.5f;
      danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__BOOL;
      danhSachVat[soLuongVatThe].mucDichBool = 1;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &xoayGom, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      
      danhSachVat[soLuongVatThe].soLuongVatThe = 2;
      danhSachVat[soLuongVatThe].danhSachVatThe = malloc( 2*sizeof(VatThe) );
      
      // ---- THÀNH PHẦN VẬT THỂ BOOL
      danhSachVat[soLuongVatThe].danhSachVatThe[0].hinhDang.hinhNon = datHinhNon( 35.0f, 30.0f, 4.0f, &(danhSachVat[soLuongVatThe].danhSachVatThe[0].baoBiVT) );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[0]), &phongTo, &quaternionKhongXoay, &viTriTuongDoiHinhNon );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].giaTri = 1;

      viTriTuongDoiHop.y = 0.1f;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].hinhDang.hop = datHop( 71.0f, 4.0f, 12.0f, &(danhSachVat[soLuongVatThe].danhSachVatThe[1].baoBiVT) );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[1]), &phongTo, &quaternionKhongXoay, &viTriTuongDoiHop );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].giaTri = -1;
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
      tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
      soLuongVatThe++;
      
      // ----
      viTri.x = mangViTri_x[soLuongVatThe >> 1];      viTri.y = mangViTri_y[soLuongVatThe >> 1];      viTri.z = 405.5f;
      danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__BOOL;
      danhSachVat[soLuongVatThe].mucDichBool = 1;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternionXoay, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      
      danhSachVat[soLuongVatThe].soLuongVatThe = 2;
      danhSachVat[soLuongVatThe].danhSachVatThe = malloc( 2*sizeof(VatThe) );
      
      viTriTuongDoiHop.y = -0.1f;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].hinhDang.hinhNon = datHinhNon( 30.0f, 35.0f, 4.0f, &(danhSachVat[soLuongVatThe].danhSachVatThe[0].baoBiVT) );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[0]), &phongTo, &quaternionKhongXoay, &viTriTuongDoiHinhNon );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].giaTri = 1;
      
      danhSachVat[soLuongVatThe].danhSachVatThe[1].hinhDang.hop = datHop( 71.0f, 4.0f, 12.0f, &(danhSachVat[soLuongVatThe].danhSachVatThe[1].baoBiVT) );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[1]), &phongTo, &quaternionKhongXoay, &viTriTuongDoiHop );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].giaTri = -1;
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
      tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
      
      soLuongVatThe++;
   }
   return soLuongVatThe;
}

unsigned short datHinhCauKhongLoXoay( VatThe *danhSachVat ) {

   Vecto trucXoay;
   trucXoay.x = 0.0f;    trucXoay.y = -1.0f;   trucXoay.z = 0.0f;
   Quaternion quaternion = datQuaternionTuVectoVaGocQuay( &trucXoay, 0.7f );
   
   Vecto viTri;
   viTri.x = 0.0f;       viTri.y = 0.0f;       viTri.z = 0.0f;
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ==== màu mặt đường
   Mau mauDat;
   mauDat.d = 1.0f;   mauDat.l = 0.0f;   mauDat.x = 0.0f;   mauDat.dd = 1.0f;   mauDat.p = 0.0f;
   Mau mau1;
   mau1.d = 1.0f;   mau1.l = 0.95f;   mau1.x = 0.95f;   mau1.dd = 1.0f;    mau1.p = 0.0f;
   
   // ---- mặt đường đi
   viTri.x = -700.0f;      viTri.y = 400.0f;        viTri.z = 900.0f;
   danhSachVat[0].hinhDang.hinhCau = datHinhCau( 215.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mauDat, &mau1, 40.0f, 40.0f, 40.0f );
   danhSachVat[0].soHoaTiet = kHOA_TIET__CA_RO;

   return 1;
}

unsigned short datHemVucNui( VatThe *danhSachVat ) {

   unsigned short soLuongVatThe = 0;
   Vecto viTri;
   float dichLen;
   
   // ---- tường hẻm núi bên +z
   viTri.x = 730.0f;    viTri.z = 260.0f;
   dichLen = -177.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 125.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = 560.0f;    viTri.z = 240.0f;
   dichLen = -174.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 65.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = 380.0f;    viTri.z = 150.0f;
   dichLen = -178.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 150.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = 145.0f;    viTri.z = 235.0f;
   dichLen = -179.5f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 100.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = 40.0f;    viTri.z = 195.0f;
   dichLen = -175.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 10.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = -20.0f;    viTri.z = 240.0f;
   dichLen = -179.9f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 75.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = -100.0f;    viTri.z = 200.0f;
   dichLen = -170.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 30.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = -190.0f;    viTri.z = 220.0f;
   dichLen = -179.9f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 50.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -350.0f;    viTri.z = 180.0f;
   dichLen = -175.0f;
   soLuongVatThe +=  datTuongSong( viTri, dichLen, 130.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -420.0f;    viTri.z = 0.0f;
   dichLen = -178.5f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 80.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = -500.0f;    viTri.z = 90.0f;
   dichLen = -179.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 120.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -700.0f;    viTri.z = 170.0f;
   dichLen = -175.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 90.0f, &(danhSachVat[soLuongVatThe]) );

   // ---- tường hẻm núi bên -z
   viTri.x = 730.0f;    viTri.z = -350.0f;
   dichLen = -179.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 90.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = 570.0f;    viTri.z = -390.0f;
   dichLen = -177.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 85.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = 400.0f;    viTri.z = -470.0f;
   dichLen = -178.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 110.0f, &(danhSachVat[soLuongVatThe]) );
   // ----
   viTri.x = 300.0f;    viTri.z = -390.0f;
   dichLen = -170.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 30.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = 200.0f;    viTri.z = -370.0f;
   dichLen = -172.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 40.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = 97.0f;    viTri.z = -420.0f;
   dichLen = -179.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 60.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = 0.0f;    viTri.z = -300.0f;
   dichLen = -180.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 100.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -80.0f;    viTri.z = -400.0f;
   dichLen = -170.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 60.0f, &(danhSachVat[soLuongVatThe]) );
   
   viTri.x = -170.0f;    viTri.z = -390.0f;
   dichLen = -175.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 50.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -250.0f;    viTri.z = -460.0f;
   dichLen = -177.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 80.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -450.0f;    viTri.z = -600.0f;
   dichLen = -179.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 160.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -650.0f;    viTri.z = -500.0f;
   dichLen = -178.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 70.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -735.0f;    viTri.z = -495.0f;
   dichLen = -170.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 40.0f, &(danhSachVat[soLuongVatThe]) );

   viTri.x = -850.0f;    viTri.z = -400.0f;
   dichLen = -179.0f;
   soLuongVatThe += datTuongSong( viTri, dichLen, 100.0f, &(danhSachVat[soLuongVatThe]) );

   return soLuongVatThe;
}

//      bánKính
//     |<---->|
//
// 280 +--(0)-+-+ 5
// 270 +------+--+ 7
//     |  (1) |  |
// 250 +--(2)-+--+
// 245 +--(3)-+-+
// 240 +--(4)-+--+
// 220 +------+--+
//     |  (5) |   \
// 180 +------+----+ 40
//     |  (6) |    |
// 140 +--(7)-+----+
// 130 +------+----\ 32
//     |  (8) |    |
// 110 +------+----+
//     |      |     \
//  90 +------+------+  90
//  80 +------+------+
//     |  (9) |       \
//  75 +------+--------+  130
//  70 +------+--------+
//  68 +------+----------+ 140
//     |      |          |
//     | (10) |          |
//   0 +------+----------+

//  Chỉ xài tọa độ (x; z) của vị trí
unsigned short datTuongSong( Vecto viTri, float dichLen, float banKinh, VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;

   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   Mau mau0;
   Mau mau1;

   // ---- xây từ trên đi xuống
   mau0.d = 1.0f;   mau0.l = 0.6f;  mau0.x = 0.6f;   mau0.dd = 1.0f;   mau0.p = 0.0f;
   mau1.d = 1.0f;   mau1.l = 1.0f;  mau1.x = 1.0f;   mau1.dd = 1.0f;   mau1.p = 0.0f;
   
   viTri.y = 275.0f + dichLen;
   danhSachVat[0].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 0.0f, 10.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[0].soHoaTiet = kHOA_TIET__CA_RO;

   // ----
   viTri.y = 260.0f + dichLen;
   danhSachVat[1].hinhDang.hinhTru = datHinhTru( banKinh + 7.0f, 20.0f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 20.0f, 15.0f, 40.0f );
   danhSachVat[1].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.y = 247.5f + dichLen;
   danhSachVat[2].hinhDang.hinhNon = datHinhNon( banKinh + 2.0f, banKinh + 7.0f, 5.0f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[2].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.y = 242.5f + dichLen;
   danhSachVat[3].hinhDang.hinhNon = datHinhNon( banKinh + 7.0f, banKinh + 4.0f, 5.0f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTri );
   danhSachVat[3].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[3].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.y = 230.0f + dichLen;
   danhSachVat[4].hinhDang.hinhTru = datHinhTru( banKinh + 7.0f, 20.0f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTri );
   danhSachVat[4].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 20.0f, 15.0f, 40.0f );
   danhSachVat[4].soHoaTiet = kHOA_TIET__CA_RO;
   // ----
   viTri.y = 200.0f + dichLen;
   danhSachVat[5].hinhDang.hinhNon = datHinhNon( banKinh + 40.0f, banKinh + 7.0f, 40.0f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[5].soHoaTiet = kHOA_TIET__CA_RO;
 
   viTri.y = 160.0f + dichLen;
   danhSachVat[6].hinhDang.hinhTru = datHinhTru( banKinh + 40.0f, 40.0f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[6].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &quaternion, &viTri );
   danhSachVat[6].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[6].soHoaTiet = kHOA_TIET__CA_RO;
   // -- nét nhỏ
   viTri.y = 135.0f + dichLen;
   danhSachVat[7].hinhDang.hinhNon = datHinhNon( banKinh + 40.0f, banKinh + 32.0f, 10.0f, &(danhSachVat[7].baoBiVT) );
   danhSachVat[7].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[7].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &quaternion, &viTri );
   danhSachVat[7].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[7].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.y = 120.0f + dichLen;
   danhSachVat[8].hinhDang.hinhTru = datHinhTru( banKinh + 40.0f, 30.0f, &(danhSachVat[8].baoBiVT) );
   danhSachVat[8].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[8].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[8]), &phongTo, &quaternion, &viTri );
   danhSachVat[8].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[8].soHoaTiet = kHOA_TIET__CA_RO;
  
   viTri.y = 100.0f + dichLen;
   danhSachVat[9].hinhDang.hinhNon = datHinhNon( banKinh + 80.0f, banKinh + 40.0f, 20.0f, &(danhSachVat[9].baoBiVT) );
   danhSachVat[9].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[9].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[9]), &phongTo, &quaternion, &viTri );
   danhSachVat[9].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[9].soHoaTiet = kHOA_TIET__CA_RO;

   viTri.y = 85.0f + dichLen;
   danhSachVat[10].hinhDang.hinhTru = datHinhTru( banKinh + 80.0f, 10.0f, &(danhSachVat[10].baoBiVT) );
   danhSachVat[10].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[10].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[10]), &phongTo, &quaternion, &viTri );
   danhSachVat[10].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[10].soHoaTiet = kHOA_TIET__CA_RO;
   // ----
   viTri.y = 77.5f + dichLen;
   danhSachVat[11].hinhDang.hinhNon = datHinhNon( banKinh + 120.0f, banKinh + 80.0f, 5.0f, &(danhSachVat[11].baoBiVT) );
   danhSachVat[11].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[11].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[11]), &phongTo, &quaternion, &viTri );
   danhSachVat[11].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[11].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.y = 72.5f + dichLen;
   danhSachVat[12].hinhDang.hinhTru = datHinhTru( banKinh + 120.0f, 5.0f, &(danhSachVat[12].baoBiVT) );
   danhSachVat[12].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[12].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[12]), &phongTo, &quaternion, &viTri );
   danhSachVat[12].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[12].soHoaTiet = kHOA_TIET__CA_RO;
   
   viTri.y =  69.0f + dichLen;
   danhSachVat[13].hinhDang.hinhNon = datHinhNon( banKinh + 140.0f, banKinh + 120.0f, 2.0f, &(danhSachVat[13].baoBiVT) );
   danhSachVat[13].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[13].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[13]), &phongTo, &quaternion, &viTri );
   danhSachVat[13].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[13].soHoaTiet = kHOA_TIET__CA_RO;
   // ----
   viTri.y = 34.0f + dichLen;
   danhSachVat[14].hinhDang.hinhNon = datHinhNon( banKinh + 145.0f, banKinh + 140.0f, 65.0f, &(danhSachVat[14].baoBiVT) );
   danhSachVat[14].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[14].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[14]), &phongTo, &quaternion, &viTri );
   danhSachVat[14].hoaTiet.hoaTietCaRo = datHoaTietCaRo( &mau0, &mau1, 40.0f, 15.0f, 40.0f );
   danhSachVat[14].soHoaTiet = kHOA_TIET__CA_RO;
   
   return 15;
}

unsigned short datBayBongBong( VatThe *danhSachVat ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   unsigned short soBongBong = 0;
   while( soBongBong < kSO_LUONG__BONG_BONG_TRONG_BAY ) {
   
      Mau mauRanh;
      Mau mauTam;
      
      // ---- chọn màu
      unsigned char soMau = rand() & 0x7;
      if( soMau == 0 ) {
         mauRanh.d = 1.0f;   mauRanh.l = 0.0f;  mauRanh.x = 1.0f;
         mauTam.d = 1.0f;   mauTam.l = 0.6f;  mauTam.x = 0.0f;
      }
      else if( soMau == 1 ) {
         mauRanh.d = 0.0f;   mauRanh.l = 0.0f;  mauRanh.x = 1.0f;
         mauTam.d = 0.0f;   mauTam.l = 1.0f;  mauTam.x = 0.7f;
      }
      else if( soMau == 2 ) {
         mauRanh.d = 1.0f;   mauRanh.l = 0.8f;  mauRanh.x = 0.0f;
         mauTam.d = 0.5f;   mauTam.l = 0.0f;  mauTam.x = 1.0f;
      }
      else if( soMau == 3 ) {
         mauRanh.d = 1.0f;   mauRanh.l = 0.0f;  mauRanh.x = 0.2f;
         mauTam.d = 0.5f;   mauTam.l = 1.0f;  mauTam.x = 0.0f;
      }
      else if( soMau == 4 ) {
         mauRanh.d = 1.0f;   mauRanh.l = 1.0f;  mauRanh.x = 0.0f;
         mauTam.d = 0.35f;   mauTam.l = 0.0f;  mauTam.x = 1.0f;
      }
      else if( soMau == 5 ) {
         mauTam.d = 1.0f;   mauTam.l = 0.3f;  mauTam.x = 0.0f;
         mauRanh.d = 0.0f;   mauRanh.l = 1.0f;  mauRanh.x = 0.3f;
      }
      else if( soMau == 6 ) {
         mauTam.d = 1.0f;   mauTam.l = 0.0f;  mauTam.x = 1.0f;
         mauRanh.d = 1.0f;   mauRanh.l = 0.45f;  mauRanh.x = 0.3f;
      }
      else {
         mauRanh.d = 0.0f;   mauRanh.l = 1.0f;  mauRanh.x = 0.55f;
         mauTam.d = 1.0f;   mauTam.l = 0.0f;  mauTam.x = 1.0f;
      }
      
      mauRanh.dd = 0.85;   mauRanh.p = 0.3f;
      mauTam.dd = 0.1f;   mauTam.p = 0.3f;

      // ---- chọn vị trí ngẫu nhiên, tương đối với đường Bezier cho bong bóng
      Vecto viTri;
      float cachDonViHoa = (rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA)/4.0f - 0.5f;  // <-----
      viTri.x = 300.0f*cachDonViHoa;

      cachDonViHoa = (rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA)/4.0f - 0.5f;  // <-----
      viTri.y = 300.0f*cachDonViHoa;
      
      cachDonViHoa = (rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA + rand()/kSO_NGUYEN_TOI_DA)/4.0f - 0.5f;
      viTri.z = 300.0f*cachDonViHoa;
      
      // --- chọn tham số Bezier ngẫu nhiên, giúp lan bong bóng rộng rãi trên đường đi
      danhSachVat[soBongBong].thamSoBezier = 4.0f*rand()/kSO_NGUYEN_TOI_DA;
   
      // ---- đặt vật thể bong bóng
      float banKinhBongBong = 3.0f + 10.0f*rand()/kSO_NGUYEN_TOI_DA;
      danhSachVat[soBongBong].hinhDang.hinhCau = datHinhCau( banKinhBongBong, &(danhSachVat[soBongBong].baoBiVT) );
      danhSachVat[soBongBong].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[soBongBong].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soBongBong]), &phongTo, &quaternion, &viTri );
      danhSachVat[soBongBong].hoaTiet.hoaTietDiHuong = datHoaTietDiHuong( &mauRanh, &mauTam );
      danhSachVat[soBongBong].soHoaTiet = kHOA_TIET__DI_HUONG;
      // ---- xài cho tính vị trí tho đường Bezier
      danhSachVat[soBongBong].viTriDau = viTri;
      soBongBong++;
   }

   return kSO_LUONG__BONG_BONG_TRONG_BAY;
}

unsigned short datCong( VatThe *danhSachVat, Vecto viTriDay ) {

   Vecto viTriCot;
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   unsigned short soLuongVatThe = 0;
   
   // ---- 4 cột bên -x (cho đấy)
   // ---- cột số 1
   viTriCot = viTriDay;
   viTriCot.x -= 13.0f;
   viTriCot.z += 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 2
   viTriCot.z = viTriDay.z - 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 3
   viTriCot.x = viTriDay.x - 23.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 4
   viTriCot.z = viTriDay.z + 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   
   // ---- 4 cột bên +x (cho đấy)
   // ---- cột số 0
   viTriCot.x = viTriDay.x + 13.0f;
   viTriCot.z = viTriDay.z + 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 1
   viTriCot.z = viTriDay.z - 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 2
   viTriCot.x = viTriDay.x + 23.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 3
   viTriCot.z = viTriDay.z + 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   

   // ---- mái bên -x
   Mau mau;
   mau.d = 1.0f;    mau.l = 0.8f;    mau.x = 0.8f;    mau.dd = 1.0f;   mau.p = 0.1f;
   
   Mau mauOc0;
   Mau mauOc1;
   Mau mauOc2;
   mauOc0.d = 1.0f;     mauOc0.l = 1.0f;      mauOc0.x = 1.0f;     mauOc0.dd = 1.0f;    mauOc0.p = 0.1f;
   mauOc1.d = 1.0f;     mauOc1.l = 0.5f;      mauOc1.x = 0.5f;     mauOc1.dd = 1.0f;    mauOc1.p = 0.1f;
   mauOc2.d = 1.0f;     mauOc2.l = 0.9f;      mauOc2.x = 0.9f;     mauOc2.dd = 1.0f;    mauOc2.p = 0.1f;

   Vecto viTri;
   viTri.x = viTriDay.x - 20.0f;
   viTri.y = viTriDay.y + 13.5f;
   viTri.z = viTriDay.z + 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 19.5f, 0.6f, 5.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.z = viTriDay.z - 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 19.5f, 0.6f, 5.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.y += 0.8f;
   viTri.z = viTriDay.z;
   Vecto huongNgang;
   huongNgang.x = 1.0f;   huongNgang.y = 0.0f;   huongNgang.z = 0.0f;
   Vecto huongDoc;
   huongDoc.x = 0.0f;   huongDoc.y = 1.0f;   huongDoc.z = 0.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 20.5f, 1.0f, 16.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mau, &mauOc0, &mauOc1, &mauOc2, 0.1667f, 0.51f, 0.5f, 2.2f, 2.2f, 0.2f, 0.0f, 0.8f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   soLuongVatThe++;
   
   viTri.x = viTriDay.x - 13.0f;
   viTri.y += 0.8f;
   viTri.z = viTriDay.z;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 5.5f, 0.6f, 15.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ---- vòng tròn lớn dưới kim tư tháp
   viTri.x = viTriDay.x - 22.0f;
   viTri.y += 0.1f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 7.0f, 0.8f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTiaPhai = datHoaTietQuanSongTiaPhai( &mau, &mauOc0, &mauOc1, &mauOc2, 0.3333f, 0.3333f, 0.3333f, 0.5f, 0.1f, 0.0f, 8,  4.0f, 8.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_TIA_PHAI;
   soLuongVatThe++;

   mau.d = 1.0f;   mau.l = 0.3f;   mau.x = 0.3f;
   viTri.y += 0.7f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 6.0f, 6.5f, 0.6f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTiaPhai = datHoaTietQuanSongTiaPhai( &mau, &mauOc0, &mauOc1, &mauOc2, 0.3333f, 0.3333f, 0.3333f, 0.5f, 0.1f, 0.0f, 24,  4.0f, 8.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_TIA_PHAI;
   soLuongVatThe++;
   
   viTri.y += 0.6f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 6.5f, 6.0f, 0.6f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTiaPhai = datHoaTietQuanSongTiaPhai( &mau, &mauOc0, &mauOc1, &mauOc2, 0.3333f, 0.3333f, 0.3333f, 0.5f, 0.1f, 0.0f, 24,  4.0f, 8.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_TIA_PHAI;
   soLuongVatThe++;
   
   // ---- hai vòng tròn nhỏ
   viTri.x = viTriDay.x - 28.5f;
   viTri.y = viTriDay.y + 15.0f;
   viTri.z = viTriDay.z + 6.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 1.3f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.z = viTriDay.z - 6.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 1.3f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   // ===== mái bên +x
   mau.d = 1.0f;     mau.l = 0.8f;   mau.x = 0.8f;
   viTri.x = viTriDay.x + 20.0f;
   viTri.y = viTriDay.y + 13.5f;
   viTri.z = viTriDay.z + 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 19.5f, 0.6f, 5.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.z = viTriDay.z - 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 19.5f, 0.6f, 5.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.y += 0.8f;
   viTri.z = viTriDay.z;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 20.5f, 1.0f, 16.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mau, &mauOc0, &mauOc1, &mauOc2, 0.1667f, 0.51f, 0.5f, 2.0f, 2.0f, 0.2f, 0.0f, 0.8f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   soLuongVatThe++;
   
   viTri.x = viTriDay.x + 13.0f;
   viTri.y += 0.8f;
   viTri.z = viTriDay.z;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 5.5f, 0.6f, 15.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   // ---- vòng tròn lớn dưới kim tư tháp
   viTri.x = viTriDay.x + 22.0f;
   viTri.y += 0.1f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 7.0f, 0.8f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTiaPhai = datHoaTietQuanSongTiaPhai( &mau, &mauOc0, &mauOc1, &mauOc2, 0.3333f, 0.3333f, 0.3333f, 0.5f, 0.1f, 0.0f, 8,  4.0f, 8.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_TIA_PHAI;
   soLuongVatThe++;
   
   mau.d = 1.0f;   mau.l = 0.3f;   mau.x = 0.3f;   mau.dd = 1.0f;
   viTri.y += 0.7f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 6.0f, 6.5f, 0.6f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTiaPhai = datHoaTietQuanSongTiaPhai( &mau, &mauOc0, &mauOc1, &mauOc2, 0.3333f, 0.3333f, 0.3333f, 0.5f, 0.1f, 0.0f, 8,  4.0f, 8.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_TIA_PHAI;
   soLuongVatThe++;

   viTri.y += 0.6f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 6.5f, 6.0f, 0.6f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTiaPhai = datHoaTietQuanSongTiaPhai( &mau, &mauOc0, &mauOc1, &mauOc2, 0.3333f, 0.3333f, 0.3333f, 0.5f, 0.1f, 0.0f, 8,  4.0f, 8.0f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_TIA_PHAI;
   soLuongVatThe++;

   // ---- hai vòng tròn nhỏ
   viTri.x = viTriDay.x + 28.5f;
   viTri.y = viTriDay.y + 15.0f;
   viTri.z = viTriDay.z + 6.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 1.3f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.z = viTriDay.z - 6.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 1.3f, 0.4f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   // ==== 2 cột bên -x (trên)
   // ---- cột số 1
   viTriCot = viTriDay;
   viTriCot.x -= 13.0f;
   viTriCot.y += 15.4f;
   viTriCot.z += 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 2
   viTriCot.z = viTriDay.z - 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   
   // ==== 2 cột bên +x (trên)
   // ---- cột số 1
   viTriCot = viTriDay;
   viTriCot.x += 13.0f;
   viTriCot.y += 15.4f;
   viTriCot.z += 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   // ---- cột số 2
   viTriCot.z = viTriDay.z - 5.0f;
   soLuongVatThe += datCotCong( &(danhSachVat[soLuongVatThe]), viTriCot );
   
   viTri = viTriDay;
   viTri.y = viTriDay.y + 29.1f;
   soLuongVatThe += datMaiDinhCong( &(danhSachVat[soLuongVatThe]), viTri );
   return soLuongVatThe;
}

unsigned short datCotCong( VatThe *danhSachVat, Vecto viTriDay ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Mau mau;
   mau.d = 0.0f;     mau.l = 0.0f;     mau.x = 1.0f;    mau.dd = 1.0f;   mau.p = 0.1f;

   Mau mauOc0;
   Mau mauOc1;
   Mau mauOc2;

   // ---- đầy cột
   viTriDay.y += 0.25f;
   danhSachVat[0].hinhDang.hinhTru = datHinhTru( 2.7f, 0.5f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[0].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   
   viTriDay.y += 0.4f;
   danhSachVat[1].hinhDang.hinhNon = datHinhNon( 2.7f, 2.2f, 0.3f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[1].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;

   mauOc0.d = 0.0f;     mauOc0.l = 0.3f;      mauOc0.x = 1.0f;     mauOc0.dd = 1.0f;    mauOc0.p = 0.1f;
   mauOc1.d = 0.2f;     mauOc1.l = 0.65f;      mauOc1.x = 1.0f;     mauOc1.dd = 1.0f;    mauOc1.p = 0.1f;
   mauOc2.d = 0.65f;     mauOc2.l = 1.0f;      mauOc2.x = 1.0f;     mauOc2.dd = 1.0f;    mauOc2.p = 0.1f;
   viTriDay.y += 0.65f;
   Vecto huongNgang;
   huongNgang.x = 0.0f;   huongNgang.y = 0.0f;   huongNgang.z = 1.0f;
   Vecto huongDoc;
   huongDoc.x = 0.0f;   huongDoc.y = 1.0f;   huongDoc.z = 0.0f;
   danhSachVat[2].hinhDang.hinhTru = datHinhTru( 2.2f, 1.0f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[2].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[2].hoaTiet.hoaTietQuanSongTrucZ = datHoaTietQuanSongTrucZ( &mau, &mauOc0, &mauOc1, &mauOc2, 0.1667f, 0.5f, 0.5f, 5.0f, 0.2f, 1.0f, 8 );
   danhSachVat[2].soHoaTiet = kHOA_TIET__QUAN_SONG_TRUC_Z;
   
   viTriDay.y += 0.65f;
   danhSachVat[3].hinhDang.hinhNon = datHinhNon( 2.2f, 2.0f, 0.3f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[3].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[3].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[3].soHoaTiet = kHOA_TIET__KHONG;
   
   viTriDay.y += 0.25f;
   danhSachVat[4].hinhDang.hinhNon = datHinhNon( 2.0f, 2.2f, 0.2f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[4].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[4].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[4].soHoaTiet = kHOA_TIET__KHONG;
   
   viTriDay.y += 0.35f;
   danhSachVat[5].hinhDang.hinhTru = datHinhTru( 2.2f, 0.5f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[5].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[5].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[5].soHoaTiet = kHOA_TIET__KHONG;

   viTriDay.y += 0.4f;
   danhSachVat[6].hinhDang.hinhNon = datHinhNon( 2.0f, 1.7f, 0.5f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[6].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[6].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[6].soHoaTiet = kHOA_TIET__KHONG;

   // ---- cột
   mau.d = 1.0f;     mau.l = 0.0f;     mau.x = 0.1f;    mau.dd = 1.0f;    mau.p = 0.1f;
   mauOc0.d = 0.65f;     mauOc0.l = 0.3f;     mauOc0.x = 0.0f;     mauOc0.dd = 1.0f;    mauOc0.p = 0.01f;
   mauOc1.d = 1.0f;     mauOc1.l = 0.8f;      mauOc1.x = 0.8f;     mauOc1.dd = 1.0f;    mauOc1.p = 0.05f;
   mauOc2.d = 0.5f;     mauOc2.l = 0.0f;      mauOc2.x = 0.05f;    mauOc2.dd = 1.0f;    mauOc2.p = 0.05f;
   viTriDay.y += 4.75f;
   danhSachVat[7].hinhDang.hinhTru = datHinhTru( 1.5f, 9.0f, &(danhSachVat[7].baoBiVT) );
   danhSachVat[7].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[7].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[7]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[7].hoaTiet.hoaTietQuanXoay = datHoaTietQuanXoay( &mau, &mauOc0, &mauOc1, &mauOc2, 0.1f, 0.22f, 0.15f, 1.0f, 0.0f, 1 );
   danhSachVat[7].soHoaTiet = kHOA_TIET__QUAN_XOAY;

   // ---- nắp cột
   mau.d = 1.0f;     mau.l = 0.45f;     mau.x = 0.45f;    mau.dd = 1.0f;    mau.p = 0.1f;
   viTriDay.y += 4.75f;
   danhSachVat[8].hinhDang.hinhNon = datHinhNon( 1.7f, 2.0f, 0.5f, &(danhSachVat[8].baoBiVT) );
   danhSachVat[8].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[8].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[8]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[8].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[8].soHoaTiet = kHOA_TIET__KHONG;
   
   viTriDay.y += 0.5f;
   danhSachVat[9].hinhDang.hinhTru = datHinhTru( 2.2f, 0.5f, &(danhSachVat[9].baoBiVT) );
   danhSachVat[9].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[9].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[9]), &phongTo, &quaternion, &viTriDay );
   danhSachVat[9].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[9].soHoaTiet = kHOA_TIET__KHONG;

   return 10;
}

unsigned short datMaiDinhCong( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;

   unsigned short soLuongVatThe = 0;
   Mau mau;
   mau.d = 1.0f;     mau.l = 0.8f;    mau.x = 0.8f;   mau.dd = 1.0f;    mau.p = 0.1f;
   Mau mauOc0;
   Mau mauOc1;
   Mau mauOc2;
   mauOc0.d = 1.0f;     mauOc0.l = 1.0f;      mauOc0.x = 1.0f;     mauOc0.dd = 1.0f;    mauOc0.p = 0.1f;
   mauOc1.d = 1.0f;     mauOc1.l = 0.5f;      mauOc1.x = 0.5f;     mauOc1.dd = 1.0f;    mauOc1.p = 0.1f;
   mauOc2.d = 1.0f;     mauOc2.l = 0.9f;      mauOc2.x = 0.9f;     mauOc2.dd = 1.0f;    mauOc2.p = 0.1f;

   Vecto huongNgang;
   huongNgang.x = 0.0f;   huongNgang.y = 0.0f;   huongNgang.z = 1.0f;
   Vecto huongDoc;
   huongDoc.x = 0.0f;   huongDoc.y = 1.0f;   huongDoc.z = 0.0f;
   
   // ---- miến dày -z
   viTri = viTriDay;
   viTri.z = viTriDay.z - 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 30.5f, 1.0f, 5.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mau, &mauOc0, &mauOc1, &mauOc2, 0.3f, 0.45f, 0.5f, 2.0f, 2.0f, 0.15f, 0.0f, 0.8f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   soLuongVatThe++;
   
   // ---- miến dày +z
   viTri.x = viTriDay.x;
   viTri.z = viTriDay.z + 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 30.5f, 1.0f, 5.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mau, &mauOc0, &mauOc1, &mauOc2, 0.3f, 0.45f, 0.5f, 2.0f, 2.0f, 0.15f, 0.0f, 0.8f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   soLuongVatThe++;

   // -----
   viTri.x = viTriDay.x - 16.0;
   viTri.z = viTriDay.z;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 8.5f, 1.0f, 8.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mau, &mauOc0, &mauOc1, &mauOc2, 0.3f, 0.45f, 0.5f, 2.0f, 2.0f, 0.15f, 0.0f, 0.8f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   soLuongVatThe++;

   viTri.x = viTriDay.x - 6.5;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 1.0f, 1.0f, 4.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = viTriDay.x;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 1.0f, 1.0f, 4.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.x = viTriDay.x + 6.5;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 1.0f, 1.0f, 4.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = viTriDay.x + 16.0;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 8.5f, 1.0f, 8.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietQuanSongTheoHuong = datHoaTietQuanSongTheoHuong( &huongNgang, &huongDoc, &mau, &mauOc0, &mauOc1, &mauOc2, 0.3f, 0.45f, 0.5f, 2.0f, 2.0f, 0.15f, 0.0f, 0.8f );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__QUAN_SONG_THEO_HUONG;
   soLuongVatThe++;
   
   // ---- 4 vuông góc
   mau.d = 1.0f;     mau.l = 0.5f;    mau.x = 0.5f;    mau.dd = 1.0f;
   viTri.x = viTriDay.x - 17.0f;
   viTri.z = viTriDay.z + 5.75f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 4.0f, 0.5f, 3.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.z = viTriDay.z - 5.75f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 4.0f, 0.5f, 3.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;
   
   viTri.x = viTriDay.x + 17.0f;
   viTri.z = viTriDay.z + 5.75f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 4.0f, 0.5f, 3.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   viTri.z = viTriDay.z - 5.75f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 4.0f, 0.5f, 3.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   soLuongVatThe++;

   // ---- dãy kim tư tháp
   mau.d = 0.5f;   mau.l = 0.4f;   mau.x = 0.4f;   mau.dd = 0.1f;    mau.p = 0.1f;
   viTri.x = viTriDay.x - 15.0;
   viTri.y = viTriDay.y + 2.8f;
   viTri.z = viTriDay.z + 3.0f;
   unsigned char soKimTuThap = 0;
   while ( soKimTuThap < 6 ) {
      danhSachVat[soLuongVatThe].hinhDang.kimTuThap = datKimTuThap( 6.0f, 4.5f, 6.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__KIM_TU_THAP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      
      viTri.x += 6.0f;
      soLuongVatThe++;
      soKimTuThap++;
   }

   viTri.x = viTriDay.x - 15.0f;
   viTri.z = viTriDay.z - 3.0f;
   soKimTuThap = 0;
   while ( soKimTuThap < 6 ) {
      danhSachVat[soLuongVatThe].hinhDang.kimTuThap = datKimTuThap( 6.0f, 4.5f, 6.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__KIM_TU_THAP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      
      viTri.x += 6.0f;
      soLuongVatThe++;
      soKimTuThap++;
   }
   
   // ---- dãy trên
   viTri.x = viTriDay.x - 12.0f;
   viTri.y += 4.5f;
   viTri.z = viTriDay.z;
   soKimTuThap = 0;
   while ( soKimTuThap < 5 ) {
      danhSachVat[soLuongVatThe].hinhDang.kimTuThap = datKimTuThap( 6.0f, 4.5f, 6.0f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__KIM_TU_THAP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      
      viTri.x += 6.0f;
      soLuongVatThe++;
      soKimTuThap++;
   }

   return soLuongVatThe;
}

unsigned short datHaiKimTuThapXoay( VatThe *danhSachVat, Vecto viTriDay ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;

   Mau mau;
   mau.d = 1.0f;   mau.l = 0.7f;   mau.x = 0.7f;   mau.dd = 0.1f;   mau.p = 0.1f;
   viTri.x = viTriDay.x - 22.0;
   viTri.y = viTriDay.y + 20.5f;
   viTri.z = viTriDay.z;
   danhSachVat[0].hinhDang.kimTuThap = datKimTuThap( 8.5f, 6.5f, 8.5f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__KIM_TU_THAP;
   danhSachVat[0].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;

   viTri.x = viTriDay.x + 22.0;
   danhSachVat[1].hinhDang.kimTuThap = datKimTuThap( 8.5f, 6.5f, 8.5f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__KIM_TU_THAP;
   danhSachVat[1].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;
   
   return 2;
}

unsigned short datHaiThauKinhXoay( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   // ---- xài phóng to tạo thấu kính
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 0.2f;
   
   Vecto viTri;
   
   Mau mau;
   mau.d = 1.0f;   mau.l = 1.0f;   mau.x = 1.0f;   mau.dd = 0.1f;   mau.p = 0.3f;
   viTri.x = viTriDay.x - 22.0;
   viTri.y = viTriDay.y + 26.0f;
   viTri.z = viTriDay.z;
   danhSachVat[0].hinhDang.hinhCau = datHinhCau( 2.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[0].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.x = viTriDay.x + 22.0;
   danhSachVat[1].hinhDang.hinhCau = datHinhCau( 2.0f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_CAU;
   danhSachVat[1].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;
   
   return 2;
}

unsigned short datVuDinhCong( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   
   Mau mau;
   mau.d = 0.6f;   mau.l = 0.3f;   mau.x = 0.0f;   mau.dd = 0.1f;   mau.p = 0.1f;
   viTri.x = viTriDay.x;
   viTri.y = viTriDay.y + 42.0f;
   viTri.z = viTriDay.z;
   danhSachVat[0].hinhDang.hinhTru = datHinhTru( 10.0f, 2.0f, &(danhSachVat[0].baoBiVT) );
   danhSachVat[0].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[0].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   danhSachVat[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[0].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.y += 4.0f;
   danhSachVat[1].hinhDang.hinhTru = datHinhTru( 7.0f, 2.0f, &(danhSachVat[1].baoBiVT) );
   danhSachVat[1].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[1].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   danhSachVat[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[1].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.y += 4.0f;
   danhSachVat[2].hinhDang.hinhTru = datHinhTru( 5.0f, 2.0f, &(danhSachVat[2].baoBiVT) );
   danhSachVat[2].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[2].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   danhSachVat[2].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[2].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.y += 4.0f;
   danhSachVat[3].hinhDang.hinhTru = datHinhTru( 2.5f, 2.0f, &(danhSachVat[3].baoBiVT) );
   danhSachVat[3].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[3].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTri );
   danhSachVat[3].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[3].soHoaTiet = kHOA_TIET__KHONG;
   
   viTri.y += 4.0f;
   danhSachVat[4].hinhDang.hinhTru = datHinhTru( 1.5f, 2.0f, &(danhSachVat[4].baoBiVT) );
   danhSachVat[4].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[4].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTri );
   danhSachVat[4].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[4].soHoaTiet = kHOA_TIET__KHONG;

   viTri.y += 4.0f;
   danhSachVat[5].hinhDang.hinhTru = datHinhTru( 1.0f, 2.0f, &(danhSachVat[5].baoBiVT) );
   danhSachVat[5].loai = kLOAI_HINH_DANG__HINH_TRU;
   danhSachVat[5].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTri );
   danhSachVat[5].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[5].soHoaTiet = kHOA_TIET__KHONG;

   mau.d = 0.6f;   mau.l = 0.3f;   mau.x = 0.0f;   mau.dd = 1.0f;    mau.p = 0.5f;
   viTri.y += 5.0f;
   danhSachVat[6].hinhDang.batDien = datBatDien( 3.0f, 3.0f, 4.0f, &(danhSachVat[6].baoBiVT) );
   danhSachVat[6].loai = kLOAI_HINH_DANG__BAT_DIEN;
   danhSachVat[6].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[6]), &phongTo, &quaternion, &viTri );
   danhSachVat[6].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
   danhSachVat[6].soHoaTiet = kHOA_TIET__KHONG;

   return 7;
}

unsigned short datChanLaCo( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   viTri = viTriDay;
   viTri.y += 1.75f;  // để hình nón trên mặt đất
   
   Vecto viTriTuongDoi;
   viTriTuongDoi.x = 0.0f;   viTriTuongDoi.y = 0.0f;   viTriTuongDoi.z = 0.0f;
   
   Mau mauNen;
   mauNen.d = 0.5f;   mauNen.l = 0.0f;  mauNen.x = 0.5f;   mauNen.dd = 1.0f;   mauNen.p = 0.2f;

   Mau mauSoc;
   mauSoc.d = 1.0f;   mauSoc.l = 0.5f;  mauSoc.x = 1.0f;   mauSoc.dd = 1.0f;   mauSoc.p = 0.0f;

   unsigned short soLuongVatThe = 0;

   viTri.x -= 5.0f;

   while ( soLuongVatThe < 5 ) {
      Vecto trucSoc;
      trucSoc.x = 0.0f;    trucSoc.y = 1.0f;    trucSoc.z = 0.0f;
      danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__BOOL;
      danhSachVat[soLuongVatThe].mucDichBool = 1;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietSoc = datHoaTietSoc( &mauNen, &mauSoc, 0.8f, 0.2f, &trucSoc );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__SOC;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình

      danhSachVat[soLuongVatThe].soLuongVatThe = 2;
      danhSachVat[soLuongVatThe].danhSachVatThe = malloc( 2*sizeof(VatThe) );
      
      // vị trí tương đối
      viTriTuongDoi.y = 0.0f;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].hinhDang.hinhNon = datHinhNon( 2.5f, 1.1f, 1.5f, &(danhSachVat[soLuongVatThe].danhSachVatThe[0].baoBiVT) );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[0]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
      danhSachVat[soLuongVatThe].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].danhSachVatThe[0].giaTri = 1;
      
      viTriTuongDoi.y = 0.0f;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].hinhDang.hinhNon = datHinhNon( 0.0f, 1.0f, 2.0f, &(danhSachVat[soLuongVatThe].danhSachVatThe[1].baoBiVT) );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_NON;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[1]), &phongTo, &quaternion, &viTriTuongDoi );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
      danhSachVat[soLuongVatThe].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].danhSachVatThe[1].giaTri = -1;
      // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
      tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
      
      soLuongVatThe++;
      viTri.x += 2.0f;
   }
   
//   mauNen.d = 1.0f;   mauNen.l = 0.85f;  mauNen.x = 0.95f;   mauNen.dd = 1.0f;   mauNen.p = 0.2f;

   viTri = viTriDay;
   viTri.x -= 5.0f;
   viTri.y += 0.75f;  // để hình nón trên mặt đất

   while ( soLuongVatThe < 10 ) {
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 2.5f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauNen );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
      
      soLuongVatThe++;
      viTri.x += 2.0f;
   }
   
   viTri = viTriDay;
   viTri.x -= 5.0f;
   viTri.y += 0.25f;  // để hình nón trên mặt đất
   
   while ( soLuongVatThe < 15 ) {
      danhSachVat[soLuongVatThe].hinhDang.hinhTru = datHinhTru( 4.5f, 0.5f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_TRU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauSoc );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
      
      soLuongVatThe++;
      viTri.x += 2.0f;
   }
   
   return soLuongVatThe;
}


unsigned short datLaCo( VatThe *danhSachVat, Vecto viTriDay ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   viTri = viTriDay;
   viTri.y += 1.0f;  // giữa hộp đầu
   
   Mau mau0;
   mau0.d = 1.0f;   mau0.l = 0.6f;  mau0.x = 0.5f;   mau0.dd = 1.0f;   mau0.p = 0.2f;
   Mau mau1;
   mau1.d = 0.5f;   mau1.l = 0.6f;  mau1.x = 1.0f;   mau1.dd = 1.0f;   mau1.p = 0.2f;
   
   unsigned short soLuongVatThe = 0;
   while ( soLuongVatThe < 30) {
      viTri.x = viTriDay.x - 5.0f;
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
      soLuongVatThe++;

      viTri.x += 4.0f;
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
      soLuongVatThe++;

      viTri.x += 4.0f;
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
      soLuongVatThe++;

      // ----
      viTri.y += 2.0f;
      viTri.x = viTriDay.x - 3.0f;
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
      soLuongVatThe++;
   
      viTri.x += 4.0f;
      danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
      danhSachVat[soLuongVatThe].chietSuat = 2.3f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau1 );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
      soLuongVatThe++;
   
      viTri.y += 2.0f;
   }
   
   // ---- hàng cuối
   viTri.x = viTriDay.x - 5.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
   soLuongVatThe++;
   
   viTri.x += 4.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
   soLuongVatThe++;
   
   viTri.x += 4.0f;
   danhSachVat[soLuongVatThe].hinhDang.hop = datHop( 2.0f, 2.0f, 0.2f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HOP;
   danhSachVat[soLuongVatThe].chietSuat = 2.3f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau0 );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
   soLuongVatThe++;

   return soLuongVatThe;
}

unsigned short datDiaSauLaCo( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   viTri = viTriDay;

   viTri.y += 0.15f;  // để hình nón trên mặt đất
   unsigned short soLuongVatThe = 0;
   
   Mau mauVang;
   mauVang.d = 1.0f;    mauVang.l = 0.9f;    mauVang.x = 0.0f;    mauVang.dd = 1.0f;    mauVang.p = 0.5f;
   danhSachVat[soLuongVatThe].hinhDang.hinhNon = datHinhNon( 5.5f, 5.2f, 0.3f, &(danhSachVat[soLuongVatThe].baoBiVT) );
   danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_NON;
   danhSachVat[soLuongVatThe].chietSuat = 1.0f;
   datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
   danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauVang );
   danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
   danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
   soLuongVatThe++;
   
   float mangViTriX[] = {-2.0f, -1.0f, 1.0f, 2.0f, 1.0f, -1.0f};
   float mangViTriZ[] = { 0.0f, 1.73205f, 1.73205f, 0.0f, -1.73205f, -1.73205f};
   Vecto viTriTuongDoi;
   viTriTuongDoi.x = 0.0f;    viTriTuongDoi.y = 0.0f;     viTriTuongDoi.z = 0.0f;
   viTri.y += 0.25f;
   
   // ---- các vòng tròng trên mặt dĩa
    while ( soLuongVatThe < 7 ) {
       viTri.x = viTriDay.x + mangViTriX[soLuongVatThe-1];
       viTri.z = viTriDay.z + mangViTriZ[soLuongVatThe-1];
       danhSachVat[soLuongVatThe].loai = kLOAI_VAT_THE__BOOL;
       danhSachVat[soLuongVatThe].mucDichBool = 1;
       danhSachVat[soLuongVatThe].chietSuat = 1.0f;
       datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
       danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauVang );
       danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
       danhSachVat[soLuongVatThe].viTriDau = viTri;  // cần này cho hoạt hình
       
       danhSachVat[soLuongVatThe].soLuongVatThe = 2;
       danhSachVat[soLuongVatThe].danhSachVatThe = malloc( 2*sizeof(VatThe) );
    
    // vị trí tương đối
       viTriTuongDoi.y = 0.0f;
       danhSachVat[soLuongVatThe].danhSachVatThe[0].hinhDang.hinhNon = datHinhNon( 2.8f, 2.6f, 0.2f, &(danhSachVat[soLuongVatThe].danhSachVatThe[0].baoBiVT) );
       danhSachVat[soLuongVatThe].danhSachVatThe[0].loai = kLOAI_HINH_DANG__HINH_NON;
       danhSachVat[soLuongVatThe].danhSachVatThe[0].chietSuat = 1.0f;
       datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[0]), &phongTo, &quaternion, &viTriTuongDoi );
       danhSachVat[soLuongVatThe].danhSachVatThe[0].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauVang );
       danhSachVat[soLuongVatThe].danhSachVatThe[0].soHoaTiet = kHOA_TIET__KHONG;
       danhSachVat[soLuongVatThe].danhSachVatThe[0].giaTri = 1;
       
       viTriTuongDoi.y += 0.01f;  // cao hơn một chút tránh vấn đề tròn số
       danhSachVat[soLuongVatThe].danhSachVatThe[1].hinhDang.hinhNon = datHinhNon( 2.45f, 2.25f, 0.2f, &(danhSachVat[soLuongVatThe].danhSachVatThe[1].baoBiVT) );
       danhSachVat[soLuongVatThe].danhSachVatThe[1].loai = kLOAI_HINH_DANG__HINH_NON;
       danhSachVat[soLuongVatThe].danhSachVatThe[1].chietSuat = 1.0f;
       datBienHoaChoVat( &(danhSachVat[soLuongVatThe].danhSachVatThe[1]), &phongTo, &quaternion, &viTriTuongDoi );
       danhSachVat[soLuongVatThe].danhSachVatThe[1].hoaTiet.hoaTietKhong = datHoaTietKhong( &mauVang );
       danhSachVat[soLuongVatThe].danhSachVatThe[1].soHoaTiet = kHOA_TIET__KHONG;
       danhSachVat[soLuongVatThe].danhSachVatThe[1].giaTri = -1;
       // ---- đừng quên tính bao bì vật thể cho vật thể ghép/bool
       tinhBaoBiVTChoVatTheGhep( &(danhSachVat[soLuongVatThe]) );
       
       soLuongVatThe++;
    }

   
   return soLuongVatThe;
}


unsigned short datLocXoay( VatThe *danhSachVat, Vecto viTriDay ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   viTri = viTriDay;
   viTri.y += 1.0f;  // giữa hộp đầu
   
   Mau mau;
   
   float goc = 0.0f;
   float banKinhXoay = 8.0f;
   float banKinhHinhCau = 1.0f;
   float doDuc = 0.01f;

   unsigned short soLuongVatThe = 0;
   while( soLuongVatThe < kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY ) {
      // ---- cỡ và màu của hình cầu lốc xoay
      if( (soLuongVatThe % 10) == 0 ) {
         mau.d = 0.3f;   mau.l = 0.3f;  mau.x = 0.3f;   mau.dd = doDuc;  mau.p = 0.1f;
         banKinhHinhCau = 1.0f;
      }
      else {
         mau.d = 0.6f;   mau.l = 0.6f;  mau.x = 0.6f;   mau.dd = doDuc;   mau.p = 0.1f;
         banKinhHinhCau = 0.7f;
      }
      float banKinhCos = banKinhXoay*cosf( goc );
      float banKinhSin = banKinhXoay*sinf( goc );
      viTri.x = viTriDay.x + banKinhCos;
      viTri.z = viTriDay.z + banKinhSin;
      danhSachVat[soLuongVatThe].hinhDang.hinhCau = datHinhCau( banKinhHinhCau, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau.x = viTriDay.x;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.y = viTri.y;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.z = viTriDay.z;  // cần này cho hoạt hình
      soLuongVatThe++;

      viTri.x = viTriDay.x - banKinhCos;
      viTri.z = viTriDay.z - banKinhSin;
      danhSachVat[soLuongVatThe].hinhDang.hinhCau = datHinhCau( banKinhHinhCau, &(danhSachVat[soLuongVatThe].baoBiVT) );
      danhSachVat[soLuongVatThe].loai = kLOAI_HINH_DANG__HINH_CAU;
      danhSachVat[soLuongVatThe].chietSuat = 1.0f;
      datBienHoaChoVat( &(danhSachVat[soLuongVatThe]), &phongTo, &quaternion, &viTri );
      danhSachVat[soLuongVatThe].hoaTiet.hoaTietKhong = datHoaTietKhong( &mau );
      danhSachVat[soLuongVatThe].soHoaTiet = kHOA_TIET__KHONG;
      danhSachVat[soLuongVatThe].viTriDau.x = viTriDay.x;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.y = viTri.y;  // cần này cho hoạt hình
      danhSachVat[soLuongVatThe].viTriDau.z = viTriDay.z;  // cần này cho hoạt hình
      soLuongVatThe++;

      goc += 0.25f;
      viTri.y += 0.5f;
      
      if( viTri.y - viTriDay.y < 5.0f ) {  // cho đoàn gần đất trong
         doDuc = (viTri.y - viTriDay.y)*0.2f;
      }
      else      
         doDuc -= 0.0065f;  // 1.0/kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY

   }

   return soLuongVatThe;
}

#pragma mark ---- NÂNG CẤP PHIM TRƯỜNG 1
void nangCapPhimTruong1( PhimTruong *phimTruong ) {
   
   //   printf( "phimTruong->soHoatHinhDau; %d\n", phimTruong->soHoatHinhDau );
   nangCapPhimTruong1_mayQuayPhim( phimTruong );
   nangCapPhimTruong1_nhanVat( phimTruong, phimTruong->soHoatHinhDau );
   
   // ---- tăng số hoạt hình
   phimTruong->soHoatHinhDau++;
}

void nangCapPhimTruong1_mayQuayPhim( PhimTruong *phimTruong ) {
   
   unsigned short soHoatHinh = phimTruong->soHoatHinhDau;
   MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);

   if( soHoatHinh < 400 ) {
      mayQuayPhim->viTri.x = 450.0f;
      mayQuayPhim->viTri.y = 250.0f;
      mayQuayPhim->viTri.z = 850.0f;

      Vecto trucQuayMayQuayPhim;
      trucQuayMayQuayPhim.x = 0.0f;
      trucQuayMayQuayPhim.y = 1.0f;
      trucQuayMayQuayPhim.z = 0.0f;
      phimTruong->mayQuayPhim.quaternion = datQuaternionTuVectoVaGocQuay( &trucQuayMayQuayPhim, 5.0f );
      quaternionSangMaTran( &(phimTruong->mayQuayPhim.quaternion), phimTruong->mayQuayPhim.xoay );
   }
   else if( soHoatHinh < 510 ) {
      mayQuayPhim->viTri.x = 70.0f;
      mayQuayPhim->viTri.y = 120.0f;
      mayQuayPhim->viTri.z = 1075.0f;
      
      Vecto huongNhin;
      huongNhin.x = -1.0f;
      huongNhin.y = -0.0f;
      huongNhin.z = -0.8f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }  // ---- sát với đất
   else if( soHoatHinh < 645 ) {
      mayQuayPhim->viTri.x = 4.0f;
      mayQuayPhim->viTri.y = 101.0f;
      mayQuayPhim->viTri.z = 650.0f;

      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = 0.0f;
      huongNhin.z = 1.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }  // theo trái banh vai chanh và sao gai, nhìn xuống từ trời
   else if( soHoatHinh < 830 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 25.0f;   congBezier.diemQuanTri[0].y = 115.0f;   congBezier.diemQuanTri[0].z = 626.0f;
      congBezier.diemQuanTri[1].x = 30.0f;   congBezier.diemQuanTri[1].y = 120.0f;   congBezier.diemQuanTri[1].z = 546.0f;
      congBezier.diemQuanTri[2].x = 90.0f;   congBezier.diemQuanTri[2].y = 200.0f;   congBezier.diemQuanTri[2].z = 330.0f;
      congBezier.diemQuanTri[3].x = 90.0f;   congBezier.diemQuanTri[3].y = 200.0f;   congBezier.diemQuanTri[3].z = 250.0f;
      
      float thamSoBezier = (soHoatHinh - 645)/185.0f;
      Vecto viTriMayQuayPhim = tinhViTriBezier3C( &congBezier, thamSoBezier );
      
      mayQuayPhim->viTri = viTriMayQuayPhim;
      
      Vecto huongNhin;
      huongNhin.x = -1.0f;
      huongNhin.y = -0.6f - 0.25f*(soHoatHinh - 645)/185.0f;
      huongNhin.z = -0.3f;  // 1,5 là vận tốc trái banh vai chánh và sao gai
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   } // theo trái banh vai chanh và sao gai trong cổng
   else if( soHoatHinh < 970 ) {
      mayQuayPhim->viTri.x = 4.0f;
      mayQuayPhim->viTri.y = 109.0f;
      mayQuayPhim->viTri.z = 290.0f - 1.5f*(soHoatHinh - 830);
      
      Vecto huongNhin;
      huongNhin.x = 0.0f;
      huongNhin.y = 0.0f;
      huongNhin.z = -1.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1080 ) {
      mayQuayPhim->viTri.x = 20.0f;
      mayQuayPhim->viTri.y = 123.0f;
      mayQuayPhim->viTri.z = -250.0f;
      
      Vecto huongNhin;
      huongNhin.x = -0.7f;
      huongNhin.y = -0.5f;
      huongNhin.z = 1.5f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   // ---- nhìn -z khi
   else if( soHoatHinh < 1150 ) {
      mayQuayPhim->viTri.x = 5.0f;
      mayQuayPhim->viTri.y = 108.0f;
      mayQuayPhim->viTri.z = -220.0f;
      
      Vecto huongNhin;
      huongNhin.x = -0.1f;
      huongNhin.y = -0.1f;
      huongNhin.z = -1.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   // ---- nhìn +z khi vào bong bóng (khi trở lại kiếm trái banh vai tranh)
   else if( soHoatHinh < 1250 ) {
      mayQuayPhim->viTri.x = 30.0f;
      mayQuayPhim->viTri.y = 133.0f;
      mayQuayPhim->viTri.z = -250.0f;
      
      Vecto huongNhin;
      huongNhin.x = -1.0f;
      huongNhin.y = -1.0f;
      huongNhin.z = 1.5f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   // ---- nhìn tới -z khi chùm ra dòng bong bóng (khi trở lại kiếm trái banh vai tranh)
   else if( soHoatHinh < 1400 ) {
      mayQuayPhim->viTri.x = 7.5f;
      mayQuayPhim->viTri.y = 106.0f;
      mayQuayPhim->viTri.z = 205.0f;
      
      Vecto huongNhin;
      huongNhin.x = -0.2f;
      huongNhin.y = -0.3f;
      huongNhin.z = -1.5f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if(soHoatHinh < 1420 ) {   // ---- nhìn tới +z
      mayQuayPhim->viTri.x = 3.0f;
      mayQuayPhim->viTri.y = 106.0f;
      mayQuayPhim->viTri.z = 175.0f;

      Vecto huongNhin;
      huongNhin.x = sinf( 0.2f );
      huongNhin.y = -0.15f;
      huongNhin.z = cosf( 0.2f);
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   } 
   else if( soHoatHinh < 1540 ) {   // ---- nhìn tới +z, quét xem
      mayQuayPhim->viTri.x = 3.0f + 0.04f*(soHoatHinh - 1420);
      mayQuayPhim->viTri.y = 106.0f;
      mayQuayPhim->viTri.z = 175.0f;
      
      float goc = (soHoatHinh - 1420)*0.007f;
      Vecto huongNhin;
      huongNhin.x = -sinf( goc - 0.2f );
      huongNhin.y = -0.15f;
      huongNhin.z = cosf( goc - 0.2f );
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1560 ) {
      mayQuayPhim->viTri.x = 7.8f;// 3.0f + 0.04f*(1540-1420) = 3.0f + 4.8f;
      mayQuayPhim->viTri.y = 106.0f;
      mayQuayPhim->viTri.z = 175.0f;
      
      float goc = 120*0.007f;
      Vecto huongNhin;
      huongNhin.x = -sinf( goc - 0.2f );
      huongNhin.y = -0.15f;
      huongNhin.z = cosf( goc - 0.2f );
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1585 ) {
      mayQuayPhim->viTri.x = -3.0f;
      mayQuayPhim->viTri.y = 106.0f;
      mayQuayPhim->viTri.z = 205.0f;
      
      Vecto huongNhin;
      huongNhin.x = 0.3f;
      huongNhin.y = -0.3f;
      huongNhin.z = -1.5f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1770 ) {
      mayQuayPhim->viTri.x = 55.0f;//800.0f - 2.0f*soHoatHinh;
      mayQuayPhim->viTri.y = 245.0f;
      mayQuayPhim->viTri.z = 165.0f - (soHoatHinh - 1585)*2.0f;
      
      Vecto huongNhin;
      huongNhin.x = -0.38f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;  // 1,5 là vận tốc trái banh vai chánh và sao gai
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
//      printf( "**** mayQayPhim viTriZ %5.3f\n",  mayQuayPhim->viTri.z );
   }
   else if( soHoatHinh < 1815 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 55.0f;    congBezier.diemQuanTri[0].y = 245.0f;    congBezier.diemQuanTri[0].z = -205.0f;
      congBezier.diemQuanTri[1].x = 55.0f;    congBezier.diemQuanTri[1].y = 245.0f;    congBezier.diemQuanTri[1].z = -235.0f;
      congBezier.diemQuanTri[2].x = 55.0f;    congBezier.diemQuanTri[2].y = 245.0f;    congBezier.diemQuanTri[2].z = -245.0f;
      congBezier.diemQuanTri[3].x = 55.0f;    congBezier.diemQuanTri[3].y = 245.0f;    congBezier.diemQuanTri[3].z = -245.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1770)/45.0f;
      mayQuayPhim->viTri = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
//      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
//      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
//      printf( "%d  may Quay Phim tocDo %5.3f\n", soHoatHinh, tocDo );

      Vecto huongNhin;
      huongNhin.x = -0.38f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;  // 1,5 là vận tốc trái banh vai chánh và sao gai
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 1860 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 55.0f;    congBezier.diemQuanTri[0].y = 245.0f;    congBezier.diemQuanTri[0].z = -245.0f;
      congBezier.diemQuanTri[1].x = 55.0f;    congBezier.diemQuanTri[1].y = 245.0f;    congBezier.diemQuanTri[1].z = -245.0f;
      congBezier.diemQuanTri[2].x = 55.0f;    congBezier.diemQuanTri[2].y = 245.0f;    congBezier.diemQuanTri[2].z = -235.0f;
      congBezier.diemQuanTri[3].x = 55.0f;    congBezier.diemQuanTri[3].y = 245.0f;    congBezier.diemQuanTri[3].z = -205.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1815)/45.0f;
      mayQuayPhim->viTri = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
//      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
//      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
//      printf( "%d  may Quay Phim tocDo %5.3f\n", soHoatHinh, tocDo );
      
      Vecto huongNhin;
      huongNhin.x = -0.38f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
//      printf( "**** mayQayPhim viTriZ %5.3f\n",  mayQuayPhim->viTri.z );
   }
   else if( soHoatHinh < 1975 ) { // đi theo sao gai trở lại đi qua cầu nữa
      mayQuayPhim->viTri.x = 55.0f;//800.0f - 2.0f*soHoatHinh;
      mayQuayPhim->viTri.y = 245.0f;
      mayQuayPhim->viTri.z = -205.0f + 1.5f*(soHoatHinh - 1860);
      
      Vecto huongNhin;
      huongNhin.x = -0.38f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
//      printf( "**** mayQayPhim viTriZ %5.3f\n",  mayQuayPhim->viTri.z );
   }
   else if( soHoatHinh < 2005 ) {
      mayQuayPhim->viTri.x = 55.0f;//800.0f - 2.0f*soHoatHinh;
      mayQuayPhim->viTri.y = 245.0f;
      mayQuayPhim->viTri.z = -35.0f - (soHoatHinh - 1975);
      
      Vecto huongNhin;
      huongNhin.x = -0.38f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
//      printf( "**** mayQayPhim viTriZ %5.3f\n",  mayQuayPhim->viTri.z );
   }
   else if( soHoatHinh < 2020 ) {
      float soHoatHinhTuongDoi = (float)(soHoatHinh - 2005);
      float phongVao = 6.0f; // phóng vào
      mayQuayPhim->viTri.x = 55.0f - phongVao*0.52f*soHoatHinhTuongDoi;  // (55 - 3) = 52
      mayQuayPhim->viTri.y = 245.0f - phongVao*1.44f*soHoatHinhTuongDoi; // (245 - 101) = 144
      mayQuayPhim->viTri.z = -65.0f - 6.4f*soHoatHinhTuongDoi;
      
      Vecto huongNhin;
      huongNhin.x = -0.38f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
//      printf( "**** mayQayPhim viTriZ %5.3f\n",  mayQuayPhim->viTri.z );
   }
   else if( soHoatHinh < 2040 ) {
      float phongVao = 6.0f; // phóng vào
      mayQuayPhim->viTri.x = 11.0f;  // (55 - 3) = 52
      mayQuayPhim->viTri.y = 124.0f; // (245 - 101) = 144
      mayQuayPhim->viTri.z = -160.0f - 2.0f*(soHoatHinh - 2020);
      
      Vecto huongNhin;
      huongNhin.x = -0.38f;
      huongNhin.y = -1.0f;
      huongNhin.z = -0.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
//      printf( "**** mayQayPhim viTriZ %5.3f\n",  mayQuayPhim->viTri.z );
   }
   else if( soHoatHinh < 2140 ) {
      mayQuayPhim->viTri.x = 3.0f;
      mayQuayPhim->viTri.y = 105.0f;
      mayQuayPhim->viTri.z = -205.0f;
      
      Vecto huongNhin;
      huongNhin.x = -0.0f;
      huongNhin.y = -0.2f + 0.4f*atanf( (soHoatHinh - 2040)*0.05f )/3.1415926f;
      huongNhin.z = -1.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else if( soHoatHinh < 2170 ) {
      mayQuayPhim->viTri.x = 3.0f;
      mayQuayPhim->viTri.y = 105.0f;
      mayQuayPhim->viTri.z = -205.0f - 7.0f*(soHoatHinh - 2140);
      
      Vecto huongNhin;
      huongNhin.x = -0.0f;
      huongNhin.y = -0.2f + 0.4f*atanf( (soHoatHinh - 2140)*0.05f )/3.1415926f;
      huongNhin.z = -1.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
   else {
      mayQuayPhim->viTri.x = 3.0f;
      mayQuayPhim->viTri.y = 105.0f;
      mayQuayPhim->viTri.z = -205.0f - 210;

      Vecto huongNhin;
      huongNhin.x = -0.0f;
      huongNhin.y = -0.2f + 0.4f*atanf( (soHoatHinh - 2140)*0.05f )/3.1415926f;
      huongNhin.z = -1.0f;
      dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin );
   }
/*
   // ---- cho xem từ trời xuống
   mayQuayPhim->viTri.x = 50.0f;//800.0f - 2.0f*soHoatHinh;
   mayQuayPhim->viTri.y = 280.0f;
   mayQuayPhim->viTri.z = -450.0f;
   
   Vecto huongNhin;
   huongNhin.x = -0.01f;
   huongNhin.y = -1.0f;
   huongNhin.z = -0.0f;  // 1,5 là vận tốc trái banh vai chánh và sao gai
   dinhHuongMaTranBangVectoNhin( mayQuayPhim->xoay, &huongNhin ); */
}

#pragma mark ---- Nâng Cấp Nhân Vật
void nangCapPhimTruong1_nhanVat( PhimTruong *phimTruong, unsigned short soHoatHinh ) {
   
   nangCapVaiChanh_PT_1( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__VAI_CHANH]]), soHoatHinh );
   nangCapSaoGai_PT_1( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__SAO_GAI]]), soHoatHinh );
   nangCapHinhCauKhongLoXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__HINH_CAU_KHONG_LO_XOAY]]) );
   nangCapNapDayHinhTru( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__NAP_DAY_HINH_TRU_DAU]]), phimTruong->nhanVat[kNHAN_VAT__NAP_DAY_HINH_TRU_CUOI] - phimTruong->nhanVat[kNHAN_VAT__NAP_DAY_HINH_TRU_DAU] );
   nangCapHaiKimTuThapXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__HAI_KIM_TU_THAP_XOAY]]) );
   nangCapHaiThauKinhXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__HAI_THAU_KINH_XOAY]]) );
   nangCapVuDinhCong( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__VU_DINH_CONG]]), soHoatHinh );
   nangCapLocXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__LOC_XOAY_0]]), soHoatHinh );
   nangCapLocXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__LOC_XOAY_1]]), soHoatHinh );
   nangCapLocXoay( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__LOC_XOAY_2]]), soHoatHinh );

   
   nangCapLaCo( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__MIEN_LA_CO_DAU]]), phimTruong->nhanVat[kNHAN_VAT__MIEN_LA_CO_CUOI] - phimTruong->nhanVat[kNHAN_VAT__MIEN_LA_CO_DAU], soHoatHinh );
   
   // ---- các bong bóng
   nangCapBayBongBong( &(phimTruong->danhSachVatThe[phimTruong->nhanVat[kNHAN_VAT__BONG_BONG_DAU_PT1]]),
                      phimTruong->nhanVat[kNHAN_VAT__BONG_BONG_CUOI_PT1] - phimTruong->nhanVat[kNHAN_VAT__BONG_BONG_DAU_PT1], soHoatHinh );
}

void nangCapVaiChanh_PT_1( VatThe *vaiChanh, unsigned short soHoatHinh ) {
   
   Vecto trucXoay;
   trucXoay.x = -1.0f;    trucXoay.y = 0.0f;   trucXoay.z = 0.0;
   Quaternion quaternion = tinhXoayChoVatThe( &(vaiChanh->quaternion), trucXoay, 2.0f, vaiChanh->hinhDang.hinhCau.banKinh );
   //   printf( "hinhCauKhongLoXoay->hinhDang.hinhCau.banKinh %5.3f\n", hinhCauKhongLoXoay->hinhDang.hinhCau.banKinh );
   //   printf( "quaternion %5.3f %5.3f %5.3f %5.3f\n", quaternion.w, quaternion.x, quaternion.y, quaternion.z );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- vị trí bắt đầu
   Vecto viTriVaiChanh;
   viTriVaiChanh.x = 3.0f; viTriVaiChanh.y = 100.2 + vaiChanh->hinhDang.hinhCau.banKinh;  viTriVaiChanh.z = 1900.0f;
   if( soHoatHinh < 970 ) {
      viTriVaiChanh.z = 1900.0f - 2.0f*soHoatHinh;
   }
   else if( soHoatHinh < 990 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;    congBezier.diemQuanTri[0].y = viTriVaiChanh.y;    congBezier.diemQuanTri[0].z = -40.0f;
      congBezier.diemQuanTri[1].x = 3.0f;    congBezier.diemQuanTri[1].y = viTriVaiChanh.y;    congBezier.diemQuanTri[1].z = -53.0f;
      congBezier.diemQuanTri[2].x = 6.0f;    congBezier.diemQuanTri[2].y = viTriVaiChanh.y;    congBezier.diemQuanTri[2].z = -53.0f;
      congBezier.diemQuanTri[3].x = 6.0f;    congBezier.diemQuanTri[3].y = viTriVaiChanh.y;    congBezier.diemQuanTri[3].z = -53.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 970)/20.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/20.0f;
 //     printf( "%d  vaiChanh tocDo %5.3f\n", soHoatHinh, tocDo );
      // ---- tính quaternion mới
      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      quaternion = tinhXoayChoVatThe( &(vaiChanh->quaternion), trucXoay, tocDo, vaiChanh->hinhDang.hinhCau.banKinh );
   }
   // ---- đợi và trốn trong bong bóng trên cầu 
   else if( soHoatHinh < 1940 ) {
      viTriVaiChanh.x = 6.0f;
      viTriVaiChanh.z = -53.0f;
   }
   // ---- chùm ra bong bóng và chạy
   else if( soHoatHinh < 2020 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 6.0f;    congBezier.diemQuanTri[0].y = viTriVaiChanh.y;    congBezier.diemQuanTri[0].z = -53.0f;
      congBezier.diemQuanTri[1].x = 6.0f;    congBezier.diemQuanTri[1].y = viTriVaiChanh.y;    congBezier.diemQuanTri[1].z = -53.0f;
      congBezier.diemQuanTri[2].x = 3.0f;    congBezier.diemQuanTri[2].y = viTriVaiChanh.y;    congBezier.diemQuanTri[2].z = -106.7f;
      congBezier.diemQuanTri[3].x = 3.0f;    congBezier.diemQuanTri[3].y = viTriVaiChanh.y;    congBezier.diemQuanTri[3].z = -160.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1940)/80.0f;
      viTriVaiChanh = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/80.0f;
//      printf( "%d  vaiChanh viTriZ %5.3f\n", soHoatHinh, viTriVaiChanh.z );
      // ---- tính quaternion mới
      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      quaternion = tinhXoayChoVatThe( &(vaiChanh->quaternion), trucXoay, tocDo, vaiChanh->hinhDang.hinhCau.banKinh );
   }

   else if( soHoatHinh < 2170 ) { // ---- chạy trống
      viTriVaiChanh.z = -160.0f - 2.0f*(soHoatHinh - 2020);
   }
   else { // ---- bị hút lên trong lốc xoay
      unsigned short soHoatHinhTuongDoi = soHoatHinh - 2170;
      viTriVaiChanh.y = 100.2f + vaiChanh->hinhDang.hinhCau.banKinh + 20.0f*atan( soHoatHinhTuongDoi*0.05f );
      
      float banKinh = expf( (viTriVaiChanh.y - 100.7f)*0.04 ) - 1.0f;
      float goc = soHoatHinh*0.3333f;
      viTriVaiChanh.x = 3.0f + 2.0f*soHoatHinhTuongDoi + banKinh*cosf( goc );
      viTriVaiChanh.z = -460.0f + 0.1f*soHoatHinhTuongDoi + banKinh*sinf( goc );
   }

//  printf( "ViTriVaiChanh %5.3f %5.3f %5.3f\n", viTriVaiChanh.x, viTriVaiChanh.y, viTriVaiChanh.z );

   datBienHoaChoVat( vaiChanh, &phongTo, &quaternion, &viTriVaiChanh );
}


void nangCapSaoGai_PT_1( VatThe *saoGai, unsigned short soHoatHinh ) {
   
   Vecto trucXoay;
   trucXoay.x = -1.0f;    trucXoay.y = 0.0f;   trucXoay.z = 0.0;
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;   quaternion.y = 0.0f;   quaternion.z = 0.0f;

   Vecto phongTo;
   phongTo.x = 1.4f;     phongTo.y = 1.4f;     phongTo.z = 1.4f;

   Vecto viTriSaoGai;
   viTriSaoGai.x = 3.0f; viTriSaoGai.y = 100.2f + kSAO_GAI__BAN_KINH*1.4f;  viTriSaoGai.z = 1920.0f;
   if( soHoatHinh < 1060 ) {
      viTriSaoGai.z = 1920.0f - 2.0f*soHoatHinh;
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, 2.0f, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- chảy chậm lại, vì không thấy trái banh vai chánh
   else if( soHoatHinh < 1105 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;    congBezier.diemQuanTri[0].y = viTriSaoGai.y;    congBezier.diemQuanTri[0].z = -200.0f;
      congBezier.diemQuanTri[1].x = 3.0f;    congBezier.diemQuanTri[1].y = viTriSaoGai.y;    congBezier.diemQuanTri[1].z = -230.0f;
      congBezier.diemQuanTri[2].x = 3.0f;    congBezier.diemQuanTri[2].y = viTriSaoGai.y;    congBezier.diemQuanTri[2].z = -240.0f;
      congBezier.diemQuanTri[3].x = 3.0f;    congBezier.diemQuanTri[3].y = viTriSaoGai.y;    congBezier.diemQuanTri[3].z = -240.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1060)/45.0f;
      viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
//      printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );

      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );

      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, tocDo, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- dừng lại
   else if( soHoatHinh < 1130 ) {
      viTriSaoGai.z = -240.0f;
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, 0.0f, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- tăng tốc độ; trở lại kiếm
   else if( soHoatHinh < 1175 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;    congBezier.diemQuanTri[0].y = viTriSaoGai.y;    congBezier.diemQuanTri[0].z = -240.0f;
      congBezier.diemQuanTri[1].x = 3.0f;    congBezier.diemQuanTri[1].y = viTriSaoGai.y;    congBezier.diemQuanTri[1].z = -240.0f;
      congBezier.diemQuanTri[2].x = 3.0f;    congBezier.diemQuanTri[2].y = viTriSaoGai.y;    congBezier.diemQuanTri[2].z = -230.0f;
      congBezier.diemQuanTri[3].x = 3.0f;    congBezier.diemQuanTri[3].y = viTriSaoGai.y;    congBezier.diemQuanTri[3].z = -200.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1130)/45.0f;
      viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
 //     printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
      
      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, tocDo, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- chạy qua cầu hướng +z
   else if( soHoatHinh < 1352 ) {
      viTriSaoGai.z = -200.0f + 2.0f*(soHoatHinh - 1175);
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, -2.0f, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- giảm tốc độ; quay trở lại nữa
   else if( soHoatHinh < 1397 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;    congBezier.diemQuanTri[0].y = viTriSaoGai.y;    congBezier.diemQuanTri[0].z = 150.0f;
      congBezier.diemQuanTri[1].x = 3.0f;    congBezier.diemQuanTri[1].y = viTriSaoGai.y;    congBezier.diemQuanTri[1].z = 180.0f;
      congBezier.diemQuanTri[2].x = 3.0f;    congBezier.diemQuanTri[2].y = viTriSaoGai.y;    congBezier.diemQuanTri[2].z = 190.0f;
      congBezier.diemQuanTri[3].x = 3.0f;    congBezier.diemQuanTri[3].y = viTriSaoGai.y;    congBezier.diemQuanTri[3].z = 190.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1352)/45.0f;
      viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
 //     printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
      
      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );

      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, tocDo, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- dừng lại lần thứ 2
   else if( soHoatHinh < 1550 ) {
      viTriSaoGai.z = 190.0f;
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, 0.0f, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- bắt đầu chạy qua cầu nữa hướng -z
   else if( soHoatHinh < 1595 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;    congBezier.diemQuanTri[0].y = viTriSaoGai.y;    congBezier.diemQuanTri[0].z = 190.0f;
      congBezier.diemQuanTri[1].x = 3.0f;    congBezier.diemQuanTri[1].y = viTriSaoGai.y;    congBezier.diemQuanTri[1].z = 190.0f;
      congBezier.diemQuanTri[2].x = 3.0f;    congBezier.diemQuanTri[2].y = viTriSaoGai.y;    congBezier.diemQuanTri[2].z = 160.0f;
      congBezier.diemQuanTri[3].x = 3.0f;    congBezier.diemQuanTri[3].y = viTriSaoGai.y;    congBezier.diemQuanTri[3].z = 150.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1550)/45.0f;
      viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
//      printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
      
      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, tocDo, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- chảy qua cầu hướng -z
   else if( soHoatHinh < 1770 ) {
      viTriSaoGai.z = 150.0f - 2.0f*(soHoatHinh - 1595);
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, 2.0f, kSAO_GAI__BAN_KINH*1.4f );
   }
   else if( soHoatHinh < 1815 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;    congBezier.diemQuanTri[0].y = viTriSaoGai.y;    congBezier.diemQuanTri[0].z = -200.0f;
      congBezier.diemQuanTri[1].x = 3.0f;    congBezier.diemQuanTri[1].y = viTriSaoGai.y;    congBezier.diemQuanTri[1].z = -230.0f;
      congBezier.diemQuanTri[2].x = 3.0f;    congBezier.diemQuanTri[2].y = viTriSaoGai.y;    congBezier.diemQuanTri[2].z = -240.0f;
      congBezier.diemQuanTri[3].x = 3.0f;    congBezier.diemQuanTri[3].y = viTriSaoGai.y;    congBezier.diemQuanTri[3].z = -240.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1770)/45.0f;
      viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
//      printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
      
      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, tocDo, kSAO_GAI__BAN_KINH*1.4f );
   }
   // ---- tăng tốc độ; trở lại kiếm
   else if( soHoatHinh < 1860 ) {
      Bezier congBezier;  // cong Bezier cho đoạn thời gian này
      congBezier.diemQuanTri[0].x = 3.0f;    congBezier.diemQuanTri[0].y = viTriSaoGai.y;    congBezier.diemQuanTri[0].z = -240.0f;
      congBezier.diemQuanTri[1].x = 3.0f;    congBezier.diemQuanTri[1].y = viTriSaoGai.y;    congBezier.diemQuanTri[1].z = -240.0f;
      congBezier.diemQuanTri[2].x = 3.0f;    congBezier.diemQuanTri[2].y = viTriSaoGai.y;    congBezier.diemQuanTri[2].z = -230.0f;
      congBezier.diemQuanTri[3].x = 3.0f;    congBezier.diemQuanTri[3].y = viTriSaoGai.y;    congBezier.diemQuanTri[3].z = -200.0f;
      
      float thamSoBezier = ((float)soHoatHinh - 1815)/45.0f;
      viTriSaoGai = tinhViTriBezier3C( &congBezier, thamSoBezier );
      // ---- vận tốc
      Vecto vanToc = tinhVanTocBezier3C( &congBezier, thamSoBezier );
      float tocDo = sqrtf( vanToc.x*vanToc.x + vanToc.z*vanToc.z )/45.0f;
 //     printf( "%d  saoGai tocDo %5.3f\n", soHoatHinh, tocDo );
      
      Vecto phapThuyenMatDat;
      phapThuyenMatDat.x = 0.0f; phapThuyenMatDat.y = 1.0f; phapThuyenMatDat.z = 0.0f;
      trucXoay = tichCoHuong( &phapThuyenMatDat, &vanToc );
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, tocDo, kSAO_GAI__BAN_KINH*1.4f );
   }
   else {
      viTriSaoGai.z = -200.0f + 2.0f*(soHoatHinh - 1860);
      quaternion = tinhXoayChoVatThe( &(saoGai->quaternion), trucXoay, -2.0f, kSAO_GAI__BAN_KINH*1.4f );
   }

//   printf( "---- saoGai viTri %5.3f %5.3f %5.3f\n", viTriSaoGai.x, viTriSaoGai.y, viTriSaoGai.z );
//   printf( "   quaternion %5.3f %5.3f %5.3f %5.3f\n", quaternion.w, quaternion.x, quaternion.y, quaternion.z );
//   printf( "   truoc saoGai->quaternion %5.3f %5.3f %5.3f %5.3f\n", saoGai->quaternion.w, saoGai->quaternion.x, saoGai->quaternion.y, saoGai->quaternion.z );
   datBienHoaChoVat( saoGai, &phongTo, &quaternion, &viTriSaoGai );
//   printf( "   sau saoGai->quaternion %5.3f %5.3f %5.3f %5.3f\n", saoGai->quaternion.w, saoGai->quaternion.x, saoGai->quaternion.y, saoGai->quaternion.z );
}

void nangCapHinhCauKhongLoXoay( VatThe *hinhCauKhongLoXoay ) {
   
   Vecto trucXoay;
   trucXoay.x = cosf(0.7f);    trucXoay.y = 0.0f;   trucXoay.z = sinf(0.7f);
   Quaternion quaternion = tinhXoayChoVatThe( &(hinhCauKhongLoXoay->quaternion), trucXoay, 0.2f, hinhCauKhongLoXoay->hinhDang.hinhCau.banKinh );
//   printf( "hinhCauKhongLoXoay->hinhDang.hinhCau.banKinh %5.3f\n", hinhCauKhongLoXoay->hinhDang.hinhCau.banKinh );
//   printf( "quaternion %5.3f %5.3f %5.3f %5.3f\n", quaternion.w, quaternion.x, quaternion.y, quaternion.z );
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   viTri.x = hinhCauKhongLoXoay->dich[12];
   viTri.y = hinhCauKhongLoXoay->dich[13];
   viTri.z = hinhCauKhongLoXoay->dich[14];
   
   datBienHoaChoVat( hinhCauKhongLoXoay, &phongTo, &quaternion, &viTri );
}

void nangCapNapDayHinhTru( VatThe *mangVatThe, unsigned short soLuongVatThe ) {
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   
   Vecto trucXoay;
   trucXoay.x = 0.0f;    trucXoay.y = 0.0f;    trucXoay.z = 1.0f;

   float vanTocGoc = 0.012f;
   Quaternion quaternionXoay = datQuaternionTuVectoVaGocQuay( &trucXoay, vanTocGoc );
   
   unsigned short soVat = 0;
   while ( soVat < soLuongVatThe ) {
      // ---- hai nắp xoay cùng hướng
      VatThe *vatThe = &(mangVatThe[soVat]);
      Vecto viTri;
      viTri.x = vatThe->dich[12];
      viTri.y = vatThe->dich[13];
      viTri.z = vatThe->dich[14];
      Quaternion quaternionVatThe = vatThe->quaternion;
      Quaternion xoayMoi = nhanQuaternionVoiQuaternion( &quaternionVatThe, &quaternionXoay );
      datBienHoaChoVat( vatThe, &phongTo, &xoayMoi, &viTri );
      soVat++;

      // ---- nắp bên kia
      vatThe = &(mangVatThe[soVat]);
      viTri.x = vatThe->dich[12];
      viTri.y = vatThe->dich[13];
      viTri.z = vatThe->dich[14];
      datBienHoaChoVat( vatThe, &phongTo, &xoayMoi, &viTri );
      soVat++;
   }
//   printf("xong nangCap nap day hinh tru\n" );
}

void nangCapBayBongBong( VatThe *danhSachBongBong, unsigned short soLuongBongBong, unsigned short soHoatHinh ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;

   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   Bezier duongBongBong[4];
   duongBongBong[0].diemQuanTri[0].x = 962.0f;   duongBongBong[0].diemQuanTri[0].y = 100.0f;   duongBongBong[0].diemQuanTri[0].z = 10.0f;
   duongBongBong[0].diemQuanTri[1].x = 586.0f;   duongBongBong[0].diemQuanTri[1].y = 100.0f;   duongBongBong[0].diemQuanTri[1].z = -167.0f;
   duongBongBong[0].diemQuanTri[2].x = 552.0f;   duongBongBong[0].diemQuanTri[2].y = 100.0f;   duongBongBong[0].diemQuanTri[2].z = -212.0f;
   duongBongBong[0].diemQuanTri[3].x = 413.0f;   duongBongBong[0].diemQuanTri[3].y = 100.0f;   duongBongBong[0].diemQuanTri[3].z = -218.0f;

   duongBongBong[1].diemQuanTri[0].x = 413.0f;   duongBongBong[1].diemQuanTri[0].y = 100.0f;   duongBongBong[1].diemQuanTri[0].z = -218.0f;
   duongBongBong[1].diemQuanTri[1].x = 275.0f;   duongBongBong[1].diemQuanTri[1].y = 100.0f;   duongBongBong[1].diemQuanTri[1].z = -223.0f;
   duongBongBong[1].diemQuanTri[2].x = 218.0f;   duongBongBong[1].diemQuanTri[2].y = 100.0f;   duongBongBong[1].diemQuanTri[2].z = 36.0f;
   duongBongBong[1].diemQuanTri[3].x = 60.0f;    duongBongBong[1].diemQuanTri[3].y = 100.0f;   duongBongBong[1].diemQuanTri[3].z = 0.0f;
// ----
   duongBongBong[2].diemQuanTri[0].x = 60.0f;     duongBongBong[2].diemQuanTri[0].y = 100.0f;   duongBongBong[2].diemQuanTri[0].z = 0.0f;
   duongBongBong[2].diemQuanTri[1].x = -108.0f;   duongBongBong[2].diemQuanTri[1].y = 100.0f;   duongBongBong[2].diemQuanTri[1].z = -34.0f;
   duongBongBong[2].diemQuanTri[2].x = -270.0f;   duongBongBong[2].diemQuanTri[2].y = 100.0f;   duongBongBong[2].diemQuanTri[2].z = -200.0f;
   duongBongBong[2].diemQuanTri[3].x = -450.0f;   duongBongBong[2].diemQuanTri[3].y = 100.0f;   duongBongBong[2].diemQuanTri[3].z = -259.0f;

   duongBongBong[3].diemQuanTri[0].x = -450.0f;   duongBongBong[3].diemQuanTri[0].y = 100.0f;   duongBongBong[3].diemQuanTri[0].z = -259.0f;
   duongBongBong[3].diemQuanTri[1].x = -632.0f;   duongBongBong[3].diemQuanTri[1].y = 100.0f;   duongBongBong[3].diemQuanTri[1].z = -320.0f;
   duongBongBong[3].diemQuanTri[2].x = -765.0f;   duongBongBong[3].diemQuanTri[2].y = 100.0f;   duongBongBong[3].diemQuanTri[2].z = -82.0f;
   duongBongBong[3].diemQuanTri[3].x = -1034.0f;  duongBongBong[3].diemQuanTri[3].y = 100.0f;   duongBongBong[3].diemQuanTri[3].z = -17.0f;

   // ---- nâng cấp vị trí cho bày bong bóng
   unsigned short soBongBong = 0;
   while ( soBongBong < soLuongBongBong ) {
      
      float thamSoBezier = danhSachBongBong[soBongBong].thamSoBezier + kTOC_DO_BONG_BONG_TRONG_BAY;
      if( thamSoBezier > 4.0f )
         thamSoBezier = 0.0f;

      danhSachBongBong[soBongBong].thamSoBezier = thamSoBezier;
      
      // --- xài tham số Bezier cho tính vị trí mới
      Vecto viTriDiChuyen;
      
      if( thamSoBezier < 1.0f )
         viTriDiChuyen = tinhViTriBezier3C( &(duongBongBong[0]), thamSoBezier );
      else if( thamSoBezier < 2.0f )
         viTriDiChuyen = tinhViTriBezier3C( &(duongBongBong[1]), thamSoBezier - 1.0f );
      else if( thamSoBezier < 3.0f )
         viTriDiChuyen = tinhViTriBezier3C( &(duongBongBong[2]), thamSoBezier - 2.0f );
      else if( thamSoBezier < 4.0f )
         viTriDiChuyen = tinhViTriBezier3C( &(duongBongBong[3]), thamSoBezier - 3.0f );

      // ---- cộng vị trí di chuyển với vị trí ban đầu
      Vecto viTriMoi;
      viTriMoi.x = danhSachBongBong[soBongBong].viTriDau.x + viTriDiChuyen.x;
      viTriMoi.y = danhSachBongBong[soBongBong].viTriDau.y + viTriDiChuyen.y;
      viTriMoi.z = danhSachBongBong[soBongBong].viTriDau.z + viTriDiChuyen.z;
//      printf( "%d %d  viTriBongBong %5.3f %5.3f %5.3f\n", soHoatHinh, soBongBong, viTriMoi.x, viTriMoi.y, viTriMoi.z );

      datBienHoaChoVat( &(danhSachBongBong[soBongBong]), &phongTo, &quaternion, &viTriMoi );
      soBongBong++;
   }
   
}

void nangCapHaiKimTuThapXoay( VatThe *kimTuThap ) {
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;    trucXoay.y = 1.0f;   trucXoay.z = 0.0f;
   Quaternion quaternion = tinhXoayChoVatThe( &(kimTuThap->quaternion), trucXoay, 0.5f, 3.0f );

   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- kim tư tháp 1
   Vecto viTri;
   viTri.x = kimTuThap->dich[12];
   viTri.y = kimTuThap->dich[13];
   viTri.z = kimTuThap->dich[14];

   datBienHoaChoVat( kimTuThap, &phongTo, &quaternion, &viTri );
   
   // ---- kim tư tháp 2
   trucXoay.y = -1.0f;
   
   viTri.x = kimTuThap[1].dich[12];
   viTri.y = kimTuThap[1].dich[13];
   viTri.z = kimTuThap[1].dich[14];
   datBienHoaChoVat( &(kimTuThap[1]), &phongTo, &quaternion, &viTri );

}

void nangCapHaiThauKinhXoay( VatThe *kimTuThap ) {
   
   Vecto trucXoay;
   trucXoay.x = 0.0f;    trucXoay.y = -1.0f;   trucXoay.z = 0.0f;
   Quaternion quaternion = tinhXoayChoVatThe( &(kimTuThap->quaternion), trucXoay, 0.5f, 3.0f );

   // ---- phóng to đặt biệt cho thấu kính
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 0.2f;
   
   // ---- kim tư tháp 1
   Vecto viTri;
   viTri.x = kimTuThap->dich[12];
   viTri.y = kimTuThap->dich[13];
   viTri.z = kimTuThap->dich[14];
   
   datBienHoaChoVat( kimTuThap, &phongTo, &quaternion, &viTri );
   
   // ---- kim tư tháp 2
   trucXoay.y = 1.0f;
   
   viTri.x = kimTuThap[1].dich[12];
   viTri.y = kimTuThap[1].dich[13];
   viTri.z = kimTuThap[1].dich[14];
   datBienHoaChoVat( &(kimTuThap[1]), &phongTo, &quaternion, &viTri );
}


void nangCapVuDinhCong( VatThe *danhSachVat, unsigned short soHoatHinh ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;

   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   // ---- 
   Vecto viTri;
   viTri.x = danhSachVat[0].dich[12];
   viTri.y = 142.0f + 1.5f*sinf( soHoatHinh*0.05f );
   viTri.z = danhSachVat[0].dich[14];
   datBienHoaChoVat( &(danhSachVat[0]), &phongTo, &quaternion, &viTri );
   
   viTri.x = danhSachVat[1].dich[12];
   viTri.y = 146.0f + 1.5f*sinf( soHoatHinh*0.05f + 0.5f );
   viTri.z = danhSachVat[1].dich[14];
   datBienHoaChoVat( &(danhSachVat[1]), &phongTo, &quaternion, &viTri );
   
   viTri.x = danhSachVat[2].dich[12];
   viTri.y = 150.0f + 1.5f*sinf( soHoatHinh*0.05f + 1.0f );
   viTri.z = danhSachVat[2].dich[14];
   datBienHoaChoVat( &(danhSachVat[2]), &phongTo, &quaternion, &viTri );
   
   viTri.x = danhSachVat[3].dich[12];
   viTri.y = 154.0f + 1.5f*sinf( soHoatHinh*0.05f + 1.5f );
   viTri.z = danhSachVat[3].dich[14];
   datBienHoaChoVat( &(danhSachVat[3]), &phongTo, &quaternion, &viTri );
   
   viTri.x = danhSachVat[4].dich[12];
   viTri.y = 158.0f + 1.5f*sinf( soHoatHinh*0.05f + 2.0f );
   viTri.z = danhSachVat[4].dich[14];
   datBienHoaChoVat( &(danhSachVat[4]), &phongTo, &quaternion, &viTri );

   viTri.x = danhSachVat[5].dich[12];
   viTri.y = 162.0f + 1.5f*sinf( soHoatHinh*0.05f + 2.5f );
   viTri.z = danhSachVat[5].dich[14];
   datBienHoaChoVat( &(danhSachVat[5]), &phongTo, &quaternion, &viTri );
}


// f(x) = A*x*sinf( B*t + C*x )
// df/dx = A*sinf( B*t + C*x ) + A*x*C*cosf( B*t + C*x )
void nangCapLaCo( VatThe *danhSachVat, unsigned short soLuongVatThe, unsigned short soHoatHinh ) {

   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;
   
   Vecto viTri;
   
   float giaTri = soHoatHinh*0.2f;

   unsigned short soMienLaCo = 0;
   while ( soMienLaCo < soLuongVatThe ) {
      viTri = danhSachVat[soMienLaCo].viTriDau;
      // ---- tính quãng từ đấy
      float quangTuDay = viTri.y - 104.0f;
      // ---- tính giá trị sin, sẽ xài cho dịchZ và gócQuay
      float bienDoSin = 0.1f*sinf( giaTri + quangTuDay*0.5f );
      // ---- dịch Z
      viTri.z += quangTuDay*bienDoSin;
   
      // ---- tính góc
      float gocQuay = atanf( 0.1f*bienDoSin + 0.05*quangTuDay*cosf( giaTri + quangTuDay*0.5f ) );
   
      // ---- tính quaternion
      Vecto trucQuay;
      trucQuay.x = 1.0f;  trucQuay.y = 0.0f;  trucQuay.z = 0.0f;
      quaternion = datQuaternionTuVectoVaGocQuay( &trucQuay, gocQuay );
      datBienHoaChoVat( &(danhSachVat[soMienLaCo]), &phongTo, &quaternion, &viTri );
      
      soMienLaCo++;
   }

}


void nangCapLocXoay( VatThe *danhSachVat, unsigned short soHoatHinh ) {
   
   Quaternion quaternion;
   quaternion.w = 1.0f;   quaternion.x = 0.0f;    quaternion.y = 0.0f;    quaternion.z = 0.0f;
   
   Vecto phongTo;
   phongTo.x = 1.0f;     phongTo.y = 1.0f;     phongTo.z = 1.0f;

   float goc = soHoatHinh*0.3333f;
   float chenhLech = 1.5f*sinf( soHoatHinh*0.5f );
 
   
   unsigned short soVat = 0;
   while ( soVat < kSO_LUONG__HAT_BAY_TRONG_LOC_XOAY ) {

      // ---- tính bán kính mới
      Vecto viTriDau = danhSachVat[soVat].viTriDau;
      float banKinh = 7.0f + expf( (viTriDau.y - 100.0f)*0.04f ) + chenhLech;  // 100.0f là đố cao mặt đất

      // ==== bên này
      // ---- tính vị trí mới
      float banKinhCos = banKinh*cosf( goc );
      float banKinhSin = banKinh*sinf( goc );

      // ---- nâng cấp vị tri
      viTriDau.x += 2.0f;
      viTriDau.z += 0.1f;
      // ---- giữ vị tri mới
      danhSachVat[soVat].viTriDau = viTriDau;
      
      Vecto viTri = viTriDau;
      // ---- 
      viTri.x += banKinhCos;
      viTri.z += banKinhSin;
      datBienHoaChoVat( &(danhSachVat[soVat]), &phongTo, &quaternion, &viTri );
      
      // ==== bên kia
      viTriDau = danhSachVat[soVat+1].viTriDau;
      // ---- nâng cấp vị tri
      viTriDau.x += 2.0f;
      viTriDau.z += 0.1f;
//      printf( "viTriDau %5.3f %5.3f\n", viTriDau.x, viTriDau.z );
      // ---- giữ vị tri mới
      danhSachVat[soVat+1].viTriDau = viTriDau;

      viTri = viTriDau;
      // ----
      viTri.x -= banKinhCos;
      viTri.z -= banKinhSin;
      datBienHoaChoVat( &(danhSachVat[soVat + 1]), &phongTo, &quaternion, &viTri );

      goc += 0.25f;
      soVat +=2;
   }
//   printf( "ViTriLocXoay %5.3f %5.3f %5.3f\n", danhSachVat[0].viTriDau.x, danhSachVat[0].viTriDau.y, danhSachVat[0].viTriDau.z );

}
