//  Ví dụ phương pháp kết xuất dò tia đơn giản
//  Phiên Bản 4.31
//  Phát hành 2560/02/04
//  Hệ tọa độ giống OpenGL (+y là hướng lên)
//  Khởi đầu 2557/12/18

//  Sai lầm Segmentation fault: 11 thường nghĩa là có hai vật thể cùng tâm và kh©ông thể xây cây thần bậc

//  Biên dịch cho gcc: gcc -lm -lz doTia.c -o <tên chương trình>
//  Biên dịch cho clang: clang -lm -lz doTia.c -o <tên chương trình>

//  Lệnh dạng: <sỗ phim trường> <số hoạt hình đầu> <số hoạt hình cuối> <beRồng ảnh> <bề cao ảnh> <cỡ kích điểm ảnh>
//  ---- Cho phối cảnh
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520   600  300   0.01
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520  8192 4096  0.00075 <---- 8K  (8192 x 4320)
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520  4096 2048  0.0015  <---- 4K  (4096 x 2160)
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520  2048 1024  0.003  <---- 2K
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520  1536  768  0.004  <---- ~ Câu Truyện Đồ Chơi 1
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520  1024  512  0.006
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520   512  256  0.014
//  Lệnh dạng ví dụ: <tên chương trình biên dịch> 0  0 1520   256  128  0.024
//
//  • CHO MÁY PHIM 1 ĐƠN VỊ CHIẾU_TOAN_CANH ≈ 5/24 ĐƠN VỊ CHIẾU_PHỐI_CẢNH
//  • Đừng cho vật thể nào có bao bì bề nào = 0
//  - Hình Cầu
//  - Mặt Phẳng
//  - Hợp
//  - Hình Trụ
//  - Hình Nón
//  - Mặt Hyperbol
//  - Mặt Parabol
//  - Tứ Diện
//  - Bát Diện
//  - Thập Nhị Diện
//  - Kim Tư Tháp
//  - Dốc
//  - Nhị Thập Diện
//  - Sao Gai
//  - Mặt Sóng
//  - Hình Xuyến

//  - Vật Thể Bool
//  - Vật Thể Ghép

//  - Biến Hóa cho vật thể, không đặt vị trí hay phóng to ---> xài ma trận;
//       Lưu Ý: nên không xài cho phóng to lớn cho vật thể xa máy quay phim
//  - Họa tiết tô màu
//  - Phim Trường
//  - ba chiếu đồ: phối cảnh, cự tuyến, toàn cảnh
//  - phản xạ thuộc màu cho một họa tiết có thể có phản xạ không đều
//  - bóng tối trong, nhưng chỉ xài đục của vật thể đầu tiên tia bóng tối gặp

//  Hồ Nhựt Châu  su_huynh@yahoo.com

#include "Anh.h"
#include "Toán/Vecto.h"
#include "Toán/Tia.h"
#include "Toán/BienHoa.h"
#include "XemCat/XemCat.h"
#include "DocThamSo.h"
#include "PhimTrường/PhimTruong0.h"
#include "PhimTrường/PhimTruong1.h"
#include "PhimTrường/PhimTruong2.h"
#include "PhimTrường/PhimTruong3.h"
#include "ThongTinToMau.h"
#include "XemCat/TinhBaoBi.h"
#include "ToMau.h"
#include "LuuAnhEXR.h"
#include <stdio.h>
#include <time.h>


void veAnhChieuPhoiCanh( Anh *anh, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem );
void veAnhChieuCuTuyen( Anh *anh, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem );
void veAnhChieuToanCanh( Anh *anh, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem );

Mau doTia( Tia *tia, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem, unsigned short soNhoi );

int main( int argc, char **argv ) {
   
   PhimTruong phimTruong;
   unsigned int soPhimTruong = 0;
   docThamSoPhimTruong( argc, argv, &soPhimTruong );
   
   if( soPhimTruong == 0 )
      phimTruong = datPhimTruongSo0( argc, argv );
   else if( soPhimTruong == 1 )
      phimTruong = datPhimTruongSo1( argc, argv );
   else if( soPhimTruong == 2 )
      phimTruong = datPhimTruongSo2( argc, argv );
   else if( soPhimTruong == 3 )
      phimTruong = datPhimTruongSo3( argc, argv );
   
   // ---- giữ số phim trường
   phimTruong.soPhimTruong = soPhimTruong;

   // ---- cỡ kích ảnh
   unsigned int beCaoAnh;// = 201;//601;  // 601
   unsigned int beRongAnh;// = beCaoAnh << 1;
   // ---- cho hình sẽ phóng to theo cỡ kích ảnh
   float coKichDiemAnh;// = 0.005f*3.0f;   // 1.0f;
   docThamCoKich( argc, argv, &beRongAnh, &beCaoAnh, &coKichDiemAnh );
   printf( "Cỡ Kích Ảnh: %d %d %5.4f\n", beRongAnh, beCaoAnh, coKichDiemAnh );
   
   
   Anh anh = taoAnhVoiCoKich( beRongAnh, beCaoAnh, coKichDiemAnh );
   printf( "PhimTrường %d  số lượng vật thể %d/%d\n", phimTruong.soPhimTruong, phimTruong.soLuongVatThe, kSO_LUONG_VAT_THE_TOI_DA );
   printf( "     bứcẢnhĐầu %d   bứcẢnhCuối %d\n", phimTruong.soHoatHinhDau, phimTruong.soHoatHinhCuoi );
   
   time_t thoiGianBatDauToanCau;
   time(&thoiGianBatDauToanCau);
   
   while( phimTruong.soHoatHinhDau < phimTruong.soHoatHinhCuoi ) {
      
      // ---- nâng cấp hoạt hình
      if( soPhimTruong == 0 )
         nangCapPhimTruong0( &phimTruong );
      else if( soPhimTruong == 1 )
         nangCapPhimTruong1( &phimTruong );
      else if( soPhimTruong == 2 )
         nangCapPhimTruong2( &phimTruong );
      else if( soPhimTruong == 3 )
         nangCapPhimTruong3( &phimTruong );

      //      xemVatThe( phimTruong.danhSachVatThe, phimTruong.soLuongVatThe );
      char tenAnh[256];
      sprintf( tenAnh, "TGB_%02d_%04d.exr", phimTruong.soPhimTruong, phimTruong.soHoatHinhDau );
 
      // ---- xây tầng bậc đoạn bao bì
      phimTruong.baoBi = tinhBaoBiTGChoDanhSachVatThe( phimTruong.danhSachVatThe, phimTruong.soLuongVatThe );
      
      unsigned int soLuongGiaoDiem = 0;
      
      datLaiMangChiVatThe( phimTruong.mangChiSoVatTheSapXep, phimTruong.soLuongVatThe );
      // ==== tạo tầng bậc bao bì
      // ---- trục và tọa độ mặt phẳng đầu
      float toaDoMatPhang;
      unsigned int truc;
      tinhTrucVaToaMatPhangChia( &(phimTruong.baoBi), &truc, &toaDoMatPhang );
   
      // ---- tạo cây tầng bậc bao bì
      GiaoDiemBIH mangGiaoDiem[kSO_LUONG__GIAO_DIEM_TOI_DA];  // 28672/7 ≈ 16384 vật thể

      chiaVatThe( phimTruong.danhSachVatThe, phimTruong.mangChiSoVatTheSapXep, phimTruong.soLuongVatThe, 0, &(phimTruong.baoBi), truc, toaDoMatPhang, mangGiaoDiem, &soLuongGiaoDiem );
      //      xemCay( mangGiaoDiem, chiSoGiaoDiem );
      printf( "cây chiSoGiaoDiem %d\n", soLuongGiaoDiem );
      // ==== thời gian bặt đầu tính
      time_t thoiGianBatDau;
      time(&thoiGianBatDau);
      
      // ==== vẽ ảnh (kết xuất)
      if( phimTruong.mayQuayPhim.kieuChieu == kKIEU_CHIEU__PHOI_CANH )
         veAnhChieuPhoiCanh( &anh, &phimTruong, mangGiaoDiem, soLuongGiaoDiem );
      else if( phimTruong.mayQuayPhim.kieuChieu == kKIEU_CHIEU__CU_TUYEN )
         veAnhChieuCuTuyen( &anh, &phimTruong, mangGiaoDiem, soLuongGiaoDiem );
      else if( phimTruong.mayQuayPhim.kieuChieu == kKIEU_CHIEU__TOAN_CANH )
         veAnhChieuToanCanh( &anh, &phimTruong, mangGiaoDiem, soLuongGiaoDiem );
      
      // ==== thời gian xong
      time_t thoiGianHienTai;
      time(&thoiGianHienTai);
      time_t thoiGianKetXuat = thoiGianHienTai - thoiGianBatDau;
      struct tm *hienTai = localtime( &thoiGianHienTai );
      
      // ---- lưu ảnh
      luuAnhEXR_ZIP( tenAnh, &anh, kKIEU_HALF, (unsigned short)thoiGianKetXuat );
      
      // ---- báo số ảnh đã lưu xong và thời gian

      printf( "-->> %s <<--  %ld giây (%5.2f phút) %d/%d    %d.%02d.%02d  %02d:%02d:%02d\n", tenAnh, thoiGianKetXuat, (float)thoiGianKetXuat/60.0f,
             phimTruong.soHoatHinhDau, phimTruong.soHoatHinhCuoi, 1900 + hienTai->tm_year, hienTai->tm_mon+1, hienTai->tm_mday, hienTai->tm_hour, hienTai->tm_min, hienTai->tm_sec );
      
      // ---- số hoạt hình hiện tại
      phimTruong.soHoatHinhHienTai++;
   }
   // ---- in ra hết thời gian
   time_t thoiGianKetThucToanCau;
   time(&thoiGianKetThucToanCau);
   printf( "Hết thời gian: %ld giây (%5.2f phút)\n", thoiGianKetThucToanCau - thoiGianBatDauToanCau, (float)(thoiGianKetThucToanCau - thoiGianBatDauToanCau)/60.0f );
   
   // ---- xóa danh sách vật thể
   huyDanhSachVatThe( phimTruong.danhSachVatThe, phimTruong.soLuongVatThe );
   
   // ---- xong công việc, xóa ảnh
   xoaAnh( &anh );
   printf( "Cỡ kích các ảnh: %d %d\n", beRongAnh, beCaoAnh );
   return 1;
}

#pragma mark ---- Vẽ Ảnh
void veAnhChieuPhoiCanh( Anh *anh, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem ) {
   
   MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);
   // ---- góc tia là vị trí máy quay phim
   Tia tia;
   tia.goc.x = mayQuayPhim->viTri.x;
   tia.goc.y = mayQuayPhim->viTri.y;
   tia.goc.z = mayQuayPhim->viTri.z;
   
   //   printf( "Tia %5.3f %5.3f %5.3f\n", tia.goc.x, tia.goc.y, tia.goc.z );
   unsigned short beRong = anh->beRong;
   unsigned short beCao = anh->beCao;
   
   //   printf( "Tia %5.3f %5.3f %5.3f\n", gocX, gocY, gocZ );
   // ---- tính vectơ hướng lên (dộc)
   Vecto huongDoc;  // hướng dọc
   huongDoc.x = mayQuayPhim->xoay[4];
   huongDoc.y = mayQuayPhim->xoay[5];
   huongDoc.z = mayQuayPhim->xoay[6];
   donViHoa( &huongDoc );
   
   Vecto huongNgang;  // hướng ngang
   huongNgang.x = -mayQuayPhim->xoay[0];
   huongNgang.y = -mayQuayPhim->xoay[1];
   huongNgang.z = -mayQuayPhim->xoay[2];
   donViHoa( &huongNgang );
   //   printf( "huongNgang %5.3f %5.3f %5.3f\n", huongNgang.x, huongNgang.y, huongNgang.z );
   //   printf( "huongDoc %5.3f %5.3f %5.3f\n\n", huongDoc.x, huongDoc.y, huongDoc.z );
   
   // ---- tính vectơ cho bước ngang
   Vecto buocNgang;
   buocNgang.x = huongNgang.x*anh->coKichDiemAnh;
   buocNgang.y = huongNgang.y*anh->coKichDiemAnh;
   buocNgang.z = huongNgang.z*anh->coKichDiemAnh;
   
   // ---- tính vectơ cho bước lên (dộc)
   Vecto buocDoc;  // bước dọc
   buocDoc.x = huongDoc.x*anh->coKichDiemAnh;
   buocDoc.y = huongDoc.y*anh->coKichDiemAnh;
   buocDoc.z = huongDoc.z*anh->coKichDiemAnh;
   //   printf( "buocgNgang %5.3f %5.3f %5.3f\n", buocNgang.x, buocNgang.y, buocNgang.z );
   //   printf( "buocDoc %5.3f %5.3f %5.3f\n\n", buocDoc.x, buocDoc.y, buocDoc.z );
   
   // ---- tính điểm góc ảnh (trái dưới)
   float gocX = -(beCao >> 1)*buocDoc.x -(beRong >> 1)*buocNgang.x + tia.goc.x + mayQuayPhim->cachManChieu*mayQuayPhim->xoay[8];
   float gocY = -(beCao >> 1)*buocDoc.y -(beRong >> 1)*buocNgang.y + tia.goc.y + mayQuayPhim->cachManChieu*mayQuayPhim->xoay[9];
   float gocZ = -(beCao >> 1)*buocDoc.z -(beRong >> 1)*buocNgang.z + tia.goc.z + mayQuayPhim->cachManChieu*mayQuayPhim->xoay[10];
   //   printf( "goc anh %5.3f %5.3f %5.3f\n", gocX, gocY, gocZ );
   //   printf( "tia.goc %5.3f %5.3f %5.3f\n", tia.goc.x, tia.goc.y, tia.goc.z );
   //   exit(0);
   unsigned long int chiSoAnh = 0;
   unsigned long int chiSoAnhCuoi = beRong*beCao;   // cho biết đang kết xuất ảnh bao nhiêu
   
   unsigned short hang = 0;
   while( hang < beCao ) {
      
      // ---- cho biết khi đến hàng mới
      printf( "hàng %4d/%d (%d‰)   ảnh %d/%d  PT %d\n", hang, beCao, hang*1000/beCao, phimTruong->soHoatHinhHienTai, phimTruong->soHoatHinhCuoi, phimTruong->soPhimTruong );
      
      // ---- tính hướng cho tia của điểm ảnh này
      tia.huong.x = gocX + buocDoc.x*hang - tia.goc.x;
      tia.huong.y = gocY + buocDoc.y*hang - tia.goc.y;
      tia.huong.z = gocZ + buocDoc.z*hang - tia.goc.z;
      
      unsigned short cot = 0;
      while( cot < beRong ) {
 //        printf( "\ncot %d ", cot );
         Mau mauDoTia = doTia( &tia, phimTruong, mangGiaoDiem, chiSoGiaoDiem, 0 );
         Mau mauBauTroi = hoaTietBauTroi( tia.huong, &(phimTruong->hoaTietBauTroi) );
         Mau mauCoSuongMu = toSuongMu( &(tia.huong), &mauDoTia, &mauBauTroi );
         
         // ---- giữ điểm ảnh kết xuất
         anh->kenhDo[chiSoAnh] = mauCoSuongMu.d;
         anh->kenhLuc[chiSoAnh] = mauCoSuongMu.l;
         anh->kenhXanh[chiSoAnh] = mauCoSuongMu.x;
         anh->kenhDuc[chiSoAnh] = mauDoTia.dd;
         
         chiSoAnh++;
         
         // ---- hướng tia tiếp
         tia.huong.x += buocNgang.x;
         tia.huong.y += buocNgang.y;
         tia.huong.z += buocNgang.z;
         
         cot++;
      }
//      exit(0);
      hang++;
   }
   
}

void veAnhChieuCuTuyen( Anh *anh, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem ) {
   
   MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);
   
   //   printf( "Tia %5.3f %5.3f %5.3f\n", tia.goc.x, tia.goc.y, tia.goc.z );
   unsigned short beRong = anh->beRong;
   unsigned short beCao = anh->beCao;
   
   //   printf( "Tia %5.3f %5.3f %5.3f\n", gocX, gocY, gocZ );
   // ---- tính vectơ hướng lên (dộc)
   Vecto huongDoc;  // hướng dọc
   huongDoc.x = mayQuayPhim->xoay[4];
   huongDoc.y = mayQuayPhim->xoay[5];
   huongDoc.z = mayQuayPhim->xoay[6];
   donViHoa( &huongDoc );
   
   Vecto huongNgang;  // hướng ngang
   huongNgang.x = -mayQuayPhim->xoay[0];
   huongNgang.y = -mayQuayPhim->xoay[1];
   huongNgang.z = -mayQuayPhim->xoay[2];
   donViHoa( &huongNgang );
   //   printf( "huongNgang %5.3f %5.3f %5.3f\n", huongNgang.x, huongNgang.y, huongNgang.z );
   //   printf( "huongDoc %5.3f %5.3f %5.3f\n\n", huongDoc.x, huongDoc.y, huongDoc.z );
   
   // ---- tính vectơ cho bước ngang
   Vecto buocNgang;
   buocNgang.x = huongNgang.x*anh->coKichDiemAnh;
   buocNgang.y = huongNgang.y*anh->coKichDiemAnh;
   buocNgang.z = huongNgang.z*anh->coKichDiemAnh;
   
   // ---- tính vectơ cho bước lên (dộc)
   Vecto buocDoc;  // bước dọc
   buocDoc.x = huongDoc.x*anh->coKichDiemAnh;
   buocDoc.y = huongDoc.y*anh->coKichDiemAnh;
   buocDoc.z = huongDoc.z*anh->coKichDiemAnh;
   //      printf( "buocgNgang %5.3f %5.3f %5.3f\n", buocNgang.x, buocNgang.y, buocNgang.z );
   //      printf( "buocDoc %5.3f %5.3f %5.3f\n\n", buocDoc.x, buocDoc.y, buocDoc.z );
   
   // ---- tính điểm góc ảnh (trái dưới)
   float gocX = -(beCao >> 1)*buocDoc.x -(beRong >> 1)*buocNgang.x + mayQuayPhim->viTri.x;
   float gocY = -(beCao >> 1)*buocDoc.y -(beRong >> 1)*buocNgang.y + mayQuayPhim->viTri.y;
   float gocZ = -(beCao >> 1)*buocDoc.z -(beRong >> 1)*buocNgang.z + mayQuayPhim->viTri.z;
   //      printf( "goc anh %5.3f %5.3f %5.3f\n", gocX, gocY, gocZ );
   // ---- tính hướng cho tia
   Tia tia;
   tia.huong.x = mayQuayPhim->xoay[8];
   tia.huong.y = mayQuayPhim->xoay[9];
   tia.huong.z = mayQuayPhim->xoay[10];
   //   printf( "tia.huong %5.3f %5.3f %5.3f\n", tia.huong.x, tia.huong.y, tia.huong.z );
   //  exit(0);
   
   unsigned int chiSoAnh = 0;
   unsigned int chiSoAnhCuoi = beRong*beCao;  // cho biết đang kết xuất ảnh bao nhiêu
   
   unsigned short hang = 0;
   while( hang < beCao ) {
      
      // ---- cho biết khi đến hàng mới
      printf( "hàng %4d/%d (%d‰)   ảnh %d/%d  PT %d\n", hang, beCao, hang*1000/beCao, phimTruong->soHoatHinhHienTai, phimTruong->soHoatHinhCuoi, phimTruong->soPhimTruong );
      
      // ---- tính hướng cho tia của điểm ảnh này
      tia.goc.x = gocX + buocDoc.x*hang;
      tia.goc.y = gocY + buocDoc.y*hang;
      tia.goc.z = gocZ + buocDoc.z*hang;
      
      unsigned short cot = 0;
      while( cot < beRong ) {
         Mau mauDoTia = doTia( &tia, phimTruong, mangGiaoDiem, chiSoGiaoDiem, 0 );
         Mau mauBauTroi = hoaTietBauTroi( tia.huong, &(phimTruong->hoaTietBauTroi) );
         Mau mauCoSuongMu = toSuongMu( &(tia.huong), &mauDoTia, &mauBauTroi );
         
         // ---- giữ điểm ảnh kết xuất
         anh->kenhDo[chiSoAnh] = mauCoSuongMu.d;
         anh->kenhLuc[chiSoAnh] = mauCoSuongMu.l;
         anh->kenhXanh[chiSoAnh] = mauCoSuongMu.x;
         anh->kenhDuc[chiSoAnh] = 1.0f;//mauDoTia.dd;
         chiSoAnh++;
         
         // ---- hướng tia tiếp
         tia.goc.x += buocNgang.x;
         tia.goc.y += buocNgang.y;
         tia.goc.z += buocNgang.z;
         
         cot++;
      }
      
      hang++;
   }
   
}

void veAnhChieuToanCanh( Anh *anh, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem ) {
   
   MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);
   // ---- góc tia là vị trí máy quay phim
   Tia tia;
   tia.goc.x = mayQuayPhim->viTri.x;
   tia.goc.y = mayQuayPhim->viTri.y;
   tia.goc.z = mayQuayPhim->viTri.z;
   
//   printf( "ToanCanh: Tia %5.3f %5.3f %5.3f\n", tia.goc.x, tia.goc.y, tia.goc.z );
   unsigned short beRong = anh->beRong;
   unsigned short beCao = anh->beCao;

   // ---- tính vectơ hướng lên (dộc)
   Vecto huongDoc;  // hướng dọc
   huongDoc.x = mayQuayPhim->xoay[4];
   huongDoc.y = mayQuayPhim->xoay[5];
   huongDoc.z = mayQuayPhim->xoay[6];
   donViHoa( &huongDoc );
   
   Vecto huongNgang;  // hướng ngang
   huongNgang.x = -mayQuayPhim->xoay[0];
   huongNgang.y = -mayQuayPhim->xoay[1];
   huongNgang.z = -mayQuayPhim->xoay[2];
   donViHoa( &huongNgang );
   
//   printf( "huongNgang %5.3f %5.3f %5.3f\n", huongNgang.x, huongNgang.y, huongNgang.z );
//   printf( "huongDoc %5.3f %5.3f %5.3f\n\n", huongDoc.x, huongDoc.y, huongDoc.z );

   // ---- vecto nhìn (trái dưới)
   Vecto huongMayQuayPhimNhin;
   huongMayQuayPhimNhin.x = mayQuayPhim->xoay[8];
   huongMayQuayPhimNhin.y = mayQuayPhim->xoay[9];
   huongMayQuayPhimNhin.z = mayQuayPhim->xoay[10];
   
   // ---- tính góc (rad)
   float gocNgang = (beRong >> 1)*anh->coKichDiemAnh;
   float gocDoc = -(beCao >> 1)*anh->coKichDiemAnh;
   
   float gocXoayDoc = gocDoc;
   //   printf( "goc anh %5.3f %5.3f %5.3f\n", gocX, gocY, gocZ );
   //   printf( "tia.goc %5.3f %5.3f %5.3f\n", tia.goc.x, tia.goc.y, tia.goc.z );
   //   exit(0);
   unsigned int chiSoAnh = 0;
   unsigned int chiSoAnhCuoi = beRong*beCao;   // cho biết đang kết xuất ảnh bao nhiêu
   
   unsigned short hang = 0;
   while( hang < beCao ) {
      
      // ---- cho biết khi đến hàng mới
      printf( "hàng %4d/%d (%d‰)   ảnh %d/%d  PT %d)\n", hang, beCao, hang*1000/beCao, phimTruong->soHoatHinhHienTai, phimTruong->soHoatHinhCuoi, phimTruong->soPhimTruong );
      
      float gocXoayNgang = gocNgang;
      Vecto xoayDoc = xoayVectoQuanhTruc( &huongMayQuayPhimNhin, &huongNgang, gocXoayDoc );
      //      printf( "tia.goc %5.3f %5.3f %5.3f\n", xoayDoc.x, xoayDoc.y, xoayDoc.z );
      //      exit(0);
      unsigned short cot = 0;
      while( cot < beRong ) {
//         printf( "======= cot %d  hang %d\n", cot, hang );
         
         tia.huong = xoayVectoQuanhTruc( &xoayDoc, &huongDoc, gocXoayNgang );
         
         Mau mauDoTia = doTia( &tia, phimTruong, mangGiaoDiem, chiSoGiaoDiem, 0 );
         Mau mauBauTroi = hoaTietBauTroi( tia.huong, &(phimTruong->hoaTietBauTroi) );
         Mau mauCoSuongMu = toSuongMu( &(tia.huong), &mauDoTia, &mauBauTroi );
         
         // ---- giữ điểm ảnh kết xuất
         anh->kenhDo[chiSoAnh] = mauCoSuongMu.d;
         anh->kenhLuc[chiSoAnh] = mauCoSuongMu.l;
         anh->kenhXanh[chiSoAnh] = mauCoSuongMu.x;
         anh->kenhDuc[chiSoAnh] = 1.0f;//mauDoTia.dd;
         
         chiSoAnh++;
         
         // ---- hướng tia tiếp
         gocXoayNgang -= anh->coKichDiemAnh;
         
         cot++;
      }
      gocXoayDoc += anh->coKichDiemAnh;
      hang++;
   }
   
}

/*void veAnhChatLuongCao( Anh *anh, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem ) {
 
 MayQuayPhim *mayQuayPhim = &(phimTruong->mayQuayPhim);
 Tia tia;
 tia.goc.x = mayQuayPhim->viTri.x;
 tia.goc.y = mayQuayPhim->viTri.y;
 tia.goc.z = mayQuayPhim->viTri.z;
 
 //   printf( "Tia %5.3f %5.3f %5.3f\n", tia.goc.x, tia.goc.y, tia.goc.z );
 unsigned short beRong = anh->beRong;
 unsigned short beCao = anh->beCao;
 
 //   printf( "Tia %5.3f %5.3f %5.3f\n", gocX, gocY, gocZ );
 // ---- tính vectơ hướng lên (dộc)
 Vecto huongDoc;  // hướng dọc
 huongDoc.x = mayQuayPhim->xoay[4];
 huongDoc.y = mayQuayPhim->xoay[5];
 huongDoc.z = mayQuayPhim->xoay[6];
 donViHoa( &huongDoc );
 
 Vecto huongNgang;  // hướng ngang
 huongNgang.x = -mayQuayPhim->xoay[0];
 huongNgang.y = -mayQuayPhim->xoay[1];
 huongNgang.z = -mayQuayPhim->xoay[2];
 donViHoa( &huongNgang );
 //   printf( "huongNgang %5.3f %5.3f %5.3f\n", huongNgang.x, huongNgang.y, huongNgang.z );
 //   printf( "huongDoc %5.3f %5.3f %5.3f\n\n", huongDoc.x, huongDoc.y, huongDoc.z );
 
 // ---- tính vectơ cho bước ngang
 Vecto buocNgang;
 buocNgang.x = huongNgang.x*anh->coKichDiemAnh;
 buocNgang.y = huongNgang.y*anh->coKichDiemAnh;
 buocNgang.z = huongNgang.z*anh->coKichDiemAnh;
 Vecto buocNgang_25;
 buocNgang_25.x = buocNgang.x*0.25f;
 buocNgang_25.y = buocNgang.y*0.25f;
 buocNgang_25.z = buocNgang.z*0.25f;
 
 // ---- tính vectơ cho bước lên (dộc)
 Vecto buocDoc;  // bước dọc
 buocDoc.x = huongDoc.x*anh->coKichDiemAnh;
 buocDoc.y = huongDoc.y*anh->coKichDiemAnh;
 buocDoc.z = huongDoc.z*anh->coKichDiemAnh;
 Vecto buocDoc_25;
 buocDoc_25.x = buocDoc.x*0.25f;
 buocDoc_25.y = buocDoc.y*0.25f;
 buocDoc_25.z = buocDoc.z*0.25f;
 //   printf( "buocgNgang %5.3f %5.3f %5.3f\n", buocNgang.x, buocNgang.y, buocNgang.z );
 //   printf( "buocDoc %5.3f %5.3f %5.3f\n\n", buocDoc.x, buocDoc.y, buocDoc.z );
 
 // ---- tính điểm góc ảnh (trái dưới)
 float gocX = -(beCao >> 1)*buocDoc.x -(beRong >> 1)*buocNgang.x + tia.goc.x + mayQuayPhim->cachManChieu*mayQuayPhim->xoay[8];
 float gocY = -(beCao >> 1)*buocDoc.y -(beRong >> 1)*buocNgang.y + tia.goc.y + mayQuayPhim->cachManChieu*mayQuayPhim->xoay[9];
 float gocZ = -(beCao >> 1)*buocDoc.z -(beRong >> 1)*buocNgang.z + tia.goc.z + mayQuayPhim->cachManChieu*mayQuayPhim->xoay[10];
 //   printf( "goc anh %5.3f %5.3f %5.3f\n", gocX, gocY, gocZ );
 //   printf( "tia.goc %5.3f %5.3f %5.3f\n", tia.goc.x, tia.goc.y, tia.goc.z );
 //   exit(0);
 unsigned int chiSoAnh = 0;
 
 unsigned short hang = 0;
 while( hang < beCao ) {
 
 // ---- tính hướng cho tia của điểm ảnh này
 tia.huong.x = gocX + buocDoc.x*hang - tia.goc.x;
 tia.huong.y = gocY + buocDoc.y*hang - tia.goc.y;
 tia.huong.z = gocZ + buocDoc.z*hang - tia.goc.z;
 
 unsigned short cot = 0;
 while( cot < beRong ) {
 
 Tia tiaPhu;
 tiaPhu.goc = tia.goc;
 // -----
 tiaPhu.huong.x = tia.huong.x - 0.25f*buocNgang.x - 0.25f*buocDoc.x;
 tiaPhu.huong.y = tia.huong.y - 0.25f*buocNgang.y - 0.25f*buocDoc.y;
 tiaPhu.huong.z = tia.huong.z - 0.25f*buocNgang.z - 0.25f*buocDoc.z;
 Mau mauDoTia = doTia( &tiaPhu, phimTruong, mangGiaoDiem, 0 );
 Mau mauBauTroi = hoaTietBauTroi( tiaPhu.huong, &(phimTruong->hoaTietBauTroi) );
 Mau mauCoSuongMu0 = toSuongMu( &(tiaPhu.huong), &mauDoTia, &mauBauTroi );
 
 // ----
 tiaPhu.huong.x = tia.huong.x + 0.25f*buocNgang.x - 0.25f*buocDoc.x;
 tiaPhu.huong.y = tia.huong.y + 0.25f*buocNgang.y - 0.25f*buocDoc.y;
 tiaPhu.huong.z = tia.huong.z + 0.25f*buocNgang.z - 0.25f*buocDoc.z;
 mauDoTia = doTia( &tiaPhu, phimTruong, mangGiaoDiem, 0 );
 mauBauTroi = hoaTietBauTroi( tiaPhu.huong, &(phimTruong->hoaTietBauTroi) );
 Mau mauCoSuongMu1 = toSuongMu( &(tiaPhu.huong), &mauDoTia, &mauBauTroi );
 
 // ----
 tiaPhu.huong.x = tia.huong.x + 0.25f*buocNgang.x - 0.25f*buocDoc.x;
 tiaPhu.huong.y = tia.huong.y + 0.25f*buocNgang.y - 0.25f*buocDoc.y;
 tiaPhu.huong.z = tia.huong.z + 0.25f*buocNgang.z - 0.25f*buocDoc.z;
 mauDoTia = doTia( &tiaPhu, phimTruong, mangGiaoDiem, 0 );
 mauBauTroi = hoaTietBauTroi( tiaPhu.huong, &(phimTruong->hoaTietBauTroi) );
 Mau mauCoSuongMu2 = toSuongMu( &(tiaPhu.huong), &mauDoTia, &mauBauTroi );
 
 // ----
 tiaPhu.huong.x = tia.huong.x + 0.25f*buocNgang.x + 0.25f*buocDoc.x;
 tiaPhu.huong.y = tia.huong.y + 0.25f*buocNgang.y + 0.25f*buocDoc.y;
 tiaPhu.huong.z = tia.huong.z + 0.25f*buocNgang.z + 0.25f*buocDoc.z;
 mauDoTia = doTia( &tiaPhu, phimTruong, mangGiaoDiem, 0 );
 mauBauTroi = hoaTietBauTroi( tiaPhu.huong, &(phimTruong->hoaTietBauTroi) );
 Mau mauCoSuongMu3 = toSuongMu( &(tiaPhu.huong), &mauDoTia, &mauBauTroi );
 
 // ---- giữ điểm ảnh kết xuất
 anh->kenhDo[chiSoAnh] = 0.25f*(mauCoSuongMu0.d + mauCoSuongMu1.d + mauCoSuongMu2.d + mauCoSuongMu3.d);
 anh->kenhLuc[chiSoAnh] = 0.25f*(mauCoSuongMu0.l + mauCoSuongMu1.l + mauCoSuongMu2.l + mauCoSuongMu3.l);
 anh->kenhXanh[chiSoAnh] = 0.25f*(mauCoSuongMu0.x + mauCoSuongMu1.x + mauCoSuongMu2.x + mauCoSuongMu3.x);
 anh->kenhDuc[chiSoAnh] = 1.0f;//mauDoTia.dd;
 
 chiSoAnh++;
 
 // ---- hướng tia tiếp
 tia.huong.x += buocNgang.x;
 tia.huong.y += buocNgang.y;
 tia.huong.z += buocNgang.z;
 
 cot++;
 }
 
 hang++;
 }
 }*/


#define kSO_LUONG__VAT_THE_BONG_TOI_DA 16

Mau doTia( Tia *tia, PhimTruong *phimTruong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem, unsigned short soNhoi ) {
   
   Mau mau;
   mau.d = 0.0f;
   mau.l = 0.0f;
   mau.x = 0.0f;
   mau.dd = 1.0f;
   mau.c = kVO_CUC;
   
   float cachXaGanNhat = kVO_CUC;   // ---- đặt cáchXaGầnNhất = kVÔ_HẠN
   
   //   Vecto phapTuyenGanNhat;
   //   phapTuyenGanNhat.x = 0.0f;
   //   phapTuyenGanNhat.y = 0.0f;
   //   phapTuyenGanNhat.z = 0.0f;
   
   // ==== xem nếu tia có trúng vật thể nào
   unsigned short chiSoVat = 0; // chỉ số vật thể
   ThongTinToMau thongTinToMauVatTheGanNhat;
   thongTinToMauVatTheGanNhat.vatThe = NULL;  // chưa có vật thể gần nhất
   
   xemTiaCoTrungVatTheGanNhat( mangGiaoDiem, chiSoGiaoDiem, phimTruong->danhSachVatThe, phimTruong->mangChiSoVatTheSapXep, tia, &thongTinToMauVatTheGanNhat );
   
   // ==== tính màu
   if( thongTinToMauVatTheGanNhat.vatThe != NULL ) {  // tô màu
      
      donViHoa( &(thongTinToMauVatTheGanNhat.phapTuyenTDVT) );
      // ---- điểm trúng (tọa độ thế giới)
      Vecto diemTrung;
      diemTrung.x = tia->goc.x + thongTinToMauVatTheGanNhat.cachXa*tia->huong.x;
      diemTrung.y = tia->goc.y + thongTinToMauVatTheGanNhat.cachXa*tia->huong.y;
      diemTrung.z = tia->goc.z + thongTinToMauVatTheGanNhat.cachXa*tia->huong.z;
      
      // ---- tính cách xa
      if( soNhoi == 0 ) {
         // ---- tính điểm trúng tương đối với máy quay phim
         Vecto viTriMayQuayPhim = phimTruong->mayQuayPhim.viTri;
         Vecto diemTrungTuongDoi;
         diemTrungTuongDoi.x = diemTrung.x - viTriMayQuayPhim.x;
         diemTrungTuongDoi.y = diemTrung.y - viTriMayQuayPhim.y;
         diemTrungTuongDoi.z = diemTrung.z - viTriMayQuayPhim.z;
         //         printf( "doTia: %5.3f %5.3f %5.3f\n", diemTrungTuongDoi.x, diemTrungTuongDoi.y, diemTrungTuongDoi.z );
         mau.c = sqrtf( diemTrungTuongDoi.x*diemTrungTuongDoi.x + diemTrungTuongDoi.y*diemTrungTuongDoi.y + diemTrungTuongDoi.z*diemTrungTuongDoi.z );
      }
      
      // ---- điểm trúng cho nguồn ánh sáng gần nhất. Cần cộng thêm pháp tuyến môt chút cho chắc chắn ở ngoài vật thể
      Vecto diemTrungChoThayNAS; // điểm trúng cho thấy nguồn ánh sáng
      diemTrungChoThayNAS.x = diemTrung.x + 0.005f*thongTinToMauVatTheGanNhat.phapTuyenTDVT.x;
      diemTrungChoThayNAS.y = diemTrung.y + 0.005f*thongTinToMauVatTheGanNhat.phapTuyenTDVT.y;
      diemTrungChoThayNAS.z = diemTrung.z + 0.005f*thongTinToMauVatTheGanNhat.phapTuyenTDVT.z;
      
      //      printf( "diemTrungChoThayNAS %5.3f %5.3f %5.3f\n", diemTrungChoThayNAS.x, diemTrungChoThayNAS.y, diemTrungChoThayNAS.z );
      // ---- xem nếu được thấy nguồn ánh sáng cho bóng tối (chỉ có mặt trời cách xa vô cực)
      ThongTinToMau thongTinToMauBong[kSO_LUONG__VAT_THE_BONG_TOI_DA];
      unsigned char soLuongVatTheBongToi = 0;
      unsigned char thay = thayNguonAnhSang( phimTruong->danhSachVatThe, phimTruong->mangChiSoVatTheSapXep, phimTruong->soLuongVatThe, &diemTrungChoThayNAS, &(phimTruong->matTroi.huongAnh), thongTinToMauBong, &soLuongVatTheBongToi,mangGiaoDiem, chiSoGiaoDiem );
      
      // ---- tính màu nguồn ánh sáng
      Mau mauNguonAnhSang;
      if( thay ) {
         mauNguonAnhSang.d = phimTruong->matTroi.mauAnh.d;
         mauNguonAnhSang.l = phimTruong->matTroi.mauAnh.l;
         mauNguonAnhSang.x = phimTruong->matTroi.mauAnh.x;
         mauNguonAnhSang.dd = phimTruong->matTroi.mauAnh.dd;
      }
      else {
         //         printf( "soLuongVatTheBongToi %d\n", soLuongVatTheBongToi );
         // ---- tịnh độ đục từ hết vật thể
         float duc = 0.0f;
         unsigned char soVatTheBongToi = 0;
         while( soVatTheBongToi < soLuongVatTheBongToi ) {
            //         printf("thongTinToMauBong loaiVatThe %d\n", thongTinToMauBong.vatThe->loai );
            // ---- tìm đục vật thể
            Vecto toaDoHoaTiet = nhanVectoVoiMaTran3x3( &(thongTinToMauBong[soVatTheBongToi].diemTrungTDVT), thongTinToMauBong[soVatTheBongToi].vatThe->phongTo ); // <---- TẠI SAO .phongTo??? phóng to họa tiết
            // toMauVat( VatThe *vatThe, Vecto *diemTrungTDVT, Vecto phapTuyen, Vecto huongTia )
            Mau mauVat = toMauVat( thongTinToMauBong[soVatTheBongToi].vatThe, &toaDoHoaTiet, thongTinToMauBong[soVatTheBongToi].phapTuyenTDVT, phimTruong->matTroi.huongAnh );
            //            printf( "mauVat.dd %5.3f  duc %5.3f\n", mauVat.dd, duc );
            if( mauVat.dd > duc )
               duc = mauVat.dd;
            soVatTheBongToi++;
         }
         /*        if( (mauVat.dd < 0.0f) || (mauVat.dd > 1.0f) ) {
          printf( "doTia: thongTinToMau.phapTuyen %5.3f %5.3f %5.3f\n", thongTinToMauBong.phapTuyenTDVT.x, thongTinToMauBong.phapTuyenTDVT.y, thongTinToMauBong.phapTuyenTDVT.z );
          printf( "doTia: thongTinToMauBong.vatThe %d  mauVat.dd %5.3f\n", thongTinToMauBong.vatThe->loai, mauVat.dd );
          exit(0);
          }*/
         
         // ---- vật thể đục
         if( duc == 1.0f ) {
            mauNguonAnhSang.d = 0.1f;  // màu ánh sánh phản xạ từ môi trường
            mauNguonAnhSang.l = 0.1f;
            mauNguonAnhSang.x = 0.2f;
            mauNguonAnhSang.dd = 1.0f;
         }
         else {
            float nghichDuc = 1.0f - duc;
            
            mauNguonAnhSang.d = 0.1f + 0.9f*(phimTruong->matTroi.mauAnh.d*nghichDuc);
            mauNguonAnhSang.l = 0.1f + 0.9f*(phimTruong->matTroi.mauAnh.l*nghichDuc);
            mauNguonAnhSang.x = 0.2f + 0.8f*(phimTruong->matTroi.mauAnh.x*nghichDuc);
            mauNguonAnhSang.dd = 1.0f;
         }
         
      }
      
      // ---- kiếm màu cho vật thể
      Vecto toaDoHoaTiet = nhanVectoVoiMaTran3x3( &(thongTinToMauVatTheGanNhat.diemTrungTDVT), thongTinToMauVatTheGanNhat.vatThe->phongTo ); // <---- TẠI SAO .phongTo???
      
      Mau mauVat = toMauVat( thongTinToMauVatTheGanNhat.vatThe, &toaDoHoaTiet, thongTinToMauVatTheGanNhat.phapTuyenTDVT, tia->huong );
      Mau mauTanXa = tinhMauTanXa( &mauNguonAnhSang, &mauVat, &(phimTruong->matTroi.huongAnh), &(thongTinToMauVatTheGanNhat.phapTuyenTDVT) );
      
      if( soNhoi + 1 < phimTruong->soNhoiToiDa ) {   // dưới giới hạn nhồi chưa
         float tiSoPhanXa = mauVat.p;
         float doDuc = mauVat.dd;
         
         Mau mauPhanXa;
         Mau mauCaoQuang;
         if( tiSoPhanXa ) {
            // ---- tia phản xạ
            Tia tiaPhanXa = tinhTiaPhanXa( thongTinToMauVatTheGanNhat.phapTuyenTDVT, diemTrung, tia->huong );
            mauPhanXa = doTia( &tiaPhanXa, phimTruong, mangGiaoDiem, chiSoGiaoDiem, soNhoi + 1 );
            // ---- tính màu cao quang
            if( thay || (mauVat.dd < 1.0f) ) {
               mauCaoQuang = tinhCaoQuang( &(phimTruong->matTroi), &(tiaPhanXa.huong), 250.0f*tiSoPhanXa );
               float chinh = sqrtf(tiSoPhanXa);
               mauCaoQuang.d *= chinh;  // màu ánh sánh phản xạ từ môi trường
               mauCaoQuang.l *= chinh;
               mauCaoQuang.x *= chinh;
               //  mauCaoQuang.dd = 1.0f;
            }
            else {
               mauCaoQuang.d = 0.0f;  // màu ánh sánh phản xạ từ môi trường
               mauCaoQuang.l = 0.0f;
               mauCaoQuang.x = 0.0f;
               mauCaoQuang.dd = 1.0f;
            }
         }
         else {
            mauPhanXa.d = 0.0f;
            mauPhanXa.l = 0.0f;
            mauPhanXa.x = 0.0f;
            mauPhanXa.dd = 0.0f;
            mauCaoQuang.d = 0.0f;
            mauCaoQuang.l = 0.0f;
            mauCaoQuang.x = 0.0f;
            mauCaoQuang.dd = 0.0f;
         }
         
         Mau mauKhucXa;
         // ---- khúc xạ
         if( doDuc < 1.0f ) {
            // ---- tia khúc xạ
            Tia tiaKhucXa = tinhTiaKhucXa( thongTinToMauVatTheGanNhat.phapTuyenTDVT, diemTrung, tia->huong, thongTinToMauVatTheGanNhat.vatThe->chietSuat );
            mauKhucXa = doTia( &tiaKhucXa, phimTruong, mangGiaoDiem, chiSoGiaoDiem, soNhoi + 1 );
         }
         else {
            mauKhucXa.d = 0.0f;
            mauKhucXa.l = 0.0f;
            mauKhucXa.x = 0.0f;
            mauKhucXa.dd = 0.0f;
         }
         
         // ---- gồm màu
         if( doDuc == 1.0f ) {
            if( tiSoPhanXa == 0.0f ) {
               mau.d = mauTanXa.d;
               mau.l = mauTanXa.l;
               mau.x = mauTanXa.x;
               mau.dd = mauTanXa.dd;
            }
            else {
               float nghichTiSoPhanXa = 1.0f - tiSoPhanXa;
               mau.d = nghichTiSoPhanXa*mauTanXa.d + tiSoPhanXa*mauPhanXa.d + mauCaoQuang.d;
               mau.l = nghichTiSoPhanXa*mauTanXa.l + tiSoPhanXa*mauPhanXa.l + mauCaoQuang.l;
               mau.x = nghichTiSoPhanXa*mauTanXa.x + tiSoPhanXa*mauPhanXa.x + mauCaoQuang.x;
               mau.dd = nghichTiSoPhanXa*mauTanXa.dd + tiSoPhanXa*mauPhanXa.dd + mauCaoQuang.dd;
            }
         }
         else {
            float nghichDoDuc = 1.0f - doDuc;
            if( tiSoPhanXa == 0.0f ) {
               mau.d = doDuc*mauTanXa.d + nghichDoDuc*mauKhucXa.d;
               mau.l = doDuc*mauTanXa.l + nghichDoDuc*mauKhucXa.l;
               mau.x = doDuc*mauTanXa.x + nghichDoDuc*mauKhucXa.x;
               mau.dd = doDuc*mauTanXa.dd + nghichDoDuc*mauKhucXa.dd;
            }
            else {
               float nghichTiSoPhanXa = 1.0f - tiSoPhanXa;
               mau.d = nghichTiSoPhanXa*(doDuc*mauTanXa.d + nghichDoDuc*mauKhucXa.d) + tiSoPhanXa*mauPhanXa.d + mauCaoQuang.d;
               mau.l = nghichTiSoPhanXa*(doDuc*mauTanXa.l + nghichDoDuc*mauKhucXa.l) + tiSoPhanXa*mauPhanXa.l + mauCaoQuang.l;
               mau.x = nghichTiSoPhanXa*(doDuc*mauTanXa.x + nghichDoDuc*mauKhucXa.x) + tiSoPhanXa*mauPhanXa.x + mauCaoQuang.x;
               mau.dd = nghichTiSoPhanXa*(doDuc*mauTanXa.dd + nghichDoDuc*mauKhucXa.dd) + tiSoPhanXa*mauPhanXa.dd + mauCaoQuang.dd;
            }
         }
         
      }
      else {  // đến giới hạn rồi, cho màu tán xạ
         // ---- xài màu tán xạ
         mau.d = mauTanXa.d;
         mau.l = mauTanXa.l;
         mau.x = mauTanXa.x;
         mau.dd = mauTanXa.dd;
      }
   }
   else {
      // ---- tính màu bầu trời
      mau = hoaTietBauTroi( tia->huong, &(phimTruong->hoaTietBauTroi) );
      // ---- đặt cách xa
      if( soNhoi == 0 )
         mau.c = kVO_CUC;
   }
   
   return mau;
}
