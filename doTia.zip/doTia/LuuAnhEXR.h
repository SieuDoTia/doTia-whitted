#pragma once
#include "Anh.h"

void luuAnhEXR_ZIP( char *tenTep, Anh *anh, unsigned char kieuDuLieu, unsigned short thoiGianKetXuat );