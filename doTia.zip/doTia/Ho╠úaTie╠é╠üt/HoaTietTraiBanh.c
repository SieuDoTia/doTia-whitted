#include "HoaTietTraiBanh.h"
#include <math.h>


#pragma mark ---- Hoạ Tiết Trái Banh
// tính màu xài tọa độ kinh vĩ tuyến
Mau hoaTietTraiBanh( Vecto *viTri ) {
   
   // ---- tính bán kính
   float banKinh = sqrtf( viTri->x*viTri->x + viTri->z*viTri->z );
   
   // ---- tính kính độ
   float kinhDo = 0.0f;
   if( banKinh != 0.0f )
      kinhDo = atan( viTri->z/viTri->x );
   
   // ---- giữ 0 ≤ kinh độ ≤ 2π
   if( viTri->x < 0.0f )
      kinhDo += 3.141592f;
   else
      if( viTri->z < 0.0f )
         kinhDo += 6.283184f;
   
   // ---- vĩ độ
   float viDo = 0.0f;
   if( banKinh != 0.0f )
      viDo = atan( viTri->y/banKinh );
   
   Mau mauTo;  // 
   // 24 16 24   24 16 24
   if( kinhDo < 1.570796f ) {
      if( viDo < -0.981748f ) {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
      else if( viDo < -0.589049f ) {
         mauTo.d = 0.309803f;
         mauTo.l = 0.294118f;
         mauTo.x = 0.690196f;
      }
      else if( viDo < 0.0f ) {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
      else if( viDo < 0.589049f ) {
         mauTo.d = 0.525490f;
         mauTo.l = 0.000000f;
         mauTo.x = 0.541176f;
      }
      else if( viDo < 0.981748f ) {
         mauTo.d = 0.925490f;
         mauTo.l = 0.827451f;
         mauTo.x = 0.925490f;
      }
      else {
         mauTo.d = 0.525490f;
         mauTo.l = 0.000000f;
         mauTo.x = 0.541176f;
      }
   }
   else if( kinhDo < 3.141592f ) {
      if( viDo < -0.981748f ) {
         mauTo.d = 0.305882f;
         mauTo.l = 0.200000f;
         mauTo.x = 0.450980f;
      }
      else if( viDo < -0.589049f ) {
         mauTo.d = 0.862745f;
         mauTo.l = 0.854902f;
         mauTo.x = 0.925492f;
      }
      else if( viDo < 0.0f ) {
         mauTo.d = 0.305882f;
         mauTo.l = 0.200000f;
         mauTo.x = 0.450980f;
      }
      else if( viDo < 0.589049f ) {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
      else if( viDo < 0.981748f ) {
         mauTo.d = 0.698039f;
         mauTo.l = 0.356863f;
         mauTo.x = 0.698039f;
         mauTo.dd = 1.0f;
      }
      else {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
   }
   else if( kinhDo < 4.712388f ) {
      if( viDo < -0.981748f ) {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
      else if( viDo < -0.589049f ) {
         mauTo.d = 0.674510f;
         mauTo.l = 0.298039f;
         mauTo.x = 0.137255f;
      }
      else if( viDo < 0.0f ) {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
      else if( viDo < 0.5890494f ) {
         mauTo.d = 0.694118f;
         mauTo.l = 0.466667f;
         mauTo.x = 0.000000f;
      }
      else if( viDo < 0.981748f ) {
         mauTo.d = 1.000000f;
         mauTo.l = 0.921569f;
         mauTo.x = 0.878431f;
      }
      else {
         mauTo.d = 0.694118f;
         mauTo.l = 0.466667f;
         mauTo.x = 0.000000f;
      }   }
   else {
      if( viDo < -0.981748f ) {
         mauTo.d = 0.796078f;
         mauTo.l = 0.509804f;
         mauTo.x = 0.000000f;
      }
      else if( viDo < -0.589049f ) {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
      else if( viDo < 0.0f ) {
         mauTo.d = 0.796078f;
         mauTo.l = 0.509804f;
         mauTo.x = 0.000000f;
      }
      else if( viDo < 0.589049f ) {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
      else if( viDo < 0.981748f ) {
         mauTo.d = 0.805882f;
         mauTo.l = 0.352941f;
         mauTo.x = 0.000000f;
      }
      else {
         mauTo.d = 1.0f;
         mauTo.l = 1.0f;
         mauTo.x = 1.0f;
      }
   }
   
   mauTo.dd = 1.0f;
   mauTo.p = 0.05f;

   return mauTo;
}
