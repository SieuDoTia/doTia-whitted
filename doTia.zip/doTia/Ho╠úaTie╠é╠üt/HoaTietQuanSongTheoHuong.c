#include "HoaTietQuanSongTheoHuong.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#pragma mark ---- Họa Tiết Quần Sóng Theo Hướng (vuông góc với hướng)
HoaTietQuanSongTheoHuong datHoaTietQuanSongTheoHuong( Vecto *huongNgang, Vecto *huongDoc, Mau *mauNen, Mau *mauQuan0, Mau *mauQuan1, Mau *mauQuan2, float phanQuan0, float phanQuan1, float phanQuan2, float tanSoNgang, float tanSoToi, float bienDo,
                                                     float dichDoan, float doan ) {

   HoaTietQuanSongTheoHuong hoaTietQuanSongTheoHuong;
   // ---- hướng, hướng ngang và dọc phải vuông góc nhau
   hoaTietQuanSongTheoHuong.huongNgang.x = huongNgang->x;
   hoaTietQuanSongTheoHuong.huongNgang.y = huongNgang->y;
   hoaTietQuanSongTheoHuong.huongNgang.z = huongNgang->z;

   hoaTietQuanSongTheoHuong.huongDoc.x = huongDoc->x;
   hoaTietQuanSongTheoHuong.huongDoc.y = huongDoc->y;
   hoaTietQuanSongTheoHuong.huongDoc.z = huongDoc->z;

   hoaTietQuanSongTheoHuong.huongToi = tichCoHuong( huongNgang, huongDoc );
//   printf( "huongToi %5.3f %5.3f %5.3f\n", hoaTietQuanSongTheoHuong.huongToi.x, hoaTietQuanSongTheoHuong.huongToi.y, hoaTietQuanSongTheoHuong.huongToi.z );
   
   // ---- màu nền
   hoaTietQuanSongTheoHuong.mauNen.d = mauNen->d;
   hoaTietQuanSongTheoHuong.mauNen.l = mauNen->l;
   hoaTietQuanSongTheoHuong.mauNen.x = mauNen->x;
   hoaTietQuanSongTheoHuong.mauNen.dd = mauNen->dd;
   hoaTietQuanSongTheoHuong.mauNen.p = mauNen->p;
   // ---- màu quằn 0
   hoaTietQuanSongTheoHuong.mauQuan0.d = mauQuan0->d;
   hoaTietQuanSongTheoHuong.mauQuan0.l = mauQuan0->l;
   hoaTietQuanSongTheoHuong.mauQuan0.x = mauQuan0->x;
   hoaTietQuanSongTheoHuong.mauQuan0.dd = mauQuan0->dd;
   hoaTietQuanSongTheoHuong.mauQuan0.p = mauQuan0->p;
   // ---- màu quằn 1
   hoaTietQuanSongTheoHuong.mauQuan1.d = mauQuan1->d;
   hoaTietQuanSongTheoHuong.mauQuan1.l = mauQuan1->l;
   hoaTietQuanSongTheoHuong.mauQuan1.x = mauQuan1->x;
   hoaTietQuanSongTheoHuong.mauQuan1.dd = mauQuan1->dd;
   hoaTietQuanSongTheoHuong.mauQuan1.p = mauQuan1->p;
   // ---- màu quằn 1
   hoaTietQuanSongTheoHuong.mauQuan2.d = mauQuan2->d;
   hoaTietQuanSongTheoHuong.mauQuan2.l = mauQuan2->l;
   hoaTietQuanSongTheoHuong.mauQuan2.x = mauQuan2->x;
   hoaTietQuanSongTheoHuong.mauQuan2.dd = mauQuan2->dd;
   hoaTietQuanSongTheoHuong.mauQuan2.p = mauQuan2->p;
   // ---- phân số cho quằn
   hoaTietQuanSongTheoHuong.phanQuan0 = phanQuan0;
   hoaTietQuanSongTheoHuong.phanQuan1 = phanQuan1;
   hoaTietQuanSongTheoHuong.phanQuan2 = phanQuan2;
   // ---- tần số
   hoaTietQuanSongTheoHuong.tanSoNgang = tanSoNgang;
   hoaTietQuanSongTheoHuong.tanSoToi = tanSoToi;
   // ---- biên độ
   hoaTietQuanSongTheoHuong.bienDo = bienDo;
   // ---- dịch xoay
   hoaTietQuanSongTheoHuong.dich = dichDoan;
   // ---- không cho đoạn = 0
   if( doan == 0.0f )
      doan = 1.0f;
   hoaTietQuanSongTheoHuong.doan = doan;
   
   return hoaTietQuanSongTheoHuong;
}

Mau hoaTietQuanSongTheoHuong( Vecto *viTri, HoaTietQuanSongTheoHuong *hoaTietQuanSongTheoHuong ) {

   // ---- đoạn
   float doan = viTri->x*hoaTietQuanSongTheoHuong->huongDoc.x + viTri->y*hoaTietQuanSongTheoHuong->huongDoc.y +
                       viTri->z*hoaTietQuanSongTheoHuong->huongDoc.z;
   
   // ---- hai góc cho sinf()
   float gocNgang = viTri->x*hoaTietQuanSongTheoHuong->huongNgang.x + viTri->y*hoaTietQuanSongTheoHuong->huongNgang.y +
   viTri->z*hoaTietQuanSongTheoHuong->huongNgang.z;
   
   float gocToi = viTri->x*hoaTietQuanSongTheoHuong->huongToi.x + viTri->y*hoaTietQuanSongTheoHuong->huongToi.y +
   viTri->z*hoaTietQuanSongTheoHuong->huongToi.z;

   // ---- xem cần tính sin
   if( hoaTietQuanSongTheoHuong->bienDo == 0.0f )
      doan += hoaTietQuanSongTheoHuong->dich;
   else
      doan += hoaTietQuanSongTheoHuong->dich + hoaTietQuanSongTheoHuong->bienDo*cosf( gocNgang*hoaTietQuanSongTheoHuong->tanSoNgang )*cosf( gocToi*hoaTietQuanSongTheoHuong->tanSoToi );

   // ---- 0,0 đến 1,0
   float doanDonViHoa = doan / hoaTietQuanSongTheoHuong->doan;
   // ---- cần phần số
   doanDonViHoa -= floorf(doanDonViHoa);
   if( doanDonViHoa > 1.0f ){
      printf( "hoaTietQuanSongTheoHuong: đoánĐơnVịHóa > 1.0f\n" );
      exit(0);
   }

   Mau mau;
   if( doanDonViHoa < 0.333333f ) {
      if( doanDonViHoa < 0.333333f - hoaTietQuanSongTheoHuong->phanQuan0 ) {
         mau.d = hoaTietQuanSongTheoHuong->mauNen.d;
         mau.l = hoaTietQuanSongTheoHuong->mauNen.l;
         mau.x = hoaTietQuanSongTheoHuong->mauNen.x;
         mau.dd = hoaTietQuanSongTheoHuong->mauNen.dd;
         mau.p = hoaTietQuanSongTheoHuong->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanSongTheoHuong->mauQuan0.d;
         mau.l = hoaTietQuanSongTheoHuong->mauQuan0.l;
         mau.x = hoaTietQuanSongTheoHuong->mauQuan0.x;
         mau.dd = hoaTietQuanSongTheoHuong->mauQuan0.dd;
         mau.p = hoaTietQuanSongTheoHuong->mauQuan0.p;
      }
   }
   else if( doanDonViHoa < 0.666667f ) {
      if( doanDonViHoa < 0.666667f - hoaTietQuanSongTheoHuong->phanQuan1 ) {
         mau.d = hoaTietQuanSongTheoHuong->mauNen.d;
         mau.l = hoaTietQuanSongTheoHuong->mauNen.l;
         mau.x = hoaTietQuanSongTheoHuong->mauNen.x;
         mau.dd = hoaTietQuanSongTheoHuong->mauNen.dd;
         mau.p = hoaTietQuanSongTheoHuong->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanSongTheoHuong->mauQuan1.d;
         mau.l = hoaTietQuanSongTheoHuong->mauQuan1.l;
         mau.x = hoaTietQuanSongTheoHuong->mauQuan1.x;
         mau.dd = hoaTietQuanSongTheoHuong->mauQuan1.dd;
         mau.p = hoaTietQuanSongTheoHuong->mauQuan1.p;
      }
   }
   else {
      if( doanDonViHoa < 1.0f - hoaTietQuanSongTheoHuong->phanQuan2 ) {
         mau.d = hoaTietQuanSongTheoHuong->mauNen.d;
         mau.l = hoaTietQuanSongTheoHuong->mauNen.l;
         mau.x = hoaTietQuanSongTheoHuong->mauNen.x;
         mau.dd = hoaTietQuanSongTheoHuong->mauNen.dd;
         mau.p = hoaTietQuanSongTheoHuong->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanSongTheoHuong->mauQuan2.d;
         mau.l = hoaTietQuanSongTheoHuong->mauQuan2.l;
         mau.x = hoaTietQuanSongTheoHuong->mauQuan2.x;
         mau.dd = hoaTietQuanSongTheoHuong->mauQuan2.dd;
         mau.p = hoaTietQuanSongTheoHuong->mauQuan2.p;
      }
   }
   
   return mau;
}
