#include "HoaTietNgoiSaoCau.h"
#include "../HangSo.h"
#include <stdlib.h>
#include <math.h>

#pragma mark ---- Họa Tiết Ngôi Sao Cầu
// Chọn tâm ngẫu nhiên xong rồi 
// bán kính nội và ngoại là góc (rag trên mặt hình cầu)
HoaTietNgoiSaoCau datHoaTietNgoiSaoCau( Mau *mauNen, Mau *mauThap, Mau *mauCao, float banKinhNoi, float banKinhNgoai, float chenhLech,  unsigned char soLuongNan ) {

   HoaTietNgoiSaoCau hoaTietNgoiSaoCau;
   hoaTietNgoiSaoCau.mauNen.d = mauNen->d;
   hoaTietNgoiSaoCau.mauNen.l = mauNen->l;
   hoaTietNgoiSaoCau.mauNen.x = mauNen->x;
   hoaTietNgoiSaoCau.mauNen.dd = mauNen->dd;
   hoaTietNgoiSaoCau.mauNen.p = mauNen->p;
   
   // ---- coi trừng số lượng nan ≥ 2
   if( soLuongNan < 2 )
      soLuongNan = 2;
   
   // ---- hạn chế chênh lệch
   if( chenhLech < 0.0f )
      chenhLech = 0.0f;
   else if( chenhLech > 10.0f )
      chenhLech = 10.0f;
   
   // --- coi trừng bán kính nội > bán kính ngoại
   if( banKinhNgoai < banKinhNoi ) {
      float so = banKinhNoi;
      banKinhNoi = banKinhNgoai;
      banKinhNgoai = so;
   }

   // ---- góc giữa nan
   hoaTietNgoiSaoCau.goc = 6.283184f/(float)soLuongNan;   // 2π/soLuongNan
   
   // --- góc từ nan đến điểm giữa nan
   hoaTietNgoiSaoCau.nuaGoc = hoaTietNgoiSaoCau.goc*0.5f;   // π/soLuongNan

   // ---- tìm bán kính và góc cho đường ranh ngôi sao
   //       đơn vị hóa bán kính nội và xài bán kính ngoại = 1,0 cho được xài một bán kính rành
   tinhBanKinhVaGocRanh( &(hoaTietNgoiSaoCau.banKinhRanh), &(hoaTietNgoiSaoCau.gocRanh), banKinhNoi/banKinhNgoai, 1.0f, hoaTietNgoiSaoCau.nuaGoc );

   Mau phamViMau;
   phamViMau.d = mauCao->d - mauThap->d;
   phamViMau.l = mauCao->l - mauThap->l;
   phamViMau.x = mauCao->x - mauThap->x;
   phamViMau.dd = mauCao->dd - mauThap->dd;
   phamViMau.p = mauCao->p - mauThap->p;
   
   unsigned char soNgoiSao = 0;
   while( soNgoiSao < 48 ) {
      // ---- chọn màu ngẫu nhiên
      hoaTietNgoiSaoCau.mangMau[soNgoiSao].d = phamViMau.d*rand()/kSO_NGUYEN_TOI_DA + mauThap->d;
      hoaTietNgoiSaoCau.mangMau[soNgoiSao].l = phamViMau.l*rand()/kSO_NGUYEN_TOI_DA + mauThap->l;
      hoaTietNgoiSaoCau.mangMau[soNgoiSao].x = phamViMau.x*rand()/kSO_NGUYEN_TOI_DA + mauThap->x;
      hoaTietNgoiSaoCau.mangMau[soNgoiSao].dd = phamViMau.dd*rand()/kSO_NGUYEN_TOI_DA + mauThap->dd;
      hoaTietNgoiSaoCau.mangMau[soNgoiSao].p = phamViMau.p*rand()/kSO_NGUYEN_TOI_DA + mauThap->p;

      float phongTo = 1.0f + (rand()/kSO_NGUYEN_TOI_DA)*chenhLech;
      hoaTietNgoiSaoCau.mangBanKinhNgoai[soNgoiSao] = banKinhNgoai*phongTo;
      hoaTietNgoiSaoCau.mangBanKinhNoi[soNgoiSao] = banKinhNoi*phongTo;
      hoaTietNgoiSaoCau.mangBanKinhRanh[soNgoiSao] = hoaTietNgoiSaoCau.banKinhRanh*hoaTietNgoiSaoCau.mangBanKinhNgoai[soNgoiSao];

      // ---- chọn tâm trên mặt hình cầu ngẫu nhiên,
      hoaTietNgoiSaoCau.mangVecto[soNgoiSao].x = 1.0f - rand()/1.07e9f;   // cho có phạm vi -1,0f đến 1,0f
      hoaTietNgoiSaoCau.mangVecto[soNgoiSao].y = 1.0f - rand()/1.07e9f;
      hoaTietNgoiSaoCau.mangVecto[soNgoiSao].z = 1.0f - rand()/1.07e9f;
      donViHoa( &(hoaTietNgoiSaoCau.mangVecto[soNgoiSao]) );
      
      // ---- tính hướng cho ngôi sao
      // một hướng ngẫu nhiên
      Vecto vectoHuong;
      vectoHuong.x = 1.0f - rand()/1.07e9f;   // cho có phạm vi -1,0f đến 1,0f
      vectoHuong.y = 1.0f - rand()/1.07e9f;
      vectoHuong.z = 1.0f - rand()/1.07e9f;
      donViHoa( &(vectoHuong) );

      hoaTietNgoiSaoCau.mangHuong0[soNgoiSao] = tichCoHuong( &vectoHuong, &(hoaTietNgoiSaoCau.mangVecto[soNgoiSao]) );
      donViHoa( &(hoaTietNgoiSaoCau.mangHuong0[soNgoiSao]) );
      hoaTietNgoiSaoCau.mangHuong1[soNgoiSao] = tichCoHuong( &(hoaTietNgoiSaoCau.mangHuong0[soNgoiSao]), &(hoaTietNgoiSaoCau.mangVecto[soNgoiSao]) );
      donViHoa( &(hoaTietNgoiSaoCau.mangHuong1[soNgoiSao]) );

      soNgoiSao++;
   }

   return hoaTietNgoiSaoCau;
}

Mau hoaTietNgoiSaoCau( Vecto *viTri, HoaTietNgoiSaoCau *hoaTietNgoiSaoCau ) {
   
   donViHoa( viTri );
   // ---- tìm gần chấm bi nào
   unsigned char coMau = kSAI;
   unsigned char soNgoiSao = 0;
   while( (soNgoiSao < 48) && !coMau ) {
      coMau = kSAI;
      // ---- tính bán kính
      float tichVoHuong = viTri->x*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].x + viTri->y*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].y + viTri->z*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].z;
      // ---- tính góc từ tâm ngôi sao
      float gocTuTam = acosf( tichVoHuong );
//      printf( " gocTuTam %5.3f", gocTuTam );
//      printf( "%5.3f %5.3f %5.3f  gocTuTam %5.3f   tichVoHuong %5.3f   BKNgoai %5.3f  BKNoi %5.3f\n", viTri->x, viTri->y, viTri->z, gocTuTam, tichVoHuong, hoaTietNgoiSaoCau->mangBanKinhNgoai[soNgoiSao], hoaTietNgoiSaoCau->mangBanKinhNoi[soNgoiSao] );
      // ---- trong bán kính nội, phải tô màu ngôi sao
      if( gocTuTam < hoaTietNgoiSaoCau->mangBanKinhNoi[soNgoiSao] )
         coMau = kDUNG;
      else if( gocTuTam > hoaTietNgoiSaoCau->mangBanKinhNgoai[soNgoiSao] )
         coMau = kSAI;
      else {
         // ==== tính vectơ vuông với mặt tâm
         // ---- tính tích vô hướng điểm với vectơ tâm
         float tichVoHuongVoiTam = viTri->x*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].x
                              + viTri->y*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].y
                              + viTri->z*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].z;
//         printf( "tichVoHuongVoiTam %5.3f  ", tichVoHuongVoiTam );
         float doLonDenTam = sqrtf( hoaTietNgoiSaoCau->mangVecto[soNgoiSao].x*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].x
                                   + hoaTietNgoiSaoCau->mangVecto[soNgoiSao].y*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].y
                                   + hoaTietNgoiSaoCau->mangVecto[soNgoiSao].z*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].z );  // cho hình cầu có thể xài bán kính nhưng vật thể khác không có bán kính
         // ----
         Vecto vectoVuongMat;
         vectoVuongMat.x = viTri->x - tichVoHuongVoiTam*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].x/doLonDenTam;
         vectoVuongMat.y = viTri->y - tichVoHuongVoiTam*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].y/doLonDenTam;
         vectoVuongMat.z = viTri->z - tichVoHuongVoiTam*hoaTietNgoiSaoCau->mangVecto[soNgoiSao].z/doLonDenTam;

         // ---- đơn vị hóa cho tìm góc tương đối với tọa độ ngôi sao
         donViHoa( &vectoVuongMat );

         // ==== tính góc tương đối toạ độ tâm
         float goc0 = acos( vectoVuongMat.x*hoaTietNgoiSaoCau->mangHuong0[soNgoiSao].x + vectoVuongMat.y*hoaTietNgoiSaoCau->mangHuong0[soNgoiSao].y + vectoVuongMat.z*hoaTietNgoiSaoCau->mangHuong0[soNgoiSao].z );
         float goc1 = acos( vectoVuongMat.x*hoaTietNgoiSaoCau->mangHuong1[soNgoiSao].x + vectoVuongMat.y*hoaTietNgoiSaoCau->mangHuong1[soNgoiSao].y + vectoVuongMat.z*hoaTietNgoiSaoCau->mangHuong1[soNgoiSao].z );

         // ---- giữ 0 ≤ kinh độ ≤ 2π
//         if( goc1 > 1.5707963f )
//            6.283184f - goc0; // <-----
         
         // ---- tìm ở đâu giữa nan
         float gocSao = goc0 - hoaTietNgoiSaoCau->goc*floorf( goc0/hoaTietNgoiSaoCau->goc );

         // ---- đơn vị hóa trong phạm vị giữa hai nan
         //            0,0       0,5       1,0 <--- góc đơn vị hóa
         //             +         |         +
         //             | \               / |
         //             |    \    |    /    |
         //             |       \   /       |
         //             +---------+---------+   ---> góc
         //           nan                  nan

         // ---- góc sao đơn vị hóa
         float gocSaoDonViHoa = gocSao/hoaTietNgoiSaoCau->goc;

         // ---- xem cần lật gócĐơnVịHóa
         if( gocSaoDonViHoa > 0.5f )
             gocSaoDonViHoa = 1.0f - gocSaoDonViHoa;
         
         // ---- tính cách (từ tâm) của ranh ngôi sao cùng góc với điểm trúng trên mặt hình cầu
         float cachRanhNgoiSao = hoaTietNgoiSaoCau->mangBanKinhRanh[soNgoiSao]/cosf( gocSaoDonViHoa*hoaTietNgoiSaoCau->goc - hoaTietNgoiSaoCau->gocRanh );
         // ---- nếu ranh ngôi sao xa hơn, tô điểm màu của ngôi sao
         if( cachRanhNgoiSao > gocTuTam )
               coMau = kDUNG;
      }
      soNgoiSao++;
   }

   // ==== tô màu
   Mau mau;
   if( coMau ) {   // có màu ngôi sao
      soNgoiSao--;
      mau.d = hoaTietNgoiSaoCau->mangMau[soNgoiSao].d;
      mau.l = hoaTietNgoiSaoCau->mangMau[soNgoiSao].l;
      mau.x = hoaTietNgoiSaoCau->mangMau[soNgoiSao].x;
      mau.dd = hoaTietNgoiSaoCau->mangMau[soNgoiSao].dd;
      mau.p = hoaTietNgoiSaoCau->mangMau[soNgoiSao].p;
   }
   else {   // màu nền
      mau.d = hoaTietNgoiSaoCau->mauNen.d;
      mau.l = hoaTietNgoiSaoCau->mauNen.l;
      mau.x = hoaTietNgoiSaoCau->mauNen.x;
      mau.dd = hoaTietNgoiSaoCau->mauNen.dd;
      mau.p = hoaTietNgoiSaoCau->mauNen.p;
   }
   
   return mau;
}

// Tìm R_c và θ_c
// R_0 = R_c/cos(θ_0 – θ_c)   R_1 = R_c/cos(θ_1 – θ_c)
void tinhBanKinhVaGocRanh( float *banKinhRanh, float *gocRanh , float banKinhNoi, float banKinhNgoai, float nuaGoc ) {
   unsigned char soLapLai = 0;
   unsigned char xong = kSAI;
   float gocThap = 0.0f;
   float gocCao = 3.1415926f;
   
   // ---- coi thử được xong sớm
   float chenhLech = banKinhNgoai*cosf( gocThap ) - banKinhNoi*cosf( nuaGoc - gocThap );
   if( chenhLech < 0.0f )
      chenhLech = -chenhLech;
   if( chenhLech < 0.0001f ) {
      xong = kDUNG;
      *gocRanh = gocThap;
      return;
   }
   
   chenhLech = banKinhNgoai*cosf( gocCao ) - banKinhNoi*cosf( nuaGoc - gocCao );
   if( chenhLech < 0.0f )
      chenhLech = -chenhLech;
   if( chenhLech < 0.0001f ) {
      xong = kDUNG;
      *gocRanh = gocCao;
      return;
   }
   
   while( !xong ) {
      // ---- tính góc trung bình của gócCao và gócThấp
      float gocGiua = (gocThap + gocCao) * 0.5f;

      // ---- tính chênh lệch
      float giaTri = banKinhNgoai*cosf( gocGiua ) - banKinhNoi*cosf( nuaGoc - gocGiua );
      
      float chenhLech = giaTri;
      
      // ---- giá trị tuyệt đối
      if( chenhLech < 0.0f )
         chenhLech = -chenhLech;
      if( chenhLech < 0.0001f ) {
         xong = kDUNG;
         *gocRanh = gocGiua;
      }
      
      if( giaTri > 0.0f ) {
         gocThap = gocGiua;
      }
      else {
         gocCao = gocGiua;
      }
      soLapLai++;
      
      if( soLapLai > 20 )
         xong = kDUNG;
   }
   *banKinhRanh = cosf( *gocRanh );

}
