#pragma once
#include "../Mau.h"
#include "../Toán/Vecto.h"


/* Họa Tiết Quằn Sóng Trục Z */
typedef struct {
   Mau mauNen; // màu nền
   Mau mauQuan0; // màu quằn 0
   Mau mauQuan1; // màu quằn 1
   Mau mauQuan2; // màu quằn 2
   float phanQuan0; // phần số quằn 0
   float phanQuan1; // phần số quằn 1
   float phanQuan2; // phần số quằn 2
   float tanSo; // tân số
   float bienDo; // biên độ
   float dich; // địch xoay
   float soLapVong; // số lặp vòng
   float doan; // đoạn = 2π/số lặp vòng
} HoaTietQuanSongTrucZ;


// ---- quằn sóng truc z
HoaTietQuanSongTrucZ datHoaTietQuanSongTrucZ( Mau *mauNen, Mau *mauQuan0, Mau *mauQuan1, Mau *mauQuan2, float phanQuan0, float phanQuan1, float phanQuan2, float tanSo, float bienDo, float dich, unsigned char soLapVong );
Mau hoaTietQuanSongTrucZ( Vecto *viTri, HoaTietQuanSongTrucZ *hoaTietQuanSongTrucZ );