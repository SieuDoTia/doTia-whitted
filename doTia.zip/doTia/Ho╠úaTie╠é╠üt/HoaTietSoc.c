#include "HoaTietSoc.h"
#include "../HangSo.h"
#include <math.h>

#pragma mark ---- Họa Tiết Sọc
HoaTietSoc datHoaTietSoc( Mau *mauNen, Mau *mauSoc, float quangSoc, float phanSoSoc, Vecto *trucSoc ) {
   
   HoaTietSoc hoaTietSoc;
   hoaTietSoc.mauNen.d = mauNen->d;
   hoaTietSoc.mauNen.l = mauNen->l;
   hoaTietSoc.mauNen.x = mauNen->x;
   hoaTietSoc.mauNen.dd = mauNen->dd;
   hoaTietSoc.mauNen.p = mauNen->p;
   
   hoaTietSoc.mauSoc.d = mauSoc->d;
   hoaTietSoc.mauSoc.l = mauSoc->l;
   hoaTietSoc.mauSoc.x = mauSoc->x;
   hoaTietSoc.mauSoc.dd = mauSoc->dd;
   hoaTietSoc.mauSoc.p = mauSoc->p;
   
   hoaTietSoc.quangSoc = quangSoc;
   hoaTietSoc.phanSoSoc = phanSoSoc;
   
   hoaTietSoc.trucSoc.x = trucSoc->x;
   hoaTietSoc.trucSoc.y = trucSoc->y;
   hoaTietSoc.trucSoc.z = trucSoc->z;
   
   donViHoa( &(hoaTietSoc.trucSoc) );

   return hoaTietSoc;
}

Mau hoaTietSoc( Vecto *viTri, HoaTietSoc *hoaTietSoc ) {

   float phanSo;
   float soSoc;

   float cach = viTri->x * hoaTietSoc->trucSoc.x + viTri->y * hoaTietSoc->trucSoc.y + viTri->z * hoaTietSoc->trucSoc.z;

   soSoc = cach/hoaTietSoc->quangSoc;
   phanSo = soSoc - floorf( soSoc );   

   // ---- chọn màu
   Mau mau;
   if( phanSo < hoaTietSoc->phanSoSoc )
      mau = hoaTietSoc->mauSoc;
   else
      mau = hoaTietSoc->mauNen;

//   printf( "phanSo %5.3f  hoaTietSoc->phanSoSoc %5.3f  mau %5.3f %5.3f %5.3f\n", phanSo, hoaTietSoc->phanSoSoc, mau.d, mau.l, mau.x );

   return mau;
}