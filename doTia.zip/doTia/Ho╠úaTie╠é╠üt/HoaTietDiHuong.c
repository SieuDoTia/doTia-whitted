#include "HoaTietDiHuong.h"

#pragma mark ---- Họa Tiết Màu Dị Hướng
HoaTietDiHuong datHoaTietDiHuong( Mau *mauRanh, Mau *mauTam ) {
   HoaTietDiHuong hoaTietDiHuong;
   hoaTietDiHuong.mauRanh.d = mauRanh->d;
   hoaTietDiHuong.mauRanh.l = mauRanh->l;
   hoaTietDiHuong.mauRanh.x = mauRanh->x;
   hoaTietDiHuong.mauRanh.dd = mauRanh->dd;
   hoaTietDiHuong.mauRanh.p = mauRanh->p;
   
   hoaTietDiHuong.mauTam.d = mauTam->d;
   hoaTietDiHuong.mauTam.l = mauTam->l;
   hoaTietDiHuong.mauTam.x = mauTam->x;
   hoaTietDiHuong.mauTam.dd = mauTam->dd;
   hoaTietDiHuong.mauTam.p = mauTam->p;
   
   return hoaTietDiHuong;
}

Mau hoaTietDiHuong( Vecto phapThuyen, Vecto huongTia, HoaTietDiHuong *hoaTietDiHuong ) {
   
   donViHoa( &huongTia );
   float tichVoHuong = phapThuyen.x*huongTia.x + phapThuyen.y*huongTia.y + phapThuyen.z*huongTia.z;

   // ---- xài giá trị tuyệt đối
   if( tichVoHuong < 0.0f )
      tichVoHuong = -tichVoHuong;
   
   tichVoHuong *= tichVoHuong;

   float nghichTichVoHuong = 1.0f - tichVoHuong;

   Mau mauDiHuong;
   mauDiHuong.d = tichVoHuong*hoaTietDiHuong->mauTam.d + nghichTichVoHuong*hoaTietDiHuong->mauRanh.d;
   mauDiHuong.l = tichVoHuong*hoaTietDiHuong->mauTam.l + nghichTichVoHuong*hoaTietDiHuong->mauRanh.l;
   mauDiHuong.x = tichVoHuong*hoaTietDiHuong->mauTam.x + nghichTichVoHuong*hoaTietDiHuong->mauRanh.x;
   mauDiHuong.dd = tichVoHuong*hoaTietDiHuong->mauTam.dd + nghichTichVoHuong*hoaTietDiHuong->mauRanh.dd;
   mauDiHuong.p = tichVoHuong*hoaTietDiHuong->mauTam.p + nghichTichVoHuong*hoaTietDiHuong->mauRanh.p;

   return mauDiHuong;
}
