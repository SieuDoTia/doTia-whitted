// 2017.07.07
#pragma once

#include "../Mau.h"

/* Họa Tiết Kim Tuyến Lấp Lánh */
typedef struct {
   Mau mau;            // màu
   float doLapLanh;    // độ lấp lánh
   float nuaDoLapLanh; // nữa độ lấp lánh
} HoaTietKimTuyenLapLanh;


// ---- kim tuyến lấp lánh
HoaTietKimTuyenLapLanh datHoaTietKimTuyenLapLanh( Mau *mau, float doLapLanh );
Mau hoaTietKimTuyenLapLanh( HoaTietKimTuyenLapLanh *hoaTietKimTuyenLapLanh );