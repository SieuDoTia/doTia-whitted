#pragma once
#include "../Mau.h"
#include "../Toán/Vecto.h"

Mau hoaTietTraiBanh( Vecto *viTri );