#include "HoaTietChamBi.h"
#include "../hangSo.h"
#include <math.h>
#include <stdlib.h>


#pragma mark ---- Họa Tiết Chấm Bi
HoaTietChamBi datHoaTietChamBi( Mau *mauNen, Mau *mauThap, Mau *mauCao ) {
   HoaTietChamBi hoaTietChamBi;
   hoaTietChamBi.mauNen.d = mauNen->d;
   hoaTietChamBi.mauNen.l = mauNen->l;
   hoaTietChamBi.mauNen.x = mauNen->x;
   hoaTietChamBi.mauNen.dd = mauNen->dd;
   hoaTietChamBi.mauNen.p = mauNen->p;
   
   Mau phamViMau;
   phamViMau.d = mauCao->d - mauThap->d;
   phamViMau.l = mauCao->l - mauThap->l;
   phamViMau.x = mauCao->x - mauThap->x;
   phamViMau.dd = mauCao->dd - mauThap->dd;
   phamViMau.p = mauCao->p - mauThap->p;

   unsigned char soCham = 0;
   while( soCham < 48 ) {
      hoaTietChamBi.mangMau[soCham].d = phamViMau.d*rand()/kSO_NGUYEN_TOI_DA + mauThap->d;
      hoaTietChamBi.mangMau[soCham].l = phamViMau.l*rand()/kSO_NGUYEN_TOI_DA + mauThap->l;
      hoaTietChamBi.mangMau[soCham].x = phamViMau.x*rand()/kSO_NGUYEN_TOI_DA + mauThap->x;
      hoaTietChamBi.mangMau[soCham].dd = phamViMau.dd*rand()/kSO_NGUYEN_TOI_DA + mauThap->dd;
      hoaTietChamBi.mangMau[soCham].p = phamViMau.p*rand()/kSO_NGUYEN_TOI_DA + mauThap->p;
//      printf( "%5.3f %5.3f %5.3f\n", hoaTietChamBi.mangMau[soCham].d, hoaTietChamBi.mangMau[soCham].l, hoaTietChamBi.mangMau[soCham].x );
      hoaTietChamBi.mangBanKinh[soCham] = 1.0f - 0.03f*rand()/kSO_NGUYEN_TOI_DA;

      hoaTietChamBi.mangVecto[soCham].x = 1.0f - rand()/1.07e9f;   // cho có phạm vi -1,0f đến 1,0f
      hoaTietChamBi.mangVecto[soCham].y = 1.0f - rand()/1.07e9f;
      hoaTietChamBi.mangVecto[soCham].z = 1.0f - rand()/1.07e9f;
      donViHoa( &(hoaTietChamBi.mangVecto[soCham]) );

      soCham++;
   }
   return hoaTietChamBi;
}

Mau hoaTietChamBi( Vecto *viTri, HoaTietChamBi *hoaTietChamBi ) {
   
   donViHoa( viTri );
   // ---- tìm gần chấm bi nào
   unsigned char coMau = kSAI;
   unsigned char soCham = 0;
   while( soCham < 48 && !coMau ) {
      
      float tichVoHuong = viTri->x*hoaTietChamBi->mangVecto[soCham].x + viTri->y*hoaTietChamBi->mangVecto[soCham].y + viTri->z*hoaTietChamBi->mangVecto[soCham].z;
      if( tichVoHuong > hoaTietChamBi->mangBanKinh[soCham] )
         coMau = kDUNG;

      soCham++;
   }

   Mau mau;
   if( coMau ) {   // màu chấm bi
      soCham--;
      mau.d = hoaTietChamBi->mangMau[soCham].d;
      mau.l = hoaTietChamBi->mangMau[soCham].l;
      mau.x = hoaTietChamBi->mangMau[soCham].x;
      mau.dd = hoaTietChamBi->mangMau[soCham].dd;
      mau.p = hoaTietChamBi->mangMau[soCham].p;
  }
   else {   // màu nền
      mau.d = hoaTietChamBi->mauNen.d;
      mau.l = hoaTietChamBi->mauNen.l;
      mau.x = hoaTietChamBi->mauNen.x;
      mau.dd = hoaTietChamBi->mauNen.dd;
      mau.p = hoaTietChamBi->mauNen.p;
   }

   return mau;
}
