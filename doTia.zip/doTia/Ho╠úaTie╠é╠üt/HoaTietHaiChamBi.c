#include "HoaTietHaiChamBi.h"
#include <math.h>


#pragma mark ---- Họa Tiết Hai Chấm Bi
// ---- Hai chấm bi trong hình khối
// ---- hai vị trí cho chấm bi là tương đối tử góc 0; 0; 0 của hình khối
//          ^
//          |
// +--------+-------+
// |        |       |
// |        |góc    |
// |        +-------+---->
// |                |
// |                |
// +----------------+

HoaTietHaiChamBi datHoaTietHaiChamBi( Mau *mauNen, Mau *mau0, Mau *mau1, float banKinh0, float banKinh1, Vecto *viTri0, Vecto *viTri1, float beRong, float beCao, float beDai ) {

   HoaTietHaiChamBi hoaTietHaiChamBi;
   
   hoaTietHaiChamBi.viTri0.x = viTri0->x;
   hoaTietHaiChamBi.viTri0.y = viTri0->y;
   hoaTietHaiChamBi.viTri0.z = viTri0->z;

   hoaTietHaiChamBi.viTri1.x = viTri1->x;
   hoaTietHaiChamBi.viTri1.y = viTri1->y;
   hoaTietHaiChamBi.viTri1.z = viTri1->z;
   
   // ---- tính bán kính bình phương
   hoaTietHaiChamBi.banKinhBinh0 = banKinh0*banKinh0;
   hoaTietHaiChamBi.banKinhBinh1 = banKinh1*banKinh1;

   hoaTietHaiChamBi.mauNen.d = mauNen->d;
   hoaTietHaiChamBi.mauNen.l = mauNen->l;
   hoaTietHaiChamBi.mauNen.x = mauNen->x;
   hoaTietHaiChamBi.mauNen.dd = mauNen->dd;
   hoaTietHaiChamBi.mauNen.p = mauNen->p;
   
   hoaTietHaiChamBi.mau0.d = mau0->d;
   hoaTietHaiChamBi.mau0.l = mau0->l;
   hoaTietHaiChamBi.mau0.x = mau0->x;
   hoaTietHaiChamBi.mau0.dd = mau0->dd;
   hoaTietHaiChamBi.mau0.p = mau0->p;
   
   hoaTietHaiChamBi.mau1.d = mau1->d;
   hoaTietHaiChamBi.mau1.l = mau1->l;
   hoaTietHaiChamBi.mau1.x = mau1->x;
   hoaTietHaiChamBi.mau1.dd = mau1->dd;
   hoaTietHaiChamBi.mau1.p = mau1->p;
   
   hoaTietHaiChamBi.beRong = beRong;
   hoaTietHaiChamBi.beCao = beCao;
   hoaTietHaiChamBi.beDai = beDai;
   
   return hoaTietHaiChamBi;
}

Mau hoaTietHaiChamBi( Vecto *viTri, HoaTietHaiChamBi *hoaTietHaiChamBi ) {
   
   // ---- vị trí tương đối hình khối
   // ---- tính tương đối vơi tâm khối, vị trí củng tươg đối với tâm vật thể rồi
   // ---- tìm bao nhiêu khối lặp dòng từ floorf((viTri->x + hoaTietHaiChamBi->beRong*0.5f)/hoaTietHaiChamBi->beRong
   Vecto viTriTuongDoiKhoi;
   viTriTuongDoiKhoi.x = viTri->x - hoaTietHaiChamBi->beRong*floorf((viTri->x + hoaTietHaiChamBi->beRong*0.5f)/hoaTietHaiChamBi->beRong);
   viTriTuongDoiKhoi.y = viTri->y - hoaTietHaiChamBi->beCao*floorf((viTri->y + hoaTietHaiChamBi->beCao*0.5f)/hoaTietHaiChamBi->beCao);
   viTriTuongDoiKhoi.z = viTri->z - hoaTietHaiChamBi->beDai*floorf((viTri->z + hoaTietHaiChamBi->beDai*0.5f)/hoaTietHaiChamBi->beDai);

   // ---- xem trong hình cầu 0 hay không
   Vecto viTriTuongDoi0;
   viTriTuongDoi0.x = hoaTietHaiChamBi->viTri0.x - viTriTuongDoiKhoi.x;
   viTriTuongDoi0.y = hoaTietHaiChamBi->viTri0.y - viTriTuongDoiKhoi.y;
   viTriTuongDoi0.z = hoaTietHaiChamBi->viTri0.z - viTriTuongDoiKhoi.z;

   Mau mau;
   float banKinhBinh0 = viTriTuongDoi0.x*viTriTuongDoi0.x + viTriTuongDoi0.y*viTriTuongDoi0.y + viTriTuongDoi0.z*viTriTuongDoi0.z;

   if( banKinhBinh0 < hoaTietHaiChamBi->banKinhBinh0 ) {
      mau.d = hoaTietHaiChamBi->mau0.d;
      mau.l = hoaTietHaiChamBi->mau0.l;
      mau.x = hoaTietHaiChamBi->mau0.x;
      mau.dd = hoaTietHaiChamBi->mau0.dd;
      mau.p = hoaTietHaiChamBi->mau0.p;
   }
   else {
      // ---- xem trong hình cầu 1 hay không
      Vecto viTriTuongDoi1;
      viTriTuongDoi1.x = hoaTietHaiChamBi->viTri1.x - viTriTuongDoiKhoi.x;
      viTriTuongDoi1.y = hoaTietHaiChamBi->viTri1.y - viTriTuongDoiKhoi.y;
      viTriTuongDoi1.z = hoaTietHaiChamBi->viTri1.z - viTriTuongDoiKhoi.z;
      
      float banKinhBinh1 = viTriTuongDoi1.x*viTriTuongDoi1.x + viTriTuongDoi1.y*viTriTuongDoi1.y + viTriTuongDoi1.z*viTriTuongDoi1.z;
      if( banKinhBinh1 < hoaTietHaiChamBi->banKinhBinh1 ) {
         mau.d = hoaTietHaiChamBi->mau1.d;
         mau.l = hoaTietHaiChamBi->mau1.l;
         mau.x = hoaTietHaiChamBi->mau1.x;
         mau.dd = hoaTietHaiChamBi->mau1.dd;
         mau.p = hoaTietHaiChamBi->mau1.p;
      }
      // ---- †ô màu nền
      else {
         mau.d = hoaTietHaiChamBi->mauNen.d;
         mau.l = hoaTietHaiChamBi->mauNen.l;
         mau.x = hoaTietHaiChamBi->mauNen.x;
         mau.dd = hoaTietHaiChamBi->mauNen.dd;
         mau.p = hoaTietHaiChamBi->mauNen.p;
      }
   }

   return mau;
}
