#include "HoaTietBongVong.h"
#include <math.h>

#pragma mark ---- Họa Tiết Bông Vòng
//    b.k. nội
// +-------------->| b.k. ngoại
// +--------------------->| b.k. vành
// +---------------------------->|
//                          vành   bông vòng
// +----------------------+------+--------+
HoaTietBongVong datHoaTietBongVong( Mau *mauNen, Mau *mauNoi, Mau *mauNgoai, Mau *mauVanh, float banKinhNoi, float banKinhNgoai, float banKinhVanh, Mau *mauBongVongNoi, Mau *mauBongVongNgoai, float tiSoToBong, unsigned short soLuongBong ) {
   
   HoaTietBongVong hoaTietBongVong;

   // ---- tính bán kính bình phương
   hoaTietBongVong.banKinhBinhNoi = banKinhNoi*banKinhNoi;
   hoaTietBongVong.banKinhBinhNgoai = banKinhNgoai*banKinhNgoai;
   hoaTietBongVong.banKinhBinhVanh = banKinhVanh*banKinhVanh;
   hoaTietBongVong.banKinhVanh = banKinhVanh;  // cần cho vẽ bông vòng
   
   hoaTietBongVong.mauNen.d = mauNen->d;
   hoaTietBongVong.mauNen.l = mauNen->l;
   hoaTietBongVong.mauNen.x = mauNen->x;
   hoaTietBongVong.mauNen.dd = mauNen->dd;
   hoaTietBongVong.mauNen.p = mauNen->p;
   
   hoaTietBongVong.mauNoi.d = mauNoi->d;
   hoaTietBongVong.mauNoi.l = mauNoi->l;
   hoaTietBongVong.mauNoi.x = mauNoi->x;
   hoaTietBongVong.mauNoi.dd = mauNoi->dd;
   hoaTietBongVong.mauNoi.p = mauNoi->p;
   
   hoaTietBongVong.mauNgoai.d = mauNgoai->d;
   hoaTietBongVong.mauNgoai.l = mauNgoai->l;
   hoaTietBongVong.mauNgoai.x = mauNgoai->x;
   hoaTietBongVong.mauNgoai.dd = mauNgoai->dd;
   hoaTietBongVong.mauNgoai.p = mauNgoai->p;
   
   hoaTietBongVong.mauVanh.d = mauVanh->d;
   hoaTietBongVong.mauVanh.l = mauVanh->l;
   hoaTietBongVong.mauVanh.x = mauVanh->x;
   hoaTietBongVong.mauVanh.dd = mauVanh->dd;
   hoaTietBongVong.mauVanh.p = mauVanh->p;
   
   if( soLuongBong < 4 )
      soLuongBong = 4;
   
   hoaTietBongVong.gocBongVong = 6.2831852f/(float)soLuongBong;
 
   // ---- tính bán kính bình cho các bông vòng
   if( tiSoToBong > 1.0f )
      tiSoToBong = 1.0f;

   float banKinhBongNgoai = 0.5f*banKinhVanh*6.2831852f/(float)soLuongBong;
   float banKinhBongNoi = banKinhBongNgoai*(1.0f - tiSoToBong );
   hoaTietBongVong.banKinhBinhBongVongNoi = banKinhBongNoi*banKinhBongNoi;
   hoaTietBongVong.banKinhBinhBongVongNgoai = banKinhBongNgoai*banKinhBongNgoai;

   hoaTietBongVong.mauBongVongNoi.d = mauBongVongNoi->d;
   hoaTietBongVong.mauBongVongNoi.l = mauBongVongNoi->l;
   hoaTietBongVong.mauBongVongNoi.x = mauBongVongNoi->x;
   hoaTietBongVong.mauBongVongNoi.dd = mauBongVongNoi->dd;
   hoaTietBongVong.mauBongVongNoi.p = mauBongVongNoi->p;
   
   hoaTietBongVong.mauBongVongNgoai.d = mauBongVongNgoai->d;
   hoaTietBongVong.mauBongVongNgoai.l = mauBongVongNgoai->l;
   hoaTietBongVong.mauBongVongNgoai.x = mauBongVongNgoai->x;
   hoaTietBongVong.mauBongVongNgoai.dd = mauBongVongNgoai->dd;
   hoaTietBongVong.mauBongVongNgoai.p = mauBongVongNgoai->p;
   
   
   
   return hoaTietBongVong;
}

Mau hoaTietBongVong( Vecto *viTri, HoaTietBongVong *hoaTietBongVong ) {
   
   // ---- vị trí tương đối tâm vất thể, quanh trục z
   Mau mau;
   float cachBinh = viTri->x*viTri->x + viTri->z*viTri->z;
   if( cachBinh < hoaTietBongVong->banKinhBinhNoi ) {
      mau = hoaTietBongVong->mauNen;
   }
   else if( cachBinh < hoaTietBongVong->banKinhBinhNgoai ) {
      // ---- tính màu, suy nội không bậc một nhe
      float tiSo = (cachBinh - hoaTietBongVong->banKinhBinhNoi)/(hoaTietBongVong->banKinhBinhNgoai - hoaTietBongVong->banKinhBinhNoi);
      float nghichTiSo = 1.0f - tiSo;
      mau.d = hoaTietBongVong->mauNoi.d*nghichTiSo + hoaTietBongVong->mauNgoai.d*tiSo;
      mau.l = hoaTietBongVong->mauNoi.l*nghichTiSo + hoaTietBongVong->mauNgoai.l*tiSo;
      mau.x = hoaTietBongVong->mauNoi.x*nghichTiSo + hoaTietBongVong->mauNgoai.x*tiSo;
      mau.dd = hoaTietBongVong->mauNoi.dd*nghichTiSo + hoaTietBongVong->mauNgoai.dd*tiSo;
      mau.p = hoaTietBongVong->mauNoi.p*nghichTiSo + hoaTietBongVong->mauNgoai.p*tiSo;
   }
   else if( cachBinh < hoaTietBongVong->banKinhBinhVanh ) {
      // ---- màu vành
      mau = hoaTietBongVong->mauVanh;
   }
   else {
      // ---- tính bán kính tương đối tâm vật thể
      float banKinh = sqrtf( viTri->x*viTri->x + viTri->z*viTri->z );
      // ---- tính góc
      float goc = 0.0f;
      if( banKinh != 0.0f )
         goc = atanf( viTri->z/viTri->x );
      
      // ---- giữ 0 ≤ góc ≤ 2π
      if( viTri->x < 0.0f )
         goc += 3.141592f;
      else
         if( viTri->z < 0.0f )
            goc += 6.283184f;

      // ---- tính tâm của bông vòng tròn cho phần bông vòng này
      float gocTam = (floorf(goc/hoaTietBongVong->gocBongVong) + 0.5f)*hoaTietBongVong->gocBongVong;
//      printf( "goc %5.3f   gocTam %5.3f\n", goc, gocTam );
      float tamBongVongX = hoaTietBongVong->banKinhVanh*cosf( gocTam );
      float tamBongVongZ = hoaTietBongVong->banKinhVanh*sinf( gocTam );
//      printf( "tamBongVong %5.3f %5.3f\n", tamBongVongX, tamBongVongZ );
      // ---- vị trí tương đối với tâm bông vòng tròn
      float tuongDoiX = viTri->x - tamBongVongX;
      float tuongDoiZ = viTri->z - tamBongVongZ;
//      printf( "tuongDoi %5.3f  %5.3f\n", tuongDoiX, tuongDoiZ );
      // ---- tính cách từ tâm bông vòng tròn
      float cachTuTamBinh = tuongDoiX*tuongDoiX + tuongDoiZ*tuongDoiZ;
//      printf( "cachTuTam %5.3f\n", cachTuTamBinh );
//      printf( "hoaTietBongVong->banKinhBinhBongVongNgoai %5.3f\n", hoaTietBongVong->banKinhBinhBongVongNgoai );

      if( cachTuTamBinh < hoaTietBongVong->banKinhBinhBongVongNoi )
         mau = hoaTietBongVong->mauNen;
      else if(  cachTuTamBinh < hoaTietBongVong->banKinhBinhBongVongNgoai ) {
         // ---- tính màu, suy nội không bậc một nhe
         float tiSo = (cachTuTamBinh - hoaTietBongVong->banKinhBinhBongVongNoi)/(hoaTietBongVong->banKinhBinhBongVongNgoai - hoaTietBongVong->banKinhBinhBongVongNoi);
         float nghichTiSo = 1.0f - tiSo;
         mau.d = hoaTietBongVong->mauNoi.d*nghichTiSo + hoaTietBongVong->mauNgoai.d*tiSo;
         mau.l = hoaTietBongVong->mauNoi.l*nghichTiSo + hoaTietBongVong->mauNgoai.l*tiSo;
         mau.x = hoaTietBongVong->mauNoi.x*nghichTiSo + hoaTietBongVong->mauNgoai.x*tiSo;
         mau.dd = hoaTietBongVong->mauNoi.dd*nghichTiSo + hoaTietBongVong->mauNgoai.dd*tiSo;
         mau.p = hoaTietBongVong->mauNoi.p*nghichTiSo + hoaTietBongVong->mauNgoai.p*tiSo;
      }
      else {
         mau = hoaTietBongVong->mauNen;
      }
//      exit(0);
   }
      
   return mau;
}
