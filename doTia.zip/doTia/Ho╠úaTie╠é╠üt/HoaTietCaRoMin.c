#include "HoaTietCaRoMin.h"
#include <math.h>

#pragma mark ---- Họa Tiết Ca Rô Mịn
HoaTietCaRoMin datHoaTietCaRoMin( Mau *mau0, Mau *mau1, float beRong, float beCao, float beDai ) {
   HoaTietCaRoMin hoaTietCaRoMin;
   hoaTietCaRoMin.mau0.d = mau0->d;
   hoaTietCaRoMin.mau0.l = mau0->l;
   hoaTietCaRoMin.mau0.x = mau0->x;
   hoaTietCaRoMin.mau0.dd = mau0->dd;
   hoaTietCaRoMin.mau0.p = mau0->p;
   
   hoaTietCaRoMin.mau1.d = mau1->d;
   hoaTietCaRoMin.mau1.l = mau1->l;
   hoaTietCaRoMin.mau1.x = mau1->x;
   hoaTietCaRoMin.mau1.dd = mau1->dd;
   hoaTietCaRoMin.mau1.p = mau1->p;
   
   hoaTietCaRoMin.beRong = beRong;
   hoaTietCaRoMin.beCao = beCao;
   hoaTietCaRoMin.beDai = beDai;
   
   return hoaTietCaRoMin;
}

Mau hoaTietCaRoMin( Vecto *viTri, HoaTietCaRoMin *hoaTietCaRoMin ) {
   
   float x = (viTri->x)/hoaTietCaRoMin->beRong;
   float y = (viTri->y)/hoaTietCaRoMin->beCao;
   float z = (viTri->z)/hoaTietCaRoMin->beDai;
   // ---- lấy phần số
   float phanSoX = 6.283184f*(x - ceil(x));
   float phanSoY = 6.283184f*(y - ceil(y));  // int
   float phanSoZ = 6.283184f*(z - ceil(z));  // int
   
   float ketQua = 0.5f*(sinf( phanSoX ) * sinf( phanSoY ) * sinf( phanSoZ ) + 1.0f);
   float ketQuaNghich = 1.0f - ketQua;

   Mau mauCaRo;
   mauCaRo.d = ketQuaNghich*hoaTietCaRoMin->mau0.d + ketQua*hoaTietCaRoMin->mau1.d;
   mauCaRo.l = ketQuaNghich*hoaTietCaRoMin->mau0.l + ketQua*hoaTietCaRoMin->mau1.l;
   mauCaRo.x = ketQuaNghich*hoaTietCaRoMin->mau0.x + ketQua*hoaTietCaRoMin->mau1.x;
   mauCaRo.dd = ketQuaNghich*hoaTietCaRoMin->mau0.dd + ketQua*hoaTietCaRoMin->mau1.dd;
   mauCaRo.p = ketQuaNghich*hoaTietCaRoMin->mau0.p + ketQua*hoaTietCaRoMin->mau1.p;

   return mauCaRo;
}

