#include "HoaTietCaRo.h"
#include <math.h>


#pragma mark ---- Họa Tiết Ca Rô
HoaTietCaRo datHoaTietCaRo( Mau *mau0, Mau *mau1, float beRong, float beCao, float beDai ) {
   HoaTietCaRo hoaTietCaRo;
   hoaTietCaRo.mau0.d = mau0->d;
   hoaTietCaRo.mau0.l = mau0->l;
   hoaTietCaRo.mau0.x = mau0->x;
   hoaTietCaRo.mau0.dd = mau0->dd;
   hoaTietCaRo.mau0.p = mau0->p;
   
   hoaTietCaRo.mau1.d = mau1->d;
   hoaTietCaRo.mau1.l = mau1->l;
   hoaTietCaRo.mau1.x = mau1->x;
   hoaTietCaRo.mau1.dd = mau1->dd;
   hoaTietCaRo.mau1.p = mau1->p;
   
   hoaTietCaRo.beRong = beRong;
   hoaTietCaRo.beCao = beCao;
   hoaTietCaRo.beDai = beDai;
   
   return hoaTietCaRo;
}

Mau hoaTietCaRo( Vecto *viTri, HoaTietCaRo *hoaTietCaRo ) {
   
   int soX = ceilf((viTri->x)/hoaTietCaRo->beRong);
   int soY = ceilf((viTri->y)/hoaTietCaRo->beCao);
   int soZ = ceilf((viTri->z)/hoaTietCaRo->beDai);
   
   Mau mauCaRo;
   
   if( soY & 0x01 ){
      if( ((soX & 0x01) && (soZ & 0x01)) || (!(soX & 0x01) && !(soZ & 0x01))  ) {
         mauCaRo.d = hoaTietCaRo->mau1.d;
         mauCaRo.l = hoaTietCaRo->mau1.l;
         mauCaRo.x = hoaTietCaRo->mau1.x;
         mauCaRo.dd = hoaTietCaRo->mau1.dd;
         mauCaRo.p = hoaTietCaRo->mau1.p;
      }
      else {
         mauCaRo.d = hoaTietCaRo->mau0.d;
         mauCaRo.l = hoaTietCaRo->mau0.l;
         mauCaRo.x = hoaTietCaRo->mau0.x;
         mauCaRo.dd = hoaTietCaRo->mau0.dd;
         mauCaRo.p = hoaTietCaRo->mau0.p;
      }
   }
   else {
      if( ((soX & 0x01) && (soZ & 0x01)) || (!(soX & 0x01) && !(soZ & 0x01))  ) {
         mauCaRo.d = hoaTietCaRo->mau0.d;
         mauCaRo.l = hoaTietCaRo->mau0.l;
         mauCaRo.x = hoaTietCaRo->mau0.x;
         mauCaRo.dd = hoaTietCaRo->mau0.dd;
         mauCaRo.p = hoaTietCaRo->mau0.p;
      }
      else {
         mauCaRo.d = hoaTietCaRo->mau1.d;
         mauCaRo.l = hoaTietCaRo->mau1.l;
         mauCaRo.x = hoaTietCaRo->mau1.x;
         mauCaRo.dd = hoaTietCaRo->mau1.dd;
         mauCaRo.p = hoaTietCaRo->mau1.p;
      }
   }
   
   return mauCaRo;
}
