#include "HoaTietOcXoay.h"
#include <math.h>

#pragma mark ---- Họa Tiết Óc Xoáy
HoaTietOcXoay datHoaTietOcXoay( Mau *mau0, Mau *mau1, float beRongNet, float phongTo ) {
   HoaTietOcXoay hoaTietOcXoay;
   hoaTietOcXoay.mau0.d = mau0->d;
   hoaTietOcXoay.mau0.l = mau0->l;
   hoaTietOcXoay.mau0.x = mau0->x;
   hoaTietOcXoay.mau0.dd = mau0->dd;
   hoaTietOcXoay.mau0.p = mau0->p;
   
   hoaTietOcXoay.mau1.d = mau1->d;
   hoaTietOcXoay.mau1.l = mau1->l;
   hoaTietOcXoay.mau1.x = mau1->x;
   hoaTietOcXoay.mau1.dd = mau1->dd;
   hoaTietOcXoay.mau1.p = mau1->p;
   
   hoaTietOcXoay.beRongNet = beRongNet;
   hoaTietOcXoay.phongTo = phongTo;

   return hoaTietOcXoay;
}

// cho phóng to, xài giá trị < 1.0 cho rộng hơn
Mau hoaTietOcXoay( Vecto *viTri, HoaTietOcXoay *hoaTietOcXoay ) {
   
   float banKinh = sqrtf( viTri->x*viTri->x + viTri->z*viTri->z );
   banKinh *= hoaTietOcXoay->phongTo;  // sẽ phóng nhỏ
   
   // ---- tính góc
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atanf( viTri->z/viTri->x );
   
   // ---- giữ 0 ≤ góc ≤ 2π
   if( viTri->x < 0.0f )
      goc += 3.141592f;
   else
      if( viTri->z < 0.0f )
         goc += 6.283184f;
   
   // ---- tính vòng
   unsigned short soVong = banKinh/6.283184f;
   
   goc += (float)soVong*6.283184f;
   
   // ---- chọn màu
   Mau mauTo;
   float nuaBeRongNet = hoaTietOcXoay->beRongNet*0.5f;
   
   if( (goc < banKinh + nuaBeRongNet) && (goc > banKinh - nuaBeRongNet ) ) {
      mauTo.d = hoaTietOcXoay->mau0.d;
      mauTo.l = hoaTietOcXoay->mau0.l;
      mauTo.x = hoaTietOcXoay->mau0.x;
      mauTo.dd = hoaTietOcXoay->mau0.dd;
      mauTo.p = hoaTietOcXoay->mau0.p;
   }
   else {
      if( goc < banKinh )
         goc += 6.283184f;
      else if( goc > banKinh )
         goc -= 6.283184f;
      if( (goc < banKinh + nuaBeRongNet) && (goc > banKinh - nuaBeRongNet ) ) {
         mauTo.d = hoaTietOcXoay->mau0.d;
         mauTo.l = hoaTietOcXoay->mau0.l;
         mauTo.x = hoaTietOcXoay->mau0.x;
         mauTo.dd = hoaTietOcXoay->mau0.dd;
         mauTo.p = hoaTietOcXoay->mau0.p;
      }
      else {
         mauTo.d = hoaTietOcXoay->mau1.d;
         mauTo.l = hoaTietOcXoay->mau1.l;
         mauTo.x = hoaTietOcXoay->mau1.x;
         mauTo.dd = hoaTietOcXoay->mau1.dd;
         mauTo.p = hoaTietOcXoay->mau1.p;
      }
   }
   //   printf( "goc %5.3f  banKinh %5.3f %5.3f  soVong %d  mauTo %5.3f\n", goc, banKinh - 0.5f*beRongNet, banKinh + 0.5f*beRongNet, soVong, mauTo.d);
   
   return mauTo;
}

