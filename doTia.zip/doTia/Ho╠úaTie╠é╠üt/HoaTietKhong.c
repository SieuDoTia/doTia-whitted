#include "HoaTietKhong.h"

#pragma mark ---- Họa Tiết Không
HoaTietKhong datHoaTietKhong( Mau *mau ) {
   HoaTietKhong hoaTietKhong;
   hoaTietKhong.mau.d = mau->d;
   hoaTietKhong.mau.l = mau->l;
   hoaTietKhong.mau.x = mau->x;
   hoaTietKhong.mau.dd = mau->dd;
   hoaTietKhong.mau.p = mau->p;

   return hoaTietKhong;
}
