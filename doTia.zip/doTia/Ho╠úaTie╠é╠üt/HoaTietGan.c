#include "HoaTietGan.h"
#include <math.h>

#pragma mark ---- Họa Tiết Gằn
HoaTietGan datHoaTietGan( Mau *mauTren, Mau *mauDuoi, float beCaoTren, float beCaoDuoi ) {
   
   HoaTietGan hoaTietGan;
   hoaTietGan.mauTren.d = mauTren->d;
   hoaTietGan.mauTren.l = mauTren->l;
   hoaTietGan.mauTren.x = mauTren->x;
   hoaTietGan.mauTren.dd = mauTren->dd;
   hoaTietGan.mauTren.p = mauTren->p;

   hoaTietGan.mauDuoi.d = mauDuoi->d;
   hoaTietGan.mauDuoi.l = mauDuoi->l;
   hoaTietGan.mauDuoi.x = mauDuoi->x;
   hoaTietGan.mauDuoi.dd = mauDuoi->dd;
   hoaTietGan.mauDuoi.p = mauDuoi->p;

   hoaTietGan.beCaoTren = beCaoTren;
   hoaTietGan.beCaoDuoi = beCaoDuoi;

   return hoaTietGan;
}

Mau hoaTietGan( float toaDo, HoaTietGan *hoaTietGan ) {
   
   // ---- tính bề cao cả hai lớp
   float beCaoHaiLop = hoaTietGan->beCaoTren + hoaTietGan->beCaoDuoi;
   // ---- tính số dư đơn vị hóa
   int so = floor(toaDo/beCaoHaiLop);
   // ---- tính số dư
   float du = (toaDo - so*beCaoHaiLop)/beCaoHaiLop;

   Mau mauTo;
   if( du < hoaTietGan->beCaoDuoi ) {
      mauTo.d = hoaTietGan->mauDuoi.d;
      mauTo.l = hoaTietGan->mauDuoi.l;
      mauTo.x = hoaTietGan->mauDuoi.x;
      mauTo.dd = hoaTietGan->mauDuoi.dd;
      mauTo.p = hoaTietGan->mauDuoi.p;
   }
   else {
      mauTo.d = hoaTietGan->mauTren.d;
      mauTo.l = hoaTietGan->mauTren.l;
      mauTo.x = hoaTietGan->mauTren.x;
      mauTo.dd = hoaTietGan->mauTren.dd;
      mauTo.p = hoaTietGan->mauTren.p;
   }

   return mauTo;
}
