#pragma once

#include "../Mau.h"

/* Họa Tiết Không */
typedef struct {
   Mau mau;     // màu
} HoaTietKhong;


// ---- không (màu đều)
HoaTietKhong datHoaTietKhong( Mau *mau );