#pragma once

#include "../Mau.h"
#include "../Toán/Vecto.h"

/* Họ Tiết Chấm Bi */
typedef struct {
   Mau mauNen;            // màu nền
   Mau mangMau[48];       // mảng màu cho chấm bi
   float mangBanKinh[48]; // mảng bán kính cho chấm bi
   Vecto mangVecto[48];   // mảng vectơ (vị trí cho chấm bi)
} HoaTietChamBi;

// ---- chấm bị
HoaTietChamBi datHoaTietChamBi( Mau *mauNen, Mau *mauThap, Mau *mauCao );
Mau hoaTietChamBi( Vecto *viTri, HoaTietChamBi *hoaTietChamBi );