// Ca Rô Sóng 2559-11-19
#include "HoaTietCaRoSong.h"
#include <math.h>


#pragma mark ---- Họa Tiết Ca Rô Sóng
HoaTietCaRoSong datHoaTietCaRoSong( Mau *mau0, Mau *mau1, float beRong, float beCao, float beDai, float bienDo, float tanSo ) {
   HoaTietCaRoSong hoaTietCaRoSong;
   hoaTietCaRoSong.mau0.d = mau0->d;
   hoaTietCaRoSong.mau0.l = mau0->l;
   hoaTietCaRoSong.mau0.x = mau0->x;
   hoaTietCaRoSong.mau0.dd = mau0->dd;
   hoaTietCaRoSong.mau0.p = mau0->p;
   
   hoaTietCaRoSong.mau1.d = mau1->d;
   hoaTietCaRoSong.mau1.l = mau1->l;
   hoaTietCaRoSong.mau1.x = mau1->x;
   hoaTietCaRoSong.mau1.dd = mau1->dd;
   hoaTietCaRoSong.mau1.p = mau1->p;
   
   hoaTietCaRoSong.beRong = beRong;
   hoaTietCaRoSong.beCao = beCao;
   hoaTietCaRoSong.beDai = beDai;
   
   hoaTietCaRoSong.bienDo = bienDo;
   hoaTietCaRoSong.tanSo = tanSo;
   
   return hoaTietCaRoSong;
}

Mau hoaTietCaRoSong( Vecto *viTri, HoaTietCaRoSong *hoaTietCaRoSong ) {
   
   float bienDo = hoaTietCaRoSong->bienDo;
   float tanSo = hoaTietCaRoSong->tanSo;
   int soX = ceilf((viTri->x + bienDo*sinf( tanSo*viTri->z ))/hoaTietCaRoSong->beRong);
   int soY = ceilf((viTri->y)/hoaTietCaRoSong->beCao);
   int soZ = ceilf((viTri->z + bienDo*sinf( tanSo*viTri->x ))/hoaTietCaRoSong->beDai);
   
   Mau mauCaRoSong;
   
   if( soY & 0x01 ){
      if( ((soX & 0x01) && (soZ & 0x01)) || (!(soX & 0x01) && !(soZ & 0x01))  ) {
         mauCaRoSong.d = hoaTietCaRoSong->mau1.d;
         mauCaRoSong.l = hoaTietCaRoSong->mau1.l;
         mauCaRoSong.x = hoaTietCaRoSong->mau1.x;
         mauCaRoSong.dd = hoaTietCaRoSong->mau1.dd;
         mauCaRoSong.p = hoaTietCaRoSong->mau1.p;
      }
      else {
         mauCaRoSong.d = hoaTietCaRoSong->mau0.d;
         mauCaRoSong.l = hoaTietCaRoSong->mau0.l;
         mauCaRoSong.x = hoaTietCaRoSong->mau0.x;
         mauCaRoSong.dd = hoaTietCaRoSong->mau0.dd;
         mauCaRoSong.p = hoaTietCaRoSong->mau0.p;
      }
   }
   else {
      if( ((soX & 0x01) && (soZ & 0x01)) || (!(soX & 0x01) && !(soZ & 0x01))  ) {
         mauCaRoSong.d = hoaTietCaRoSong->mau0.d;
         mauCaRoSong.l = hoaTietCaRoSong->mau0.l;
         mauCaRoSong.x = hoaTietCaRoSong->mau0.x;
         mauCaRoSong.dd = hoaTietCaRoSong->mau0.dd;
         mauCaRoSong.p = hoaTietCaRoSong->mau0.p;
      }
      else {
         mauCaRoSong.d = hoaTietCaRoSong->mau1.d;
         mauCaRoSong.l = hoaTietCaRoSong->mau1.l;
         mauCaRoSong.x = hoaTietCaRoSong->mau1.x;
         mauCaRoSong.dd = hoaTietCaRoSong->mau1.dd;
         mauCaRoSong.p = hoaTietCaRoSong->mau1.p;
      }
   }
   
   return mauCaRoSong;
}
