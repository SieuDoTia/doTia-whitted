#include "HoaTietVongTron.h"

#pragma mark ---- Họa Tiết Vòng Tròn
HoaTietVongTron datHoaTietVongTron( Mau *mauNoi, Mau *mauNgoai, float banKinh ) {
   HoaTietVongTron hoaTietVongTron;
   hoaTietVongTron.mauNoi.d = mauNoi->d;
   hoaTietVongTron.mauNoi.l = mauNoi->l;
   hoaTietVongTron.mauNoi.x = mauNoi->x;
   hoaTietVongTron.mauNoi.dd = mauNoi->dd;
   hoaTietVongTron.mauNoi.p = mauNoi->p;

   hoaTietVongTron.mauNgoai.d = mauNgoai->d;
   hoaTietVongTron.mauNgoai.l = mauNgoai->l;
   hoaTietVongTron.mauNgoai.x = mauNgoai->x;
   hoaTietVongTron.mauNgoai.dd = mauNgoai->dd;
   hoaTietVongTron.mauNgoai.p = mauNgoai->p;
   
   hoaTietVongTron.banKinh = banKinh;
   return hoaTietVongTron;
}

Mau hoaTietVongTron( Vecto *viTri, HoaTietVongTron *hoaTietVongTron ) {

   // ---- chọn màu
   Mau mauTo;
   if( viTri->x*viTri->x + viTri->z*viTri->z < hoaTietVongTron->banKinh*hoaTietVongTron->banKinh ) {
      mauTo.d = hoaTietVongTron->mauNoi.d;
      mauTo.l = hoaTietVongTron->mauNoi.l;
      mauTo.x = hoaTietVongTron->mauNoi.x;
      mauTo.dd = hoaTietVongTron->mauNoi.dd;
      mauTo.p = hoaTietVongTron->mauNoi.p;
   }
   else {
      mauTo.d = hoaTietVongTron->mauNgoai.d;
      mauTo.l = hoaTietVongTron->mauNgoai.l;
      mauTo.x = hoaTietVongTron->mauNgoai.x;
      mauTo.dd = hoaTietVongTron->mauNgoai.dd;
      mauTo.p = hoaTietVongTron->mauNgoai.p;
   }
   
   return mauTo;
}
