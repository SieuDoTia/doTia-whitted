#pragma once

#include "../Mau.h"
#include "../Toán/Vecto.h"

/* Họa Tiết Bầu Trời */
typedef struct {
   Mau mauDinhTroi;       // màu đỉnh trời
   Mau mauChanTroiTay;    // màu chân trời tây
   Mau mauChanTroiDong;   // màu chân trời đậng
   float gocXoayChanTroi; // góc xoay chân trời
} HoaTietBauTroi;

// ---- bầu trời
HoaTietBauTroi datHoaTietBauTroi( Mau *mauDinhToi, Mau *mauChanTroiTay, Mau *mauChanTroiDong, float gocXoayChanTroi );
Mau hoaTietBauTroi( Vecto huongTia, HoaTietBauTroi *hoaTietBauTroi );