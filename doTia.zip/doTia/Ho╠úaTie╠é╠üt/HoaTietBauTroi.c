#include "HoaTietBauTroi.h"
#include <math.h>

#pragma mark ---- Họa Tiết Bầu Trời
HoaTietBauTroi datHoaTietBauTroi( Mau *mauDinhTroi, Mau *mauChanTroiTay, Mau *mauChanTroiDong, float gocXoayChanTroi ) {
   
   HoaTietBauTroi hoaTietBauTroi;
   hoaTietBauTroi.mauDinhTroi.d = mauDinhTroi->d;
   hoaTietBauTroi.mauDinhTroi.l = mauDinhTroi->l;
   hoaTietBauTroi.mauDinhTroi.x = mauDinhTroi->x;
   hoaTietBauTroi.mauDinhTroi.dd = mauDinhTroi->dd;
   hoaTietBauTroi.mauDinhTroi.p = mauDinhTroi->p;
   
   hoaTietBauTroi.mauChanTroiTay.d = mauChanTroiTay->d;
   hoaTietBauTroi.mauChanTroiTay.l = mauChanTroiTay->l;
   hoaTietBauTroi.mauChanTroiTay.x = mauChanTroiTay->x;
   hoaTietBauTroi.mauChanTroiTay.dd = mauChanTroiTay->dd;
   hoaTietBauTroi.mauChanTroiTay.p = mauChanTroiTay->p;
   
   hoaTietBauTroi.mauChanTroiDong.d = mauChanTroiDong->d;
   hoaTietBauTroi.mauChanTroiDong.l = mauChanTroiDong->l;
   hoaTietBauTroi.mauChanTroiDong.x = mauChanTroiDong->x;
   hoaTietBauTroi.mauChanTroiDong.dd = mauChanTroiDong->dd;
   hoaTietBauTroi.mauChanTroiDong.p = mauChanTroiDong->p;
   
   hoaTietBauTroi.gocXoayChanTroi = gocXoayChanTroi;
   
   return hoaTietBauTroi;
}

// tính màu theo hướng
//          -----
//        -       -
//      /           \
//     /             \
// TÂY +-π----+----0-+ ĐÔNG
//     \             /
//      \           /
//        -       -
//          -----
//
Mau hoaTietBauTroi( Vecto huongTia, HoaTietBauTroi *hoaTietBauTroi ) {
   
   donViHoa( &huongTia );
   
   float banKinh = sqrtf( huongTia.x*huongTia.x + huongTia.z*huongTia.z );
   
   // ---- tính góc
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atan( huongTia.z/huongTia.x );
   
   // ---- giữ 0 ≤ góc ≤ 2π
   if( huongTia.x < 0.0f )
      goc += 3.141592f;
   else
      if( huongTia.z < 0.0f )
         goc += 6.283184f;

   // ---- phạm vi 0 ≤ 2
   goc /= 3.141592f;
   
   // ---- tính màu chân trời
   Mau mauChanTroi;
   if( goc < 1.0f ) {
      float nghichGoc = 1.0f - goc;
      mauChanTroi.d = nghichGoc*hoaTietBauTroi->mauChanTroiDong.d + goc*hoaTietBauTroi->mauChanTroiTay.d;
      mauChanTroi.l = nghichGoc*hoaTietBauTroi->mauChanTroiDong.l + goc*hoaTietBauTroi->mauChanTroiTay.l;
      mauChanTroi.x = nghichGoc*hoaTietBauTroi->mauChanTroiDong.x + goc*hoaTietBauTroi->mauChanTroiTay.x;
      mauChanTroi.dd = nghichGoc*hoaTietBauTroi->mauChanTroiDong.dd + goc*hoaTietBauTroi->mauChanTroiTay.dd;
      mauChanTroi.p = nghichGoc*hoaTietBauTroi->mauChanTroiDong.p + goc*hoaTietBauTroi->mauChanTroiTay.p;
   }
   else {
      goc -= 1.0f;
      float nghichGoc = 1.0f - goc;
      mauChanTroi.d = nghichGoc*hoaTietBauTroi->mauChanTroiDong.d + goc*hoaTietBauTroi->mauChanTroiTay.d;
      mauChanTroi.l = nghichGoc*hoaTietBauTroi->mauChanTroiDong.l + goc*hoaTietBauTroi->mauChanTroiTay.l;
      mauChanTroi.x = nghichGoc*hoaTietBauTroi->mauChanTroiDong.x + goc*hoaTietBauTroi->mauChanTroiTay.x;
      mauChanTroi.dd = nghichGoc*hoaTietBauTroi->mauChanTroiDong.dd + goc*hoaTietBauTroi->mauChanTroiTay.dd;
      mauChanTroi.p = nghichGoc*hoaTietBauTroi->mauChanTroiDong.p + goc*hoaTietBauTroi->mauChanTroiTay.p;
   }
   
   Mau mauTroi;
   // ---- màu chân trời cho hướng dưới chên trời
   if( huongTia.y < 0.0f ) {
      mauTroi.d = mauChanTroi.d;
      mauTroi.l = mauChanTroi.l;
      mauTroi.x = mauChanTroi.x;
      mauTroi.dd = mauChanTroi.dd;
      mauTroi.p = mauChanTroi.p;
   }
   else {   // bầu trời
      float tiSoChanTroi = 1.0f - huongTia.y;
      tiSoChanTroi = powf( tiSoChanTroi, 8.0f );
      float nghichTiSoChanTroi = 1.0f - tiSoChanTroi;
      mauTroi.d = tiSoChanTroi*mauChanTroi.d + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.d;
      mauTroi.l = tiSoChanTroi*mauChanTroi.l + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.l;
      mauTroi.x = tiSoChanTroi*mauChanTroi.x + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.x;
      mauTroi.dd = tiSoChanTroi*mauChanTroi.dd + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.dd;
      mauTroi.p = tiSoChanTroi*mauChanTroi.p + nghichTiSoChanTroi*hoaTietBauTroi->mauDinhTroi.p;
   }

   return mauTroi;
}
