#pragma once
#include "../Mau.h"
#include "../Toán/Vecto.h"

/* Họa Tiết Quằn Sọc Phai */
typedef struct {
   Mau mauNen;     // màu nền
   Mau mauQuan0;   // màu quằn 0
   Mau mauQuan1;   // màu quằn 1
   Mau mauQuan2;   // màu quằn 2
   float phanQuan0;     // phần số quằn 0
   float phanQuan1;     // phần số quằn 1
   float phanQuan2;     // phần số quằn 2
   float tanSo;         // tân số
   float bienDo;        // biên độ
   float dich;          // địch xoay
   float soLapVong;     // số lặp vòng
   float doanVong;          // đoạn vòng = 2π/số lặp vòng
   float banKinhBatDauPhai;  // bán kính bắt đầu phai
   float banKinhKetThucPhai; // bán kính kết thúc phai
   float doanPhai;      // đoạn vòng = bán kính kết thúc phai - bán kính bắt đầu phai
} HoaTietQuanSongTiaPhai;


// ---- quằn sóng tia phai
HoaTietQuanSongTiaPhai datHoaTietQuanSongTiaPhai( Mau *mauNen, Mau *mauQuan0, Mau *mauQuan1, Mau *mauQuan2, float phanQuan0, float phanQuan1, float phanQuan2, float tanSo, float bienDo, float dich, unsigned char soLapVong, float banKinhBatDauPhai, float banKinhKetThucPhai );
Mau hoaTietQuanSongTiaPhai( Vecto *viTri, HoaTietQuanSongTiaPhai *HoaTietQuanSongTiaPhai );