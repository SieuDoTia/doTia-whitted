#include "HoaTietQuanSongTrucZ.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#pragma mark ---- Họa Tiết Quần Sóng Trục Z
HoaTietQuanSongTrucZ datHoaTietQuanSongTrucZ( Mau *mauNen, Mau *mauQuan0, Mau *mauQuan1, Mau *mauQuan2, float phanQuan0, float phanQuan1, float phanQuan2, float tanSo, float bienDo, float dich, unsigned char soLapVong ) {

   HoaTietQuanSongTrucZ hoaTietQuanSongTrucZ;
   // ---- màu nền
   hoaTietQuanSongTrucZ.mauNen.d = mauNen->d;
   hoaTietQuanSongTrucZ.mauNen.l = mauNen->l;
   hoaTietQuanSongTrucZ.mauNen.x = mauNen->x;
   hoaTietQuanSongTrucZ.mauNen.dd = mauNen->dd;
   hoaTietQuanSongTrucZ.mauNen.p = mauNen->p;
   // ---- màu quằn 0
   hoaTietQuanSongTrucZ.mauQuan0.d = mauQuan0->d;
   hoaTietQuanSongTrucZ.mauQuan0.l = mauQuan0->l;
   hoaTietQuanSongTrucZ.mauQuan0.x = mauQuan0->x;
   hoaTietQuanSongTrucZ.mauQuan0.dd = mauQuan0->dd;
   hoaTietQuanSongTrucZ.mauQuan0.p = mauQuan0->p;
   // ---- màu quằn 1
   hoaTietQuanSongTrucZ.mauQuan1.d = mauQuan1->d;
   hoaTietQuanSongTrucZ.mauQuan1.l = mauQuan1->l;
   hoaTietQuanSongTrucZ.mauQuan1.x = mauQuan1->x;
   hoaTietQuanSongTrucZ.mauQuan1.dd = mauQuan1->dd;
   hoaTietQuanSongTrucZ.mauQuan1.p = mauQuan1->p;
   // ---- màu quằn 1
   hoaTietQuanSongTrucZ.mauQuan2.d = mauQuan2->d;
   hoaTietQuanSongTrucZ.mauQuan2.l = mauQuan2->l;
   hoaTietQuanSongTrucZ.mauQuan2.x = mauQuan2->x;
   hoaTietQuanSongTrucZ.mauQuan2.dd = mauQuan2->dd;
   hoaTietQuanSongTrucZ.mauQuan2.p = mauQuan2->p;
   // ---- phân số cho quằn
   hoaTietQuanSongTrucZ.phanQuan0 = phanQuan0;
   hoaTietQuanSongTrucZ.phanQuan1 = phanQuan1;
   hoaTietQuanSongTrucZ.phanQuan2 = phanQuan2;
   // ---- tần số
   hoaTietQuanSongTrucZ.tanSo = tanSo;
   // ---- biên độ
   hoaTietQuanSongTrucZ.bienDo = bienDo;
   // ---- dịch xoay
   hoaTietQuanSongTrucZ.dich = dich;
   // ---- tính đoạn
   if( soLapVong < 2 )
      soLapVong = 2;
   hoaTietQuanSongTrucZ.soLapVong = soLapVong;
   hoaTietQuanSongTrucZ.doan = 6.283184f/(float)soLapVong;
   return hoaTietQuanSongTrucZ;
}

Mau hoaTietQuanSongTrucZ( Vecto *viTri, HoaTietQuanSongTrucZ *hoaTietQuanSongTrucZ ) {
   
   // ---- tính góc
   float banKinh = viTri->x*viTri->x + viTri->z*viTri->z;
   
   // ---- tính góc
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atanf( viTri->z/viTri->x );
   
   // ---- giữ 0 ≤ góc ≤ 2π
   if( viTri->x < 0.0f )
      goc += 3.141592f;
   else
      if( viTri->z < 0.0f )
         goc += 6.283184f;
   
   goc += hoaTietQuanSongTrucZ->dich + hoaTietQuanSongTrucZ->bienDo*sinf( viTri->y*hoaTietQuanSongTrucZ->tanSo );
   if( goc < 0.0f )
      goc += 6.283184f;
   else if( goc > 6.283184f )
      goc -= 6.283184f;
   
   // ---- 0,0 đến 1,0
   goc /= hoaTietQuanSongTrucZ->doan;
   // ---- cần phần số
   goc -= floorf(goc);
   if( goc > 1.0f )
      exit(0);
   
   Mau mau;
   if( goc < 0.333333f ) {
      if( goc < 0.333333f - hoaTietQuanSongTrucZ->phanQuan0 ) {
         mau.d = hoaTietQuanSongTrucZ->mauNen.d;
         mau.l = hoaTietQuanSongTrucZ->mauNen.l;
         mau.x = hoaTietQuanSongTrucZ->mauNen.x;
         mau.dd = hoaTietQuanSongTrucZ->mauNen.dd;
         mau.p = hoaTietQuanSongTrucZ->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanSongTrucZ->mauQuan0.d;
         mau.l = hoaTietQuanSongTrucZ->mauQuan0.l;
         mau.x = hoaTietQuanSongTrucZ->mauQuan0.x;
         mau.dd = hoaTietQuanSongTrucZ->mauQuan0.dd;
         mau.p = hoaTietQuanSongTrucZ->mauQuan0.p;
      }
   }
   else if( goc < 0.666667f ) {
      if( goc < 0.666667f - hoaTietQuanSongTrucZ->phanQuan1 ) {
         mau.d = hoaTietQuanSongTrucZ->mauNen.d;
         mau.l = hoaTietQuanSongTrucZ->mauNen.l;
         mau.x = hoaTietQuanSongTrucZ->mauNen.x;
         mau.dd = hoaTietQuanSongTrucZ->mauNen.dd;
         mau.p = hoaTietQuanSongTrucZ->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanSongTrucZ->mauQuan1.d;
         mau.l = hoaTietQuanSongTrucZ->mauQuan1.l;
         mau.x = hoaTietQuanSongTrucZ->mauQuan1.x;
         mau.dd = hoaTietQuanSongTrucZ->mauQuan1.dd;
         mau.p = hoaTietQuanSongTrucZ->mauQuan1.p;
      }
   }
   else {
      if( goc < 1.0f - hoaTietQuanSongTrucZ->phanQuan2 ) {
         mau.d = hoaTietQuanSongTrucZ->mauNen.d;
         mau.l = hoaTietQuanSongTrucZ->mauNen.l;
         mau.x = hoaTietQuanSongTrucZ->mauNen.x;
         mau.dd = hoaTietQuanSongTrucZ->mauNen.dd;
         mau.p = hoaTietQuanSongTrucZ->mauNen.p;
      }
      else {
         mau.d = hoaTietQuanSongTrucZ->mauQuan2.d;
         mau.l = hoaTietQuanSongTrucZ->mauQuan2.l;
         mau.x = hoaTietQuanSongTrucZ->mauQuan2.x;
         mau.dd = hoaTietQuanSongTrucZ->mauQuan2.dd;
         mau.p = hoaTietQuanSongTrucZ->mauQuan2.p;
      }
   }
   
   return mau;
}
