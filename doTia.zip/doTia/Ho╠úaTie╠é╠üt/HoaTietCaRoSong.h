// Ca Rô Sóng 2559-11-19
#pragma once

#include "../Mau.h"
#include "../Toán/Vecto.h"

/* Họa Tiết Ca Rô Sóng */
typedef struct {
   Mau mau0;     // màu0
   Mau mau1;     // màu1
   float beRong; // bề rộng (x)
   float beCao;  // bề dài (y)
   float beDai;  // bề dài (z)
   float bienDo; // biên độ - hướng x, z giống
   float tanSo;  // tần số - hướng x, z giống
} HoaTietCaRoSong;


HoaTietCaRoSong datHoaTietCaRoSong( Mau *mau0, Mau *mau1, float beRong, float beCao, float beDai, float bienDo, float tanSo );
Mau hoaTietCaRoSong( Vecto *viTri, HoaTietCaRoSong *hoaTietCaoSong ); // họa tiết ca rô sóng
