#include "HoaTietQuanSongTiaPhai.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#pragma mark ---- Họa Tiết Quằn Sóng Tia Phai
HoaTietQuanSongTiaPhai datHoaTietQuanSongTiaPhai( Mau *mauNen, Mau *mauQuan0, Mau *mauQuan1, Mau *mauQuan2, float phanQuan0, float phanQuan1, float phanQuan2, float tanSo, float bienDo, float dich, unsigned char soLapVong, float banKinhBatDauPhai, float banKinhKetThucPhai ) {

   HoaTietQuanSongTiaPhai hoaTietQuanSongTiaPhai;
   // ---- màu nền
   hoaTietQuanSongTiaPhai.mauNen.d = mauNen->d;
   hoaTietQuanSongTiaPhai.mauNen.l = mauNen->l;
   hoaTietQuanSongTiaPhai.mauNen.x = mauNen->x;
   hoaTietQuanSongTiaPhai.mauNen.dd = mauNen->dd;
   hoaTietQuanSongTiaPhai.mauNen.p = mauNen->p;
   // ---- màu quằn 0
   hoaTietQuanSongTiaPhai.mauQuan0.d = mauQuan0->d;
   hoaTietQuanSongTiaPhai.mauQuan0.l = mauQuan0->l;
   hoaTietQuanSongTiaPhai.mauQuan0.x = mauQuan0->x;
   hoaTietQuanSongTiaPhai.mauQuan0.dd = mauQuan0->dd;
   hoaTietQuanSongTiaPhai.mauQuan0.p = mauQuan0->p;
   // ---- màu quằn 1
   hoaTietQuanSongTiaPhai.mauQuan1.d = mauQuan1->d;
   hoaTietQuanSongTiaPhai.mauQuan1.l = mauQuan1->l;
   hoaTietQuanSongTiaPhai.mauQuan1.x = mauQuan1->x;
   hoaTietQuanSongTiaPhai.mauQuan1.dd = mauQuan1->dd;
   hoaTietQuanSongTiaPhai.mauQuan1.p = mauQuan1->p;
   // ---- màu quằn 1
   hoaTietQuanSongTiaPhai.mauQuan2.d = mauQuan2->d;
   hoaTietQuanSongTiaPhai.mauQuan2.l = mauQuan2->l;
   hoaTietQuanSongTiaPhai.mauQuan2.x = mauQuan2->x;
   hoaTietQuanSongTiaPhai.mauQuan2.dd = mauQuan2->dd;
   hoaTietQuanSongTiaPhai.mauQuan2.p = mauQuan2->p;
   // ---- phân số cho quằn
   hoaTietQuanSongTiaPhai.phanQuan0 = phanQuan0;
   hoaTietQuanSongTiaPhai.phanQuan1 = phanQuan1;
   hoaTietQuanSongTiaPhai.phanQuan2 = phanQuan2;
   // ---- tần số
   hoaTietQuanSongTiaPhai.tanSo = tanSo;
   // ---- biên độ
   hoaTietQuanSongTiaPhai.bienDo = bienDo;
   // ---- dịch xoay
   hoaTietQuanSongTiaPhai.dich = dich;
   // ---- tính đoạn
   if( soLapVong < 2 )
      soLapVong = 2;
   hoaTietQuanSongTiaPhai.soLapVong = soLapVong;
   hoaTietQuanSongTiaPhai.doanVong = 6.283184f/(float)soLapVong;
   
   // ---- bán kính bắt đầu và kết thúc phai màu
   hoaTietQuanSongTiaPhai.banKinhBatDauPhai = banKinhBatDauPhai*banKinhBatDauPhai;
   hoaTietQuanSongTiaPhai.banKinhKetThucPhai = banKinhKetThucPhai*banKinhKetThucPhai;
   hoaTietQuanSongTiaPhai.doanPhai = hoaTietQuanSongTiaPhai.banKinhKetThucPhai - hoaTietQuanSongTiaPhai.banKinhBatDauPhai;

   return hoaTietQuanSongTiaPhai;
}

Mau hoaTietQuanSongTiaPhai( Vecto *viTri, HoaTietQuanSongTiaPhai *hoaTietQuanSongTiaPhai ) {
   
   // ---- tính góc
   float banKinh = viTri->x*viTri->x + viTri->z*viTri->z;
   
   // ---- tính góc
   float goc = 0.0f;
   if( banKinh != 0.0f )
      goc = atanf( viTri->z/viTri->x );
   
   // ---- giữ 0 ≤ góc ≤ 2π
   if( viTri->x < 0.0f )
      goc += 3.141592f;
   else
      if( viTri->z < 0.0f )
         goc += 6.283184f;
   
   goc += hoaTietQuanSongTiaPhai->dich + hoaTietQuanSongTiaPhai->bienDo*sinf( banKinh*hoaTietQuanSongTiaPhai->tanSo );
   if( goc < 0.0f )
      goc += 6.283184f;
   else if( goc > 6.283184f )
      goc -= 6.283184f;
   
   // ---- 0,0 đến 1,0
   goc /= hoaTietQuanSongTiaPhai->doanVong;
   // ---- cần phần số
   goc -= floorf(goc);
   if( goc > 1.0f ){
      printf( "hoaTietQuanSongTiaPhai: góc > 1\n" );
      exit(0);
   }
   // ---- tìm màu
   Mau mau;
   if( goc < 0.333333f ) {

      if( (goc < 0.333333f - hoaTietQuanSongTiaPhai->phanQuan0) || (banKinh > hoaTietQuanSongTiaPhai->banKinhKetThucPhai) ) {
         mau.d = hoaTietQuanSongTiaPhai->mauNen.d;
         mau.l = hoaTietQuanSongTiaPhai->mauNen.l;
         mau.x = hoaTietQuanSongTiaPhai->mauNen.x;
         mau.dd = hoaTietQuanSongTiaPhai->mauNen.dd;
         mau.p = hoaTietQuanSongTiaPhai->mauNen.p;
      }
      else if( banKinh < hoaTietQuanSongTiaPhai->banKinhBatDauPhai ) {
         mau.d = hoaTietQuanSongTiaPhai->mauQuan0.d;
         mau.l = hoaTietQuanSongTiaPhai->mauQuan0.l;
         mau.x = hoaTietQuanSongTiaPhai->mauQuan0.x;
         mau.dd = hoaTietQuanSongTiaPhai->mauQuan0.dd;
         mau.p = hoaTietQuanSongTiaPhai->mauQuan0.p;
      }
      else {
         float tiSoMauSong = (banKinh - hoaTietQuanSongTiaPhai->banKinhBatDauPhai)/hoaTietQuanSongTiaPhai->doanPhai;
         float nghichTiSoMauSong = 1.0f - tiSoMauSong;
         mau.d = hoaTietQuanSongTiaPhai->mauNen.d*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan0.d*nghichTiSoMauSong;
         mau.l = hoaTietQuanSongTiaPhai->mauNen.l*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan0.l*nghichTiSoMauSong;
         mau.x = hoaTietQuanSongTiaPhai->mauNen.x*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan0.x*nghichTiSoMauSong;
         mau.dd = hoaTietQuanSongTiaPhai->mauNen.dd*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan0.dd*nghichTiSoMauSong;
         mau.p = hoaTietQuanSongTiaPhai->mauNen.p*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan0.p*nghichTiSoMauSong;
      }
   }
   else if( goc < 0.666667f ) {
      if( (goc < 0.666667f - hoaTietQuanSongTiaPhai->phanQuan1) || (banKinh > hoaTietQuanSongTiaPhai->banKinhKetThucPhai) ) {
         mau.d = hoaTietQuanSongTiaPhai->mauNen.d;
         mau.l = hoaTietQuanSongTiaPhai->mauNen.l;
         mau.x = hoaTietQuanSongTiaPhai->mauNen.x;
         mau.dd = hoaTietQuanSongTiaPhai->mauNen.dd;
         mau.p = hoaTietQuanSongTiaPhai->mauNen.p;
      }
      else if( banKinh < hoaTietQuanSongTiaPhai->banKinhBatDauPhai ) {
         mau.d = hoaTietQuanSongTiaPhai->mauQuan1.d;
         mau.l = hoaTietQuanSongTiaPhai->mauQuan1.l;
         mau.x = hoaTietQuanSongTiaPhai->mauQuan1.x;
         mau.dd = hoaTietQuanSongTiaPhai->mauQuan1.dd;
         mau.p = hoaTietQuanSongTiaPhai->mauQuan1.p;
      }
      else {
         float tiSoMauSong = (banKinh - hoaTietQuanSongTiaPhai->banKinhBatDauPhai)/hoaTietQuanSongTiaPhai->doanPhai;
         float nghichTiSoMauSong = 1.0f - tiSoMauSong;
         mau.d = hoaTietQuanSongTiaPhai->mauNen.d*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan1.d*nghichTiSoMauSong;
         mau.l = hoaTietQuanSongTiaPhai->mauNen.l*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan1.l*nghichTiSoMauSong;
         mau.x = hoaTietQuanSongTiaPhai->mauNen.x*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan1.x*nghichTiSoMauSong;
         mau.dd = hoaTietQuanSongTiaPhai->mauNen.dd*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan1.dd*nghichTiSoMauSong;
         mau.p = hoaTietQuanSongTiaPhai->mauNen.p*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan1.p*nghichTiSoMauSong;
      }
   }
   else {
      if( (goc < 1.0f - hoaTietQuanSongTiaPhai->phanQuan2) || (banKinh > hoaTietQuanSongTiaPhai->banKinhKetThucPhai) ) {
         mau.d = hoaTietQuanSongTiaPhai->mauNen.d;
         mau.l = hoaTietQuanSongTiaPhai->mauNen.l;
         mau.x = hoaTietQuanSongTiaPhai->mauNen.x;
         mau.dd = hoaTietQuanSongTiaPhai->mauNen.dd;
         mau.p = hoaTietQuanSongTiaPhai->mauNen.p;
      }
      else if( banKinh < hoaTietQuanSongTiaPhai->banKinhBatDauPhai ) {
         mau.d = hoaTietQuanSongTiaPhai->mauQuan2.d;
         mau.l = hoaTietQuanSongTiaPhai->mauQuan2.l;
         mau.x = hoaTietQuanSongTiaPhai->mauQuan2.x;
         mau.dd = hoaTietQuanSongTiaPhai->mauQuan2.dd;
         mau.p = hoaTietQuanSongTiaPhai->mauQuan2.p;
      }
      else {
         float tiSoMauSong = (banKinh - hoaTietQuanSongTiaPhai->banKinhBatDauPhai)/hoaTietQuanSongTiaPhai->doanPhai;
         float nghichTiSoMauSong = 1.0f - tiSoMauSong;
         mau.d = hoaTietQuanSongTiaPhai->mauNen.d*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan2.d*nghichTiSoMauSong;
         mau.l = hoaTietQuanSongTiaPhai->mauNen.l*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan2.l*nghichTiSoMauSong;
         mau.x = hoaTietQuanSongTiaPhai->mauNen.x*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan2.x*nghichTiSoMauSong;
         mau.dd = hoaTietQuanSongTiaPhai->mauNen.dd*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan2.dd*nghichTiSoMauSong;
         mau.p = hoaTietQuanSongTiaPhai->mauNen.p*tiSoMauSong + hoaTietQuanSongTiaPhai->mauQuan2.p*nghichTiSoMauSong;
      }
   }
   
   return mau;
}
