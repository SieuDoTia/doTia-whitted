#pragma once

#include "../Mau.h"
#include "../Toán/Vecto.h"
#include <math.h>

/* Họa Tiết Ngôi Sao Cầu */
typedef struct {
   Mau mauNen;            // màu nền
   Mau mangMau[48];       // mảng màu cho chấm bi
   float mangBanKinhRanh[48]; // mảng bán kính ranh cho ngôi sao, tích cỡ ngôi sao
   float mangBanKinhNgoai[48]; // mảng bán kính ranh cho ngôi sao, tích cỡ ngôi sao
   float mangBanKinhNoi[48]; // mảng bán kính ranh cho ngôi sao, tích cỡ ngôi sao
   Vecto mangVecto[48];   // mảng vectơ (vị trí cho ngôi sao trên mặt hình cầu)
   Vecto mangHuong0[48];   // mảng hướng 0 cho biết điểm trên mặt hình cầu tương đối với nan ngôi sao
   Vecto mangHuong1[48];   // mảng hướng 1 cho biết điểm trên mặt hình cầu tương đối với nan ngôi sao
   float goc;             // góc cho nan sao (để chọn số lượng nan sao)
   float nuaGoc;          // góc nữa góc giữa nan (cần cho biết dùng ranh nào của ngôi sao)
   float banKinhRanh;     // bán kính cho đường ranh giới, (đơn vị hóa tương đối với bán kính ngoài = 1,0f)
   float gocRanh;         // góc cho điềm cần nhất của rành giới, giống cho mỗi ngôi sao, không kể  
                             // tính tương đối với điểm xa = banKinhRanhNgoai tại góc = 0
} HoaTietNgoiSaoCau;


// ---- ngôi sao cầu
HoaTietNgoiSaoCau datHoaTietNgoiSaoCau( Mau *mauNen, Mau *mauThap, Mau *mauCao, float banKinhNoi, float banKinhNgoai, float chenhLech,  unsigned char soLuongNan );
Mau hoaTietNgoiSaoCau( Vecto *viTri, HoaTietNgoiSaoCau *hoaTietNgoiSaoCau );
void tinhBanKinhVaGocRanh( float *banKinh, float *gocRanh , float banKinhNoi, float banKinhNgoai, float nuaGoc );