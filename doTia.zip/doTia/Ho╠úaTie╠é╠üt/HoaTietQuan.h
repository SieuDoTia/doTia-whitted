#pragma once

#include "../Mau.h"
#include "../Toán/Vecto.h"


/* Họa Tiết Quằn */
typedef struct {
   Mau mauNen;        // màu nền
   Mau mangMau[16];   // mảng màu cho chấm bi
   float tanSo;       // tân số
   float soLuongQuan; // số lượng quăn
   float beRongQuan;  // bề rộng quằn
} HoaTietQuan;


// ---- quăn
HoaTietQuan datHoaTietQuan( Mau *mauNen, Mau *mauThap, Mau *mauCao );
Mau hoaTietQuan( Vecto *viTri, HoaTietQuan *hoaTietQuan );