#include "HoaTietKimTuyenLapLanh.h"
#include "../HangSo.h"
#include <stdlib.h>
#include <math.h>

#pragma mark ---- Họa Tiết Kim Tuyên Lấp Lánh
HoaTietKimTuyenLapLanh datHoaTietKimTuyenLapLanh( Mau *mau, float doLapLanh ) {
   HoaTietKimTuyenLapLanh hoaTietKimTuyenLapLanh;
   hoaTietKimTuyenLapLanh.mau.d = mau->d;
   hoaTietKimTuyenLapLanh.mau.l = mau->l;
   hoaTietKimTuyenLapLanh.mau.x = mau->x;
   hoaTietKimTuyenLapLanh.mau.dd = mau->dd;
   hoaTietKimTuyenLapLanh.mau.p = mau->p;

   hoaTietKimTuyenLapLanh.doLapLanh = doLapLanh;
   hoaTietKimTuyenLapLanh.nuaDoLapLanh = doLapLanh*0.5f;

   return hoaTietKimTuyenLapLanh;
}

Mau hoaTietKimTuyenLapLanh( HoaTietKimTuyenLapLanh *hoaTietKimTuyenLapLanh ) {
   
   float doLapLanh = hoaTietKimTuyenLapLanh->doLapLanh;
   float soNgauNhien = rand()/kSO_NGUYEN_TOI_DA;
//   float cach = soNgauNhien *hoaTietKimTuyenLapLanh->doLapLanh
//             - hoaTietKimTuyenLapLanh->nuaDoLapLanh;

   float phanPhoiExp = expf( -soNgauNhien*10.0f );
//   printf( "ngauNhien %5.3f   phanPhoiExp %5.3f\n", soNgauNhien, phanPhoiExp );
   Mau mau;
   mau.dd = hoaTietKimTuyenLapLanh->mau.dd;
   mau.p = hoaTietKimTuyenLapLanh->mau.p;
   
   //                         màu
   // đen +--------------------+----------+ trắng
   if( rand() & 0x01 ) {  // tối
      float cachDen = 1.0f - phanPhoiExp;
      mau.d = hoaTietKimTuyenLapLanh->mau.d*cachDen;
      mau.l = hoaTietKimTuyenLapLanh->mau.l*cachDen;
      mau.x = hoaTietKimTuyenLapLanh->mau.x*cachDen;
   }
   else {  // sáng, cho đến màu trắng
      float cachTrang = phanPhoiExp*hoaTietKimTuyenLapLanh->doLapLanh;
      mau.d = hoaTietKimTuyenLapLanh->mau.d + (1.0f - hoaTietKimTuyenLapLanh->mau.d)*cachTrang;
      mau.l = hoaTietKimTuyenLapLanh->mau.l + (1.0f - hoaTietKimTuyenLapLanh->mau.l)*cachTrang;
      mau.x = hoaTietKimTuyenLapLanh->mau.x + (1.0f - hoaTietKimTuyenLapLanh->mau.x)*cachTrang;
   }

//   printf( "mauHT %5.3f %5.3f %5.3f   mau %5.3f %5.3f %5.3f  cach %5.3f\n",
//          hoaTietKimTuyenLapLanh->mau.d, hoaTietKimTuyenLapLanh->mau.l, hoaTietKimTuyenLapLanh->mau.x,
//          mau.d, mau.l, mau.x, cach );
   return mau;
}
