#include "HoaTietKimTuyenLapLanh.h"
#include "../HangSo.h"
#include <stdlib.h>

#pragma mark ---- Họa Tiết Kim Tuyên Lấp Lánh
HoaTietKimTuyenLapLanh datHoaTietKimTuyenLapLanh( Mau *mau, float doLapLanh ) {
   HoaTietKimTuyenLapLanh hoaTietKimTuyenLapLanh;
   hoaTietKimTuyenLapLanh.mau.d = mau->d;
   hoaTietKimTuyenLapLanh.mau.l = mau->l;
   hoaTietKimTuyenLapLanh.mau.x = mau->x;
   hoaTietKimTuyenLapLanh.mau.dd = mau->dd;
   hoaTietKimTuyenLapLanh.mau.p = mau->p;

   hoaTietKimTuyenLapLanh.doLapLanh = doLapLanh;
   hoaTietKimTuyenLapLanh.nuaDoLapLanh = doLapLanh*0.5f;

   return hoaTietKimTuyenLapLanh;
}

Mau hoaTietKimTuyenLapLanh( HoaTietKimTuyenLapLanh *hoaTietKimTuyenLapLanh ) {
   
   float doLapLanh = hoaTietKimTuyenLapLanh->doLapLanh;
   float cach = (rand()/kSO_NGUYEN_TOI_DA)*hoaTietKimTuyenLapLanh->doLapLanh
   - hoaTietKimTuyenLapLanh->nuaDoLapLanh;
   
   Mau mau;
   mau.dd = hoaTietKimTuyenLapLanh->mau.dd;
   mau.p = hoaTietKimTuyenLapLanh->mau.p;
   
   //                         màu
   // đen +--------------------+----------+ trắng
   if( cach < 0.0f ) {  // tối
      float cachDen = 1.0f + cach;
      mau.d = hoaTietKimTuyenLapLanh->mau.d*cachDen;
      mau.l = hoaTietKimTuyenLapLanh->mau.l*cachDen;
      mau.x = hoaTietKimTuyenLapLanh->mau.x*cachDen;
   }
   else {  // sáng   (1-m)c + m = c - mc + m = (1 - c)m + c
      float cachTrang =  1.0f - cach;
      mau.d = cach + hoaTietKimTuyenLapLanh->mau.d*cachTrang;
      mau.l = cach + hoaTietKimTuyenLapLanh->mau.l*cachTrang;
      mau.x = cach + hoaTietKimTuyenLapLanh->mau.x*cachTrang;
   }

//   printf( "mauHT %5.3f %5.3f %5.3f   mau %5.3f %5.3f %5.3f  cach %5.3f\n",
//          hoaTietKimTuyenLapLanh->mau.d, hoaTietKimTuyenLapLanh->mau.l, hoaTietKimTuyenLapLanh->mau.x,
//          mau.d, mau.l, mau.x, cach );
   return mau;
}
