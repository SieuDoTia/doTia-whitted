#pragma once

#include "../Mau.h"
#include "../Toán/Vecto.h"

/* Họa Tiết Ốc Xoay */
typedef struct {
   Mau mau0;     // màu0
   Mau mau1;     // màu1hinhdang
   float phongTo;   // phóng to
   float beRongNet; // bề rộng nét
} HoaTietOcXoay;


// ---- óc xoáy
HoaTietOcXoay datHoaTietOcXoay( Mau *mau0, Mau *mau1, float beRongNet, float phongTo );
Mau hoaTietOcXoay( Vecto *viTri, HoaTietOcXoay *hoaTietOcXoay );  // hoạ tiết óc xoáy