#pragma once
#include "../Mau.h"
#include "../Toán/Vecto.h"

/* Họa Tiết Bông Vòng */
typedef struct {
   float banKinhBinhNoi;   // bán kính bình nội
   float banKinhBinhNgoai; // bán kính bình ngoại
   float banKinhBinhVanh;  // bán kính bình vành
   float banKinhVanh;      // bán kính vành
   Mau mauNen;     // màu nền
   Mau mauNoi;     // màu nội
   Mau mauNgoai;   // màu ngoại
   Mau mauVanh;    // màu cho vành ngoại

   float gocBongVong;     // góc cho một bông vòng (rad) tương đối với tâm vật thể
   float banKinhBinhBongVongNoi;   // bán kính bình cho bông vòng nọi
   float banKinhBinhBongVongNgoai; // bán kính bình cho bông vòng ngoại
   Mau mauBongVongNoi;     // màu nội
   Mau mauBongVongNgoai;   // màu ngoại
} HoaTietBongVong;


// ---- bông vòng
HoaTietBongVong datHoaTietBongVong( Mau *mauNen, Mau *mauNoi, Mau *mauNgoai, Mau *mauVanh, float banKinhNoi, float banKinhNgoai, float banKinhVanh, Mau *mauBongVongNoi, Mau *mauBongVongNgoai, float tiSoToBong, unsigned short soLuongBong );
Mau hoaTietBongVong( Vecto *viTri, HoaTietBongVong *hoaTietBongVong );