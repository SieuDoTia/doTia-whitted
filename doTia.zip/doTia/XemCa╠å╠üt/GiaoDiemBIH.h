#include "../VậtThể/VatThe.h"
#include "BaoBi.h"

// ---- Xài 3 bit thấp 
#define kTRUC_X 0x00   // 0 0 00
#define kTRUC_Y 0x01   // 0 0 01
#define kTRUC_Z 0x02   // 0 0 10
//#define kHOP    0x04   // 0 1 00
#define kLA     0x08   // 1 0 00

#define kBEN_TRAI  0
#define kBEN_PHAI  1

/* Giao Điểm */
typedef struct {
   int conTrai;   // con trái
   int conPhai;   // con phải
   unsigned char truc;  // trục
   union {
      unsigned int chiSoVatThe;
      float cat[2];  // mặt phẳng cắt
   };
} GiaoDiemBIH;

/* đặt lại mảng chi vật thể */
void datLaiMangChiVatThe( unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVatThe );

/* chia vật thể */
unsigned int chiaVatThe( VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVatThe, unsigned short chiSoVatThe, BaoBi *baoBi, unsigned int truc, float toaDoMatPhang, GiaoDiemBIH *mangGiaoDiem, unsigned int *soLuongGiaoDiem );

/* chia vật thể và tạo giao điểm */
GiaoDiemBIH chiaVatTheVaTaoGiaoDiem( VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVatThe, unsigned int truc,
                                    float toaDoMatPhang, unsigned short *soLuongTrai, unsigned short *soLuongPhai );

/* Tính trúc và mặ phẳng chia */
void tinhTrucVaToaMatPhangChia( BaoBi *baoBi, unsigned int *truc, float *toaDoMatPhang );