#pragma once
#include "BaoBi.h"
#include "../VậtThể/VatThe.h"


/* Tính bao bì thế giới cho danh sách vật thể */
BaoBi tinhBaoBiTGChoDanhSachVatThe( VatThe *danhSachVatThe, unsigned short soLuongVatThe );

/* tính bao bì thế giới cho vật thể */
void tinhBaoBiTGChoVatThe( VatThe *vatThe );

/* tính bao bì cho vật thể ghép, cũng xài cho vật thể bool */
void tinhBaoBiVTChoVatTheGhep( VatThe *vatThe );