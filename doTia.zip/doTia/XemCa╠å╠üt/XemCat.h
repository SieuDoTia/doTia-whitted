#pragma once
#include "GiaoDiemBIH.h"
#include "../Toán/Vecto.h"
#include "../Toán/Tia.h"
#include "../VậtThể/VatThe.h"
#include "../ThongTinToMau.h"

/* em tia có trúng vật thể gần nhất */
void xemTiaCoTrungVatTheGanNhat( GiaoDiemBIH *nhiCayGiaoDiem, unsigned short soLuongGiaoDiem, VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, Tia *tia, ThongTinToMau *thongTinToMauVatTheGanNhat );

/* Xem tia có trúng vật thể nào */
unsigned char xemTiaCoTrungVatTheNao( GiaoDiemBIH *nhiCayGiaoDiem, unsigned short soLuongGiaoDiem, VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, Tia *tia, ThongTinToMau *thongTinToMauBong, unsigned char *soLuongVatTheToMauBong );

/* Xem tia cắt mặt phẳng và trục */
unsigned char xemTiaCatMatPhangVaTruc( Tia *tia, float toaDoMatPhang, unsigned char truc, unsigned char ben );

/* Xem tiá có trúng trong không gian vật */
float xemTiaCoTrungVatTrongKhongGianVat( VatThe *vatThe, Tia *tia, Vecto *phapTuyen, Vecto *diemTrungTDVT );

/* Xem tia có trúng vật bool trong không gian vật */
float xemTiaCoTrungVatBoolTrongKhongGianVat( VatThe *danhSachVatTheBool, unsigned char soLuongVatThe, unsigned char mucDichBool, Tia *tia, Vecto *phapTuyen, Vecto *diemTrungTDVT );

/* Xem tia có trúng vật ghép trong không gian vật */
float xemTiaCoTrungVatGhepTrongKhongGianVat( VatThe *danhSachVatTheBool, unsigned char soLuongVatThe, Tia *tia, Vecto *phapTuyen, Vecto *diemTrungTDVT, unsigned char *soVatTheTrung );

/* Xem điểm trong vật thể */
unsigned char xemDiemTrongVatThe( VatThe *vatThe, Vecto *diem );


/* Thấy nguồn ánh sáng */
unsigned char thayNguonAnhSang( VatThe *danhSachVat, unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVat, Vecto *diemTrung, Vecto *huongAnhSang, ThongTinToMau *thongTinToMauBong, unsigned char *soLuongVatTheToMauBong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem );