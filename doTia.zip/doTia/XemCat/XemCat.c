#include "XemCat.h"
#include "../HangSo.h"
#include "../Toán/BienHoa.h"
#include <stdlib.h>

#pragma mark ---- Xem Tia Có Trúng Vật
#define kXEP_DONG_CUC_DAI 1024

void xemTiaCoTrungVatTheGanNhat( GiaoDiemBIH *nhiCayGiaoDiem, unsigned short soLuongGiaoDiem, VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, Tia *tia, ThongTinToMau *thongTinToMauVatTheGanNhat ) {
   
   GiaoDiemBIH xepDong[kXEP_DONG_CUC_DAI];   // xếp đống
   unsigned short chiSoXepDong = 0;
   float cachXaGanNhat = kVO_CUC;
//   printf( "  cay: tia %5.3f %5.3f %5.3f   %5.3f %5.3f %5.3f\n", tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z );
   // ---- nếu có giao điểm trong cây
   if( soLuongGiaoDiem > 0 ) {
      xepDong[0] = nhiCayGiaoDiem[0];
      chiSoXepDong = 1;

      while( chiSoXepDong > 0 ) {
         chiSoXepDong--;
         GiaoDiemBIH giaoDiem = xepDong[chiSoXepDong];
         unsigned char truc = giaoDiem.truc;
//         printf( "  truc %x  conTrai %d  conPhai %d\n", truc, giaoDiem.conTrai, giaoDiem.conPhai );

         // ---- xem không phải là lá
         if( truc != kLA ) {

            if( giaoDiem.conTrai != -1 ) {
               // ---- xem cắt mặt phẳng
               float toaDoMatPhang = giaoDiem.cat[0];
               unsigned char cat = xemTiaCatMatPhangVaTruc( tia, toaDoMatPhang, truc, kBEN_TRAI ); // toạ độ thế giới

               // ---- nếu cắt, bỏ con lên xếp đống
               if( cat ) {
                  xepDong[chiSoXepDong] = nhiCayGiaoDiem[giaoDiem.conTrai];
                  chiSoXepDong++;
               }
            }

            if( giaoDiem.conPhai != -1 ) {
               // ---- xem cắt mặt phẳng
               float toaDoMatPhang = giaoDiem.cat[1];
               unsigned char cat = xemTiaCatMatPhangVaTruc( tia, toaDoMatPhang, truc, kBEN_PHAI ); // toạ độ thế giới
               // ---- nếu cắt, bỏ con lên xếp đống
               if( cat ) {
                  xepDong[chiSoXepDong] = nhiCayGiaoDiem[giaoDiem.conPhai];
                  chiSoXepDong++;
               }
            }
            
            if( chiSoXepDong >= kXEP_DONG_CUC_DAI ) {
               printf( "xemTiaCoTrungVatTheGanNhat: SAI LẦM chiSoXepDong %d ra ngoài xếp đống: %d\n", chiSoXepDong, kXEP_DONG_CUC_DAI );
               exit(0);
            }

         }
         else {  // giao điểm lá
            VatThe *vatThe = &(danhSachVatThe[mangChiSoVatTheSapXep[giaoDiem.chiSoVatThe]]);
            Vecto diemTrungTDVT;
            Vecto phapTuyenTDVT;
            Tia tiaBienHoa;
            
            // ---- biến hóa tia đến không gian vật thể  [gốc]•[dịch]-1 •[xoay]-1 •[phóng to]-1
            tiaBienHoa.goc = nhanVectoVoiMaTran4x4( &(tia->goc), vatThe->nghichBienHoa );
            // ---- đừng dịch hướng, chỉ [hướng]•[xoay]-1 •[phóng to]-1
            tiaBienHoa.huong = nhanVectoVoiMaTran3x3( &(tia->huong), vatThe->nghichBienHoa );

            // ---- xem nếu tia có trúng vật này
            float cachXa = kVO_CUC;
            cachXa = xemTiaCoTrungVatTrongKhongGianVat( vatThe, &tiaBienHoa, &phapTuyenTDVT, &diemTrungTDVT );

            // ---- xem nếu có gần hơn vật thể trước
            if( cachXa < cachXaGanNhat ) {
               if( vatThe->loai != kLOAI_VAT_THE__GHEP ) {
                  thongTinToMauVatTheGanNhat->vatThe = vatThe;
               }
               else {
                  if( vatThe->xaiHoaThietVatTheGhep )
                     thongTinToMauVatTheGanNhat->vatThe = &(vatThe->danhSachVatThe[vatThe->soVatTheGhepTrung]);
                  else
                     thongTinToMauVatTheGanNhat->vatThe = vatThe;
                  
               }
               thongTinToMauVatTheGanNhat->cachXa = cachXa;
               cachXaGanNhat = cachXa;
               // ---- biến hóa pháp tuyến trờ lại tọa độ thế giới [pháp tuyến]•[phóng to]-1 •[xoay]
               thongTinToMauVatTheGanNhat->phapTuyenTDVT = phapTuyenTDVT;
               thongTinToMauVatTheGanNhat->diemTrungTDVT = diemTrungTDVT;
            }
         }
      }
   }
   else {
      thongTinToMauVatTheGanNhat->vatThe = NULL;
      thongTinToMauVatTheGanNhat->cachXa = kVO_CUC;
//      printf( "xemTiaCóTrúngVậtThểGầnNhất: SAI LẦM số lượng giao điểm == 0\n" );
      // không có vật thể, tia không trúng vật thể nào
      cachXaGanNhat = kVO_CUC;
   }

//   return cachXaGanNhat;
}

unsigned char xemTiaCoTrungVatTheNao( GiaoDiemBIH *nhiCayGiaoDiem, unsigned short soLuongGiaoDiem, VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, Tia *tia, ThongTinToMau *thongTinToMauBong, unsigned char *soLuongVatTheToMauBong ) {
   
   GiaoDiemBIH xepDong[256];   // xếp đống
   unsigned short chiSoXepDong = 0;
   float cachXaGanNhat = kVO_CUC;

   thongTinToMauBong->vatThe = NULL;
   //   printf( "  cay: tia %5.3f %5.3f %5.3f   %5.3f %5.3f %5.3f\n", tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z );
   // ---- nếu có giao điểm trong cây
   if( soLuongGiaoDiem > 0 ) {
      xepDong[0] = nhiCayGiaoDiem[0];
      chiSoXepDong = 1;
      
      while( chiSoXepDong > 0 ) {
         chiSoXepDong--;
         GiaoDiemBIH giaoDiem = xepDong[chiSoXepDong];
         unsigned char truc = giaoDiem.truc;
         //         printf( "  truc %x  conTrai %d  conPhai %d\n", truc, giaoDiem.conTrai, giaoDiem.conPhai );
         
         // ---- xem có
         if( truc != kLA ) {
            
            if( giaoDiem.conTrai != -1 ) {
               // ---- xem cắt mặt phẳng
               float toaDoMatPhang = giaoDiem.cat[0];
               unsigned char cat = xemTiaCatMatPhangVaTruc( tia, toaDoMatPhang, truc, kBEN_TRAI ); // toạ độ thế giới
               
               // ---- nếu cắt, bỏ con lên xếp đống
               if( cat ) {
                  xepDong[chiSoXepDong] = nhiCayGiaoDiem[giaoDiem.conTrai];
                  chiSoXepDong++;
               }
               
            }

            if( giaoDiem.conPhai != -1 ) {
               // ---- xem cắt mặt phẳng
               float toaDoMatPhang = giaoDiem.cat[1];
               unsigned char cat = xemTiaCatMatPhangVaTruc( tia, toaDoMatPhang, truc, kBEN_PHAI ); // toạ độ thế giới
               // ---- nếu cắt, bỏ con lên xếp đống
               if( cat ) {
                  xepDong[chiSoXepDong] = nhiCayGiaoDiem[giaoDiem.conPhai];
                  chiSoXepDong++;
               }
            }
            //            printf( " cay: chiSoXepDong %d\n", chiSoXepDong );
            
         }
         else {  // giao điểm lá
            VatThe *vatThe = &(danhSachVatThe[mangChiSoVatTheSapXep[giaoDiem.chiSoVatThe]]);
            Vecto diemTrungTDVT;
            Vecto phapTuyenTDVT;
            Tia tiaBienHoa;
            
            // ---- biến hóa tia đến không gian vật thể  [gốc]•[dịch]-1 •[xoay]-1 •[phóng to]-1
            tiaBienHoa.goc = nhanVectoVoiMaTran4x4( &(tia->goc), vatThe->nghichBienHoa );
            // ---- đừng dịch hướng, chỉ [hướng]•[xoay]-1 •[phóng to]-1
            tiaBienHoa.huong = nhanVectoVoiMaTran3x3( &(tia->huong), vatThe->nghichBienHoa );
            
            // ---- xem nếu tia có trúng vật này
            float cachXa = kVO_CUC;
            cachXa = xemTiaCoTrungVatTrongKhongGianVat( vatThe, &tiaBienHoa, &phapTuyenTDVT, &diemTrungTDVT );
            
            // ---- xem nếu có gần hơn vật thể trước
            if( cachXa < kVO_CUC ) {
//               printf( "vatTheloai %d  cachXa %5.3f  *soLuongVatTheToMauBong %d\n", vatThe->loai, cachXa, *soLuongVatTheToMauBong );
               thongTinToMauBong[*soLuongVatTheToMauBong].vatThe = vatThe;
               thongTinToMauBong[*soLuongVatTheToMauBong].diemTrungTDVT = diemTrungTDVT;
               thongTinToMauBong[*soLuongVatTheToMauBong].phapTuyenTDVT = phapTuyenTDVT;
//               cachXaGanNhat = cachXa;
//               printf( "xemCoTrungVat: thongtin.phapTueyn %5.3f %5.3f %5.3f\n", thongTinToMauBong->phapTuyenTDVT.x, thongTinToMauBong->phapTuyenTDVT.y, thongTinToMauBong->phapTuyenTDVT.z );
//               printf( "xemCoTrungVat: phapTueyn %5.3f %5.3f %5.3f\n", phapTuyenTDVT.x, phapTuyenTDVT.y, phapTuyenTDVT.z );
               thongTinToMauBong[*soLuongVatTheToMauBong].cachXa = cachXa;
               (*soLuongVatTheToMauBong)++;
//               return kDUNG;  // kiếm vật thể cần nhất
            }
            
            if( *soLuongVatTheToMauBong == kSO_LUONG__VAT_THE_BONG_TOI_DA ) {
               return kDUNG;
            }
         }
      }
   }
   else { // số lượng giao điểm == 0, không có vật thể
//      printf( "xemTiaCóTrúngVậtThểNào: SAI LẦM số lượng giao điểm == 0\n" );
      // ---- không có vật thể, không thể trúng vật thể nào
      thongTinToMauBong[*soLuongVatTheToMauBong].vatThe = NULL;
      thongTinToMauBong[*soLuongVatTheToMauBong].cachXa = kVO_CUC;
      return kSAI;
   }
   
   // ---- không trúng vật thể nào
   if( thongTinToMauBong->vatThe == NULL ) {
      thongTinToMauBong->cachXa = kVO_CUC;
      return kSAI;
   }
   // ---- có trúng vật thể
   else {
      return kDUNG;
   }
}


unsigned char xemTiaCatMatPhangVaTruc( Tia *tia, float toaDoMatPhang, unsigned char truc, unsigned char ben ) {
   
   unsigned char cat = kDUNG;
   
   if( truc == kTRUC_X ) {
      if( ben == kBEN_TRAI ) {  // nếu thành phần hướng x = 0.0f, tia songๆ với mặt phẳng và không thể cặt nó
         if( (tia->huong.x >= 0.0f) && (tia->goc.x > toaDoMatPhang) )
            cat = kSAI;
      }
      else { // if( ben == kBEN_PHAI ) {
         if( (tia->huong.x <= 0.0f) && (tia->goc.x < toaDoMatPhang) )
            cat = kSAI;
      }
   }
   else if( truc == kTRUC_Y ) {
      if( ben == kBEN_TRAI ) {  // nếu thành phần hướng x = 0.0f, tia songๆ với mặt phẳng và không thể cặt nó
         if( (tia->huong.y >= 0.0f) && (tia->goc.y > toaDoMatPhang) )
            cat = kSAI;
      }
      else { // if( ben == kBEN_PHAI ) {
         if( (tia->huong.y <= 0.0f) && (tia->goc.y < toaDoMatPhang) )
            cat = kSAI;
      }
   }
   else {  // if( truc == kTRUC_Z ) {
      if( ben == kBEN_TRAI ) {  // nếu thành phần hướng x = 0.0f, tia songๆ với mặt phẳng và không thể cặt nó
         if( (tia->huong.z >= 0.0f) && (tia->goc.z > toaDoMatPhang) )
            cat = kSAI;
      }
      else { // if( ben == kBEN_PHAI ) {
         if( (tia->huong.z <= 0.0f) && (tia->goc.z < toaDoMatPhang) )
            cat = kSAI;
      }
   }
   //   printf( "truc %d  ben %d  toaDo %5.3f  cat %d   tia  %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f\n", truc, ben, toaDoMatPhang, cat, tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z );
   return cat;
}


float xemTiaCoTrungVatTrongKhongGianVat( VatThe *vatThe, Tia *tia, Vecto *phapTuyen, Vecto *diemTrungTDVT ) {

 //  printf( "xemTiaCat: tia %5.3f %5.3f %5.3f   %5.3f %5.3f %5.3f\n", tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z );

   float cachXa = kVO_CUC;
   
   // ---- xem cắt bao bì trước (tại làm này nhanh hơn) 
   unsigned char cat = xemCatBaoBi( &(vatThe->baoBiVT), tia );

   if( cat ) {
      if( vatThe->loai == kLOAI_HINH_DANG__HINH_CAU ) {
         HinhCau *hinhCau = &(vatThe->hinhDang.hinhCau);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatHinhCau( hinhCau, tia, phapTuyen, diemTrungTDVT );
      }
//      else if( vatThe->loai == kLOAI_HINH_DANG__MAT_PHANG ) {
//         MatPhang *matPhang = &(vatThe->hinhDang.matPhang);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
//         cachXa = xemCatMatPhang( matPhang, tia, phapTuyen, diemTrungTDVT );
//      }
      else if( vatThe->loai == kLOAI_HINH_DANG__HOP ) {
         Hop *hop = &(vatThe->hinhDang.hop);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatHop( hop, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__HINH_TRU ) {
         HinhTru *hinhTru = &(vatThe->hinhDang.hinhTru );
         cachXa = xemCatHinhTru( hinhTru, tia, phapTuyen, diemTrungTDVT );
         //      printf( "xemCat: cachXa %5.3f\n", cachXa );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__HINH_NON ) {
         HinhNon *hinhNon = &(vatThe->hinhDang.hinhNon);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatHinhNon( hinhNon, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__MAT_HYPERBOL ) {
         MatHyperbol *matHyperbol = &(vatThe->hinhDang.matHyperbol);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatMatHyperbol( matHyperbol, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__MAT_PARABOL ) {
         MatParabol *matParabol = &(vatThe->hinhDang.matParabol);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatMatParabol( matParabol, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__MAT_SONG ) {
         MatSong *matSong = &(vatThe->hinhDang.matSong);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatMatSong( matSong, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__HINH_XUYEN ) {
         HinhXuyen *hinhXuyen = &(vatThe->hinhDang.hinhXuyen);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatHinhXuyen( hinhXuyen, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__TU_DIEN ) {
         TuDien *tuDien = &(vatThe->hinhDang.tuDien);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatVatTheTamGiac( tuDien->mangDinh, tuDien->mangTamGiac, tuDien->soLuongTamGiac,
                                      tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__BAT_DIEN ) {
         BatDien *batDien = &(vatThe->hinhDang.batDien);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatVatTheTamGiac( batDien->mangDinh, batDien->mangTamGiac, batDien->soLuongTamGiac, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__THAP_NHI_DIEN ) {
         ThapNhiDien *thapNhiDien = &(vatThe->hinhDang.thapNhiDien);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatVatTheTamGiac( thapNhiDien->mangDinh, thapNhiDien->mangTamGiac, thapNhiDien->soLuongTamGiac, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__KIM_TU_THAP ) {
         KimTuThap *kimTuThap = &(vatThe->hinhDang.kimTuThap);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatVatTheTamGiac( kimTuThap->mangDinh, kimTuThap->mangTamGiac, kimTuThap->soLuongTamGiac, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__DOC ) {
         Doc *doc = &(vatThe->hinhDang.doc);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatVatTheTamGiac( doc->mangDinh, doc->mangTamGiac, doc->soLuongTamGiac, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__NHI_THAP_DIEN ) {
         NhiThapDien *nhiThapDien = &(vatThe->hinhDang.nhiThapDien);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatVatTheTamGiac( nhiThapDien->mangDinh, nhiThapDien->mangTamGiac, nhiThapDien->soLuongTamGiac, tia, phapTuyen, diemTrungTDVT );
      }
      else if( vatThe->loai == kLOAI_HINH_DANG__SAO_GAI ) {
         SaoGai *saoGai = &(vatThe->hinhDang.saoGai);
         // ---- kiếm cách xa (cách xa theo đơn vị hướng tia, không phải đơn vị thế giới)
         cachXa = xemCatVatTheTamGiac( saoGai->mangDinh, saoGai->mangTamGiac, saoGai->soLuongTamGiac, tia, phapTuyen, diemTrungTDVT );
      }
      // -----
      else if( vatThe->loai == kLOAI_VAT_THE__BOOL ) {
         cachXa = xemTiaCoTrungVatBoolTrongKhongGianVat( vatThe->danhSachVatThe, vatThe->soLuongVatThe, vatThe->mucDichBool, tia, phapTuyen, diemTrungTDVT );
         //      printf( "cachXa %5.3f   diem %5.3f %5.3f %5.3f   phap %5.3f %5.3f %5.3f\n", cachXa, diemTrungTDVT->x, diemTrungTDVT->y, diemTrungTDVT->z, phapTuyen->x, phapTuyen->y, phapTuyen->z );
      }
      else if( vatThe->loai == kLOAI_VAT_THE__GHEP ) {
         unsigned char soVatTheTrung;
         cachXa = xemTiaCoTrungVatGhepTrongKhongGianVat( vatThe->danhSachVatThe, vatThe->soLuongVatThe, tia, phapTuyen, diemTrungTDVT, &soVatTheTrung );
         vatThe->soVatTheGhepTrung = soVatTheTrung;
      }
   }

   // ---- biến đổi pháp tuyến trở lại tọa độ thấ giới
   if( cachXa < kVO_CUC ) {
      Vecto phapTuyenTDTG;
      phapTuyenTDTG = nhanVectoVoiMaTran3x3( phapTuyen, vatThe->nghichBienHoaChoPhapTuyen );
      phapTuyen->x = phapTuyenTDTG.x;
      phapTuyen->y = phapTuyenTDTG.y;
      phapTuyen->z = phapTuyenTDTG.z;
   }

   return cachXa;
}


// -----
// Cần đoạn xuyên qua vật: Điểm vào và Điểm ra
// - cần biết điểm ra hay vào gì có thể phát tia ở trong vật thể và chỉ đi ra ngoài (không có vào)
// - cần pháp tuyến toạ độ thế giới và điểm trúng tọa độ vật thể (cho tô màu) 
// giá trị vật thể +1 hay -1

typedef struct {
   float cach;
   Vecto diemTrungTDVT;
   Vecto phapTuyen;
   char giaTri;     // giá trị bool tùy vào hay ra vật và giá trị vật thể
   char giaTriBool; // giá trị bool của vật thể đang xuyên qua
   unsigned char chiSoVatBool;  // chỉ số vật thể trong danh sách bool
} Doan;

#define kSO_LUONG__VAT_THE_BOOL 32

float xemTiaCoTrungVatBoolTrongKhongGianVat( VatThe *danhSachVatTheBool, unsigned char soLuongVatThe, unsigned char mucDichBool, Tia *tia, Vecto *phapTuyen, Vecto *diemTrungTDVT ) {

   if( soLuongVatThe > kSO_LUONG__VAT_THE_BOOL )
      soLuongVatThe = kSO_LUONG__VAT_THE_BOOL;

   Doan doan[kSO_LUONG__VAT_THE_BOOL << 3];
   char giaTriTrongVatThe[kSO_LUONG__VAT_THE_BOOL << 2];

   // ---- trước tìm hết đoạn ở trong vật thể (nếu có)
   unsigned char soDoan = 0;
   unsigned char soVat = 0;
   while( soVat < soLuongVatThe ) {
      VatThe *vatThe = &(danhSachVatTheBool[soVat]);
      Tia tiaBienHoa0;
      // ---- biến hóa tia đến không gian vật thể  [gốc]•[dịch]-1 •[xoay]-1 •[phóng to]-1
      tiaBienHoa0.goc = nhanVectoVoiMaTran4x4( &(tia->goc), vatThe->nghichBienHoa );
      // ---- đừng dịch hướng, chỉ [hướng]•[xoay]-1 •[phóng to]-1
      tiaBienHoa0.huong = nhanVectoVoiMaTran3x3( &(tia->huong), vatThe->nghichBienHoa );
      Vecto diemTrungVatThe;
      Vecto phapTuyenVatThe;
      float cachXa0 = xemTiaCoTrungVatTrongKhongGianVat( vatThe, &tiaBienHoa0, &phapTuyenVatThe, &diemTrungVatThe );
      
      // ---- xem nếu góc tia trong vật thể
      if( xemDiemTrongVatThe( vatThe, &(tiaBienHoa0.goc) ) )
         giaTriTrongVatThe[soVat] = vatThe->giaTri;
      else
         giaTriTrongVatThe[soVat] = 0;

      // ---- xem nếu chúng cái gì
      if( cachXa0 < kVO_CUC ) {
         // ---- xem dấu tích vô hướng tia với pháp tuyến (cho biết vào hay ra)
         float tichVoHuong = phapTuyenVatThe.x*tia->huong.x + phapTuyenVatThe.y*tia->huong.y + phapTuyenVatThe.z*tia->huong.z;
         doan[soDoan].giaTriBool = vatThe->giaTri;
         if( vatThe->giaTri == 1 ) {
            if( tichVoHuong < 0.0f )  // vào vật thể +
               doan[soDoan].giaTri = +1;
            else       // ra vật thể +
               doan[soDoan].giaTri = -1;
         }
         else if( vatThe->giaTri == -1 ) {
            if( tichVoHuong < 0.0f )  // vào vật thể -
               doan[soDoan].giaTri = -1;
            else       // ra vật thể -
               doan[soDoan].giaTri = +1;
         }
         // ---- giữ thông tin cho đoạn
         doan[soDoan].cach = cachXa0;
         // ---- tính pháp tuyến
         Vecto phapTuyen;
         phapTuyen = nhanVectoVoiMaTran3x3( &phapTuyenVatThe, vatThe->nghichBienHoaChoPhapTuyen );
         doan[soDoan].phapTuyen.x = phapTuyen.x;
         doan[soDoan].phapTuyen.y = phapTuyen.y;
         doan[soDoan].phapTuyen.z = phapTuyen.z;
         // ---- điểm trúng
         doan[soDoan].diemTrungTDVT.x = diemTrungVatThe.x;
         doan[soDoan].diemTrungTDVT.y = diemTrungVatThe.y;
         doan[soDoan].diemTrungTDVT.z = diemTrungVatThe.z;
         
         doan[soDoan].chiSoVatBool = soVat;
         soDoan++;
   
         // ---- phát tia tiếp đến bên kia nếu có
         if( tichVoHuong < 0.0f ) {  // đang vào
             // ---- tính tia tiếp từ điểm trúng (cộng thêm 0.1f cho không trúng điểm cũ)
            Tia tiaBienHoa1;
            tiaBienHoa1.goc.x = tiaBienHoa0.goc.x + cachXa0*tiaBienHoa0.huong.x;
            tiaBienHoa1.goc.y = tiaBienHoa0.goc.y + cachXa0*tiaBienHoa0.huong.y;
            tiaBienHoa1.goc.z = tiaBienHoa0.goc.z + cachXa0*tiaBienHoa0.huong.z;
            tiaBienHoa1.goc.x += 0.005f*tiaBienHoa0.huong.x;
            tiaBienHoa1.goc.y += 0.005f*tiaBienHoa0.huong.y;
            tiaBienHoa1.goc.z += 0.005f*tiaBienHoa0.huong.z;
            tiaBienHoa1.huong = tiaBienHoa0.huong;
            float cachXa1 = xemTiaCoTrungVatTrongKhongGianVat( vatThe, &tiaBienHoa1, &phapTuyenVatThe, &diemTrungVatThe );
            // ---- tính tích vô hướng
            float tichVoHuong = phapTuyenVatThe.x*tia->huong.x + phapTuyenVatThe.y*tia->huong.y + phapTuyenVatThe.z*tia->huong.z;

            if( cachXa1 < kVO_CUC ) {
               doan[soDoan].giaTriBool = vatThe->giaTri;
               if( vatThe->giaTri == 1 ) {
                  if( tichVoHuong < 0.0f )  // vào vật thể +
                     printf( "XemCắtBool: SAI LẦM Không nên vào vật %d cachXa0 %5.3f  cachXa1 %5.3f\n", soVat, cachXa0, cachXa1 );
                  else       // ra vật thể +
                     doan[soDoan].giaTri = -1;
               }
               else if( vatThe->giaTri == -1 ) {
                  if( tichVoHuong < 0.0f )  // vào vật thể -
                     printf( "XemCắtBool: SAI LẦM Không nên vào vật %d  cachXa0 %5.3f  cachXa1 %5.3f\n", soVat, cachXa0, cachXa1 );
                  else       // ra vật thể -
                     doan[soDoan].giaTri = +1;
               }
               // ---- giữ thông tin cho đoạn
               doan[soDoan].cach = cachXa1 + cachXa0;
               // ---- tính pháp tuyến
               phapTuyen = nhanVectoVoiMaTran3x3( &phapTuyenVatThe, vatThe->nghichBienHoaChoPhapTuyen );
               doan[soDoan].phapTuyen.x = phapTuyen.x;
               doan[soDoan].phapTuyen.y = phapTuyen.y;
               doan[soDoan].phapTuyen.z = phapTuyen.z;
               // ---- giữ điểm trúng
               doan[soDoan].diemTrungTDVT.x = diemTrungVatThe.x;
               doan[soDoan].diemTrungTDVT.y = diemTrungVatThe.y;
               doan[soDoan].diemTrungTDVT.z = diemTrungVatThe.z;
               
               doan[soDoan].chiSoVatBool = soVat;
               soDoan++;
            }
            else {  // tia đã cắt một góc và không thất mặt kia, bỏ đoàn này
               // thật nên xem nếu ờ trong vật thể trước bỏ đoàn này
               soDoan--;
            }
         }
      }
      soVat++;
   }
   
   // ----
   
   // ---- xử lý: cần kiếm điểm gần nhất mà giá trị đém = 1
   if( soDoan > 0 ) {
      // ---- chuần bị mảng chỉ số
      unsigned char soLuongDoan = soDoan;
      soDoan = 0;
      unsigned char mangChiSo[16];
      while ( soDoan < soLuongDoan ) {
         mangChiSo[soDoan] = soDoan;
         soDoan++;
      }

      // ---- sắp xếp lại từ cách gần nhất đến xa nhất
      unsigned char soVong = 0;
      while( soVong < soLuongDoan - 1 ) {
         soDoan = 0;
         while ( soDoan < soLuongDoan-1 ) {
            if( doan[mangChiSo[soDoan]].cach > doan[mangChiSo[soDoan+1]].cach ) {
               unsigned char chiSo = mangChiSo[soDoan];
               mangChiSo[soDoan] = mangChiSo[soDoan+1];
               mangChiSo[soDoan+1]= chiSo;
            }
            soDoan++;
         }
         soVong++;
      }
      
      // ---- kiếm cách gần nhất
      char dem = 0;
      // ---- đặt giá trị đếm bằng tổng giả trị của vật thể góc tia đang ở trong
      // ---- Xem nếu điểm này ở trong vật thể nào nếu không ở trong vật thể nào, đếm sẽ = 0
      unsigned char soVat = 0;
      while ( soVat < soLuongVatThe ) {
         dem += giaTriTrongVatThe[soVat];
         soVat++;
      }
   
      // ---- tìm điểm trúng có giá trị bool đến mục đích
      soDoan = 0;
      while ( (soDoan < soLuongDoan) && (dem < mucDichBool) ) {
         dem += doan[mangChiSo[soDoan]].giaTri;
//         printf( "mangChiSo[%d] = %d  %5.3f  %d  %d\n", soDoan, mangChiSo[soDoan], doan[mangChiSo[soDoan]].cach, dem, doan[mangChiSo[soDoan]].giaTriBool );
         soDoan++;
      }
      
//      printf( "dem %d\n\n", dem );
      if( (dem > 0) && soDoan ) {


         soDoan--;
         diemTrungTDVT->x = doan[mangChiSo[soDoan]].diemTrungTDVT.x;
         diemTrungTDVT->y = doan[mangChiSo[soDoan]].diemTrungTDVT.y;
         diemTrungTDVT->z = doan[mangChiSo[soDoan]].diemTrungTDVT.z;

         // ---- vật âm, lật pháp tuyến;
         Vecto phapTuyenTDVT; // toạ độ vật thể thành phần bool
         if( doan[mangChiSo[soDoan]].giaTriBool < 0 ) {
            phapTuyenTDVT.x = -doan[mangChiSo[soDoan]].phapTuyen.x;
            phapTuyenTDVT.y = -doan[mangChiSo[soDoan]].phapTuyen.y;
            phapTuyenTDVT.z = -doan[mangChiSo[soDoan]].phapTuyen.z;
         }
         else {
            // ---- lật hướng
            phapTuyenTDVT.x = doan[mangChiSo[soDoan]].phapTuyen.x;
            phapTuyenTDVT.y = doan[mangChiSo[soDoan]].phapTuyen.y;
            phapTuyenTDVT.z = doan[mangChiSo[soDoan]].phapTuyen.z;
         }
         // ---- biến hóa pháp tuyến sang toạ độ vật thể phụ huynh
         unsigned char chiSoVatBool = doan[mangChiSo[soDoan]].chiSoVatBool;
         
         Vecto phapTuyenTDTG = nhanVectoVoiMaTran3x3( &phapTuyenTDVT, danhSachVatTheBool[doan[mangChiSo[soDoan]].chiSoVatBool].nghichBienHoa );
         phapTuyen->x = phapTuyenTDTG.x;
         phapTuyen->y = phapTuyenTDTG.y;
         phapTuyen->z = phapTuyenTDTG.z;

         return doan[mangChiSo[soDoan]].cach;
      }
      else {
         return kVO_CUC;
      }
   }
   else {
         return kVO_CUC;
   }
}

float xemTiaCoTrungVatGhepTrongKhongGianVat( VatThe *danhSachVatTheBool, unsigned char soLuongVatThe, Tia *tia, Vecto *phapTuyen, Vecto *diemTrungTDVT, unsigned char *soVatTheTrung ) {
   
   float cachXaGanNhat = kVO_CUC;
   Vecto phapTuyenGanNhat;
   Vecto diemTrungGanNhatTDVT;
   
   unsigned char soVatThe = 0;
   while( soVatThe < soLuongVatThe ) {
      VatThe *vatThe = &(danhSachVatTheBool[soVatThe]);
      Tia tiaBienHoa0;
      // ---- biến hóa tia đến không gian vật thể  [gốc]•[dịch]-1 •[xoay]-1 •[phóng to]-1
      tiaBienHoa0.goc = nhanVectoVoiMaTran4x4( &(tia->goc), vatThe->nghichBienHoa );
      // ---- đừng dịch hướng, chỉ [hướng]•[xoay]-1 •[phóng to]-1
      tiaBienHoa0.huong = nhanVectoVoiMaTran3x3( &(tia->huong), vatThe->nghichBienHoa );
      Vecto diemTrungVatThe;
      Vecto phapTuyenVatThe;
      float cachXa = xemTiaCoTrungVatTrongKhongGianVat( vatThe, &tiaBienHoa0, &phapTuyenVatThe, &diemTrungVatThe );

      // ---- xem nếu có gần hơn vật thể trước
      if( cachXa < cachXaGanNhat ) {
         *soVatTheTrung = soVatThe;
         cachXaGanNhat = cachXa;
         phapTuyen->x = phapTuyenVatThe.x;
         phapTuyen->y = phapTuyenVatThe.y;
         phapTuyen->z = phapTuyenVatThe.z;
         diemTrungTDVT->x = diemTrungVatThe.x;
         diemTrungTDVT->y = diemTrungVatThe.y;
         diemTrungTDVT->z = diemTrungVatThe.z;
      }
      soVatThe++;
   }
   
   return cachXaGanNhat;
}

unsigned char xemDiemTrongVatThe( VatThe *vatThe, Vecto *diem ) {
   
   unsigned char diemTrong = kSAI;  // đặt sẵn không có trong vật thể
   if( vatThe->loai == kLOAI_HINH_DANG__HINH_CAU )
      diemTrong = xemDiemTrongHinhCau( &(vatThe->hinhDang.hinhCau), diem );

   else if( vatThe->loai == kLOAI_HINH_DANG__HOP )
      diemTrong = xemDiemTrongHop( &(vatThe->hinhDang.hop), diem );
   
   else if( vatThe->loai == kLOAI_HINH_DANG__HINH_TRU )
      diemTrong = xemDiemTrongHinhTru( &(vatThe->hinhDang.hinhTru), diem );
   
   else if( vatThe->loai == kLOAI_HINH_DANG__HINH_NON )
      diemTrong = xemDiemTrongHinhNon( &(vatThe->hinhDang.hinhNon), diem );
   
   return diemTrong;
}


unsigned char thayNguonAnhSang( VatThe *danhSachVat, unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVat, Vecto *diemTrung, Vecto *huongAnhSang, ThongTinToMau *thongTinToMauBong, unsigned char *soLuongVatTheToMauBong, GiaoDiemBIH *mangGiaoDiem, unsigned int chiSoGiaoDiem ) {
   
   Tia tiaDenNguonaAnhSang;
   
   // ---- hướng đến ngườn ảnh sáng là ngược hướng tia ánh sáng
   tiaDenNguonaAnhSang.huong.x = -huongAnhSang->x;
   tiaDenNguonaAnhSang.huong.y = -huongAnhSang->y;
   tiaDenNguonaAnhSang.huong.z = -huongAnhSang->z;
   
   tiaDenNguonaAnhSang.goc.x = diemTrung->x;// + 0.001f*tiaDenNguonaAnhSang.huong.x;
   tiaDenNguonaAnhSang.goc.y = diemTrung->y;// + 0.001f*tiaDenNguonaAnhSang.huong.y;
   tiaDenNguonaAnhSang.goc.z = diemTrung->z;// + 0.001f*tiaDenNguonaAnhSang.huong.z;
   
   // ==== xem nếu tia có trúng vật thể nào
   // ---- xem nếu có trúng vật thể nào
   unsigned char ketQuaThay = xemTiaCoTrungVatTheNao( mangGiaoDiem, chiSoGiaoDiem, danhSachVat, mangChiSoVatTheSapXep, &(tiaDenNguonaAnhSang), thongTinToMauBong, soLuongVatTheToMauBong );
   //   printf( "-- thayNguon: thay %d phapTuyen %5.3f %5.3f %5.3f\n", ketQuaThay, thongTinToMauBong->phapTuyenTDVT.x, thongTinToMauBong->phapTuyenTDVT.y, thongTinToMauBong->phapTuyenTDVT.z );
   return !ketQuaThay;
}
/*
typedef struct {  // đang làm chưa xong nhe!
   Mau mauVat;
   float cach;
} DoanBongToi;

unsigned char tinhAnhSangBongTuNguonAnhSang( VatThe *danhSachVat, unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVat, Vecto *diemTrung, Vecto *huongAnhSang ) {
   
   Tia tiaDenNguonaAnhSang;
   
   // ---- hướng đến ngườn ảnh sáng là ngược hướng tia ánh sáng
   tiaDenNguonaAnhSang.huong.x = -huongAnhSang->x;
   tiaDenNguonaAnhSang.huong.y = -huongAnhSang->y;
   tiaDenNguonaAnhSang.huong.z = -huongAnhSang->z;
   
   tiaDenNguonaAnhSang.goc.x = diemTrung->x;
   tiaDenNguonaAnhSang.goc.y = diemTrung->y;
   tiaDenNguonaAnhSang.goc.z = diemTrung->z;
   
   DoanBongToi mangBongToi[32];   // mảng bong tốo, danh sách các vật thể tia được trúng trên tia đến nguồn ánh sáng
   unsigned char soDoan = 0;
   
   // ==== xem nếu tia có trúng vật thể nào
   // ---- trúng vật thể, tìm cách xa trong vật thể
   // ---- giữ màu và độ đục của vật thể
   // ---- tính điểm trúng khi ra vật thể và
   return kDUNG;
} */

