#include "BaoBi.h"
#include "../HangSo.h"


#pragma mark ---- Bao Bì
// hop 6 float [-x, +x, -y, +y, -z, +z]  dấu == 1 nếu âm
// tia.goc.x + t*tia.huong.x = x
// t = (x - tia.goc.x)/tia.huong
unsigned char xemCatBaoBi( BaoBi *baoBiVT, Tia *tia ) {
   
//   printf( "baoBi: hop %5.3f %5.3f %5.3f %5.3f %5.3f %5.3f\n", baoBiVT->gocCucTieu.x, baoBiVT->gocCucDai.x, baoBiVT->gocCucTieu.y, baoBiVT->gocCucDai.y, baoBiVT->gocCucTieu.z, baoBiVT->gocCucDai.z );
//   printf( "baoBi: tia %5.3f %5.3f %5.3f   %5.3f %5.3f %5.3f\n", tia->goc.x, tia->goc.y, tia->goc.z, tia->huong.x, tia->huong.y, tia->huong.z );
   unsigned char trung = kSAI;

   // ---- tính nghiệm cho hướng x
   if( tia->huong.x != 0.0f ) {
//      printf( "baoBi: x\n");
      // ---- tính hai nghiệm
      float nghiem0 = (baoBiVT->gocCucTieu.x - tia->goc.x) / tia->huong.x;
      float nghiem1 = (baoBiVT->gocCucDai.x - tia->goc.x) / tia->huong.x;

      // ----
      if( nghiem0 < 0.0001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.0001f )
         nghiem1 = kVO_CUC;
      
      if( nghiem0 < kVO_CUC ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungX;
         //         diemTrungX.x = tia->goc.x + nghiem0*tia->huong.x;
         diemTrungX.y = tia->goc.y + nghiem0*tia->huong.y;
         diemTrungX.z = tia->goc.z + nghiem0*tia->huong.z;

         if( diemTrungX.y > baoBiVT->gocCucDai.y )
            trung = kSAI;
         else if( diemTrungX.y < baoBiVT->gocCucTieu.y )
            trung = kSAI;
         else if( diemTrungX.z > baoBiVT->gocCucDai.z )
            trung = kSAI;
         else if( diemTrungX.z < baoBiVT->gocCucTieu.z )
            trung = kSAI;
         else
            trung = kDUNG;
      }
      if( nghiem1 < kVO_CUC && trung == kSAI ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungX;
         //         diemTrungX.x = tia->goc.x + nghiem1*tia->huong.x;
         diemTrungX.y = tia->goc.y + nghiem1*tia->huong.y;
         diemTrungX.z = tia->goc.z + nghiem1*tia->huong.z;
         //      printf("nghiemX %5.3f  %5.3f\n", nghiemX, nghiemGanNhat );
         if( diemTrungX.y > baoBiVT->gocCucDai.y )
            trung = kSAI;
         else if( diemTrungX.y < baoBiVT->gocCucTieu.y )
            trung = kSAI;
         else if( diemTrungX.z > baoBiVT->gocCucDai.z )
            trung = kSAI;
         else if( diemTrungX.z < baoBiVT->gocCucTieu.z )
            trung = kSAI;
         else
            trung = kDUNG;
      }
   }
   
   // ---- tính nghiệm cho hướng y
   if( tia->huong.y != 0.0f && trung == kSAI ) {
//      printf( "baoBi: y\n ");
      // ---- tính hai nghiệm
      float nghiem0 = (baoBiVT->gocCucTieu.y - tia->goc.y) / tia->huong.y;
      float nghiem1 = (baoBiVT->gocCucDai.y - tia->goc.y) / tia->huong.y;
      
      // ----
      if( nghiem0 < 0.0001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.0001f )
         nghiem1 = kVO_CUC;
      
      if( nghiem0 < kVO_CUC ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungY;
         diemTrungY.x = tia->goc.x + nghiem0*tia->huong.x;
         //         diemTrungY.y = tia->goc.y + nghiem0*tia->huong.y;
         diemTrungY.z = tia->goc.z + nghiem0*tia->huong.z;
         //      printf("nghiemX %5.3f  %5.3f\n", nghiemX, nghiemGanNhat );
         if( diemTrungY.x > baoBiVT->gocCucDai.x )
            trung = kSAI;
         else if( diemTrungY.x < baoBiVT->gocCucTieu.x )
            trung = kSAI;
         else if( diemTrungY.z > baoBiVT->gocCucDai.z )
            trung = kSAI;
         else if( diemTrungY.z < baoBiVT->gocCucTieu.z )
            trung = kSAI;
         else
            trung = kDUNG;
      }
      if( nghiem1 < kVO_CUC && trung == kSAI ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungY;
         diemTrungY.x = tia->goc.x + nghiem1*tia->huong.x;
         //         diemTrungY.y = tia->goc.y + nghiem1*tia->huong.y;
         diemTrungY.z = tia->goc.z + nghiem1*tia->huong.z;
         //      printf("nghiemX %5.3f  %5.3f\n", nghiemX, nghiemGanNhat );
         if( diemTrungY.x > baoBiVT->gocCucDai.x )
            trung = kSAI;
         else if( diemTrungY.x < baoBiVT->gocCucTieu.x )
            trung = kSAI;
         else if( diemTrungY.z > baoBiVT->gocCucDai.z )
            trung = kSAI;
         else if( diemTrungY.z < baoBiVT->gocCucTieu.z )
            trung = kSAI;
         else
            trung = kDUNG;
      }
   }
//   printf( "tia->huong.z %5.3f  trung %d\n", tia->huong.z, trung );
   // ---- tính nghiệm cho hướng z
   if( tia->huong.z != 0.0f && trung == kSAI ) {

      // ---- tính hai nghiệm
      float nghiem0 = (baoBiVT->gocCucTieu.z - tia->goc.z) / tia->huong.z;
      float nghiem1 = (baoBiVT->gocCucDai.z - tia->goc.z) / tia->huong.z;
//      printf( "baoBi: z nghiem0 %5.3f    nghiem1 %5.3e\n", nghiem0, nghiem1 );
      // ----
      if( nghiem0 < 0.0001f )
         nghiem0 = kVO_CUC;
      if( nghiem1 < 0.0001f )
         nghiem1 = kVO_CUC;
//      printf( "baoBi: z 2 nghiem0 %5.3f    nghiem1 %5.3e\n", nghiem0, nghiem1 );
      
      if( nghiem0 < kVO_CUC ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungZ;
         diemTrungZ.x = tia->goc.x + nghiem0*tia->huong.x;
         diemTrungZ.y = tia->goc.y + nghiem0*tia->huong.y;
         //         diemTrungZ.z = tia->goc.z + nghiem0*tia->huong.z;
//         printf("diemTrungZ %5.3f  %5.3f\n", diemTrungZ.x, diemTrungZ.y );
         if( diemTrungZ.x > baoBiVT->gocCucDai.x )
            trung = kSAI;
         else if( diemTrungZ.x < baoBiVT->gocCucTieu.x )
            trung = kSAI;
         else if( diemTrungZ.y > baoBiVT->gocCucDai.y )
            trung = kSAI;
         else if( diemTrungZ.y < baoBiVT->gocCucTieu.y )
            trung = kSAI;
         else
            trung = kDUNG;
      }
      
//      printf("trung %d\n", trung );
      
      if( nghiem1 < kVO_CUC && trung == kSAI ) {
         // ---- xem nếu ở trong mặt
         Vecto diemTrungZ;
         diemTrungZ.x = tia->goc.x + nghiem1*tia->huong.x;
         diemTrungZ.y = tia->goc.y + nghiem1*tia->huong.y;
         //         diemTrungZ.z = tia->goc.z + nghiem1*tia->huong.z;
         //      printf("nghiemX %5.3f  %5.3f\n", nghiemX, nghiemGanNhat );
         if( diemTrungZ.x > baoBiVT->gocCucDai.x )
            trung = kSAI;
         else if( diemTrungZ.x < baoBiVT->gocCucTieu.x )
            trung = kSAI;
         else if( diemTrungZ.y > baoBiVT->gocCucDai.y )
            trung = kSAI;
         else if( diemTrungZ.y < baoBiVT->gocCucTieu.y )
            trung = kSAI;
         else
            trung = kDUNG;
      }
   }
//   printf("baoBi: trung %d\n\n", trung );

   return trung; // ( (tmin < t1) && (tmax > t0) );
}

float timNhoNhatCuaTamGiaTri( float so0, float so1, float so2, float so3, float so4, float so5, float so6, float so7 ) {
   
   float nhoNhat = so0;
   if( so1 < nhoNhat )
      nhoNhat = so1;
   if( so2 < nhoNhat )
      nhoNhat = so2;
   if( so3 < nhoNhat )
      nhoNhat = so3;
   if( so4 < nhoNhat )
      nhoNhat = so4;
   if( so5 < nhoNhat )
      nhoNhat = so5;
   if( so6 < nhoNhat )
      nhoNhat = so6;
   if( so7 < nhoNhat )
      nhoNhat = so7;
   
   return nhoNhat;
}

float timLonNhatCuaTamGiaTri( float so0, float so1, float so2, float so3, float so4, float so5, float so6, float so7 ) {
   
   float lonNhat = so0;
   if( so1 > lonNhat )
      lonNhat = so1;
   if( so2 > lonNhat )
      lonNhat = so2;
   if( so3 > lonNhat )
      lonNhat = so3;
   if( so4 > lonNhat )
      lonNhat = so4;
   if( so5 > lonNhat )
      lonNhat = so5;
   if( so6 > lonNhat )
      lonNhat = so6;
   if( so7 > lonNhat )
      lonNhat = so7;
   
   return lonNhat;
}
