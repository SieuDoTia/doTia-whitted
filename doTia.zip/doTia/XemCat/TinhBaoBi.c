#include "TinhBaoBi.h"
#include "../Toán/BienHoa.h"
#include <stdlib.h>


BaoBi tinhBaoBiTGChoDanhSachVatThe( VatThe *danhSachVatThe, unsigned short soLuongVatThe ) {

   BaoBi baoBiPhimTruong;
   if( soLuongVatThe == 0 )
      printf( "TínhBaoBìChoPhimTrường: Số lượng vật thể = 0\n" );
   else {
      // ---- đặt bao bì phim trường bằng bao bì vật thể đầu
      tinhBaoBiTGChoVatThe( &(danhSachVatThe[0]) );
      baoBiPhimTruong = danhSachVatThe[0].baoBiTG;

      // ----
      unsigned short chiSo = 1;
      while ( chiSo < soLuongVatThe ) {
//         printf( "soVatThe %d\n", chiSo );
         tinhBaoBiTGChoVatThe( &(danhSachVatThe[chiSo]) );
   
         BaoBi baoBiTG = danhSachVatThe[chiSo].baoBiTG;
         // ---- X
         if( baoBiTG.gocCucTieu.x < baoBiPhimTruong.gocCucTieu.x )
            baoBiPhimTruong.gocCucTieu.x = baoBiTG.gocCucTieu.x;
         if( baoBiTG.gocCucDai.x > baoBiPhimTruong.gocCucDai.x )
            baoBiPhimTruong.gocCucDai.x = baoBiTG.gocCucDai.x;
         // ---- Y
         if( baoBiTG.gocCucTieu.y < baoBiPhimTruong.gocCucTieu.y )
            baoBiPhimTruong.gocCucTieu.y = baoBiTG.gocCucTieu.y;
         if( baoBiTG.gocCucDai.y > baoBiPhimTruong.gocCucDai.y )
            baoBiPhimTruong.gocCucDai.y = baoBiTG.gocCucDai.y;
         // ---- Z
         if( baoBiTG.gocCucTieu.z < baoBiPhimTruong.gocCucTieu.z )
            baoBiPhimTruong.gocCucTieu.z = baoBiTG.gocCucTieu.z;
         if( baoBiTG.gocCucDai.z > baoBiPhimTruong.gocCucDai.z )
            baoBiPhimTruong.gocCucDai.z = baoBiTG.gocCucDai.z;
         chiSo++;
      }
   }

   return baoBiPhimTruong;
}

void tinhBaoBiTGChoVatThe( VatThe *vatThe ) {
   
   // ---- xem loại vật thể, tính bao bì cho vật thể ghép khác cho vật thể ghép và bool
   unsigned char loaiVatThe = vatThe->loai;
   // ---- biến hóa thành tọa độ thế giới
 //  printf( "loaiVatThe %d\n", loaiVatThe );
    {
      // ---- tính các vectơ sẽ cần (một vectơ đến mỗi góc -> 8 vectơ)
      Vecto goc_xAm_yAm_zAm_TG;
      Vecto goc_xDuong_yAm_zAm_TG;
      Vecto goc_xAm_yAm_zDuong_TG;
      Vecto goc_xDuong_yAm_zDuong_TG;
      
      Vecto goc_xAm_yDuong_zAm_TG;
      Vecto goc_xDuong_yDuong_zAm_TG;
      Vecto goc_xAm_yDuong_zDuong_TG;
      Vecto goc_xDuong_yDuong_zDuong_TG;
      
      // ---- vectơ 8 góc tương đối với vật thể
      Vecto goc_xAm_yAm_zAm_VT;
      goc_xAm_yAm_zAm_VT.x = vatThe->baoBiVT.gocCucTieu.x;
      goc_xAm_yAm_zAm_VT.y = vatThe->baoBiVT.gocCucTieu.y;
      goc_xAm_yAm_zAm_VT.z = vatThe->baoBiVT.gocCucTieu.z;
      
      Vecto goc_xDuong_yAm_zAm_VT;
      goc_xDuong_yAm_zAm_VT.x = vatThe->baoBiVT.gocCucDai.x;
      goc_xDuong_yAm_zAm_VT.y = vatThe->baoBiVT.gocCucTieu.y;
      goc_xDuong_yAm_zAm_VT.z = vatThe->baoBiVT.gocCucTieu.z;
      
      Vecto goc_xAm_yAm_zDuong_VT;
      goc_xAm_yAm_zDuong_VT.x = vatThe->baoBiVT.gocCucTieu.x;
      goc_xAm_yAm_zDuong_VT.y = vatThe->baoBiVT.gocCucTieu.y;
      goc_xAm_yAm_zDuong_VT.z = vatThe->baoBiVT.gocCucDai.z;
      
      Vecto goc_xDuong_yAm_zDuong_VT;
      goc_xDuong_yAm_zDuong_VT.x = vatThe->baoBiVT.gocCucDai.x;
      goc_xDuong_yAm_zDuong_VT.y = vatThe->baoBiVT.gocCucTieu.y;
      goc_xDuong_yAm_zDuong_VT.z = vatThe->baoBiVT.gocCucDai.z;
      // ----
      Vecto goc_xAm_yDuong_zAm_VT;
      goc_xAm_yDuong_zAm_VT.x = vatThe->baoBiVT.gocCucTieu.x;
      goc_xAm_yDuong_zAm_VT.y = vatThe->baoBiVT.gocCucDai.y;
      goc_xAm_yDuong_zAm_VT.z = vatThe->baoBiVT.gocCucTieu.z;
      
      Vecto goc_xDuong_yDuong_zAm_VT;
      goc_xDuong_yDuong_zAm_VT.x = vatThe->baoBiVT.gocCucDai.x;
      goc_xDuong_yDuong_zAm_VT.y = vatThe->baoBiVT.gocCucDai.y;
      goc_xDuong_yDuong_zAm_VT.z = vatThe->baoBiVT.gocCucTieu.z;
      
      Vecto goc_xAm_yDuong_zDuong_VT;
      goc_xAm_yDuong_zDuong_VT.x = vatThe->baoBiVT.gocCucTieu.x;
      goc_xAm_yDuong_zDuong_VT.y = vatThe->baoBiVT.gocCucDai.y;
      goc_xAm_yDuong_zDuong_VT.z = vatThe->baoBiVT.gocCucDai.z;
      
      Vecto goc_xDuong_yDuong_zDuong_VT;
      goc_xDuong_yDuong_zDuong_VT.x = vatThe->baoBiVT.gocCucDai.x;
      goc_xDuong_yDuong_zDuong_VT.y = vatThe->baoBiVT.gocCucDai.y;
      goc_xDuong_yDuong_zDuong_VT.z = vatThe->baoBiVT.gocCucDai.z;
      
     /*
      printf( "%5.3f %5.3f\n", goc_xAm_yAm_zAm_VT.x, goc_xAm_yAm_zAm_VT.y, goc_xAm_yAm_zAm_VT.z );
      printf( "%5.3f %5.3f\n", goc_xDuong_yAm_zAm_VT.x, goc_xDuong_yAm_zAm_VT.y, goc_xAm_yDuong_zAm_VT.z );
      printf( "%5.3f %5.3f\n", goc_xAm_yAm_zDuong_VT.x, goc_xAm_yAm_zDuong_VT.y, goc_xAm_yAm_zDuong_VT.z );
      printf( "%5.3f %5.3f\n\n", goc_xDuong_yAm_zDuong_VT.x, goc_xDuong_yAm_zDuong_VT.y, goc_xDuong_yAm_zDuong_VT.z );
      
      printf( "%5.3f %5.3f\n", goc_xAm_yDuong_zAm_VT.x, goc_xAm_yDuong_zAm_VT.y, goc_xAm_yDuong_zAm_VT.z );
      printf( "%5.3f %5.3f\n", goc_xDuong_yDuong_zAm_VT.x, goc_xDuong_yDuong_zAm_VT.y, goc_xDuong_yDuong_zAm_VT.z );
      printf( "%5.3f %5.3f\n", goc_xAm_yDuong_zDuong_VT.x, goc_xAm_yDuong_zDuong_VT.y, goc_xAm_yDuong_zDuong_VT.z );
      printf( "%5.3f %5.3f\n\n", goc_xDuong_yDuong_zDuong_VT.x, goc_xDuong_yDuong_zDuong_VT.y, goc_xDuong_yDuong_zDuong_VT.z );
      
      printf( "phongTo %5.3f %5.3f %5.3f\n", vatThe->phongTo[0], vatThe->phongTo[5], vatThe->phongTo[10] );
      printf( "xoay %5.3f %5.3f %5.3f\n", vatThe->xoay[0], vatThe->xoay[5], vatThe->xoay[10] );
      printf( "dich %5.3f %5.3f %5.3f\n", vatThe->dich[12], vatThe->dich[13], vatThe->dich[14] );
      
         printf( "\n-----vatThe->nghichXoay\n" );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichXoay[0], vatThe->nghichXoay[1], vatThe->nghichXoay[2], vatThe->nghichXoay[3] );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichXoay[4], vatThe->nghichXoay[5], vatThe->nghichXoay[6], vatThe->nghichXoay[7] );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichXoay[8], vatThe->nghichXoay[9], vatThe->nghichXoay[10], vatThe->nghichXoay[11] );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichXoay[12], vatThe->nghichXoay[13], vatThe->nghichXoay[14], vatThe->nghichXoay[15] );
       printf( "\n-----vatThe->nghichBienHoa\n" );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichBienHoa[0], vatThe->nghichBienHoa[1], vatThe->nghichBienHoa[2], vatThe->nghichBienHoa[3] );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichBienHoa[4], vatThe->nghichBienHoa[5], vatThe->nghichBienHoa[6], vatThe->nghichBienHoa[7] );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichBienHoa[8], vatThe->nghichBienHoa[9], vatThe->nghichBienHoa[10], vatThe->nghichBienHoa[11] );
       printf( "%5.3f %5.3f %5.3f %5.3f\n", vatThe->nghichBienHoa[12], vatThe->nghichBienHoa[13], vatThe->nghichBienHoa[14], vatThe->nghichBienHoa[15] ); */
      
      goc_xAm_yAm_zAm_TG = nhanVectoVoiMaTran4x4( &goc_xAm_yAm_zAm_VT, vatThe->bienHoa );
      goc_xDuong_yAm_zAm_TG = nhanVectoVoiMaTran4x4( &goc_xDuong_yAm_zAm_VT, vatThe->bienHoa );
      goc_xAm_yAm_zDuong_TG = nhanVectoVoiMaTran4x4( &goc_xAm_yAm_zDuong_VT, vatThe->bienHoa );
      goc_xDuong_yAm_zDuong_TG = nhanVectoVoiMaTran4x4( &goc_xDuong_yAm_zDuong_VT, vatThe->bienHoa );
      
      goc_xAm_yDuong_zAm_TG = nhanVectoVoiMaTran4x4( &goc_xAm_yDuong_zAm_VT, vatThe->bienHoa );
      goc_xDuong_yDuong_zAm_TG = nhanVectoVoiMaTran4x4( &goc_xDuong_yDuong_zAm_VT, vatThe->bienHoa );
      goc_xAm_yDuong_zDuong_TG = nhanVectoVoiMaTran4x4( &goc_xAm_yDuong_zDuong_VT, vatThe->bienHoa );
      goc_xDuong_yDuong_zDuong_TG = nhanVectoVoiMaTran4x4( &goc_xDuong_yDuong_zDuong_VT, vatThe->bienHoa );
/*
      printf( "%5.3f %5.3f\n", goc_xAm_yAm_zAm_TG.x, goc_xAm_yAm_zAm_TG.y, goc_xAm_yAm_zAm_TG.z );
      printf( "%5.3f %5.3f\n", goc_xDuong_yAm_zAm_TG.x, goc_xDuong_yAm_zAm_TG.y, goc_xAm_yDuong_zAm_TG.z );
      printf( "%5.3f %5.3f\n", goc_xAm_yAm_zDuong_TG.x, goc_xAm_yAm_zDuong_TG.y, goc_xAm_yAm_zDuong_TG.z );
      printf( "%5.3f %5.3f\n\n", goc_xDuong_yAm_zDuong_TG.x, goc_xDuong_yAm_zDuong_TG.y, goc_xDuong_yAm_zDuong_TG.z );
   
      printf( "%5.3f %5.3f\n", goc_xAm_yDuong_zAm_TG.x, goc_xAm_yDuong_zAm_TG.y, goc_xAm_yDuong_zAm_TG.z );
      printf( "%5.3f %5.3f\n", goc_xDuong_yDuong_zAm_TG.x, goc_xDuong_yDuong_zAm_TG.y, goc_xDuong_yDuong_zAm_TG.z );
      printf( "%5.3f %5.3f\n", goc_xAm_yDuong_zDuong_TG.x, goc_xAm_yDuong_zDuong_TG.y, goc_xAm_yDuong_zDuong_TG.z );
      printf( "%5.3f %5.3f\n", goc_xDuong_yDuong_zDuong_TG.x, goc_xDuong_yDuong_zDuong_TG.y, goc_xDuong_yDuong_zDuong_TG.z );
      */
      vatThe->baoBiTG.gocCucTieu.x = timNhoNhatCuaTamGiaTri( goc_xAm_yAm_zAm_TG.x, goc_xAm_yAm_zDuong_TG.x, goc_xDuong_yAm_zAm_TG.x, goc_xDuong_yAm_zDuong_TG.x,
                                                            goc_xAm_yDuong_zAm_TG.x, goc_xAm_yDuong_zDuong_TG.x, goc_xDuong_yDuong_zAm_TG.x, goc_xDuong_yDuong_zDuong_TG.x );
      vatThe->baoBiTG.gocCucTieu.y = timNhoNhatCuaTamGiaTri( goc_xAm_yAm_zAm_TG.y, goc_xAm_yAm_zDuong_TG.y, goc_xDuong_yAm_zAm_TG.y, goc_xDuong_yAm_zDuong_TG.y,
                                                            goc_xAm_yDuong_zAm_TG.y, goc_xAm_yDuong_zDuong_TG.y, goc_xDuong_yDuong_zAm_TG.y, goc_xDuong_yDuong_zDuong_TG.y );
      vatThe->baoBiTG.gocCucTieu.z = timNhoNhatCuaTamGiaTri( goc_xAm_yAm_zAm_TG.z, goc_xAm_yAm_zDuong_TG.z, goc_xDuong_yAm_zAm_TG.z, goc_xDuong_yAm_zDuong_TG.z,
                                                            goc_xAm_yDuong_zAm_TG.z, goc_xAm_yDuong_zDuong_TG.z, goc_xDuong_yDuong_zAm_TG.z, goc_xDuong_yDuong_zDuong_TG.z );
      
      
      vatThe->baoBiTG.gocCucDai.x = timLonNhatCuaTamGiaTri( goc_xAm_yAm_zAm_TG.x, goc_xAm_yAm_zDuong_TG.x, goc_xDuong_yAm_zAm_TG.x, goc_xDuong_yAm_zDuong_TG.x,
                                                           goc_xAm_yDuong_zAm_TG.x, goc_xAm_yDuong_zDuong_TG.x, goc_xDuong_yDuong_zAm_TG.x, goc_xDuong_yDuong_zDuong_TG.x );
      vatThe->baoBiTG.gocCucDai.y = timLonNhatCuaTamGiaTri( goc_xAm_yAm_zAm_TG.y, goc_xAm_yAm_zDuong_TG.y, goc_xDuong_yAm_zAm_TG.y, goc_xDuong_yAm_zDuong_TG.y,
                                                           goc_xAm_yDuong_zAm_TG.y, goc_xAm_yDuong_zDuong_TG.y, goc_xDuong_yDuong_zAm_TG.y, goc_xDuong_yDuong_zDuong_TG.y );
      vatThe->baoBiTG.gocCucDai.z = timLonNhatCuaTamGiaTri( goc_xAm_yAm_zAm_TG.z, goc_xAm_yAm_zDuong_TG.z, goc_xDuong_yAm_zAm_TG.z, goc_xDuong_yAm_zDuong_TG.z,
                                                           goc_xAm_yDuong_zAm_TG.z, goc_xAm_yDuong_zDuong_TG.z, goc_xDuong_yDuong_zAm_TG.z, goc_xDuong_yDuong_zDuong_TG.z );
   }

   
   
//   printf( "tinhBaoBi: %5.3f %5.3f %5.3f\n", vatThe->baoBiTG.gocCucDai.x - vatThe->baoBiTG.gocCucTieu.x, vatThe->baoBiTG.gocCucDai.y - vatThe->baoBiTG.gocCucTieu.y, vatThe->baoBiTG.gocCucDai.z - vatThe->baoBiTG.gocCucTieu.z );
   if( (vatThe->baoBiTG.gocCucDai.x - vatThe->baoBiTG.gocCucTieu.x == 0.0f) || (vatThe->baoBiTG.gocCucDai.y - vatThe->baoBiTG.gocCucTieu.y == 0.0f) || (vatThe->baoBiTG.gocCucDai.z - vatThe->baoBiTG.gocCucTieu.z == 0.0f) ) {
      printf( "SAI LẦM: Bao bì cỡ kích 0.0  loại %d  tâm %5.3f %5.3f %5.3f\n",  vatThe->loai, vatThe->dich[12], vatThe->dich[13], vatThe->dich[14] );
      printf( "baoBiVT   %5.3f %5.3f %5.3f    %5.3f %5.3f %5.3f\n", vatThe->baoBiVT.gocCucTieu.x, vatThe->baoBiVT.gocCucTieu.y, vatThe->baoBiVT.gocCucTieu.z, vatThe->baoBiVT.gocCucDai.x, vatThe->baoBiVT.gocCucDai.y, vatThe->baoBiVT.gocCucDai.z );
      exit(0);
   }
      

}

// Cũng xài cho vật thể bool, tương đối với vật thể này
void tinhBaoBiVTChoVatTheGhep( VatThe *vatThe ) {
   
   unsigned short soLuongVatThe = vatThe->soLuongVatThe;
   
   if( soLuongVatThe == 0 )
      printf( "TínhBaoBìTGChoVatTheGhep: Số lượng vật thể = 0\n" );
   else {
      // ---- đặt bao bì phim trường bằng bao bì vật thể đầu, tương đối với tâm vật thể ghép
      tinhBaoBiTGChoVatThe( &(vatThe->danhSachVatThe[0]) );
      BaoBi baoBiVatTheGhep = vatThe->danhSachVatThe[0].baoBiTG;
      
//      printf( "tinhBaoBi: baoBiGhep: 0 %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f\n", baoBiVatTheGhep.gocCucTieu.x, baoBiVatTheGhep.gocCucTieu.y, baoBiVatTheGhep.gocCucTieu.z, baoBiVatTheGhep.gocCucDai.x, baoBiVatTheGhep.gocCucDai.y, baoBiVatTheGhep.gocCucDai.z);
      // ----
      unsigned short chiSo = 1;
      while ( chiSo < soLuongVatThe ) {
         // ---- tương đối với tâm vật thể ghép
         tinhBaoBiTGChoVatThe( &(vatThe->danhSachVatThe[chiSo]) );
         
         BaoBi baoBiVT = vatThe->danhSachVatThe[chiSo].baoBiTG;
//      printf( "tinhBaoBiVT: baoBiVT: %d %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f\n", chiSo, baoBiVT.gocCucTieu.x, baoBiVT.gocCucTieu.y, baoBiVT.gocCucTieu.z, baoBiVT.gocCucDai.x, baoBiVT.gocCucDai.y, baoBiVT.gocCucDai.z);
         
         // ---- X
         if( baoBiVT.gocCucTieu.x < baoBiVatTheGhep.gocCucTieu.x )
            baoBiVatTheGhep.gocCucTieu.x = baoBiVT.gocCucTieu.x;
         if( baoBiVT.gocCucDai.x > baoBiVatTheGhep.gocCucDai.x )
            baoBiVatTheGhep.gocCucDai.x = baoBiVT.gocCucDai.x;
         // ---- Y
         if( baoBiVT.gocCucTieu.y < baoBiVatTheGhep.gocCucTieu.y )
            baoBiVatTheGhep.gocCucTieu.y = baoBiVT.gocCucTieu.y;
         if( baoBiVT.gocCucDai.y > baoBiVatTheGhep.gocCucDai.y )
            baoBiVatTheGhep.gocCucDai.y = baoBiVT.gocCucDai.y;
         // ---- Z
         if( baoBiVT.gocCucTieu.z < baoBiVatTheGhep.gocCucTieu.z )
            baoBiVatTheGhep.gocCucTieu.z = baoBiVT.gocCucTieu.z;
         if( baoBiVT.gocCucDai.z > baoBiVatTheGhep.gocCucDai.z )
            baoBiVatTheGhep.gocCucDai.z = baoBiVT.gocCucDai.z;
         
//      printf( "tinhBaoBiVT: baoBiGhep: %d %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f\n", chiSo, baoBiVatTheGhep.gocCucTieu.x, baoBiVatTheGhep.gocCucTieu.y, baoBiVatTheGhep.gocCucTieu.z, baoBiVatTheGhep.gocCucDai.x, baoBiVatTheGhep.gocCucDai.y, baoBiVatTheGhep.gocCucDai.z);
         chiSo++;
      }

      vatThe->baoBiVT.gocCucTieu = baoBiVatTheGhep.gocCucTieu;
      vatThe->baoBiVT.gocCucDai = baoBiVatTheGhep.gocCucDai;
   }
}
