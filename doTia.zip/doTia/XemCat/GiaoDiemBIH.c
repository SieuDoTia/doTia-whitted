#include "GiaoDiemBIH.h"
#include <stdlib.h>

void chiaBaoBi( unsigned int truc, float matPhangChia, BaoBi *baoBi, BaoBi *baoBiTrai, BaoBi *baoBiPhai );

#pragma mark ---- Chia Thành Tầng Bậc
void datLaiMangChiVatThe( unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVatThe ) {
   
   unsigned short chiSo = 0;
   while ( chiSo < soLuongVatThe ) {
      mangChiSoVatTheSapXep[chiSo] = chiSo;
      chiSo++;
   }

}


unsigned int chiaVatThe( VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVatThe, unsigned short chiSoVatThe, BaoBi *baoBi, unsigned int truc, float toaDoMatPhang, GiaoDiemBIH *mangGiaoDiem, unsigned int *soLuongGiaoDiem ) {
   
   // ---- giữ chỉ số cho giao điểm này
   unsigned int chiSoGiaoDiemNay = *soLuongGiaoDiem;
   
   // ---- tính bao bì trại và phải
   if( soLuongVatThe > 1 ) {
      
      unsigned short soLuongTrai = 0;
      unsigned short soLuongPhai = 0;
      // ---- đặt giao điểm
      mangGiaoDiem[chiSoGiaoDiemNay] = chiaVatTheVaTaoGiaoDiem( danhSachVatThe, mangChiSoVatTheSapXep, soLuongVatThe, truc, toaDoMatPhang, &soLuongTrai, &soLuongPhai );
      //   printf( "chiSoGiaoDiemNay %d  soLuongTrai %d  soLuongPhai %d\n", chiSoGiaoDiemNay, soLuongTrai, soLuongPhai );
      // ---- đã tạo giao điểm này, tăng lên cho giao điểm tiếp trong mảngGiaoĐiểm
      (*soLuongGiaoDiem)++;
      if( *soLuongGiaoDiem == kSO_LUONG__GIAO_DIEM_TOI_DA ) {
         printf( "soLuongGiaoDiem > kSO_LUONG__GIAO_DIEM_TOI_DA (%d)\n", kSO_LUONG__GIAO_DIEM_TOI_DA );
         exit(0);
      }
      
      // ---- chia bao bì thanh hai phần bằng nhau
      BaoBi baoBiTrai;
      BaoBi baoBiPhai;
      // ---- kiếm trục chia, xài cạnh dài nhất
      chiaBaoBi( truc, toaDoMatPhang, baoBi, &baoBiTrai, &baoBiPhai );
      
      // ---- nếu có vật thể trong bao bi trái
      if( soLuongTrai > 0 ) {
         tinhTrucVaToaMatPhangChia( &baoBiTrai, &truc, &toaDoMatPhang );
         mangGiaoDiem[chiSoGiaoDiemNay].conTrai = chiaVatThe( danhSachVatThe, &(mangChiSoVatTheSapXep[0]), soLuongTrai, chiSoVatThe, &baoBiTrai, truc, toaDoMatPhang, mangGiaoDiem, soLuongGiaoDiem );
      }
      else {
         mangGiaoDiem[chiSoGiaoDiemNay].conTrai = -1;
      }
      
      // ---- nếu có vật thể trong bao bi trái
      if( soLuongPhai > 0 ) {
         tinhTrucVaToaMatPhangChia( &baoBiPhai, &truc, &toaDoMatPhang );   // phải làm vì tọaĐộMặtPhẳng không giống
         mangGiaoDiem[chiSoGiaoDiemNay].conPhai = chiaVatThe( danhSachVatThe, &(mangChiSoVatTheSapXep[soLuongTrai]), soLuongPhai, chiSoVatThe + soLuongTrai, &baoBiPhai, truc, toaDoMatPhang, mangGiaoDiem, soLuongGiaoDiem );
      }
      else {
         mangGiaoDiem[chiSoGiaoDiemNay].conPhai = -1;
      }
   }
   else if( soLuongVatThe == 1) {
      mangGiaoDiem[chiSoGiaoDiemNay].truc = kLA;
      mangGiaoDiem[chiSoGiaoDiemNay].conTrai = -1;
      mangGiaoDiem[chiSoGiaoDiemNay].conPhai = -1;
      mangGiaoDiem[chiSoGiaoDiemNay].chiSoVatThe = chiSoVatThe;
      (*soLuongGiaoDiem)++;
      if( *soLuongGiaoDiem == kSO_LUONG__GIAO_DIEM_TOI_DA ) {
         printf( "soLuongGiaoDiem == kSO_LUONG__GIAO_DIEM_TOI_DA (%d)\n", kSO_LUONG__GIAO_DIEM_TOI_DA );
         exit(0);
      }
   }
   
   return chiSoGiaoDiemNay;
}


GiaoDiemBIH chiaVatTheVaTaoGiaoDiem( VatThe *danhSachVatThe, unsigned short *mangChiSoVatTheSapXep, unsigned short soLuongVatThe, unsigned int truc,
                                    float toaDoMatPhang, unsigned short *soLuongTrai, unsigned short *soLuongPhai ) {

   float cucTrai = -kVO_CUC;
   float cucPhai = kVO_CUC;

   short chiSoDau = 0;
   short chiSoCuoi = soLuongVatThe - 1;

   while( chiSoDau <= chiSoCuoi ) {

      BaoBi baoBiTG = danhSachVatThe[mangChiSoVatTheSapXep[chiSoDau]].baoBiTG;
//      printf( "%d baoBiTG: %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f  %d\n", mangChiSoVatTheSapXep[chiSoDau], baoBiTG.gocCucTieu.x, baoBiTG.gocCucTieu.y, baoBiTG.gocCucTieu.z,
//             baoBiTG.gocCucDai.x, baoBiTG.gocCucDai.y, baoBiTG.gocCucDai.z, danhSachVatThe[mangChiSoVatTheSapXep[chiSoDau]].loai );

      // ---- xem nếu vật thể ở bên trái hay bên phải
      if( truc == kTRUC_X ) {
         if( baoBiTG.gocCucDai.x < toaDoMatPhang ) {   // bên trái
            (*soLuongTrai)++;  // tăng số lượng vật thể bên trái
            if( baoBiTG.gocCucDai.x > cucTrai )
               cucTrai = baoBiTG.gocCucDai.x;
            chiSoDau++;  // không cần đổi vật thể
         }
         else if( baoBiTG.gocCucTieu.x > toaDoMatPhang ) {  // bên phải
            (*soLuongPhai)++;  // tăng số lượng vật thể bên phái
            if( baoBiTG.gocCucTieu.x < cucPhai )
               cucPhai = baoBiTG.gocCucTieu.x;
            // ---- đổi vật thể
            unsigned short chiSoVatThe = mangChiSoVatTheSapXep[chiSoDau];
            mangChiSoVatTheSapXep[chiSoDau] = mangChiSoVatTheSapXep[chiSoCuoi];
            mangChiSoVatTheSapXep[chiSoCuoi] = chiSoVatThe;
            chiSoCuoi--;
         }
         else {   // vật thể nằm trên mặt phẳng chia, cần xem ở bên nào nhất
            float cachTrai = toaDoMatPhang - baoBiTG.gocCucTieu.x;
            float cachPhai = baoBiTG.gocCucDai.x - toaDoMatPhang;
            if( cachTrai > cachPhai ) {
               (*soLuongTrai)++;  // tăng số lượng vật thể bên trái
               if( baoBiTG.gocCucDai.x > cucTrai )
                  cucTrai = baoBiTG.gocCucDai.x;
               chiSoDau++;
            }
            else {
               (*soLuongPhai)++;  // tăng số lượng vật thể bên phái
               if( baoBiTG.gocCucTieu.x < cucPhai )
                  cucPhai = baoBiTG.gocCucTieu.x;
               // ---- đổi vật thể
               unsigned short chiSoVatThe = mangChiSoVatTheSapXep[chiSoDau];
               mangChiSoVatTheSapXep[chiSoDau] = mangChiSoVatTheSapXep[chiSoCuoi];
               mangChiSoVatTheSapXep[chiSoCuoi] = chiSoVatThe;
               chiSoCuoi--;
            }
         }
      }
      else if( truc == kTRUC_Y ) {
         if( baoBiTG.gocCucDai.y < toaDoMatPhang ) {   // bên trái
            (*soLuongTrai)++;  // tăng số lượng vật thể bên trái
            if( baoBiTG.gocCucDai.y > cucTrai )
               cucTrai = baoBiTG.gocCucDai.y;
            chiSoDau++;  // không cần đổi vật thể
         }
         else if( baoBiTG.gocCucTieu.y > toaDoMatPhang ) {  // bên phải
            (*soLuongPhai)++;  // tăng số lượng vật thể bên phái
            if( baoBiTG.gocCucTieu.y < cucPhai )
               cucPhai = baoBiTG.gocCucTieu.y;
            // ---- đổi vật thể
            unsigned short chiSoVatThe = mangChiSoVatTheSapXep[chiSoDau];
            mangChiSoVatTheSapXep[chiSoDau] = mangChiSoVatTheSapXep[chiSoCuoi];
            mangChiSoVatTheSapXep[chiSoCuoi] = chiSoVatThe;
            chiSoCuoi--;
         }
         else {   // vật thể nằm trên mặt phẳng chia, cần xem ở bên nào nhất
            float cachTrai = toaDoMatPhang - baoBiTG.gocCucTieu.y;
            float cachPhai = baoBiTG.gocCucDai.y - toaDoMatPhang;
            if( cachTrai > cachPhai ) {
               (*soLuongTrai)++;  // tăng số lượng vật thể bên trái
               if( baoBiTG.gocCucDai.y > cucTrai )
                  cucTrai = baoBiTG.gocCucDai.y;
               chiSoDau++;
            }
            else {
               (*soLuongPhai)++;  // tăng số lượng vật thể bên phái
               if( baoBiTG.gocCucTieu.y < cucPhai )
                  cucPhai = baoBiTG.gocCucTieu.y;
               // ---- đổi vật thể
               unsigned short chiSoVatThe = mangChiSoVatTheSapXep[chiSoDau];
               mangChiSoVatTheSapXep[chiSoDau] = mangChiSoVatTheSapXep[chiSoCuoi];
               mangChiSoVatTheSapXep[chiSoCuoi] = chiSoVatThe;
               chiSoCuoi--;
            }
         }
      }
      else {//if( truc == kTRUC_Z ) {
         if( baoBiTG.gocCucDai.z < toaDoMatPhang ) {   // bên trái
            (*soLuongTrai)++;  // tăng số lượng vật thể bên trái
            if( baoBiTG.gocCucDai.z > cucTrai )
               cucTrai = baoBiTG.gocCucDai.z;
            chiSoDau++;  // không cần đổi vật thể
         }
         else if( baoBiTG.gocCucTieu.z > toaDoMatPhang ) {  // bên phải
            (*soLuongPhai)++;  // tăng số lượng vật thể bên phái
            if( baoBiTG.gocCucTieu.z < cucPhai )
               cucPhai = baoBiTG.gocCucTieu.z;
            // ---- đổi vật thể
            unsigned short chiSoVatThe = mangChiSoVatTheSapXep[chiSoDau];
            mangChiSoVatTheSapXep[chiSoDau] = mangChiSoVatTheSapXep[chiSoCuoi];
            mangChiSoVatTheSapXep[chiSoCuoi] = chiSoVatThe;
            chiSoCuoi--;
         }
         else {   // vật thể nằm trên mặt phẳng chia, cần xem ở bên nào nhất
            float cachTrai = toaDoMatPhang - baoBiTG.gocCucTieu.z;
            float cachPhai = baoBiTG.gocCucDai.z - toaDoMatPhang;
            if( cachTrai > cachPhai ) {
               (*soLuongTrai)++;  // tăng số lượng vật thể bên trái
               if( baoBiTG.gocCucDai.z > cucTrai )
                  cucTrai = baoBiTG.gocCucDai.z;
               chiSoDau++;
            }
            else {  // tăng số lượng vật thể bên phái
               (*soLuongPhai)++;
               if( baoBiTG.gocCucTieu.z < cucPhai )
                  cucPhai = baoBiTG.gocCucTieu.z;
               // ---- đổi vật thể
               unsigned short chiSoVatThe = mangChiSoVatTheSapXep[chiSoDau];
               mangChiSoVatTheSapXep[chiSoDau] = mangChiSoVatTheSapXep[chiSoCuoi];
               mangChiSoVatTheSapXep[chiSoCuoi] = chiSoVatThe;
               chiSoCuoi--;
            }
         }
      }
   }

   
   // ---- tạo giao điểm
   GiaoDiemBIH giaoDiem;

   giaoDiem.cat[0] = cucTrai;
   giaoDiem.cat[1] = cucPhai;
   giaoDiem.truc = truc;
   
   return giaoDiem;
}

void tinhTrucVaToaMatPhangChia( BaoBi *baoBi, unsigned int *truc, float *toaDoMatPhang ) {
   // ---- kiếm trục chia, xài cạnh dài nhất
   float canh = baoBi->gocCucDai.x - baoBi->gocCucTieu.x;
   *truc = kTRUC_X;
   float canhY = baoBi->gocCucDai.y - baoBi->gocCucTieu.y;
   if( canh < canhY ) {
      canh = canhY;
      *truc = kTRUC_Y;
   }
   float canhZ = baoBi->gocCucDai.z - baoBi->gocCucTieu.z;
   if( canh < canhZ ) {
      canh = canhZ;
      *truc = kTRUC_Z;
   }
   
   // ---- tính tọa độ mặt phẳng, phần nữa cạnh dài nhất
   if( *truc == kTRUC_X )
      *toaDoMatPhang = baoBi->gocCucTieu.x + canh*0.5f;
   else if( *truc == kTRUC_Y )
      *toaDoMatPhang = baoBi->gocCucTieu.y + canh*0.5f;
   else  // if( *truc == kTRUC_Z )
      *toaDoMatPhang = baoBi->gocCucTieu.z + canh*0.5f;
   
/*   printf( "BaoBi %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f  Truc %x  toaDoMatPhang %5.3f\n", baoBi->gocCucTieu.x, baoBi->gocCucTieu.y, baoBi->gocCucTieu.z,
          baoBi->gocCucDai.x, baoBi->gocCucDai.y, baoBi->gocCucDai.z,
          *truc, *toaDoMatPhang ); */
}

void chiaBaoBi( unsigned int truc, float matPhangChia, BaoBi *baoBi, BaoBi *baoBiTrai, BaoBi *baoBiPhai ) {
   
   // ---- chép bao bì
   baoBiTrai->gocCucTieu.x = baoBi->gocCucTieu.x;
   baoBiTrai->gocCucTieu.y = baoBi->gocCucTieu.y;
   baoBiTrai->gocCucTieu.z = baoBi->gocCucTieu.z;
   baoBiTrai->gocCucDai.x = baoBi->gocCucDai.x;
   baoBiTrai->gocCucDai.y = baoBi->gocCucDai.y;
   baoBiTrai->gocCucDai.z = baoBi->gocCucDai.z;
   
   baoBiPhai->gocCucTieu.x = baoBi->gocCucTieu.x;
   baoBiPhai->gocCucTieu.y = baoBi->gocCucTieu.y;
   baoBiPhai->gocCucTieu.z = baoBi->gocCucTieu.z;
   baoBiPhai->gocCucDai.x = baoBi->gocCucDai.x;
   baoBiPhai->gocCucDai.y = baoBi->gocCucDai.y;
   baoBiPhai->gocCucDai.z = baoBi->gocCucDai.z;
   
   // ---- tính bao bì chia mới
   if( truc == kTRUC_X ) {
      baoBiTrai->gocCucDai.x = matPhangChia;
      baoBiPhai->gocCucTieu.x = matPhangChia;
   }
   else if( truc == kTRUC_Y ) {
      baoBiTrai->gocCucDai.y = matPhangChia;
      baoBiPhai->gocCucTieu.y = matPhangChia;
   }
   else { //if( truc == kTRUC_Z ) {
      baoBiTrai->gocCucDai.z = matPhangChia;
      baoBiPhai->gocCucTieu.z = matPhangChia;
   }
}
