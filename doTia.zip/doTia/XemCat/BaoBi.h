#pragma once

#include "../Toan/Vecto.h"
#include "../Toan/Tia.h"

/* Bao Bì */
typedef struct {
   Vecto gocCucTieu;
   Vecto gocCucDai;
} BaoBi;


/* xem cắt bao bì */
unsigned char xemCatBaoBi( BaoBi *baoBi, Tia *tia );

/* tính nhỏ nhất của tám gía trị */
float timNhoNhatCuaTamGiaTri( float so0, float so1, float so2, float so3, float so4, float so5, float so6, float so7 );

/* tính lớn nhất của tám gía trị */
float timLonNhatCuaTamGiaTri( float so0, float so1, float so2, float so3, float so4, float so5, float so6, float so7 );
