#include "VatThe.h"
#include "../HangSo.h"
#include <stdlib.h>

/* Hủy Danh Sách Vật Thể */
void huyDanhSachVatThe( VatThe *danhSachVatThe, unsigned short soLuongVatThe ) {
   
   unsigned short chiSoVatThe = 0;
   while( chiSoVatThe < soLuongVatThe ) {
      if( (danhSachVatThe[chiSoVatThe].loai == kLOAI_VAT_THE__BOOL)
         || (danhSachVatThe[chiSoVatThe].loai == kLOAI_VAT_THE__GHEP) ) {
         free( danhSachVatThe[chiSoVatThe].danhSachVatThe );
      }
      chiSoVatThe++;
   }
}