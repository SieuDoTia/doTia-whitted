#pragma once

#include "../Toán/Vecto.h"
#include "../Toán/Quaternion.h"
#include "../Mau.h"
#include "../HọaTiết/HoaTiet.h"
#include "../XemCat/BaoBi.h"
#include "../HìnhDạng/HinhDang.h"


/* Vật Thể */
struct VatThe {
   HinhDang hinhDang;    // hìng dạng
   unsigned char loai;   // loại
   float phongTo[16];
   float xoay[16];
   float dich[16];
   float bienHoa[16];    // ma trận biến hóa

   float nghichDich[16];
   float nghichXoay[16];
   float nghichPhongTo[16];
   float nghichBienHoa[16];  // ma trận nghịch biến hóa
   float nghichBienHoaChoPhapTuyen[16];  // ma trận xài cho tính pháp tuyến (đổi thành toạ độ thế giới)
   
   // ---- cho các phim trường
   Quaternion quaternion;
   Vecto vanToc;   // vận tốc, xài khi cần giữ vận tốc từ thời trước, ví dụ rớt xuống bởi hấp dẫn
   Vecto viTriDau; // vị trí đầu, xài khi cần tính vị trí tương đối với vị trí ban đầu
   // ---- cho phim trường 0
   unsigned char duongVao; // đường vào, cho chọn đường ngẫu nhiên
   unsigned char duongRa;  // đường ra, cho chọn đường ngẫu nhiên
   unsigned char thaiTrang; // trong vòng tròn

   Mau mau;   // màu của vật
//   float tiSoPhanXa;  // tỉ số phản xạ
   float chietSuat;    // chiết suất khúc xạ
   unsigned char soHoaTiet;   // tên họa tiết màu
   HoaTiet hoaTiet;

   // ---- bao bì
   BaoBi baoBiVT; // bao bì toạ độ vật thể
   BaoBi baoBiTG; // bao bì toạ độ thế giới

   // ---- chỉ cho vật thể ghép và bool
   struct VatThe *danhSachVatThe;  // chỉ cho vật thể ghép hay bool
   char giaTri;    // -1 hay 1 cho bool
   unsigned char mucDichBool;  // giá trị mục dịch cho thao tác bool
   unsigned soLuongVatThe;   // số lượng vật thế trong ghép hay bool
   
   // ---- cho vật thể ghép
   unsigned char xaiHoaThietVatTheGhep;  // cho vật thể ghép (-1)
   unsigned char soVatTheGhepTrung;  // cho biết dùng màu cho vật thể nào

   // ---- chỉ cho di chuyển theo cong Bezier, có thể lập lại
   float thamSoBezier;
   unsigned short soHoatHinh;   // số hoạt hình
};

/* Chỉ Định Kiểu Vật Thể */
typedef struct VatThe VatThe;   // Vật Thể

/* Hủ danh sách vật thể */
void huyDanhSachVatThe( VatThe *danhSachVatThe, unsigned short soLuongVatThe );