#include "../Toán/Vecto.h"
#include "../Toán/Quaternion.h"


typedef enum {
   kKIEU_CHIEU__PHOI_CANH,
   kKIEU_CHIEU__CU_TUYEN,
   kKIEU_CHIEU__TOAN_CANH,
} KieuChieu;

/* MáyQuayPhim */
typedef struct {
   Vecto viTri;       // vị trí
   float cachManChieu;   // cách xa màn chiếu
   float xoay[16];
   Quaternion quaternion;
   
   unsigned char kieuChieu;  // kiểu chiếu ảnh

} MayQuayPhim;

