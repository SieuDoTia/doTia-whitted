// Vectơ.c
// 2558-12-16
// Có hàm dịch vụ vectơ xài thường xuyên

#include <math.h>
#include "Vecto.h"

#pragma mark ---- Tích Có Hướng
Vecto tichCoHuong( Vecto *vecto0, Vecto *vecto1 ) {
   Vecto ketQua;
   ketQua.x = vecto0->y*vecto1->z - vecto0->z*vecto1->y;
   ketQua.y = vecto0->z*vecto1->x - vecto0->x*vecto1->z;
   ketQua.z = vecto0->x*vecto1->y - vecto0->y*vecto1->x;
   return ketQua;
}

void donViHoa( Vecto *vecto ) {
   float doLon = vecto->x*vecto->x + vecto->y*vecto->y + vecto->z*vecto->z;
   if( doLon > 0.0f ) {
      doLon = sqrtf( doLon );
      vecto->x /= doLon;
      vecto->y /= doLon;
      vecto->z /= doLon;
   }
}
