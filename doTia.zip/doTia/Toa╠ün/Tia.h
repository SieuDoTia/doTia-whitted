#pragma once

#include "Vecto.h"

/* Tia */
typedef struct {
   Vecto goc;       // điểm gốc
   Vecto huong;     // hướng
   Vecto daoNghichHuong;  // đạo nghịch hướng
   unsigned char dau[3];     // dấu cho hướng 
} Tia;