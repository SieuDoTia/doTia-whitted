// Vecto.h
// 2558-12-16

#pragma once

typedef struct {
   float x;   // tọa đồ x; y; z
   float y;
   float z;
} Vecto;

// ---- dịch vụ vectơ
void donViHoa( Vecto *vecto );   // đơn vị hóa
Vecto tichCoHuong( Vecto *vecto0, Vecto *vecto1 );   // tích có hướng