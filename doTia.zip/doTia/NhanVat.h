#include "VậtThể/VatThe.h"
#include "Toán/Vecto.h"

unsigned short datVaiChanh( VatThe *danhSachVat, Vecto viTri );
unsigned short datKeThuSaoGaiDo( VatThe *danhSachVat, Vecto viTri );
unsigned short datKeThuSaoGaiXanh( VatThe *danhSachVat, Vecto viTri );
unsigned short datTraiBanhBiGiet( VatThe *danhSachVat );