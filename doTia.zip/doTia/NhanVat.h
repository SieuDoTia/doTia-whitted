#include "VậtThể/VatThe.h"
#include "Toán/Vecto.h"

unsigned short datVaiChanh( VatThe *danhSachVat, Vecto viTri );
unsigned short datKeThuSaoGai( VatThe *danhSachVat, Vecto viTri );
unsigned short datTraiBanhBiGiet( VatThe *danhSachVat );