#pragma once

#include "../Toan/Vecto.h"
#include "../Toan/Tia.h"
#include "../XemCat/BaoBi.h"

/* HìnhCầu */
typedef struct {
   float banKinh;
   float hopQuanh[6];   // hộp quanh
} HinhCau;



// ---- hình cầu
HinhCau datHinhCau( float banKinh, BaoBi *baoBiVT ); // đặt hình cầu
float xemCatHinhCau( HinhCau *hinhCau, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );   // xem hình cầu
unsigned char xemDiemTrongHinhCau( HinhCau *hinhCau, Vecto *diem );