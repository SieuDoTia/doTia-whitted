#pragma once

#include "TamGiac.h"
#include "../Toan/Vecto.h"
#include "../Toan/Tia.h"
#include "../XemCat/BaoBi.h"


/* Hình Lăng Trụ */
typedef struct {
   Vecto *mangDinh;   // mảng đỉnh
   TamGiac *mangTamGiac;  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} HinhLangTru;


// ---- hình lăng trụ
HinhLangTru datHinhLangTru( float banKinh, float beCao, unsigned char soLuongMat, BaoBi *baoBiVT );  // đặt hình lăng trụ
