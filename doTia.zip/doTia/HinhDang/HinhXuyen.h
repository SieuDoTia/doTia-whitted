#pragma once
#include "../Toan/Vecto.h"
#include "../Toan/Tia.h"
#include "../XemCat/BaoBi.h"


/* Hình Xuyến */
typedef struct {
   Vecto viTri;    // vị trí
   float banKinhVong;   // bán kính vòng
   float banKinhOng;    // bán kính ống
   float hopQuanh[6];  // hộp quanh
} HinhXuyen;


/* đặt hình xuyến */
HinhXuyen datHinhXuyen( float banKinhVong, float banKinhOng, BaoBi *baoBiVT ); // đặt hình xuyến

/*  xem cắt hình xuyến */
float xemCatHinhXuyen( HinhXuyen *hinhXuyen, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );