#pragma once

#include "TamGiac.h"
#include "../Toan/Vecto.h"
#include "../XemCat/BaoBi.h"


/* Thập Nhị Diện */
typedef struct {
   Vecto mangDinh[32];   // mảng đỉnh
   TamGiac mangTamGiac[60];  // mảng mặt
   unsigned short soLuongTamGiac;   // số lượng tam giác
   float hopQuanh[6];   // hộp quanh
} ThapNhiDien;


// Đặt thập nhị diện
ThapNhiDien datThapNhiDien( float beRong, float beCao, float beDai, BaoBi *baoBiVT ); // đặt thập nhị diện