#pragma once
#include "../Toan/Vecto.h"
#include "../Toan/Tia.h"
#include "../XemCat/BaoBi.h"


/* Mặt Sóng */
typedef struct {
   Vecto viTri;    // vị trí
   float nuaBeRong;   // bề dài cảnh X
   float nuaBeDai;    // bề dài cảnh Z
   float banKinhBinhBP;   // bán kính bình phương
   
   float bienDo0;  // biên độ 0
   float bienDo1;  // biên độ 1
   float bienDoNhat;  // biến độ nhất = biên độ 0 + biên độ 1
   
   float tanSo0;  // tần số 0
   float tanSo1;  // tần số 1
   
   float tanSo0_x;  // tần số 0 hướng x
   float tanSo1_x;  // tần số 1 hướng x

   float tanSo0_z;  // tần số 0 hướng z
   float tanSo1_z;  // tần số 1 hướng z
   
   unsigned char tron;  // cho biết mặt chữ nhật hay tròn , = 0 CH; = 1 tròn
   float hopQuanh[6];  // hộp quanh
   unsigned int thoiGian;  // thời gian cho chuyển động mặt sóng
} MatSong;


/* Đặt mặt sóng */
MatSong datMatSong( float beRong, float beDai, float bienDo0, float bienDo1, float tanSo0, float tanSo1, float tanSo0_x, float tanSo1_x, float tanSo0_z, float tanSo1_z, unsigned char tron, BaoBi *baoBiVT );

/* Xem cắt mặt sóng */
float xemCatMatSong( MatSong *matSong, Tia *tia, Vecto *phapTuyen, Vecto *diemTrung );
