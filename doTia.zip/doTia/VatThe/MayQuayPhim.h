#include "../Toan/Vecto.h"
#include "../Toan/Quaternion.h"


typedef enum {
   kKIEU_CHIEU__PHOI_CANH,
   kKIEU_CHIEU__TRUC_GIAO,
   kKIEU_CHIEU__TOAN_CANH,
} KieuChieu;

/* MáyQuayPhim */
typedef struct {
   Vecto viTri;       // vị trí
   float cachManChieu;   // cách xa màn chiếu
   float xoay[16];
   Quaternion quaternion;
   
   unsigned char kieuChieu;  // kiểu chiếu ảnh

} MayQuayPhim;

