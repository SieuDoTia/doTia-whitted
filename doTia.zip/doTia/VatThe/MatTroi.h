#pragma once
#include "../Toan/Vecto.h"
#include "../Mau.h"


/* Mật Trời */
typedef struct {
   Vecto huongAnh;
   Mau mauAnh;
} MatTroi;