// For Open Digital Cinema Package
#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>
#include <string.h>
#include "DocEXR.h"

#define MAGIC_NUMBER_EXR 0x762f3101

typedef enum {
   EXR_COMPRESSION_NO       = 0,          /* no compression                  */
   EXR_COMPRESSION_RLE      = 1,          /* 8-bit run-length-encoded        */
   EXR_COMPRESSION_ZIPS     = 2,          /* zip single lines                    */
   EXR_COMPRESSION_ZIP      = 3,          /* zip 16 line                 */
   EXR_COMPRESSION_PIZ      = 4,          /* piz (not supported)             */
   EXR_COMPRESSION_PXR24    = 5,          /* pixar 24 bit (not supported)    */
   EXR_COMPRESSION_B44      = 6,          /* b44 (not supported)             */
   EXR_COMPRESSION_B44A     = 7,          /* b44a (not supported)            */
   EXR_COMPRESSION_DWAA     = 8,          /* dwaa 32 lines (not supported)  */
   EXR_COMPRESSION_DWAB     = 9,          /* dwab 256 lines (not supported) */
} exr_compression_enum;

typedef enum {
   EXR_UINT      = 0,          /* unsigned int 32 bit, never use for color data */
   EXR_HALF      = 1,          /* half, 16 bit floating point */
   EXR_FLOAT     = 2,          /* float, 32 bit floating point */
} exr_dataType_enum;

typedef struct {
   char name[255];    /* channel name, want find 'B', 'G', 'R' channels    */
   unsigned char data_type;   /* channel data type, int, half, float               */
   unsigned char non_linear;  /* non linear, only use for B44 and B44A compression */
   unsigned int sample_x;     /* sample x direction, only support == 1             */
   unsigned int sample_y;     /* sample y direction, only support == 1             */
   unsigned int offset;       /* position in image data                            */
} exr_channel;

typedef struct {
   unsigned short num_channels; /* number channels       */
   exr_channel channel[5];      /* channel array, only read data for A, B, G, R, Z channel */
   unsigned short data_width;   /* channel data width for all channels */
} exr_channel_list;

typedef struct {
   int left;
   int right;
   int bottom;
   int top;
} exr_window;

typedef struct {
   int width;        /* tile width */
   int height;       /* tile height */
   char level;       /* level: 0 = one level, 1 = MIP, 2 = RIP */
} exr_tile;

/* exr attributes, only save data for create dip */
typedef struct {
   exr_channel_list channel_list;    /* channel list */
   unsigned char compression;        /* compression */
   exr_window dataWindow;            /* data window */
   exr_window displayWindow;         /* display window */
   //    unsigned int width;              /* width of image - calculate */
   unsigned char tiles;              /* bool tell if have tiles */
   exr_tile tileDesc;                /* tileDesc */
   unsigned char opacity;            /* bool tell if have opacity channel */
   unsigned char depth;              /* bool tell if have depth channel */
} exr_attributes;

/* exr chunk data */
typedef struct {
   unsigned int num_chunks;                  /* number chunks */
   unsigned long long *chunk_table;          /* chunk table list */
   unsigned long long *chunk_table_position; /* list for chunk's position in table */
} exr_chunk_data;


/* for change half become float */
typedef union {
   unsigned int i;
   float f;
} u_intfloat;

/* index for channels */
enum {
   BLUE,
   GREEN,
   RED,
   OPACITY,
   DEPTH
};


void luuAnhZIP( char *tenTep, exr_image_data *anh, unsigned char kieuDuLieu, unsigned short thoiGianKetXuat );

/* shift for not normal numbers */
unsigned char shiftForNumber( unsigned short value ) {
 
    unsigned char shift = 0;
  
   if( value < 1 )   // never see this case
      shift = 0;
   else if( value < 2 )
      shift = 1;
   else if( value < 4 )
      shift = 2;
   else if( value < 8 )
      shift = 3;
   else if( value < 16 )
      shift = 4;
   else if( value < 32 )
      shift = 5;
   else if( value < 64 )
      shift = 6;
   else if( value < 128 )
      shift = 7;
   else if( value < 256 )
      shift = 8;
   else if( value < 512 )
      shift = 9;
   else if( value < 1024 )
      shift = 10;
   // never see case after 1024
    
   return shift;
}


float half2float( unsigned short half ) {
    
    u_intfloat int_fl;

    // normal number +
    if( (half > 0x03ff) && (half < 0x7c00) ) {
       unsigned int exponent = (((half & 0x7c00) >> 10) + 112) << 23;
       unsigned int value = (half & 0x03ff) << 13;
       int_fl.i = exponent | value;
    }
     // normal number -
    else if( (half > 0x83ff) && (half < 0xfc00) ) {
       unsigned int exponent = (((half & 0x7c00) >> 10) + 112) << 23;
       unsigned int value = (half & 0x03ff) << 13;
       int_fl.i = 0x80000000 + exponent + value;
    }
    // not normal number +
    else if( (half > 0x0000) && (half < 0x0400) ) {
       unsigned char shift = shiftForNumber( half );
       unsigned int exponent = (shift + 102) << 23;
       unsigned int value = (half << (24 - shift)) & 0x007fffff;
      int_fl.i = exponent + value;
    }
    // not normal number -
    else if( (half > 0x8000) && (half < 0x8400) ) {
       unsigned char shift = shiftForNumber( half & 0x7fff );
       unsigned int exponent = (shift + 102) << 23;
       unsigned int value = (half << (24 - shift)) & 0x007fffff;
      int_fl.i = 0x80000000 + exponent + value;
    }
    // zero +
    else if( half == 0x0000 )
        int_fl.i = 0x00000000;
 
    // zero -
    else if( half == 0x8000 )
        int_fl.i = 0x80000000;
 
    // infinity +
    else if( half == 0x7c00 ) 
        int_fl.i = 0x7f800000;
  
    // infinity -
    else if( half == 0xfc00 )
        int_fl.i = 0xff800000;

    // NaN +
    else if( (half > 0x7c00) && (half < 0x8000) ) 
        int_fl.i = ((half & 0x3ff) << 13) | 0x7f800000;
 
    // NaN -
    else if( half > 0xfc00 )
        int_fl.i = ((half & 0x3ff) << 13) | 0xff800000;

    return int_fl.f;
}

#pragma mark ---- Read Attributes
unsigned char readString255FromFile( FILE *fp, char *string ) {

   unsigned char index = 0;
   do {
     string[index] = fgetc( fp );
     index++;
   } while( string[index-1] != 0x00 );

   return index-1;
}

exr_channel_list readChannelData( FILE *exr_fp) {
   
   exr_channel_list channel_list;
   unsigned char finish = 0x00;
   channel_list.num_channels = 0;
   channel_list.data_width = 0;
   unsigned short channel_index = 0;
   unsigned short offset = 0;
   
   // ---- use channel name for know if have channel (name not 0x00)
   channel_list.channel[BLUE].name[0] = 0x00;
   channel_list.channel[GREEN].name[0] = 0x00;
   channel_list.channel[RED].name[0] = 0x00;
   channel_list.channel[OPACITY].name[0] = 0x00;
   channel_list.channel[DEPTH].name[0] = 0x00;
   
   do {
      // ---- find channels 'A', 'B', 'G', 'R', 'Z'
      exr_channel channel;
      unsigned char stringLength = readString255FromFile( exr_fp, channel.name );

      if( stringLength ) {
         unsigned char find_channel = 0x00;

         if( channel.name[0] == 'B' ) {
            find_channel = 0x01;
            channel_index = BLUE;
         }
         else if( channel.name[0] == 'G' ) {
            find_channel = 0x01;
            channel_index = GREEN;
         }
         else if( channel.name[0] == 'R' ) {
            find_channel = 0x01;
            channel_index = RED;
         }
         else if( channel.name[0] == 'A' ) {
            find_channel = 0x01;
            channel_index = OPACITY;
         }
         else if( channel.name[0] == 'Z' ) {
            find_channel = 0x01;
            channel_index = DEPTH;
         }

         if( find_channel ) {
            // ---- read channel data type
            channel.data_type = fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
            // ---- read channel non linear
            channel.non_linear = fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
            // ---- read sample x
            channel.sample_x = fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
            // ---- read sample y
            channel.sample_y = fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
            fgetc( exr_fp );
   
            // ---- offset
            channel.offset = offset;
            if( channel.data_type == EXR_HALF) {
               offset += 2;
               channel_list.data_width += 2;
            }
            else {
               offset += 4;
               channel_list.data_width += 4;
            }
   
            // ---- save channel
            channel_list.channel[channel_index] = channel;
            channel_list.num_channels++;
         }
         // ---- not need channel, skip channel, need read all channels
         else {
            // ---- data offset
            unsigned char data_type = fgetc( exr_fp );
            if( data_type == EXR_HALF) {
               offset += 2;
               channel_list.data_width += 2;
            }
            else {
               offset += 4;
               channel_list.data_width += 4;
            }
            fseek( exr_fp, ftell( exr_fp ) + 15, SEEK_SET );
         }
   }
   else
       finish = 0x01;

   } while( !finish );
 
   return channel_list;
}

exr_attributes readAttributes( FILE *exr_fp ) {

   exr_attributes attributes;
   attributes.tiles = 0;
   unsigned char finish = 0;

   do {
      // ----
      char attribute_name[255];
      unsigned char string_length = readString255FromFile( exr_fp, attribute_name );

      if( string_length ) {
         // ---- read attribute data type
         char attribute_data_type[255];
         readString255FromFile( exr_fp, attribute_data_type );

         // ---- read attribute length
         unsigned int attribute_length = 0;
         fread( &attribute_length, 4, 1, exr_fp );

         if( !strcmp( "channels", attribute_name ) ) {
            // ---- skip attribute, chưa làm hàm này
            attributes.channel_list = readChannelData( exr_fp );
            
            // ---- check have extra channels
            if( attributes.channel_list.channel[OPACITY].name[0] == 'A' )
               attributes.opacity = 1;
            else
               attributes.opacity = 0;

            if( attributes.channel_list.channel[DEPTH].name[0] == 'Z' )
               attributes.depth = 1;
            else
               attributes.depth = 0;
            
         }
         else if( !strcmp( "compression", attribute_name ) )
            attributes.compression = fgetc( exr_fp );
         else if( !strcmp( "dataWindow", attribute_name ) ) {
            fread( &(attributes.dataWindow.left), 4, 1, exr_fp );
            fread( &(attributes.dataWindow.bottom), 4, 1, exr_fp );
            fread( &(attributes.dataWindow.right), 4, 1, exr_fp );
            fread( &(attributes.dataWindow.top), 4, 1, exr_fp );
         }
         else if( !strcmp( "displayWindow", attribute_name ) ) {
            fread( &(attributes.displayWindow.left), 4, 1, exr_fp );
            fread( &(attributes.displayWindow.bottom), 4, 1, exr_fp );
            fread( &(attributes.displayWindow.right), 4, 1, exr_fp );
            fread( &(attributes.displayWindow.top), 4, 1, exr_fp );
         }
         else if( !strcmp( "tiles", attribute_name ) ) {
            attributes.tiles = 1;
            fread( &(attributes.tileDesc.width), 4, 1, exr_fp );
            fread( &(attributes.tileDesc.height), 4, 1, exr_fp );
            attributes.tileDesc.level = fgetc( exr_fp );

         }
         else
            // ---- skip attribute
            fseek( exr_fp, ftell( exr_fp ) + attribute_length, SEEK_SET );

 //        printf( "%s %s %d\n", attribute_name, attribute_data_type, attribute_length );
      }
      else 
         finish = 0x01;
   } while( !finish );

   return attributes;
}

exr_chunk_data read_chunk_data( FILE *exr_fp, exr_attributes *attributes ) {

   exr_chunk_data chunk_data;
   unsigned short num_rows = (attributes->dataWindow.top - attributes->dataWindow.bottom) + 1;


   if( attributes->tiles ) {
      unsigned short num_columns = (attributes->dataWindow.right - attributes->dataWindow.left) + 1;
      unsigned short number_tile_column = num_columns/attributes->tileDesc.width;
      unsigned short number_tile_row = num_rows/attributes->tileDesc.height;
      if( num_columns % attributes->tileDesc.width )
         number_tile_column++;
      if( num_rows % attributes->tileDesc.height )
         number_tile_row++;
      chunk_data.num_chunks = number_tile_column*number_tile_row;
   }
   else {  // scanlines
      // ---- if EXR_COMPRESSION_ZIP, 16 rows per chunk
      if( attributes->compression == EXR_COMPRESSION_ZIP ) { //
         chunk_data.num_chunks = num_rows >> 4;
         if( num_rows & 0xf )
            chunk_data.num_chunks++;
      }
      else
         chunk_data.num_chunks = num_rows;
   }
   
//   printf( "chunk_data.num_chunks %d\n", chunk_data.num_chunks );
   // ---- get memory for chunk table
   chunk_data.chunk_table = malloc( chunk_data.num_chunks << 3 );  // 8 bytes
   chunk_data.chunk_table_position = malloc( chunk_data.num_chunks << 3 );  // 8 bytes
   
   // ----- read address for chunks
   unsigned int chunk_index = 0;
   while( chunk_index < chunk_data.num_chunks ) {
      chunk_data.chunk_table_position[chunk_index] = ftell( exr_fp );
      fread( &(chunk_data.chunk_table[chunk_index]), 8, 1, exr_fp );
//      printf( "%d %lld %llx - %lld\n", chunk_index, chunk_data.chunk_table[chunk_index], chunk_data.chunk_table[chunk_index], chunk_data.chunk_table_position[chunk_index] );
      chunk_index++;
   }

   return chunk_data;
}


#pragma mark ----- Compression
/* unfilter buffer - from OpenEXR library */
void unfilter_buffer( unsigned char *buffer, unsigned char *unfilteredBuffer, unsigned int length ) {

   {
      unsigned char *t = (unsigned char *)buffer + 1;           // bỏ byte đầu tiên
      unsigned char *stop = (unsigned char *)buffer + length;   // cuối buffer
      
      while (t < stop) {
 //        printf( "unfilter_buffer t %p  stop %p  length %d\n", t, stop, length );
         // ---- unfilter byte
         int d = (int) (t[-1]) + (int)(t[0]) - 128;  // add difference byte before subtract 128
         //      NSLog( @"ImfFilter: unfilter t[-1] %d + t[0] %d - 128 = d %d", t[-1], t[0], d);
         // ---- save unfiltered byte
         t[0] = d;
         ++t;
      }
   }
   //
   // Data organization || 0; (length+1)/2 || 1; (length+1)/2 + 1 || 2; (length+1)/2 + 2 || etc.
   //

   char *t1 = (char *)buffer;          // begin buffer
   char *t2 = (char *)buffer + (length + 1) / 2;  // half buffer
   char *s = (char *)unfilteredBuffer;  // start of unfiltered buffer
   char *stop = s + length;             // end unfiltered buffer
   unsigned char finished = 0x0;
   
   while( !finished ) {
      // ---- if not at unfilteredBuffer end
      if (s < stop)
         *(s++) = *(t1++);  // copy from buffer
      else
         finished = 0x1;
      // ---- if not at unfilteredBuffer end
      if (s < stop)
         *(s++) = *(t2++);  // copy next from half buffer
      else
         finished = 0x1;
   }
}

void uncompress_rle( unsigned char *compressed_buffer, unsigned int compressed_buffer_length, unsigned char *uncompressed_buffer, int uncompressed_buffer_length) {
   
   unsigned char *outStart = compressed_buffer;
   
   // ---- while not finish all in buffer
   while (compressed_buffer_length > 0) {
      // ---- if signed byte value less than zero
      if (*compressed_buffer > 127) {
         // ---- count for not same byte value
         int count = -((char)*compressed_buffer);
         compressed_buffer++;
         // ---- reduce amount count of bytes remaining for in buffer
         compressed_buffer_length -= count + 1;
         // ---- if count larger than out buffer length still available
         if (0 > (uncompressed_buffer_length -= count)) {
            printf( "uncompress_rle: Error buffer not length not enough\n" );
            return;
         }
         // ---- copy not same byte and move to next byte
         while (count-- > 0)
            *uncompressed_buffer++ = *(compressed_buffer++);
      }
      else {
         // ---- count number bytes same
         int count = *compressed_buffer++;
         // ---- reduce amount count of remaining bytes for in buffer
         compressed_buffer_length -= 2;
         // ---- if count larger than out buffer length still available
         if (0 > (uncompressed_buffer_length -= count + 1)) {
            printf( "uncompress_rle: Error buffer not length not enough\n" );
            return;
         }
         // ---- copy same byte
         while (count-- >= 0)
            *uncompressed_buffer++ = *compressed_buffer;
         // ---- move to next byte
         compressed_buffer++;
      }
   }
}

unsigned int uncompress_zip( unsigned char *compressed_buffer, unsigned int compressed_buffer_length, unsigned char *uncompressed_buffer, unsigned int uncompressed_buffer_length ) {

   // ---- use zlib to inflate (decompress) image data
   int err;
   z_stream d_stream; // decompression stream data struct
   
   d_stream.zalloc = Z_NULL;
   d_stream.zfree = Z_NULL;
   d_stream.opaque = Z_NULL;
   d_stream.data_type = Z_BINARY;
   
   d_stream.next_in  = compressed_buffer;
   d_stream.avail_in = compressed_buffer_length;

   // ---- check if initialization has no error
   err = inflateInit(&d_stream);

   if( err != Z_OK ) {
      printf( "uncompress_zip: error inflateInit %d (%x) d_stream.avail_in %d\n", err, err, d_stream.avail_in );
   }
   
   // ---- give data to decompress
   d_stream.next_out = uncompressed_buffer;
   d_stream.avail_out = uncompressed_buffer_length;
   
   err = inflate(&d_stream, Z_STREAM_END);
 
   if( err != Z_STREAM_END ) {
      if( err == Z_OK) {
         printf( "ImfCompressorZIP: uncompress: Z_OK d_stream.avail_out %d d_stream.total_out %lu\n",
               d_stream.avail_out, d_stream.total_out );
      }
      else
      printf( "ImfCompressorZIP: uncompress: error inflate %d (%x) d_stream.avail_out %d d_stream.total_out %lu\n",
            err, err, d_stream.avail_out, d_stream.total_out );
      
   }

   err = inflateEnd( &d_stream );
   if( err != Z_OK )
      printf( "ExrZIP: uncompress: error inflateEnd %d (%x) c_stream.avail_in %d\n", err, err, d_stream.avail_in );

   return d_stream.total_out;
}

#pragma mark ---- Copy Scanline
void copy_half_data( unsigned char *buffer, float *channel_data, unsigned short num_rows, unsigned short num_columns, unsigned short start_row_number, exr_channel *channel, unsigned short channel_data_width ) {

   // ---- calculate offset for channel data,
   unsigned int channel_data_offset = num_columns*start_row_number;
 
   unsigned short row_index = 0;
   while( row_index < num_rows ) {
      // ---- calculate offset for channels
      unsigned int buffer_offset = num_columns*(channel_data_width*row_index + channel->offset);

      unsigned short column_index = 0;
      while( column_index < num_columns ) {
         // ---- combine data for half number
         unsigned short half = buffer[buffer_offset] | buffer[buffer_offset+1] << 8;

         // ---- convert half and save float data in channel
         channel_data[channel_data_offset] = half2float( half );

         channel_data_offset++;
         buffer_offset += 2;
         column_index++;
      }
      row_index++;
   }
}

void copy_float_data( unsigned char *buffer, float *channel_data, unsigned short num_rows, unsigned short num_columns, unsigned short start_row_number, exr_channel *channel, unsigned short channel_data_width ) {

   // ---- calculate offset for channel data,
   unsigned int channel_data_offset = num_columns*start_row_number;
//   printf( "float: channel_data_offset %d\n", channel_data_offset );
   
   u_intfloat int_fl;

   unsigned short row_index = 0;
   while( row_index < num_rows ) {
      // ---- calculate offset for channels
      unsigned int buffer_offset = num_columns*(channel_data_width*row_index + channel->offset);
//      printf( "  float: channel_data_offset %d  buffer_offset %d\n", channel_data_offset, buffer_offset );

      unsigned short column_index = 0;
      while( column_index < num_columns ) {
         // ---- combine data for float number
         int_fl.i = buffer[buffer_offset] | buffer[buffer_offset+1] << 8 | buffer[buffer_offset+2] << 16 | buffer[buffer_offset+3] << 24;

         // ---- save float data in channel
         channel_data[channel_data_offset] = int_fl.f;
 /*        printf( " %d %02x %02x %02x %02x  channel_data_offset %d (%5.3e)\n", buffer_offset, buffer[buffer_offset], buffer[buffer_offset+1], buffer[buffer_offset+2],
                buffer[buffer_offset+3], channel_data_offset, 
                channel_data[channel_data_offset] );
*/
         channel_data_offset++;
         buffer_offset += 4;
         column_index++;
      }
      row_index++;
   }
}

#pragma mark ---- Copy Tile
void copy_half_data__tile( unsigned char *buffer, float *channel_data, unsigned short image_width, unsigned short num_rows, unsigned short num_columns, unsigned short start_row_number, unsigned short start_col_number, exr_channel *channel, unsigned short channel_data_width ) {
   
   unsigned short tile_row_index = 0;
   while( tile_row_index < num_rows ) {
      // ---- calculate offset for channel data,
      unsigned int channel_data_offset = image_width*(tile_row_index + start_row_number) + start_col_number;
      
      // ---- calculate offset for channels
      unsigned int buffer_offset = num_columns*(channel_data_width*tile_row_index + channel->offset);
      
      unsigned short tile_column_index = 0;
      while( tile_column_index < num_columns ) {
     //    printf( "tile row %d  col  %d\n", tile_row_index, tile_column_index );
         // ---- combine data for half number
         unsigned short half = buffer[buffer_offset] | buffer[buffer_offset+1] << 8;
         
         // ---- convert half and save float data in channel
         channel_data[channel_data_offset] = half2float( half );
         
         channel_data_offset++;
         buffer_offset += 2;
         tile_column_index++;
      }
      tile_row_index++;
   }
}

void copy_float_data__tile( unsigned char *buffer, float *channel_data, unsigned short image_width, unsigned short num_rows, unsigned short num_columns, unsigned short start_row_number, unsigned short start_col_number, exr_channel *channel, unsigned short channel_data_width ) {
   
   u_intfloat int_fl;
   
   unsigned short tile_row_index = 0;
   while( tile_row_index < num_rows ) {
      // ---- calculate offset for channel data,
      unsigned int channel_data_offset = image_width*(tile_row_index + start_row_number) + start_col_number;

      // ---- calculate offset for channels
      unsigned int buffer_offset = num_columns*channel_data_width*tile_row_index + num_columns*channel->offset;
      
      unsigned short tile_column_index = 0;
      while( tile_column_index < num_columns ) {
         // ---- combine data for float number
         int_fl.i = buffer[buffer_offset] | buffer[buffer_offset+1] << 8 | buffer[buffer_offset+2] << 16 | buffer[buffer_offset+3] << 24;
         
         // ---- save float data in channel
         channel_data[channel_data_offset] = int_fl.f;
         
         channel_data_offset++;
         buffer_offset += 4;
         tile_column_index++;
      }
      tile_row_index++;
   }
}

#pragma mark ---- Compression

/* compression no */
void read_data_compression_no__scanline( FILE *exr_fp, exr_chunk_data *chunk_data, exr_attributes *attributes, exr_image_data *image_data ) {

   unsigned int num_columns = (attributes->dataWindow.right - attributes->dataWindow.left) + 1;
  
   unsigned short channel_data_width = attributes->channel_list.data_width;

   unsigned char *data_buffer = malloc( num_columns*channel_data_width );

   unsigned short chunk_number = 0;
   while( chunk_number < chunk_data->num_chunks ) {
      // ---- begin chunk
      fseek( exr_fp, chunk_data->chunk_table[chunk_number], SEEK_SET );

      // ---- read row number
      unsigned int row_number = 0;
      fread( &row_number, 4, 1, exr_fp );

      // ---- read data length
      unsigned int data_length = 0; 
      fread( &data_length, 4, 1, exr_fp );

      // ---- read compressed data
      fread( data_buffer, 1, data_length, exr_fp );
 //     printf( "%d/%d row_number %d  data_length %d\n", chunk_number, chunk_data->num_chunks, row_number, data_length ); 

      // ---- copy data from buffer
      if( attributes->channel_list.channel[BLUE].data_type == EXR_HALF )
         copy_half_data( data_buffer, image_data->channel_B, 1, num_columns, row_number, &(attributes->channel_list.channel[BLUE]), channel_data_width );
      else
         copy_float_data( data_buffer, image_data->channel_B, 1, num_columns, row_number, &(attributes->channel_list.channel[BLUE]), channel_data_width );

      if( attributes->channel_list.channel[GREEN].data_type == EXR_HALF )
         copy_half_data( data_buffer, image_data->channel_G, 1, num_columns, row_number, &(attributes->channel_list.channel[GREEN]), channel_data_width );
      else
         copy_float_data( data_buffer, image_data->channel_G, 1, num_columns, row_number, &(attributes->channel_list.channel[GREEN]), channel_data_width );

      if( attributes->channel_list.channel[RED].data_type == EXR_HALF )
         copy_half_data( data_buffer, image_data->channel_R, 1, num_columns, row_number, &(attributes->channel_list.channel[RED]), channel_data_width );
      else
         copy_float_data( data_buffer, image_data->channel_R, 1, num_columns, row_number, &(attributes->channel_list.channel[RED]), channel_data_width );

      // ---- if have depth channel (only have float data)
      if( attributes->depth )
         copy_float_data( data_buffer, image_data->channel_Z, 1, num_columns, row_number, &(attributes->channel_list.channel[DEPTH]), channel_data_width );

      chunk_number++;
   }
}

/* compression RLE */
void read_data_compression_rle__scanline( FILE *exr_fp, exr_chunk_data *chunk_data, exr_attributes *attributes, exr_image_data *image_data ) {

   unsigned int num_columns = (attributes->dataWindow.right - attributes->dataWindow.left) + 1;
  
   unsigned short channel_data_width = attributes->channel_list.data_width;

   unsigned int uncompressed_data_length = num_columns*channel_data_width;

   unsigned char *compressed_buffer = malloc( uncompressed_data_length << 1 );
   unsigned char *uncompressed_buffer = malloc( uncompressed_data_length );
   unsigned char *unfiltered_buffer = malloc( uncompressed_data_length ); 

   unsigned short chunk_number = 0;
   while( chunk_number < chunk_data->num_chunks ) {
      // ---- begin chunk
      fseek( exr_fp, chunk_data->chunk_table[chunk_number], SEEK_SET );

      // ---- read row number
      unsigned int row_number = 0;
      fread( &row_number, 4, 1, exr_fp );

      // ---- read data length
      unsigned int data_length = 0; 
      fread( &data_length, 4, 1, exr_fp );

      // ---- read compressed data
      fread( compressed_buffer, 1, data_length, exr_fp );

      // ---- uncompress rle
      uncompress_rle( compressed_buffer, data_length, uncompressed_buffer, uncompressed_data_length );
      
      // ---- unfilter data
      unfilter_buffer( uncompressed_buffer, unfiltered_buffer, uncompressed_data_length );

      // ---- copy data from buffer
      if( attributes->channel_list.channel[BLUE].data_type == EXR_HALF )
         copy_half_data( unfiltered_buffer, image_data->channel_B, 1, num_columns, row_number, &(attributes->channel_list.channel[BLUE]), channel_data_width );
      else
         copy_float_data( unfiltered_buffer, image_data->channel_B, 1, num_columns, row_number, &(attributes->channel_list.channel[BLUE]), channel_data_width );

      if( attributes->channel_list.channel[GREEN].data_type == EXR_HALF )
         copy_half_data( unfiltered_buffer, image_data->channel_G, 1, num_columns, row_number, &(attributes->channel_list.channel[GREEN]), channel_data_width );
      else
         copy_float_data( unfiltered_buffer, image_data->channel_G, 1, num_columns, row_number, &(attributes->channel_list.channel[GREEN]), channel_data_width );

      if( attributes->channel_list.channel[RED].data_type == EXR_HALF )
         copy_half_data( unfiltered_buffer, image_data->channel_R, 1, num_columns, row_number, &(attributes->channel_list.channel[RED]), channel_data_width );
      else
         copy_float_data( unfiltered_buffer, image_data->channel_R, 1, num_columns, row_number, &(attributes->channel_list.channel[RED]), channel_data_width );
   
      // ---- if have depth channel (only have float data)
      if( attributes->depth )
         copy_float_data( unfiltered_buffer, image_data->channel_Z, 1, num_columns, row_number, &(attributes->channel_list.channel[DEPTH]), channel_data_width );

      chunk_number++;
   }

   // ---- free memory
   free( compressed_buffer );
   free( uncompressed_buffer );
   free( unfiltered_buffer );
}

/* compression ZIPS and ZIP */
void read_data_compression_zip__scanline( FILE *exr_fp, exr_chunk_data *chunk_data, exr_attributes *attributes, exr_image_data *image_data ) {

   unsigned int num_columns = (attributes->dataWindow.right - attributes->dataWindow.left) + 1;
   unsigned char num_rows = 1;
   unsigned char *compressed_buffer = NULL;
   unsigned char *uncompressed_buffer = NULL;
   unsigned char *unfiltered_buffer = NULL;
  
   unsigned short channel_data_width = attributes->channel_list.data_width;

   unsigned int uncompressed_data_length = num_columns*channel_data_width;

   // ---- check if use ZIP
   if( attributes->compression == EXR_COMPRESSION_ZIP ) {
       uncompressed_data_length <<= 4;  // multiply 16
       num_rows = 16;
   }
   
   compressed_buffer = malloc( uncompressed_data_length << 1 );
   uncompressed_buffer = malloc( uncompressed_data_length );
   unfiltered_buffer = malloc( uncompressed_data_length ); 

   unsigned short chunk_number = 0;
   while( chunk_number < chunk_data->num_chunks ) {
      unsigned long long filePosition = chunk_data->chunk_table[chunk_number];
      // ---- begin chunk
      fseek( exr_fp, filePosition, SEEK_SET );

      // ---- read row number
      unsigned int row_number = 0;
      fread( &row_number, 4, 1, exr_fp );

      // ---- read data length
      unsigned int data_length = 0; 
      fread( &data_length, 4, 1, exr_fp );

      // ---- check if use ZIP and number row remain
      if( attributes->compression == EXR_COMPRESSION_ZIP ) {
         // ---- calculate number row remain in image, check if have 16 rows for this chunk
         unsigned short num_rows_remain = image_data->height - row_number;
         if( num_rows_remain < 16 ) { // only for last chunk
            uncompressed_data_length = (uncompressed_data_length >> 4)*num_rows_remain;
            num_rows = num_rows_remain;
         }
      }

      // ---- read compressed data
      fread( compressed_buffer, 1, data_length, exr_fp );

      // ---- uncompress zip
      uncompress_zip( compressed_buffer, data_length, uncompressed_buffer, uncompressed_data_length );
      
      // ---- unfilter data
      unfilter_buffer( uncompressed_buffer, unfiltered_buffer, uncompressed_data_length );
      
  /*    unsigned int diaChi = 0;
      while( diaChi <  uncompressed_data_length ) {
         printf( "chunk_num %d/%d  diaChi %d %02x\n", chunk_number, chunk_data->num_chunks, diaChi, uncompressed_buffer[diaChi] );
         diaChi++;
      } */
   
      // ---- copy data from buffer
      if( attributes->channel_list.channel[BLUE].data_type == EXR_HALF )
         copy_half_data( unfiltered_buffer, image_data->channel_B, num_rows, num_columns, row_number, &(attributes->channel_list.channel[BLUE]), channel_data_width );
      else
         copy_float_data( unfiltered_buffer, image_data->channel_B, num_rows, num_columns, row_number, &(attributes->channel_list.channel[BLUE]), channel_data_width );

      if( attributes->channel_list.channel[GREEN].data_type == EXR_HALF )
         copy_half_data( unfiltered_buffer, image_data->channel_G, num_rows, num_columns, row_number, &(attributes->channel_list.channel[GREEN]), channel_data_width );
      else
         copy_float_data( unfiltered_buffer, image_data->channel_G, num_rows, num_columns, row_number, &(attributes->channel_list.channel[GREEN]), channel_data_width );

      if( attributes->channel_list.channel[RED].data_type == EXR_HALF )
         copy_half_data( unfiltered_buffer, image_data->channel_R, num_rows, num_columns, row_number, &(attributes->channel_list.channel[RED]), channel_data_width );
      else
         copy_float_data( unfiltered_buffer, image_data->channel_R, num_rows, num_columns, row_number, &(attributes->channel_list.channel[RED]), channel_data_width );
      
      // ---- if have depth channel (only have float data)
      if( attributes->depth )
         copy_float_data( unfiltered_buffer, image_data->channel_Z, num_rows, num_columns, row_number, &(attributes->channel_list.channel[DEPTH]), channel_data_width );
 /*
      unsigned int diaChi = 0;
       while( diaChi < num_rows*num_columns ) {
       printf( "%d %5.3f\n", diaChi, image_data->channel_Z[diaChi] );
       diaChi++;
       }
*/
      chunk_number++;
   }
//   exit(0);

   // ---- free memory
   free( compressed_buffer );
   free( uncompressed_buffer );
   free( unfiltered_buffer );
}

void read_data_compression_zip__tile( FILE *exr_fp, exr_chunk_data *chunk_data, exr_attributes *attributes, exr_image_data *image_data ) {

   unsigned int image_width = (attributes->dataWindow.right - attributes->dataWindow.left) + 1;
   unsigned int image_height = (attributes->dataWindow.top - attributes->dataWindow.bottom) + 1;
   unsigned int tile_width = attributes->tileDesc.width;
   unsigned int tile_height = attributes->tileDesc.height;
   unsigned char *compressed_buffer = NULL;
   unsigned char *uncompressed_buffer = NULL;
   unsigned char *unfiltered_buffer = NULL;
   
   unsigned short channel_data_width = attributes->channel_list.data_width;
   
   unsigned int uncompressed_data_length = tile_width*tile_height*channel_data_width;
   
   compressed_buffer = malloc( uncompressed_data_length << 1 );
   uncompressed_buffer = malloc( uncompressed_data_length );
   unfiltered_buffer = malloc( uncompressed_data_length );
   
   unsigned short chunk_number = 0;
   while( chunk_number < chunk_data->num_chunks ) {
      unsigned long long filePosition = chunk_data->chunk_table[chunk_number];
      printf( "chunkNumber %d  filePosition %lld (%08llx) uncompressed_data_length %d\n", chunk_number, filePosition, filePosition, uncompressed_data_length );

      if( filePosition > 0 ) {
         // ---- begin chunk
         fseek( exr_fp, filePosition, SEEK_SET );

         // ---- read tile number x and y
         unsigned int tile_number_x = 0;
         fread( &tile_number_x, 4, 1, exr_fp );
   
         unsigned int tile_number_y = 0;
         fread( &tile_number_y, 4, 1, exr_fp );
         
         // ---- resolution x and y
         unsigned int resolution_x = 0;
         fread( &resolution_x, 4, 1, exr_fp );
         
         unsigned int resolution_y = 0;
         fread( &resolution_y, 4, 1, exr_fp );

         // ---- read data length
         unsigned int data_length = 0;
         fread( &data_length, 4, 1, exr_fp );
         printf( "tile_number (%d; %d) data_length %d\n", tile_number_x, tile_number_y, data_length );
         printf( "    dự đoán cho thành phần kề tiếp %lld\n", filePosition + data_length + 20 );
         
         if( (data_length < (uncompressed_data_length << 1)) && (data_length > 0) ) {
         
         // ---- read compressed data
         fread( compressed_buffer, 1, data_length, exr_fp );

         // ---- uncompress zip
         unsigned int real_uncompressed_length = uncompress_zip( compressed_buffer, data_length, uncompressed_buffer, uncompressed_data_length );

         if( real_uncompressed_length ) {
            // ---- unfilter data
            unfilter_buffer( uncompressed_buffer, unfiltered_buffer, real_uncompressed_length );
            
            // ---- tile position
            int tile_position_x = tile_number_x*tile_width;
            int tile_position_y = tile_number_y*tile_height;
            
            // ---- real tile width and height - right and bottom edge tile maybe smaller
            unsigned int real_tile_width = tile_width;
            unsigned int real_tile_height = tile_height;
            if( tile_position_x + tile_width > image_width )
               real_tile_width = image_width - tile_position_x;
            
            if( tile_position_y + tile_height > image_height )
               real_tile_height = image_height - tile_position_y;
            
            // ---- copy data from buffer
            if( attributes->channel_list.channel[BLUE].data_type == EXR_HALF )
               copy_half_data__tile( unfiltered_buffer, image_data->channel_B, image_width, real_tile_height, real_tile_width, tile_position_y, tile_position_x, &(attributes->channel_list.channel[BLUE]), channel_data_width );
            else
               copy_float_data__tile( unfiltered_buffer, image_data->channel_B, image_width, real_tile_height, real_tile_width, tile_position_y, tile_position_x, &(attributes->channel_list.channel[BLUE]), channel_data_width );
            
            if( attributes->channel_list.channel[GREEN].data_type == EXR_HALF )
               copy_half_data__tile( unfiltered_buffer, image_data->channel_G, image_width, real_tile_height, real_tile_width, tile_position_y, tile_position_x, &(attributes->channel_list.channel[GREEN]), channel_data_width );
            else
               copy_float_data__tile( unfiltered_buffer, image_data->channel_G, image_width, real_tile_height, real_tile_width, tile_position_y, tile_position_x, &(attributes->channel_list.channel[GREEN]), channel_data_width );
            
            if( attributes->channel_list.channel[RED].data_type == EXR_HALF )
               copy_half_data__tile( unfiltered_buffer, image_data->channel_R, image_width, real_tile_height, real_tile_width, tile_position_y, tile_position_x, &(attributes->channel_list.channel[RED]), channel_data_width );
            else
               copy_float_data__tile( unfiltered_buffer, image_data->channel_R, image_width, real_tile_height, real_tile_width, tile_position_y, tile_position_x, &(attributes->channel_list.channel[RED]), channel_data_width );
            
            // ---- if have depth channel (only have float data)
            if( attributes->depth )
               copy_float_data__tile( unfiltered_buffer, image_data->channel_Z, image_width, real_tile_height, real_tile_width, tile_position_y, tile_position_x, &(attributes->channel_list.channel[DEPTH]), channel_data_width );
         }
         else
            printf( "  ERROR: chunkNumber %d  filePosition %lld (%08llx) -- %lld\n", chunk_number, filePosition, filePosition, chunk_data->chunk_table_position[chunk_number] );
         }
         else
            printf( "  ERROR: chunkNumber %d  filePosition %lld (%08llx) -- %lld\n", chunk_number, filePosition, filePosition, chunk_data->chunk_table_position[chunk_number] );
      }

      chunk_number++;
   }
   
   // ---- free memory
   free( compressed_buffer );
   free( uncompressed_buffer );
   free( unfiltered_buffer );
   
   // ---- kết thúc tệp
   fseek( exr_fp, 0, SEEK_END );
   printf( " Kết Thúc Tệp: %ld\n", ftell( exr_fp ) );
}


exr_image_data opendcp_decode_exr( const char *sfile ) {

   FILE *exr_fp;
   exr_image_data duLieuAnhEXR;
   duLieuAnhEXR.width = 0;
   duLieuAnhEXR.height = 0;
   
   printf( "docEXR: TenTep %s\n", sfile );
    
   /* open exr using filename or file descriptor */
   exr_fp = fopen(sfile, "rb");
    
   if (!exr_fp) {
      printf("%-15.15s: Error open exr file %s\n","read_exr",sfile);
      return duLieuAnhEXR;
   }
    
   // ---- check magic number/file signature
   unsigned int magicNumber = 0x0;
   magicNumber = fgetc(exr_fp) << 24;
   magicNumber |= fgetc(exr_fp) << 16;
   magicNumber |= fgetc(exr_fp) << 8;
   magicNumber |= fgetc(exr_fp);
   if( magicNumber != MAGIC_NUMBER_EXR ) {
      printf( "%-15.15s: failed to read magic number expected 0x%08x read 0x%08x\n","read_exr", MAGIC_NUMBER_EXR, magicNumber );
      printf( "%s is not a valid EXR file", sfile);
      return duLieuAnhEXR;
   }
   
   // ---- version
   unsigned char version = fgetc(exr_fp);
   if( version != 2 ) {
     printf( "Only support exr file version 2, this file version %d\n", version);
     return duLieuAnhEXR;
   }

   // ---- file type: normal, deep pixel, multipart (only support normal)
   unsigned char type = fgetc(exr_fp);
   if( (type & 0x18) != 0x00 ) {  // mask 0001 1000
      printf("Only support normal scanline or tile exr file, no deep pixel or multipart file\n");
     return duLieuAnhEXR;
   }

   // ---- skip two bytes, not used
   fgetc(exr_fp);
   fgetc(exr_fp);

   // ---- read EXR attritubes need for dcp
   exr_attributes attributes = readAttributes( exr_fp );

   // ---- show data about file
   printf( "compression %d\n", attributes.compression );

   printf( "dataWindow %d %d  %d %d\n", attributes.dataWindow.bottom, attributes.dataWindow.left, attributes.dataWindow.top, attributes.dataWindow.right );
   printf( "displayWindow %d %d  %d %d\n", attributes.displayWindow.bottom, attributes.displayWindow.left, attributes.displayWindow.top, attributes.displayWindow.right );


   printf( "  %s dataType %d  sample %d %d  offset %d\n",
          attributes.channel_list.channel[BLUE].name, attributes.channel_list.channel[BLUE].data_type,
          attributes.channel_list.channel[BLUE].sample_x, attributes.channel_list.channel[BLUE].sample_y,
          attributes.channel_list.channel[BLUE].offset );
   printf( "  %s dataType %d  sample %d %d  offset %d\n",
          attributes.channel_list.channel[GREEN].name, attributes.channel_list.channel[GREEN].data_type,
          attributes.channel_list.channel[GREEN].sample_x, attributes.channel_list.channel[GREEN].sample_y,
          attributes.channel_list.channel[GREEN].offset );
   printf( "  %s dataType %d  sample %d %d  offset %d\n",
          attributes.channel_list.channel[RED].name, attributes.channel_list.channel[RED].data_type,
          attributes.channel_list.channel[RED].sample_x, attributes.channel_list.channel[RED].sample_y,
          attributes.channel_list.channel[RED].offset );
   
   if( attributes.opacity )
      printf( "  %s dataType %d  sample %d %d  offset %d\n",
             attributes.channel_list.channel[OPACITY].name, attributes.channel_list.channel[OPACITY].data_type,
             attributes.channel_list.channel[OPACITY].sample_x, attributes.channel_list.channel[OPACITY].sample_y,
             attributes.channel_list.channel[OPACITY].offset );

   if( attributes.depth )
      printf( "  %s dataType %d  sample %d %d  offset %d\n",
             attributes.channel_list.channel[DEPTH].name, attributes.channel_list.channel[DEPTH].data_type,
             attributes.channel_list.channel[DEPTH].sample_x, attributes.channel_list.channel[DEPTH].sample_y,
             attributes.channel_list.channel[DEPTH].offset );
   
   if( attributes.tiles )
   printf( "tiles: width %d  height %d\n", attributes.tileDesc.width, attributes.tileDesc.height );

   // ---- check compression
   if( attributes.compression > EXR_COMPRESSION_ZIP ) {
      printf( "Only support NO, RLE, ZIPS, ZIP compression in exr file\n");
      return duLieuAnhEXR;
   }

   // ---- check number channels, need all B, G, R channels
   if( attributes.channel_list.num_channels < 3 ) {
      printf( "Exr file not have all B, G, R channels");
      return duLieuAnhEXR;
   }

   // ---- read offset table
   exr_chunk_data chunk_data = read_chunk_data( exr_fp, &attributes );
   
   printf( "number chunks: %d\n", chunk_data.num_chunks );

    // ---- for store image data
   duLieuAnhEXR.width = attributes.dataWindow.right - attributes.dataWindow.left + 1;
   duLieuAnhEXR.height = attributes.dataWindow.top - attributes.dataWindow.bottom + 1;

   // ---- create buffers for image data
   unsigned int beDaiDem = duLieuAnhEXR.width*duLieuAnhEXR.height * sizeof( float );

   duLieuAnhEXR.channel_B = malloc( beDaiDem );
   duLieuAnhEXR.channel_G = malloc( beDaiDem );
   duLieuAnhEXR.channel_R = malloc( beDaiDem );

   if( attributes.opacity )
      duLieuAnhEXR.channel_A = malloc( beDaiDem );
   else
      duLieuAnhEXR.channel_A = NULL;
      
   if( attributes.depth )
      duLieuAnhEXR.channel_Z = malloc( beDaiDem );
   else
      duLieuAnhEXR.channel_Z = NULL;

   // ---- read file data
   if( attributes.tiles ) {
      if( attributes.compression == EXR_COMPRESSION_NO )
         ;//read_data_compression_no__tile( exr_fp, &chunk_data, &attributes, &duLieuAnhEXR );
      else if( attributes.compression == EXR_COMPRESSION_RLE )
         ;//read_data_compression_rle__tile( exr_fp, &chunk_data, &attributes, &duLieuAnhEXR );
      else if( (attributes.compression == EXR_COMPRESSION_ZIPS) || (attributes.compression == EXR_COMPRESSION_ZIP) )
         read_data_compression_zip__tile( exr_fp , &chunk_data, &attributes, &duLieuAnhEXR );
   }
   else {
      if( attributes.compression == EXR_COMPRESSION_NO )
         read_data_compression_no__scanline( exr_fp, &chunk_data, &attributes, &duLieuAnhEXR );
      else if( attributes.compression == EXR_COMPRESSION_RLE )
         read_data_compression_rle__scanline( exr_fp, &chunk_data, &attributes, &duLieuAnhEXR );
      else if( (attributes.compression == EXR_COMPRESSION_ZIPS) || (attributes.compression == EXR_COMPRESSION_ZIP) )
         read_data_compression_zip__scanline( exr_fp , &chunk_data, &attributes, &duLieuAnhEXR );
   }

   fclose( exr_fp );

//   luuAnhZIP( "T_ketQua.exr", &image_data, EXR_HALF, 0xffff );

   // ---- free memory
   free( chunk_data.chunk_table );

   return duLieuAnhEXR;
}

/*
int main() {

   opendcp_decode_exr( "TGTB_00_0808.exr");
   
   return 1;
}*/


// =====
#pragma mark ---- Lưư Ảnh
void luuThongTinKenh_EXR( FILE *tep, unsigned char *danhSachKenh, unsigned char soLuongKenh, unsigned char kieuDuLieu );
void luuThongTinCuaSoDuLieu( FILE *tep, unsigned int beRong, unsigned int beCao );
void luuThongTinCuaSoChieu( FILE *tep, unsigned int beRong, unsigned int beCao );
void luuThoiGianKetXuat( FILE *tep, unsigned short thoiGianKetXuat );
void luuBangDuLieuAnh( FILE *tep, unsigned short soLuongThanhPhan );
void chepDuLieuKenhFloat( unsigned char *dem, const float *kenh, unsigned short beRong );
void chepDuLieuKenhHalf( unsigned char *dem, const float *kenh, unsigned short beRong );
unsigned short doiFloatSangHalf( float soFloat );
void locDuLieuTrongDem(unsigned char *dem, unsigned int beDai, unsigned char *demLoc );
unsigned int nenZIP(unsigned char *dem, int beDaiDem, unsigned char *demNen, int beDaiDemNen );

/* Lưu Ảnh ZIP */
void luuAnhZIP( char *tenTep, exr_image_data *anh, unsigned char kieuDuLieu, unsigned short thoiGianKetXuat ) {

   FILE *tep = fopen( tenTep, "wb" );
//   luuThongTinKenhEXR( unsigned short beRong, unsigned short beCao );
   // ---- mã số EXR
   fputc( 0x76, tep );
   fputc( 0x2f, tep );
   fputc( 0x31, tep );
   fputc( 0x01, tep );

   // ---- phiên bản 2 (chỉ phiên bản 2 được phát hành)
   unsigned int phienBan = 0x02;
   fputc( 0x02, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   
   unsigned short beRong = anh->width;
   unsigned short beCao = anh->height;

   // ---- thông cho các kênh
   unsigned char danhSachKenh[4] = {'B', 'G', 'R'};
   luuThongTinKenh_EXR( tep, danhSachKenh, 3, kieuDuLieu );
   
   // ---- nén
   fprintf( tep, "compression" );
   fputc( 0x00, tep );
   fprintf( tep, "compression" );
   fputc( 0x00, tep );
   fputc( 0x01, tep );   // bề dài dữ liệu
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );

   fputc( 0x03, tep );  // ZIP

   // ---- cửa sổ dữ liệu
   luuThongTinCuaSoDuLieu( tep, beRong, beCao );

   // ---- cửa sổ dữ liệu
   luuThongTinCuaSoChieu( tep, beRong, beCao );
   
   // ---- thứ tự hàng
   fprintf( tep, "lineOrder" );
   fputc( 0x00, tep );
   fprintf( tep, "lineOrder" );
   fputc( 0x00, tep );
   fputc( 0x01, tep );   // bề dài dữ liệu
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   
   fputc( 0x00, tep );  // từ nhỏ tới lớn
   
   // ---- tỉ số cạnh điểm ảnh
   fprintf( tep, "pixelAspectRatio" );
   fputc( 0x00, tep );
   fprintf( tep, "float" );
   fputc( 0x00, tep );
   fputc( 0x04, tep );   // bề dài dữ liệu
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   
   fputc( 0x00, tep );  // 1.0
   fputc( 0x00, tep );
   fputc( 0x80, tep );
   fputc( 0x3f, tep );
   
   luuThoiGianKetXuat( tep, thoiGianKetXuat );
   
   // ---- trung tâm cửa sổ màn
   fprintf( tep, "screenWindowCenter" );
   fputc( 0x00, tep );
   fprintf( tep, "v2f" );
   fputc( 0x00, tep );
   fputc( 0x08, tep );   // bề dài dữ liệu
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- tọa độ x (hoành độ)
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- tọa độ y (tung độ)
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   
   // ---- bề rộng cửa sổ màn
   fprintf( tep, "screenWindowWidth" );
   fputc( 0x00, tep );
   fprintf( tep, "float" );
   fputc( 0x00, tep );
   fputc( 0x04, tep );   // bề dài dữ liệu
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );

   fputc( 0x00, tep );   // 1.0f
   fputc( 0x00, tep );
   fputc( 0x80, tep );
   fputc( 0x3f, tep );

   // ---- kết thúc phần đầu
   fputc( 0x00, tep );
   
   // ==== bảng cho thành phần dữ liệu ảnh
   // ---- giữ địa chỉ đầu bảng thành phần
   unsigned long long diaChiDauBangThanhPhan = ftell( tep );
   unsigned short soLuongThanhPhan = beCao >> 4;
   // ---- nếu có phần dư, cần thêm một thành phần
   if( beCao & 0xf )
      soLuongThanhPhan++;

   // ---- lưu bàng rỗng
   luuBangDuLieuAnh( tep, soLuongThanhPhan );
   unsigned long long *bangThanhPhan = malloc( soLuongThanhPhan << 3 );  // sốLượngThanhPhần * 8

   // ---- bề dài dệm
   unsigned int beDaiDem = (beRong << kieuDuLieu)*3 << 4; // nhân 3 cho 3 kênh, 16 hàng
   // ---- tạo đệm để lọc dữ liệu
   unsigned char *dem = malloc( beDaiDem );
   unsigned char *demLoc = malloc( beDaiDem );
   unsigned char *demNenZIP = malloc( beDaiDem << 1);  // nhân 2 cho an toàn
   unsigned short soThanhPhan = 0;
   
   // ---- lưu dữ liệu cho thành phần ảnh
   unsigned short soHang = 0;
   while( soHang < beCao ) {
      
      // ---- tính số lượng hàng còn
      unsigned short soLuongHangCon = beCao - soHang;
      if( soLuongHangCon > 16 )
         soLuongHangCon = 16;
      else
         beDaiDem = (beDaiDem >> 4)*soLuongHangCon;   // bề dài đệm cho thành phần dư (không đủ 16 hàng)
      
      bangThanhPhan[soThanhPhan] = ftell( tep );
      soThanhPhan++;

      // ---- luư số hàng
      fputc( soHang & 0xff, tep );
      fputc( (soHang >> 8), tep );
      fputc( (soHang >> 16), tep );
      fputc( (soHang >> 24), tep );
      
      // ---- dữ liệu kênh
      unsigned int diaChiKenhBatDau = beRong*(beCao - soHang - 1);
      unsigned int diaChiDem = 0;
      
      // ---- gồm dữ liệu từ các hàng
      unsigned char soHangTrongThanhPhan = 0;
      
      while( soHangTrongThanhPhan < soLuongHangCon ) {
         
         // ---- tùy kiểu dữ liệu trong ảnh
         if( kieuDuLieu == EXR_FLOAT ) {
            // ---- chép kênh xanh
            chepDuLieuKenhFloat( &(dem[diaChiDem]), &(anh->channel_B[diaChiKenhBatDau]), beRong );
            // ---- chép kênh lục
            diaChiDem += beRong << kieuDuLieu;
            chepDuLieuKenhFloat( &(dem[diaChiDem]), &(anh->channel_G[diaChiKenhBatDau]), beRong );
            // ---- chép kênh đỏ
            diaChiDem += beRong << kieuDuLieu;
            chepDuLieuKenhFloat( &(dem[diaChiDem]), &(anh->channel_R[diaChiKenhBatDau]), beRong );
            // ---- tiếp theo
            diaChiDem += beRong << kieuDuLieu;
            diaChiKenhBatDau -= beRong;
         }
         else {  // EXR_HALF
            // ---- chép kênh xanh
            chepDuLieuKenhHalf( &(dem[diaChiDem]), &(anh->channel_B[diaChiKenhBatDau]), beRong );
            // ---- chép kênh lục
            diaChiDem += beRong << kieuDuLieu;
            chepDuLieuKenhHalf( &(dem[diaChiDem]), &(anh->channel_G[diaChiKenhBatDau]), beRong );
            // ---- chép kênh đỏ
            diaChiDem += beRong << kieuDuLieu;
            chepDuLieuKenhHalf( &(dem[diaChiDem]), &(anh->channel_R[diaChiKenhBatDau]), beRong );
            // ---- tiếp theo
            diaChiDem += beRong << kieuDuLieu;
            diaChiKenhBatDau -= beRong;
         }
         
         soHangTrongThanhPhan++;
      }

      locDuLieuTrongDem( dem, beDaiDem, demLoc);
      unsigned int beDaiDuLieuNen = nenZIP( demLoc, beDaiDem, demNenZIP, beDaiDem << 1 );
     
      fputc( beDaiDuLieuNen & 0xff, tep );
      fputc( (beDaiDuLieuNen >> 8), tep );
      fputc( (beDaiDuLieuNen >> 16), tep );
      fputc( (beDaiDuLieuNen >> 24), tep );
      
      // ---- lưu dữ liệu nén
      unsigned int diaChi = 0;
      while( diaChi < beDaiDuLieuNen ) {
         fputc( demNenZIP[diaChi], tep );
         diaChi++;
      }

      soHang+= 16;
   }
   
   // ---- lưu bảng thành phân
   fseek( tep, diaChiDauBangThanhPhan, SEEK_SET );
   soHang = 0;

   soThanhPhan = 0;
   while( soThanhPhan < soLuongThanhPhan ) {
      unsigned long long diaChiThanhPhan = bangThanhPhan[soThanhPhan];
      fputc( diaChiThanhPhan & 0xff, tep );
      fputc( (diaChiThanhPhan >> 8), tep );
      fputc( (diaChiThanhPhan >> 16), tep );
      fputc( (diaChiThanhPhan >> 24), tep );
      fputc( (diaChiThanhPhan >> 32), tep );
      fputc( (diaChiThanhPhan >> 40), tep );
      fputc( (diaChiThanhPhan >> 48), tep );
      fputc( (diaChiThanhPhan >> 56), tep );
      soThanhPhan++;
   }
 
   // ---- thả trí nhớ
   free( dem );
   free( demLoc );
   free( demNenZIP );
   // ---- đóng tệp
   fclose( tep );
}


void luuThongTinKenh_EXR( FILE *tep, unsigned char *danhSachKenh, unsigned char soLuongKenh, unsigned char kieuDuLieu ) {

   fprintf( tep, "channels" );
   fputc( 0x00, tep );
   fprintf( tep, "chlist" );
   fputc( 0x00, tep );
   unsigned char beDaiDuLieuKenh = soLuongKenh*18 + 1;
   fputc( beDaiDuLieuKenh, tep );   // bề dài cho n kênh, tên các kênh dài một chữ cái ASCII
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );

   // ---- thông tin cho các kênh
   unsigned char soKenh = 0;
   while( soKenh < soLuongKenh ) {
      fputc( danhSachKenh[soKenh], tep );
      fputc( 0x00, tep );
      
      fputc( kieuDuLieu, tep );  // kiểu dữ liệu 0x02 nghỉa là float, 0x01 là half
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      
      fputc( 0x00, tep );   // chỉ xài cho phương pháp nén B44, ở đây không xài
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      
      fputc( 0x01, tep );  // nhịp x
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      
      fputc( 0x01, tep );  // nhịp y
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      fputc( 0x00, tep );

      soKenh++;
   }
   
   // ---- kết thúc danh sách kênh
   fputc( 0x00, tep );
}

void luuThongTinCuaSoDuLieu( FILE *tep, unsigned int beRong, unsigned int beCao ) {
   beRong--;  // số cột cuối
   beCao--;   // số hàng cuối
   fprintf( tep, "dataWindow" );
   fputc( 0x00, tep );
   fprintf( tep, "box2i" );
   fputc( 0x00, tep );
   fputc( 16, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   
   // ---- góc x
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- góc y
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- cột cuối
   fputc( beRong & 0xff, tep );
   fputc( (beRong >> 8) & 0xff, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- hàng cuối
   fputc( beCao & 0xff, tep );
   fputc( (beCao >> 8), tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
}

void luuThongTinCuaSoChieu( FILE *tep, unsigned int beRong, unsigned int beCao ) {
   beRong--;  // số cột cuối
   beCao--;   // số hàng cuối
   fprintf( tep, "displayWindow" );
   fputc( 0x00, tep );
   fprintf( tep, "box2i" );
   fputc( 0x00, tep );
   fputc( 16, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   
   // ---- góc x
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- góc y
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- cột cuối
   fputc( beRong & 0xff, tep );
   fputc( (beRong >> 8) & 0xff, tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
   // ---- hàng cuối
   fputc( beCao & 0xff, tep );
   fputc( (beCao >> 8), tep );
   fputc( 0x00, tep );
   fputc( 0x00, tep );
}

void luuThoiGianKetXuat( FILE *tep, unsigned short thoiGianKetXuat ) {

   // ---- tỉ số cạnh điểm ảnh
   fprintf( tep, "RenderTime" );
   fputc( 0x00, tep );
   fprintf( tep, "string" );
   fputc( 0x00, tep );

   // ---- phút
   unsigned short phut = thoiGianKetXuat/60;
   unsigned short giay = thoiGianKetXuat - phut*60;
   if( phut < 60 ) {
      fputc( 0x08, tep );   // bề dài dữ liệu
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      fprintf( tep, "%02d", phut );   // đổi thành thập phận
   }
   else {
      // ---- giờ
     unsigned short gio = phut/60;
      phut -= gio*60;
      fputc( 0x0b, tep );   // bề dài dữ liệu
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      fputc( 0x00, tep );
      gio = phut/60;
      fprintf( tep, "%02d:%02d", gio, phut );   // đổi thành thập phận
   }

   // ---- giây
   fprintf( tep, ":%02d", giay );  // đổi thành thập phận
   fputc( '.', tep );
   fputc( '0', tep );
   fputc( '0', tep );
}

void luuBangDuLieuAnh( FILE *tep, unsigned short soLuongThanhPhan ) {
   
   // ---- chưa biết địa chỉ thành phần vì chưa nén dữ liệu, sau nén sẽ đặt gía trị trong bảng  
   unsigned long long diaChiThanhPhan = 0x0;

   unsigned short soThanhPhan = 0;
   while( soThanhPhan < soLuongThanhPhan ) {
      fputc( diaChiThanhPhan & 0xff, tep );
      fputc( (diaChiThanhPhan >> 8), tep );
      fputc( (diaChiThanhPhan >> 16), tep );
      fputc( (diaChiThanhPhan >> 24), tep );
      fputc( (diaChiThanhPhan >> 32), tep );
      fputc( (diaChiThanhPhan >> 40), tep );
      fputc( (diaChiThanhPhan >> 48), tep );
      fputc( (diaChiThanhPhan >> 56), tep );
      soThanhPhan++;
   }

}

void chepDuLieuKenhFloat( unsigned char *dem, const float *kenh, unsigned short beRong ) {

   unsigned short soCot = 0;
   unsigned int diaChiDem = 0;
   while( soCot < beRong ) {

      union {
         unsigned int i;
         float f;
      } u_if;

      u_if.f = kenh[soCot];
      dem[diaChiDem] = u_if.i & 0xff;
      dem[diaChiDem + 1] = (u_if.i >> 8) & 0xff;
      dem[diaChiDem + 2] = (u_if.i >> 16) & 0xff;
      dem[diaChiDem + 3] = (u_if.i >> 24) & 0xff;
      diaChiDem += 4;
      soCot++;
   }

}

void chepDuLieuKenhHalf( unsigned char *dem, const float *kenh, unsigned short beRong ) {
   
   unsigned short soCot = 0;
   unsigned int diaChiDem = 0;
   while( soCot < beRong ) {

      unsigned short h = doiFloatSangHalf( kenh[soCot] );
      dem[diaChiDem] = h & 0xff;
      dem[diaChiDem + 1] = (h >> 8) & 0xff;
      diaChiDem += 2;
      soCot++;
   }

}

// ---- rất đơn giản, cho tốc đ`ộ nhanh và biết nguồn dữ liệu, KHÔNG THEO TOÀN CHUẨN EXR cho đổi float
// giá trị nào âm, NaN, ∞ đặt = 0,0
unsigned short doiFloatSangHalf( float soFloat ) {
 
   union {
      float f;
      unsigned int i;
   } ui;

   ui.f = soFloat;

   unsigned short soHalf;
   if( ui.i & 0x80000000 )   // âm
      soHalf = 0x0000;
   else if( (ui.f == 0.0f) || (ui.f == -0.0f) ) { // số không
      soHalf = 0x0000;
   }
   else {
      int muFloat = ui.i & 0x7f800000;

      if( muFloat == 0x7f800000 )  // NaN
         soHalf = 0x0000;
      else {
         char muKiemTra = (muFloat >> 23) - 127;

         if( muKiemTra < -14 ) // qúa nhỏ
            soHalf = 0x0000;
         else if( muKiemTra > 15 )
            soHalf = 0x7c00;  //+∞
         else {  // bình thường
            unsigned short muHalf = (((muFloat & 0x7f800000) >> 23) - 112) << 10;
            unsigned int dinhTriFloat = ui.i & 0x007fffff;
            unsigned short dinhTriHalf = ((dinhTriFloat + 0x00000fff + ((dinhTriFloat >> 13) & 1)) >> 13);
            soHalf = muHalf + dinhTriHalf;
         }
      }
   }

   return soHalf;
}

// ---- Từ thư viện OpenEXR
void locDuLieuTrongDem(unsigned char *dem, unsigned int beDai, unsigned char *demLoc ) {

   {
      unsigned char *t1 = demLoc;
      unsigned char *t2 = demLoc + (beDai + 1) / 2;
      char *dau = (char *)dem;  // đầu đệm cần lọc
      char *ketThuc = dau + beDai;
      unsigned char xong = 0x0;
      
      while( !xong )
      {
         if (dau < ketThuc)
            *(t1++) = *(dau++);
         else
            xong = 0x0;
         
         if (dau < ketThuc)
            *(t2++) = *(dau++);
         else
            xong = 0x1;
      }
   }
   
   // trừ
   {
      unsigned char *t = (unsigned char *)demLoc + 1;
      unsigned char *ketThuc = (unsigned char *)demLoc + beDai;
      int p = t[-1];
      
      while (t < ketThuc) {
         
         int d = (int)(t[0]) - p + 128;
         p = t[0];
         t[0] = d;
         ++t;
      }
   }

}

// ---- Từ thư viện OpenEXR
unsigned int nenZIP(unsigned char *dem, int beDaiDem, unsigned char *demNen, int beDaiDemNen ) {
   
   int err;
   z_stream dongNen; // dòng nén
   
   dongNen.zalloc = Z_NULL;
   dongNen.zfree = Z_NULL;
   dongNen.opaque = Z_NULL;
   
   
   // ---- kiểm tra sai có lầm khởi đầu
   err = deflateInit(&dongNen, Z_DEFAULT_COMPRESSION);
   
   if( err != Z_OK )
      printf( "nenZip: Vấn đề khởi đầu nén %d (%x) dongNen.avail_in %d", err, err, dongNen.avail_in );
   
   // ---- cho dữ liệu cần nén
   dongNen.next_in = dem;
   dongNen.avail_in = beDaiDem;
   
   // ---- xem nếu đệm có thể chứa dữ liệu nén  
   unsigned int beDaiDuDoan = (unsigned int)deflateBound(&dongNen, beDaiDem );
   if( beDaiDuDoan > beDaiDemNen )
      printf( "nenZIP: dự đoán beDaiDuDoan %d > đệm chứa beDaiDemNen %d", beDaiDuDoan, beDaiDemNen );
   
   // ---- cho đệm cho chứa dữ liệu nén
   dongNen.next_out  = demNen;
   dongNen.avail_out = beDaiDemNen;  // bề dải đệm chứa dữ liệu nén
   err = deflate(&dongNen, Z_FINISH);
   
   if( err != Z_STREAM_END ) {
      if( err == Z_OK) {
         printf( "nenZIP: Z_OK d_stream.avail_out %d d_stream.total_out %lu",
               dongNen.avail_out, dongNen.total_out );
      }
      else
         printf( "nenZIP: sai lầm hết dữ liệu sớm hơn ý định, deflate %d (%x) d_stream.avail_out %d d_stream.total_out %lu",
               err, err, dongNen.avail_in, dongNen.total_in );
   }
   
   err = deflateEnd( &dongNen );
   if( err != Z_OK )
      printf( "nenZIP: Sai lầm deflateEnd %d (%x) dongNen.avail_out %d", err, err, dongNen.avail_out );

   return dongNen.total_out;
}


