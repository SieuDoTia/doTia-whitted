/* EXRSangPNG.c */
// 2019.05.21


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "docEXR.h"
#include "PNG.h"
#include "HangSo.h"


#define kLOAI_ANH__KHONG_BIET 0
#define kLOAI_ANH__PNG        1
#define kLOAI_ANH__EXR        2

/* xem đuôi tệp */
unsigned char xemDuoiTep( char *tenAnh );

/* kèm tên ảnh kênh */
void tenAnh_RGBO( char *tenAnhGoc, char *tenAnhPNG );
void tenAnh_doSau( char *tenAnhGoc, char *tenAnhPNG );

 
/* kèm đuôi PNG */
void kemDuoiPNG( char *ten, char *tenTep );

/* Đổi Dữ Liệu */
unsigned char *doiDuLieuFloatSangUnchar_RGB( exr_image_data *duLieuTapEXR );
unsigned char *doiDuLieuFloatSangUnchar_xam( exr_image_data *duLieuTapEXR, float doSau );

#define kDO_SAU_MAC_DINH 250.0f 


int main( int argc, char **argv ) {
   
   // ---- chiếu phiên bản
   printf( "EXRSangPNG %s\n", kXAU_PHIEN_BAN );
   
   // ---- có ảnh bộ lọc sẵn,
   if( argc > 1 ) {
         
      // ---- phân tích tên ảnh
      char tenTep[255];
    //  kemDuoiPNG( argv[1], tenTep );
      
      // ---- mỗi ảnh phải bằng nhau
      unsigned int beRongAnh = 0;
      unsigned int beCaoAnh = 0;
      unsigned char loaiPNG = kPNG_CHUA_BIET;
      unsigned char canLatMauTep;
      
      // ==== đọc EXR
      exr_image_data duLieuTapTinEXR = opendcp_decode_exr( argv[1] );
 
      if( (duLieuTapTinEXR.width > 0) && (duLieuTapTinEXR.height > 0) ) {
 
         // ---- đỏi dữ liêụ EXR sang PNG
         printf( "beRong %d  beCao %d\n", duLieuTapTinEXR.width, duLieuTapTinEXR.height );
         unsigned char *duLieuAnhPNG = doiDuLieuFloatSangUnchar_RGB( &duLieuTapTinEXR );
 
         if( duLieuAnhPNG ) {
            char tenTapTinPNG[255];
            
            tenAnh_RGBO( argv[1], tenTapTinPNG );
            
            // ==== lưu PNG RGBO
            luuAnhPNG( tenTapTinPNG, duLieuAnhPNG, duLieuTapTinEXR.width, duLieuTapTinEXR.height, kPNG_BGRO );
            
            free( duLieuAnhPNG );
         };
      
         // ---- thả trí nhớ
         free( duLieuTapTinEXR.channel_B );
         free( duLieuTapTinEXR.channel_G );
         free( duLieuTapTinEXR.channel_R );
         
         // ---- tùy có
         if( duLieuTapTinEXR.channel_A )
            free( duLieuTapTinEXR.channel_A );
         
         // ==== Nếu có kênh Z (cách xa/độ sâu)
         // ==== Nếu có kênh Z (cách xa/độ sâu)
         if( duLieuTapTinEXR.channel_Z != NULL ) {
            
            // ---- tỉ số độ sâu
            float doSau = kDO_SAU_MAC_DINH;

            if( argc > 2 ) {
               sscanf( argv[2], "%f", &doSau );

               // ---- kiểm tra gíá trị độ sâu
               if( doSau >= 512.0f )
                  doSau = 512.0f;
               else if( doSau < 1.0f )
                  doSau = 1.0f;
            }
            printf( "DoSau %5.3f\n", doSau );
            
            unsigned char *duLieuAnh_xam = doiDuLieuFloatSangUnchar_xam( &duLieuTapTinEXR, doSau );
            if( duLieuAnh_xam ) {
               
               char tenTapTinPNG_xam[255];
               tenAnh_doSau( argv[1], tenTapTinPNG_xam );

               // ==== lưu PNG độ xám
               luuAnhPNG( tenTapTinPNG_xam, duLieuAnh_xam, duLieuTapTinEXR.width, duLieuTapTinEXR.height, kPNG_XAM_DUC );
               
               // ----
               free( duLieuAnh_xam );
            }
            else {
               printf( "Vấn đề\n");
            }
            free( duLieuTapTinEXR.channel_Z );
         }
      }
 
   }
   else {
      printf( "Gõ tên ảnh PNG để ghép và phân tích\n");
   }
   
   return 1;
}

/* Xem Đuôi Ảnh */
unsigned char xemDuoiTep( char *tenAnh ) {
   
   printf( "TênTệp: %s\n", tenAnh );
   char *dauTenTep = tenAnh;
   unsigned char soLuongKyTu = 0;
   
   while( *(tenAnh++) != 0x00 )
      soLuongKyTu++;
   
   // --- ba ký tự của đuôi
   char kyTu0 = dauTenTep[soLuongKyTu-3];
   char kyTu1 = dauTenTep[soLuongKyTu-2];
   char kyTu2 = dauTenTep[soLuongKyTu-1];
   //   printf( "%c%c%c\n", kyTu0, kyTu1, kyTu2 );
   
   // ---- PNG
   if( (kyTu0 == 'p') && (kyTu1 == 'n') && (kyTu2 == 'g') )
      return kLOAI_ANH__PNG;
   else if( (kyTu0 == 'P') && (kyTu1 == 'N') && (kyTu2 == 'G') )
      return kLOAI_ANH__PNG;
   // ---- EXR
   else if( (kyTu0 == 'e') && (kyTu1 == 'x') && (kyTu2 == 'r') )
      return kLOAI_ANH__EXR;
   else if( (kyTu0 == 'E') && (kyTu1 == 'X') && (kyTu2 == 'R') )
      return kLOAI_ANH__EXR;
   
   return kLOAI_ANH__KHONG_BIET;
}

void tenAnh_RGBO( char *tenAnhGoc, char *tenAnhPNG ) {

   // ---- chép tên ảnh gốc
   while( (*tenAnhGoc != 0x00) && (*tenAnhGoc != '.') ) {
      *tenAnhPNG = *tenAnhGoc;
      tenAnhPNG++;
      tenAnhGoc++;
   }
   
   // ---- kèm đuôi
   *tenAnhPNG = '.';
   tenAnhPNG++;
   *tenAnhPNG = 'p';
   tenAnhPNG++;
   *tenAnhPNG = 'n';
   tenAnhPNG++;
   *tenAnhPNG = 'g';
   tenAnhPNG++;
   *tenAnhPNG = 0x0;
   tenAnhPNG++;
}

void tenAnh_doSau( char *tenAnhGoc, char *tenAnhPNG ) {
   
   // ---- chép tên ảnh gốc
   while( (*tenAnhGoc != 0x00) && (*tenAnhGoc != '.') ) {
      *tenAnhPNG = *tenAnhGoc;
      tenAnhPNG++;
      tenAnhGoc++;
   }
   
   // ---- kèm đuôi
   *tenAnhPNG = '_';
   tenAnhPNG++;
   *tenAnhPNG = 'd';
   tenAnhPNG++;
   *tenAnhPNG = 'e';
   tenAnhPNG++;
   *tenAnhPNG = 'p';
   tenAnhPNG++;
   *tenAnhPNG = 't';
   tenAnhPNG++;
   *tenAnhPNG = 'h';
   tenAnhPNG++;
   *tenAnhPNG = '.';
   tenAnhPNG++;
   *tenAnhPNG = 'p';
   tenAnhPNG++;
   *tenAnhPNG = 'n';
   tenAnhPNG++;
   *tenAnhPNG = 'g';
   tenAnhPNG++;
   *tenAnhPNG = 0x0;
   tenAnhPNG++;
}
/*
void kemDuoiPNG( char *ten, char *tenTep ) {
   
   // ---- chép tên ảnh gốc
   while( *ten != 0x00 ) {
      *tenTep = *ten;
      ten++;
      tenTep++;
   }
   
   // ---- kèm đuôi
   *tenTep = '.';
   tenTep++;
   *tenTep = 'p';
   tenTep++;
   *tenTep = 'n';
   tenTep++;
   *tenTep = 'g';
   tenTep++;
   *tenTep = 0x0;
   tenTep++;
} */


#pragma mark ---- Đổi kiểu dữ liệu ảnh
#define kGAMMA 2.2f

unsigned char *doiDuLieuFloatSangUnchar_RGB( exr_image_data *duLieuTapTinEXR ) {

   unsigned int beRongAnh = duLieuTapTinEXR->width;
   unsigned int beCaoAnh = duLieuTapTinEXR->height;
   unsigned int beDaiDem = beRongAnh*beCaoAnh << 2;
   
   unsigned char *demDuLieuPNG = malloc( beDaiDem );
   if( demDuLieuPNG ) {
      
      float luyThua = 1.0f/kGAMMA;
   

      unsigned int chiSoDemEXR = 0;
      short soHang = beCaoAnh - 1;    // cần lật ảnh

      while( soHang > -1 ) {
         
         unsigned int chiSoDemPNG = soHang*beRongAnh << 2;
         unsigned short soCot = 0;
         while( soCot < beRongAnh ) {
            // ----
            short diemAnhDo = 255.0f*powf( duLieuTapTinEXR->channel_R[chiSoDemEXR], luyThua );
            
            if( diemAnhDo > 255 )
               diemAnhDo = 255;
            else if( diemAnhDo < 0 )
               diemAnhDo = 0;
            // ----
            short diemAnhLuc = 255.0f*powf( duLieuTapTinEXR->channel_G[chiSoDemEXR], luyThua );
            
            if( diemAnhLuc > 255 )
               diemAnhLuc = 255;
            else if( diemAnhLuc < 0 )
               diemAnhLuc = 0;
            // ----
            short diemAnhXanh = 255.0f*powf( duLieuTapTinEXR->channel_B[chiSoDemEXR], luyThua );
            
            if( diemAnhXanh > 255 )
               diemAnhXanh = 255;
            else if( diemAnhXanh < 0 )
               diemAnhXanh = 0;
            //
            demDuLieuPNG[chiSoDemPNG] = (unsigned char)diemAnhDo;
            demDuLieuPNG[chiSoDemPNG+1] = (unsigned char)diemAnhLuc;
            demDuLieuPNG[chiSoDemPNG+2] = (unsigned char)diemAnhXanh;
            demDuLieuPNG[chiSoDemPNG+3] = 0xff;
            chiSoDemPNG += 4;
            chiSoDemEXR++;
            soCot++;
         }
         soHang--;
      }
   }
   else {
      printf( "DoiDuLieuFloatSangUnchar_RGB: Vấn đề giành trí nhớ cho đệm\n" );
      return NULL;
   }
      
   
   return demDuLieuPNG;
}


unsigned char *doiDuLieuFloatSangUnchar_xam( exr_image_data *duLieuTapTinEXR, float doSau ) {
   
   unsigned int beRongAnh = duLieuTapTinEXR->width;
   unsigned int beCaoAnh = duLieuTapTinEXR->height;
   unsigned int beDaiDem = beRongAnh*beCaoAnh << 1;
   
   unsigned char *demDuLieuPNG_doXam = malloc( beDaiDem );
   if( demDuLieuPNG_doXam ) {
      
      unsigned int chiSoDemEXR = 0;
      short soHang = beCaoAnh - 1;    // cần lật ảnh
      
      while( soHang > -1 ) {
         
         unsigned int chiSoDemPNG = soHang*beRongAnh << 1;
         unsigned short soCot = 0;

         while( soCot < beRongAnh ) {
            // ---- tiính độ xám (nghịch tiêu chuẩn OpenGL)
            unsigned char doXam = 0;
    
            float cachXa = duLieuTapTinEXR->channel_Z[chiSoDemEXR];

            if( cachXa < 0.0f )
               doXam = 255;  // hình như không bao giờ tới này
            else if( cachXa < doSau )
               doXam = doSau*(1.0f - (float)cachXa/doSau);

            demDuLieuPNG_doXam[chiSoDemPNG] = doXam;
            demDuLieuPNG_doXam[chiSoDemPNG+1] = 0xff;

            chiSoDemPNG += 2;
            chiSoDemEXR++;
            soCot++;
         }
         soHang--;
      }
   }
   else {
      printf( "DoiDuLieuFloatSangUnchar_RGB: Vấn đề giành trí nhớ cho đệm\n" );
      return NULL;
   }
   
   
   return demDuLieuPNG_doXam;
}




