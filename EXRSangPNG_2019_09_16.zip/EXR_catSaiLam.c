/* EXR_catSaiLam.c */
// 2019.06.30

// ----- 8 byte đầu thành phần
// chuỗi đặc điểm
// ----- <xâu - tên đặc điểm> 0x00 <xâu - kiểu dữ liệu cuả đặc điểm> 0x00 <bề dài dữ liệt đặc điểm (byte)>
//  ...
// ---- 0x00 kết thúc đặc điểm
// ---- bảng vị trí thàn phần ảnh - bề dài: 8 x số lượng thành phần
// ---- các thàn phần ảnh

// Khi cắt sai lầm cần:
// - tạo tập tin mới để chép dữ liệu tốt qua
// - xóa bảng vị trí thành phần tại sai làm dện kết thúc bảng
// - cắt tập tin tại thành sai lầm

#include <stdio.h>
#include <stdlib.h>

#define kXAU_PHIEN_BAN "1.0"

#define kSO_KY_HIEU_EXR 0x762f3101

#define kMAT_NA_TO_CHUC_O 0x02000000  // mặt nạ tổ chức ô

#define kDUNG 1
#define kSAI  0

void chepPhanKhongSaiLam( char *tenTepGoc, FILE *tepGoc, unsigned long long dauBangViTriThanhPhan, unsigned short soLuongThanhPhanKhongSaiLam, unsigned short tongSoThanhPhan, unsigned long long viTriThanhPhan );


int main( int argc, char **argv ) {
   
   // ---- chiếu phiên bản
   printf( "EXR_catSaiLam %s\n", kXAU_PHIEN_BAN );
   
   // ---- có ảnh bộ lọc sẵn,
   if( argc > 1 ) {
      
      FILE *tepKiemTra = fopen( argv[1], "rb" );
      
      if( tepKiemTra != NULL ) {
         unsigned int kyHieuTapTinEXR = 0;
         kyHieuTapTinEXR = fgetc(tepKiemTra) << 24 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra);
         
         // ---- nhảy qua bốn byte cuối của đầu tệp
         unsigned int toChucThanhPhan = 0;
         toChucThanhPhan = fgetc(tepKiemTra) << 24 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra);

         toChucThanhPhan &= kMAT_NA_TO_CHUC_O;


         if( kyHieuTapTinEXR == kSO_KY_HIEU_EXR ) {
            unsigned short beRongAnh = 0;
            unsigned short beCaoAnh = 0;
            
            unsigned short beRongO = 0;
            unsigned short beCaoO = 0;
            // ---- nhảy qua chuỗi đặc điểm trừ đặc điểm tiles
            unsigned char kyTuTiep = fgetc( tepKiemTra );
            while( kyTuTiep != 0x00 ) {

               if( kyTuTiep == 't' ) {
                  if( fgetc( tepKiemTra ) == 'i' )
                     if( fgetc( tepKiemTra ) == 'l' )
                        if( fgetc( tepKiemTra ) ==  'e' )
                           if( fgetc( tepKiemTra ) == 's' ) {

                              fseek( tepKiemTra, 14, SEEK_CUR );
                              beRongO = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                              beCaoO = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                              // ---- loại mức của ô
                              unsigned char loaiMuc = fgetc(tepKiemTra);
                              printf( "Kích Cỡ Ô: %d %d\n", beRongO, beCaoO );
                           }
               }
               else if( kyTuTiep == 'd' ) {
                  if( fgetc( tepKiemTra ) == 'a' )
                     if( fgetc( tepKiemTra ) == 't' )
                        if( fgetc( tepKiemTra ) ==  'a' )
                           if( fgetc( tepKiemTra ) == 'W' )
                           if( fgetc( tepKiemTra ) == 'i' )
                           if( fgetc( tepKiemTra ) == 'n' )
                           if( fgetc( tepKiemTra ) == 'd' )
                           if( fgetc( tepKiemTra ) == 'o' )
                           if( fgetc( tepKiemTra ) == 'w' ){
                              
                              fseek( tepKiemTra, 11, SEEK_CUR );
                              unsigned int trai = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                              unsigned int duoi = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                              unsigned int phai = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                              unsigned int tren = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                              beRongAnh = phai - trai + 1;
                              beCaoAnh = tren - duoi + 1;
                              printf( "Dữ liệu ảnh (khổ ảnh): %d %d\n", beRongAnh, beCaoAnh );
                           }

               }
               else {
                  // tên đặc điểm
                  while( fgetc( tepKiemTra ) != 0x00 )
                     ;
                  // kiểu dữ liệu của đặc điểm
                  while( fgetc( tepKiemTra ) != 0x00 )
                     ;
                  // đọc bề dài đặc điểm
                  printf("vịTrí sau Chuỗi %ld\n", ftell( tepKiemTra ) );
                  unsigned int beDaiDuLieuDacDiem = 0;
                  beDaiDuLieuDacDiem = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                  fseek( tepKiemTra, beDaiDuLieuDacDiem, SEEK_CUR );
                  printf( "beDaiDuLieuDacDiem %d\n", beDaiDuLieuDacDiem );
               }
               
               // ---- xem đã đến kết thúc chuỗi chưa
               kyTuTiep = fgetc( tepKiemTra );
            }
            
            unsigned long long dauBangViTriThanhPhan = ftell( tepKiemTra );
            
            // ---- vị trí thành phần đầu - cho biết chứng nào đọc hết mục trong bảng
            unsigned long long viTriThanhPhanDau = 0;
            viTriThanhPhanDau = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
            
            unsigned long long bonByteCao = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
            viTriThanhPhanDau |= bonByteCao << 32;
            
            unsigned long long bangViTriThanhPhan = dauBangViTriThanhPhan;
            unsigned long long viTriThanhPhan = viTriThanhPhanDau;
            // ---- tính tổng số thành phần (chia 8 vì mỗi mục dài 8 byte)
            unsigned int tongSoThanhPhan = (viTriThanhPhanDau - dauBangViTriThanhPhan) >> 3;
            printf( "dauBangViTriThanhPhan %lld  viTriThanhPhanDau %lld\n", dauBangViTriThanhPhan, viTriThanhPhanDau );
            printf( "tôngSốThànhPhần %d\n", tongSoThanhPhan );

            // ==== TÌM SAI LẦM ====
            unsigned char saiLam = kSAI;
            unsigned short soLuongThanhPhanKhongSaiLam = 0;

            // ---- TỔ CHỨC Ô
            if( toChucThanhPhan ) {  // tổ chức ô
               unsigned short so_doc_cuoi = beRongAnh/beRongO - 1;
               if( beRongAnh % beRongO )
                  so_doc_cuoi++;
               unsigned short so_hang_cuoi = beCaoAnh/beCaoO - 1;
               if( beCaoAnh % beCaoO )
                  so_hang_cuoi++;
               printf( "Số lượng dọc %d  hàng %d\n", so_doc_cuoi, so_hang_cuoi );
               
               short so_x_truoc = so_doc_cuoi;
               short so_y_truoc = -1;

               while( (bangViTriThanhPhan < viTriThanhPhanDau) && !saiLam ) {
                  
                  if( viTriThanhPhan > 0 ) {
                     // ---- đọc dữ liệu thành phần
                     fseek( tepKiemTra, viTriThanhPhan, SEEK_SET );
                     // -- số ô
                     unsigned int so_x = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                     unsigned int so_y = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                     
                     // -- độ phân giải
                     unsigned int do_phan_giai_x = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                     unsigned int do_phan_giai_y = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                     
                     // -- bề dữ liệu ô
                     unsigned int beDaiDuLieuO = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                     
                     // ---- phân tích thành phần
                     if( so_x > so_doc_cuoi )
                        saiLam = kDUNG;
                     else if( so_y > so_hang_cuoi )
                        saiLam = kDUNG;
                     else if( do_phan_giai_x > 128 )
                        saiLam = kDUNG;
                     else if( do_phan_giai_y > 128 )
                        saiLam = kDUNG;
                     else if( beDaiDuLieuO == 0 )
                        saiLam = kDUNG;
                     
                     // ---- thiếu ô dọc - không thể tìm thiếu dọc cuối (phía phải ảnh)
                     if( so_y == so_y_truoc ) {
                        if( so_x != so_x_truoc + 1 )
                           saiLam = kDUNG;
                     }
                     else if( so_y == so_y_truoc + 1 ) {
                        if( (so_x_truoc != so_doc_cuoi) || (so_x != 0) )
                           saiLam = kDUNG;
                     }
                     else
                        saiLam = kDUNG;                       

                     
                     if( !saiLam ) {
                        printf( " (%d; %d) - (%d; %d) bề dài %d\n", so_x, so_y,
                               do_phan_giai_x, do_phan_giai_y, beDaiDuLieuO );
                        bangViTriThanhPhan += 8;
                        fseek( tepKiemTra, bangViTriThanhPhan, SEEK_SET );
                        viTriThanhPhan = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                        
                        unsigned long long bonByteCao = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                        viTriThanhPhan |= bonByteCao << 32;
                        soLuongThanhPhanKhongSaiLam++;
                        printf( "%d bangViTriThanhPhanTiep %lld  viTriThanhPhanTiep %lld\n", soLuongThanhPhanKhongSaiLam, bangViTriThanhPhan, viTriThanhPhan );
                        
                        so_x_truoc = so_x;
                        so_y_truoc = so_y;
                     }
                     
                  }
                  else  // viTriThanhPhan == 0
                     saiLam = kDUNG;
            
               }  // while
               
               if( saiLam ) {
                  printf( "soLuongThanhPhanKhongSaiLam %d/%d\n", soLuongThanhPhanKhongSaiLam, tongSoThanhPhan );
                  
                  // ---- chép phần không sai lầm vào tệp mới
                  chepPhanKhongSaiLam( argv[1], tepKiemTra, dauBangViTriThanhPhan, soLuongThanhPhanKhongSaiLam, tongSoThanhPhan, viTriThanhPhan );
               }
               else
                  printf( "Tập tin không có sai làm, %d/%d thành phần không sai lầm\n", soLuongThanhPhanKhongSaiLam, tongSoThanhPhan );
            }
            
            // ---- TỔ CHỨC HÀNG
            else { // tổ chức hàng
               while( (bangViTriThanhPhan < viTriThanhPhanDau) && !saiLam ) {
                  
                  if( viTriThanhPhan > 0 ) {
                     // ---- đọc dữ liệu thành phần
                     fseek( tepKiemTra, viTriThanhPhan, SEEK_SET );
                     // -- số hàng
                     int so_hang = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                     
                     // -- bề dữ liệu bó
                     unsigned int beDaiDuLieuBo = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                     
                     // ---- phân tích thành phần
                     if( so_hang > 8192 )
                        saiLam = kDUNG;
                     else if( so_hang < -8192 )
                        saiLam = kDUNG;
                     else if( beDaiDuLieuBo == 0 )
                        saiLam = kDUNG;
                     
                     if( !saiLam ) {
                        printf( " số hàng %d - bềDàiDữLiệu %d\n", so_hang, beDaiDuLieuBo );
                        bangViTriThanhPhan += 8;
                        fseek( tepKiemTra, bangViTriThanhPhan, SEEK_SET );
                        viTriThanhPhan = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                        
                        unsigned long long bonByteCao = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
                        viTriThanhPhan |= bonByteCao << 32;
                        soLuongThanhPhanKhongSaiLam++;
                        printf( "%d bangViTriThanhPhanTiep %lld  viTriThanhPhanTiep %lld\n", soLuongThanhPhanKhongSaiLam, bangViTriThanhPhan, viTriThanhPhan );
                     }
                     
                  }
                  else  // viTriThanhPhan == 0
                     saiLam = kDUNG;
                  
               }  // while
               
               if( saiLam )
                  printf( "soLuongThanhPhanKhongSaiLam %d/%d\n", soLuongThanhPhanKhongSaiLam, tongSoThanhPhan );
               else
                  printf( "Tập tin không có sai làm %d/%d thành phần không sai lầm\n", soLuongThanhPhanKhongSaiLam, tongSoThanhPhan );

            }
            
            // ---- đọc vi trí của thành phần và kiểm trà nó
            printf("viTri sau Chuoi %ld\n", ftell( tepKiemTra ) );
            
         }
         else
            printf( "Tập tin không phải là định dạng EXR\n" );
         
         // ----
         fclose( tepKiemTra );
      }
      else {
         printf( "Không tìm được tập tin: %s\n", argv[1] );         
      }

   }
   else {
      printf( "Gõ tên ảnh EXR để ghép và phân tích\n");
   }
   
   return 1;
}

#pragma mark ---- Chép Thành Phần Không Sai Lầm
void tenAnhSaoChep( char *tenAnhGoc, char *tenAnhSaoChep );

// ++++++ đầu tệp
// +-----------------------+
// |    chuỗi đặc điểm     |
// +-----------------------+-+
// **  bảng vị trí thành phần **
// +--------------------------------+
// | vị trí các thành phần không hữ |
// +--------------------------------+
// | đặt = 0 cho các thành phần hữ  |
// +--------------------------------+
// ** các thành phần **
// +--------------------------+
// | chép thành phần không hư |
// +--------------------------+
// | bỏ các thành phần hư     |
// +--------------------------+

void chepPhanKhongSaiLam( char *tenTepGoc, FILE *tepGoc, unsigned long long dauBangViTriThanhPhan, unsigned short soLuongThanhPhanKhongSaiLam, unsigned short tongSoThanhPhan, unsigned long long viTriThanhPhan ) {
   
   // ---- tên tệp sao chép
   char tenTepSaoChep[255];
   tenAnhSaoChep( tenTepGoc, tenTepSaoChep );
   
   FILE *tepSaoChep = fopen( tenTepSaoChep, "wb" );
   
   if( tepSaoChep != NULL ) {
      // ---- chép đầu, chuỗi đặc điểm
      rewind( tepGoc );
      
      unsigned long long viTriChep = 0;
      while( viTriChep < dauBangViTriThanhPhan ) {
         unsigned char byte = fgetc( tepGoc );
         fputc( byte, tepSaoChep );
         viTriChep++;
      }
      
      // ---- chép bảng vị trí thành phần
      viTriChep = 0;
      unsigned long long viTriChepCuoi = soLuongThanhPhanKhongSaiLam << 3;
      while( viTriChep < viTriChepCuoi ) {
         unsigned char byte = fgetc( tepGoc );
         fputc( byte, tepSaoChep );
         viTriChep++;
      }
      
      // ---- xóa bảng vị trí thành phần sau thành phần sai lầm
      viTriChepCuoi = tongSoThanhPhan << 3;
      while( viTriChep < viTriChepCuoi ) {
         fputc( 0x00, tepSaoChep );
         viTriChep++;
      }
      
      // ---- chép các thành phần không sai lầm
      viTriChep = ftell( tepSaoChep );
      fseek( tepGoc, viTriChep, SEEK_SET );
      viTriChepCuoi = viTriThanhPhan;
      while( viTriChep < viTriChepCuoi ) {
         unsigned char byte = fgetc( tepGoc );
         fputc( byte, tepSaoChep );
         viTriChep++;
      }

      // ---- đóng tệp
      fclose( tepSaoChep );
   }
}

void tenAnhSaoChep( char *tenAnhGoc, char *tenAnhSaoChep ) {
   
   // ---- chép tên ảnh gốc
   while( (*tenAnhGoc != 0x00) && (*tenAnhGoc != '.') ) {
      *tenAnhSaoChep = *tenAnhGoc;
      tenAnhSaoChep++;
      tenAnhGoc++;
   }

   *tenAnhSaoChep = '_';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'c';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'h';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'e';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'p';
   tenAnhSaoChep++;
   
   // ---- kèm đuôi
   *tenAnhSaoChep = '.';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'e';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'x';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'r';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 0x0;
   tenAnhSaoChep++;
}