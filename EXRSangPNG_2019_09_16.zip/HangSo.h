/* HằngSố.h */

#pragma once

#define kXAU_PHIEN_BAN "1.0"
#define kNAM_THANG_NGAY "2019.05.21"

#define kSAI  0
#define kDUNG 1


