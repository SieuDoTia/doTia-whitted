/* EXR_hepHaiAnh.c */
// 2019.07.03

// QUAN TRỌNG - LƯU Ý: chương trình chỉ hoạt động đúng cho:
//  - hai ảnh cùng tổ chức (ô hay hàng)
//  - hai ảnh cùng khổ
//  - hai ảnh có số lượng thành phần bằng nhau

// Ngõ vào hai ảnh EXR: tệp0 (tệp để kèm), tệp 1 (tệp nguồn) 
// Tìm chổ để ghép ảnh nguồn

// cần hai
//  - mục trong bảng vị trí thành phần cẩn chèn
//  - địa chi trong tệp 0 (tệp kèm) để kẻm
//  - địa chi trong tệp 1 (tệp kèm) để đọc dữ liệu thành phần
//  - số lượng thành phần còn


// ----- 8 byte đầu thành phần
// chuỗi đặc điểm
// ----- <xâu - tên đặc điểm> 0x00 <xâu - kiểu dữ liệu cuả đặc điểm> 0x00 <bề dài dữ liệt đặc điểm (byte)>
//  ...
// ---- 0x00 kết thúc đặc điểm
// ---- bảng vị trí thàn phần ảnh - bề dài: 8 x số lượng thành phần
// ---- các thàn phần ảnh

// Khi cắt sai lầm cần:
// - tạo tập tin mới để chép dữ liệu tốt qua
// - xóa bảng vị trí thành phần tại sai làm dện kết thúc bảng
// - cắt tập tin tại thành sai lầm

#include <stdio.h>
#include <stdlib.h>

#define kXAU_PHIEN_BAN "1.1"

#define kSO_KY_HIEU_EXR 0x762f3101

#define kMAT_NA_TO_CHUC_O 0x02000000  // mặt nạ tổ chức ô

#define kDUNG 1
#define kSAI  0

void kemAnhSauSaiLam_o( char *tenTepGoc, FILE *tepGoc, unsigned long long dauBangViTriThanhPhan,
                     unsigned short soLuongThanhPhanKhongSaiLam, unsigned short tongSoThanhPhan, char *tenAnhNguon );


int main( int argc, char **argv ) {
   
   // ---- chiếu phiên bản
   printf( "EXR_kemAnh %s\n", kXAU_PHIEN_BAN );
   
   // ---- có ảnh bộ lọc sẵn,
   if( argc > 2 ) {
      
      FILE *tepKiemTra = fopen( argv[1], "rb+" );
      rewind( tepKiemTra );
      
      if( tepKiemTra != NULL ) {
         unsigned int kyHieuTapTinEXR = 0;
         kyHieuTapTinEXR = fgetc(tepKiemTra) << 24 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra);
         
         // ---- nhảy qua bốn byte cuối của đầu tệp
         unsigned int toChucThanhPhan = 0;
         toChucThanhPhan = fgetc(tepKiemTra) << 24 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra);

         toChucThanhPhan &= kMAT_NA_TO_CHUC_O;


         if( kyHieuTapTinEXR == kSO_KY_HIEU_EXR ) {
            // ---- nhảy qua chuỗi đặc điểm
            unsigned char kyTuTiep = fgetc( tepKiemTra );
            while( kyTuTiep != 0x00 ) {
               // tên đặc điểm
               while( fgetc( tepKiemTra ) != 0x00 )
                  ;
               // kiểu dữ liệu của đặc điểm
               while( fgetc( tepKiemTra ) != 0x00 )
                  ;
               // đọc bề dài đặc điểm
               printf("viTri sau Chuoi %ld\n", ftell( tepKiemTra ) );
               unsigned int beDaiDuLieuDacDiem = 0;
               beDaiDuLieuDacDiem = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
               fseek( tepKiemTra, beDaiDuLieuDacDiem, SEEK_CUR );
               printf( "beDaiDuLieuDacDiem %d\n", beDaiDuLieuDacDiem );
               
               // ---- xem đã đến kết thúc chuỗi chưa
               kyTuTiep = fgetc( tepKiemTra );
            }
            
            // ==== tỉm mục đầu trong bảng thành phần == 0
            //      Đây là chổ được bắt đầu kèm dữ liệu từ ảnh thứ 2
            unsigned long long dauBangViTriThanhPhan = ftell( tepKiemTra );
            printf( "dauBangViTriThanhPhan %lld\n", dauBangViTriThanhPhan );
            
            // ---- vị trí thành phần đầu - cho biết chứng nào đọc hết mục trong bảng
            unsigned long long viTriThanhPhanDau = 0;
            viTriThanhPhanDau = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
            
            unsigned long long bonByteCao = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
            viTriThanhPhanDau |= bonByteCao << 32;
            
            // ---- tính tổng số thành phần (chia 8 vì mỗi mục dài 8 byte)
            unsigned int tongSoThanhPhan = 0;
            if( viTriThanhPhanDau > dauBangViTriThanhPhan )
            tongSoThanhPhan = (viTriThanhPhanDau - dauBangViTriThanhPhan) >> 3;
            else {
               printf( "Bảng thành phần có vấn đề: viTriThanhPhanDau (%lld) < dauBangViTriThanhPhan (%lld)\n", viTriThanhPhanDau, dauBangViTriThanhPhan );
               exit(0);
            }
            
            unsigned long long bangViTriThanhPhan = dauBangViTriThanhPhan;
            unsigned long long viTriThanhPhan = viTriThanhPhanDau;
            unsigned long long viTriThanhPhanCuoi;
            unsigned short soThanhPhan = 0; // đã đọc vị trí thành đầu ở trên
            while( viTriThanhPhan != 0 ) {
               viTriThanhPhanCuoi = viTriThanhPhan;
               viTriThanhPhan = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
               
               bonByteCao = fgetc(tepKiemTra) | fgetc(tepKiemTra) << 8 | fgetc(tepKiemTra) << 16 | fgetc(tepKiemTra) << 24;
               viTriThanhPhanDau |= bonByteCao << 32;
               soThanhPhan++;
            }

            if( soThanhPhan == tongSoThanhPhan ) {
               printf("Tệp đầy thành phần rồi, không còn chổ để kèm ảnh thứ hai");
               exit(0);
            }
            printf( "soThanhPhan %d/%d  viTriThanhPhanCuoi %lld\n", soThanhPhan, tongSoThanhPhan, viTriThanhPhanCuoi );
            kemAnhSauSaiLam_o( argv[1], tepKiemTra, dauBangViTriThanhPhan,
                              soThanhPhan, tongSoThanhPhan, argv[2] );

            
         }
         else
            printf( "Tập tin %s không phải là định dạng EXR\n", argv[1] );
         
         // ----
         fclose( tepKiemTra );
      }
      else {
         printf( "Không tìm được tập tin: %s\n", argv[1] );         
      }

   }
   else {
      printf( "Gõ tên hai ảnh EXR để ghé, ảnh kèm trước, ảnh nguồn (đê chép) sau)\n");
      printf( " LƯU Ý: Hai ảnh phải có khổ, tổ chức, và số lượng thành phần bằng nhau\n");
   }
   
   return 1;
}

#pragma mark ---- Chép Thành Phần Không Sai Lầm


// ++++++ đầu tệp
// +-----------------------+
// |    chuỗi đặc điểm     |
// +-----------------------+-+
// **  bảng vị trí thành phần **
// +--------------------------------+
// | vị trí các thành phần không hữ |
// +--------------------------------+
// | đặt = 0 cho các thành phần hữ  |
// +--------------------------------+
// ** các thành phần **
// +--------------------------+
// | chép thành phần không hư |
// +--------------------------+
// | bỏ các thành phần hư     |
// +--------------------------+

void kemAnhSauSaiLam_o( char *tenTepKem, FILE *tepKem, unsigned long long dauBangViTriThanhPhan,
                     unsigned short soLuongThanhPhanKhongSaiLam, unsigned short tongSoThanhPhan, char *tenAnhNguon ) {
   
   // ---- mớ tệp nguồn để chép dữ liệu cho kèm vào tệp thứ nhất
   FILE *tepNguon = fopen( tenAnhNguon, "rb" );

   if( tepNguon != NULL ) {
      
      unsigned long long bangViTriThanhPhan = dauBangViTriThanhPhan + (soLuongThanhPhanKhongSaiLam << 3);
      
      // ---- đến cùng chổ trong bảng vị trí thành phần và lấy vị trí của thành phần cần chép
      fseek( tepNguon, bangViTriThanhPhan, SEEK_SET );
      long long viTriChepThanhPhan = fgetc(tepNguon) | fgetc(tepNguon) << 8 | fgetc(tepNguon) << 16 | fgetc(tepNguon) << 24;
      
      long long bonByteCao = fgetc(tepNguon) | fgetc(tepNguon) << 8 | fgetc(tepNguon) << 16 | fgetc(tepNguon) << 24;
      viTriChepThanhPhan |= bonByteCao << 32;
      
      printf( "viTriChepThanhPhan %lld\n", viTriChepThanhPhan );
      
      // ---- đến thành phần cần chép
      fseek( tepNguon, viTriChepThanhPhan, SEEK_SET );
      
      // ---- đến cùng của tệp kèm - chuẩn bị kèm thành phần vào tệp kèm
      fseek( tepKem, 0, SEEK_END );
      long long viTriKemThanhPhan = ftell( tepKem );
      
      long long chenhLechBangThanhPhan = viTriKemThanhPhan - viTriChepThanhPhan;
      printf( "  viTriKemThanhPhan %lld  chenhLech %lld\n", viTriKemThanhPhan, chenhLechBangThanhPhan );
      
      // ==== chép đến cuối tệp nguồn
      while( !feof( tepNguon ) ) {
         char c = fgetc( tepNguon );
         //  printf( " %c", c );
         fputc( c, tepKem );
      }
      printf( "ViTri kem thanh phan vào anh kem: %ld\n", ftell(tepKem) );
      
      // ==== nâng cấp bảnh thành phần
      fseek( tepKem, bangViTriThanhPhan, SEEK_SET );
      fseek( tepNguon, bangViTriThanhPhan, SEEK_SET );
      
      unsigned short soThanhPhan = soLuongThanhPhanKhongSaiLam;
      while( soThanhPhan < tongSoThanhPhan ) {
         // ---- đọc vị trí thành phần nguồn trong bàng thành phần
         long long viTriThanhPhanNguon = fgetc(tepNguon) | fgetc(tepNguon) << 8 | fgetc(tepNguon) << 16 | fgetc(tepNguon) << 24;
         
         bonByteCao = fgetc(tepNguon) | fgetc(tepNguon) << 8 | fgetc(tepNguon) << 16 | fgetc(tepNguon) << 24;
         viTriThanhPhanNguon |= bonByteCao << 32;
         
         // ---- cộng chênh lệch
         viTriThanhPhanNguon += chenhLechBangThanhPhan;
         
         // ---- lưu giá trị mới
         bonByteCao = viTriThanhPhanNguon >> 32;
         
         fputc( viTriThanhPhanNguon & 0xff, tepKem );
         fputc( (viTriThanhPhanNguon >> 8) & 0xff, tepKem );
         fputc( (viTriThanhPhanNguon >> 16) & 0xff, tepKem );
         fputc( viTriThanhPhanNguon >> 24, tepKem );
         
         fputc( bonByteCao & 0xff, tepKem );
         fputc( (bonByteCao >> 8) & 0xff, tepKem );
         fputc( (bonByteCao >> 16) & 0xff, tepKem );
         fputc( bonByteCao >> 24, tepKem);
         
         soThanhPhan++;
      }

      // ---- đóng tệp
      fclose( tepNguon );
   }
}
/*
void tenAnhSaoChep( char *tenAnhGoc, char *tenAnhSaoChep ) {
   
   // ---- chép tên ảnh gốc
   while( (*tenAnhGoc != 0x00) && (*tenAnhGoc != '.') ) {
      *tenAnhSaoChep = *tenAnhGoc;
      tenAnhSaoChep++;
      tenAnhGoc++;
   }

   *tenAnhSaoChep = '_';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'c';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'h';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'e';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'p';
   tenAnhSaoChep++;
   
   // ---- kèm đuôi
   *tenAnhSaoChep = '.';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'e';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'x';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 'r';
   tenAnhSaoChep++;
   *tenAnhSaoChep = 0x0;
   tenAnhSaoChep++;
}*/